package lk.ideahub.symphony.controller.catalogue.geofence;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by samith on 8/14/15.
 */
public class CatalogueGeofenceNotificationResponse extends Response {

    // geofence notification list
    private Integer geofenceNotificationCount;
    private boolean hasMsisdn;
    private List geofenceNotifications;

    //geofence beacon notification list
    private Integer geofenceBeaconNotificationCount;
    private List geofenceBeaconNotifications;

    // status
    private String status;
    private String message;

    public Integer getGeofenceNotificationCount() {
        return geofenceNotificationCount;
    }

    public void setGeofenceNotificationCount(Integer geofenceNotificationCount) {
        this.geofenceNotificationCount = geofenceNotificationCount;
    }

    public boolean isHasMsisdn() {
        return hasMsisdn;
    }

    public void setHasMsisdn(boolean hasMsisdn) {
        this.hasMsisdn = hasMsisdn;
    }

    public List getGeofenceNotifications() {
        return geofenceNotifications;
    }

    public void setGeofenceNotifications(List geofenceNotifications) {
        this.geofenceNotifications = geofenceNotifications;
    }

    public Integer getGeofenceBeaconNotificationCount() {
        return geofenceBeaconNotificationCount;
    }

    public void setGeofenceBeaconNotificationCount(Integer geofenceBeaconNotificationCount) {
        this.geofenceBeaconNotificationCount = geofenceBeaconNotificationCount;
    }

    public List getGeofenceBeaconNotifications() {
        return geofenceBeaconNotifications;
    }

    public void setGeofenceBeaconNotifications(List geofenceBeaconNotifications) {
        this.geofenceBeaconNotifications = geofenceBeaconNotifications;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CatalogueGeofenceNotificationResponse{");
        sb.append("geofenceNotificationCount=").append(geofenceNotificationCount);
        sb.append(", hasMsisdn=").append(hasMsisdn);
        sb.append(", geofenceNotifications=").append(geofenceNotifications);
        sb.append(", geofenceBeaconNotificationCount=").append(geofenceBeaconNotificationCount);
        sb.append(", geofenceBeaconNotifications=").append(geofenceBeaconNotifications);
        sb.append(", status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
