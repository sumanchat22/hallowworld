package lk.ideahub.symphony.controller.types;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.types.entity.CountryCode;
import lk.ideahub.symphony.modules.types.service.CountryCodeService;

/**
 * Created by samith on 10/29/15.
 */
@Controller
@RequestMapping(value = "country/code", consumes = "application/json", produces = "application/json")
public class CountryCodeController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(CountryCodeController.class);

    @Autowired
    CountryCodeService countryCodeService;

    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public Response getCountryCode() {

        CountryCodeResponse response = new CountryCodeResponse();

        ServiceContext serviceContext = getServiceContext(false);

        CountryCode countryCode = new CountryCode();

        try {

            List list = countryCodeService.find(countryCode, serviceContext);

            response.setCountryList(list);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get country list - failure ");
        } else {
            log.debug("Service get country list ");
        }


        return response;

    }

}
