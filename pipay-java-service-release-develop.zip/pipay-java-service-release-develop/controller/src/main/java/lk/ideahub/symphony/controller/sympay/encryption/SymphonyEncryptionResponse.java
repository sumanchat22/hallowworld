package lk.ideahub.symphony.controller.sympay.encryption;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by samith on 1/7/16.
 */
public class SymphonyEncryptionResponse extends Response {

    private List custodiansStatuses;

    private boolean isMainMasterKeyLive;
    private boolean isTempMasterKeyLive;

    // status
    private String status;
    private String message;

    public List getCustodiansStatuses() {
        return custodiansStatuses;
    }

    public void setCustodiansStatuses(List custodiansStatuses) {
        this.custodiansStatuses = custodiansStatuses;
    }

    public boolean isMainMasterKeyLive() {
        return isMainMasterKeyLive;
    }

    public void setIsMainMasterKeyLive(boolean isMainMasterKeyLive) {
        this.isMainMasterKeyLive = isMainMasterKeyLive;
    }

    public boolean isTempMasterKeyLive() {
        return isTempMasterKeyLive;
    }

    public void setIsTempMasterKeyLive(boolean isTempMasterKeyLive) {
        this.isTempMasterKeyLive = isTempMasterKeyLive;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyEncryptionResponse{");
        sb.append("custodiansStatuses=").append(custodiansStatuses);
        sb.append(", isMainMasterKeyLive=").append(isMainMasterKeyLive);
        sb.append(", isTempMasterKeyLive=").append(isTempMasterKeyLive);
        sb.append(", status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
