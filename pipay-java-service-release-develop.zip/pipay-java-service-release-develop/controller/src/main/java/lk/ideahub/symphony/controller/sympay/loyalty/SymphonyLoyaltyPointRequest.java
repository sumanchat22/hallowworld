package lk.ideahub.symphony.controller.sympay.loyalty;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by mahesha on 2/26/19.
 */
@Getter
@Setter
@ToString
public class SymphonyLoyaltyPointRequest extends Request {

    //view point balance
    private Long customerId;
    private String searchPoint;

    //get payable points
    private Long merchantId;
    private Long outletId;

    private Boolean isExpirationProcessDisabled;

    //transfer points
    private Long receiverId;
    private Long transferPointAmount;
    private Integer page;
    private Integer pageSize;

    //bulk rewards transfer
    private Long bulkRewardsTransferId;
    private String encryptedText;
    private Long campaignId;

}
