package lk.ideahub.symphony.controller.sympay.receiver;

import java.math.BigDecimal;
import java.util.Arrays;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by mahesha on 12/3/18.
 */
@Getter
@Setter
public class SymphonyReceiverRequest extends Request {

    //list business types
    private Long customerId;

    //add customer merchant profile
    private String profileName;
    private String address;
    private Long merchantBusinessTypeId;
    private byte[] mainImageByte;
    private String mainImageType;
    private byte[] thumbnailImageByte;
    private String thumbnailImageType;

    // get business profile details
    private Long businessProfileId;

    // business profile enable/disable
    private Boolean enable;
    
    //encryption
    private String currencyCode;
    private BigDecimal amount;
    private Long receiverId;
    private String receiverName;
    private Long receiverMerchantProfileId;

    @Override
    public String toString() {
        return "SymphonyReceiverRequest{" +
                "customerId=" + customerId +
                ", profileName='" + profileName + '\'' +
                ", address='" + address + '\'' +
                ", merchantBusinessTypeId=" + merchantBusinessTypeId +
               // ", mainImageByte=" + Arrays.toString(mainImageByte) +
                ", mainImageType='" + mainImageType + '\'' +
               // ", thumbnailImageByte=" + Arrays.toString(thumbnailImageByte) +
                ", thumbnailImageType='" + thumbnailImageType + '\'' +
                ", businessProfileId=" + businessProfileId +
                ", enable=" + enable +
                ", currencyCode='" + currencyCode + '\'' +
                ", amount=" + amount +
                ", receiverId=" + receiverId +
                ", receiverName='" + receiverName + '\'' +
                ", receiverMerchantProfileId=" + receiverMerchantProfileId +
                '}';
    }
}
