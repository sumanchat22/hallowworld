package lk.ideahub.symphony.controller.sympay.hashtag;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by mahesha on 12/7/18.
 */
@Getter
@Setter
@ToString
public class SymphonyHashTagRequest extends Request {

    private Long customerId;
}
