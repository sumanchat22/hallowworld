package lk.ideahub.symphony.controller.sympay.casa;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.cargillsCASA.service.CargillsCASAService;
import lk.ideahub.symphony.product.sympay.casa.entity.SymphonyCASA;
import lk.ideahub.symphony.product.sympay.casa.service.SymphonyCASAService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by kalpana on 3/24/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/casa", consumes = "application/json", produces = "application/json")
public class SymphonyCASAController extends GenericController
{
    private static final Logger log = LoggerFactory.getLogger(SymphonyCASAController.class);

    @Autowired
    SymphonyCASAService symphonyCASAService;


    @Autowired
    CargillsCASAService cargillsCASAService;

    @RequestMapping(value = "register/account", method = RequestMethod.POST)
    @ResponseBody
    public Response initializeRegistration(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();

        try {

            SymphonyCASA result = cargillsCASAService.registerAccount(symphonyCASA, serviceContext);

            response.setAccountId(result.getAccountId());
            response.setResponseCode(result.getResponseCode());
            response.setResponseCodeDescription(result.getResponseCodeDescription());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setPaymentOption(result.getPaymentOption());
            response.setCargillsCustomerCasaAccount(result.getCargillsCustomerCasaAccount());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service account registration - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service account registration [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //------------------- Send Consent ---------------------

//    @RequestMapping(value = "send/consent", method = RequestMethod.POST)
//    @ResponseBody
//    public Response sendSignedConsent(final @RequestBody SymphonyCASARequest _request,HttpServletRequest servletRequest) {
//
//        setClientIP(_request, servletRequest);
//        ServiceContext serviceContext = getServiceContext(_request, false);
//
//        SymphonyCASA piPayCASA = new SymphonyCASA();
//        BeanUtils.copyProperties(_request, piPayCASA);
//
//        SymphonyCASAResponse response = new SymphonyCASAResponse();
//
//        try {
//            SymphonyCASA result = symphonyCASAService.sendSignedConsent(piPayCASA, serviceContext);
//
//            response.setBank(result.getBank());
//            response.setReferenceId(result.getReferenceId());
//            response.setResponseCode(result.getResponseCode());
//            response.setResponseCodeDescription(result.getResponseCodeDescription());
//            response.setStatus(result.getStatus());
//            response.setMessage(result.getMessage());
//
//        } catch (InvalidRequestException exception) {
//            response.setStatus(RequestStatus.FAILURE.getStatus());
//            response.setMessage(exception.getMessage());
//
//        }
//
//        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
//            log.warn("Service account registration - failure [request: {}; response: {}]", _request, response);
//        } else {
//            log.debug("Service account registration [request: {}; response: {}]", _request, response);
//        }
//        return response;
//    }

    //------------------- List Banks -----------------------

    @RequestMapping(value = "list/banks", method = RequestMethod.POST)
    @ResponseBody
    public Response listBanks(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();

        try {
            SymphonyCASA result = cargillsCASAService.listBanks(symphonyCASA, serviceContext);

            response.setBankList(result.getBankList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service list banks - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service list banks [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //------------------- List Branches -----------------------

    @RequestMapping(value = "list/bank/branches", method = RequestMethod.POST)
    @ResponseBody
    public Response listBranches(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();

        try {
            SymphonyCASA result = symphonyCASAService.listBranches(symphonyCASA, serviceContext);

            response.setBranchList(result.getBranchList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service list branches - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service list branches [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //------------------- RandomAmt -----------------------

    @RequestMapping(value = "validate/account", method = RequestMethod.POST)
    @ResponseBody
    public Response validateAccount(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();

        try {
            SymphonyCASA result = cargillsCASAService.validateAmount(symphonyCASA, serviceContext);

            response.setResponseCode(result.getResponseCode());
            response.setResponseCodeDescription(result.getResponseCodeDescription());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service account validation - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service account validation [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //------------------- Get Consent -----------------------

    @RequestMapping(value = "get/consent", method = RequestMethod.POST)
    @ResponseBody
    public Response getConsent(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();

        try {
            //SymphonyCASA result = symphonyCASAService.getConsent(symphonyCASA, serviceContext);
            SymphonyCASA result =cargillsCASAService.getConsent(symphonyCASA,serviceContext);

            response.setConsent(result.getConsent());
            response.setShowConsent(result.getShowConsent());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service account validation - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service account validation [request: {}; response: {}]", _request, response);
        }
        return response;
    }



    //--------------------------create device signature-----  ------------------------------------------------------

    @RequestMapping(value = "create/devicesignature",method = RequestMethod.POST)
    @ResponseBody
    public Response deviceSignature(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();
        try {

            SymphonyCASA signature=cargillsCASAService.createDeviceSignature(symphonyCASA,serviceContext);
            response.setResponseCode(signature.getResponseCode());
            response.setMessage(signature.getMessage());
            response.setStatus(signature.getStatus());

        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        return response;
    }


    //--------------------------get challenge-----  ------------------------------------------------------

    @RequestMapping(value = "get/challenge",method = RequestMethod.POST)
    @ResponseBody
    public Response getChallenge(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {
        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();
        try {

            SymphonyCASA challenge=cargillsCASAService.getChallenge(symphonyCASA,serviceContext);
            response.setResponseCode(challenge.getResponseCode());
            response.setMessage(challenge.getMessage());
            response.setStatus(challenge.getStatus());
            response.setChallenge(challenge.getChallenge());
            response.setComment(challenge.getComment());

        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        return response;
    }

    @RequestMapping(value = "create/account/signature",method = RequestMethod.POST)
    @ResponseBody
    public Response createAccountSignature(final @RequestBody SymphonyCASARequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyCASA symphonyCASA = new SymphonyCASA();
        BeanUtils.copyProperties(_request, symphonyCASA);

        SymphonyCASAResponse response = new SymphonyCASAResponse();
        try {

            SymphonyCASA deleteResponse = cargillsCASAService.createAccountSignature(symphonyCASA,serviceContext);
            response.setResponseCode(deleteResponse.getResponseCode());
            response.setMessage(deleteResponse.getMessage());
            response.setStatus(deleteResponse.getStatus());

        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        return response;
    }

    private void setClientIP(final SymphonyCASARequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }


}
