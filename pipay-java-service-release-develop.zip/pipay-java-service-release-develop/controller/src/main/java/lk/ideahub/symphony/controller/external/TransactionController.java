package lk.ideahub.symphony.controller.external;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.external.CustomerExternalDto;
import lk.ideahub.symphony.modules.external.ExternalServiceResponseCodes;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.payment.entity.TransactionExternalDto;
import lk.ideahub.symphony.product.sympay.payment.service.PiPayPaymentService;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/service/external/transaction")
public class TransactionController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(TransactionController.class);
	
	@Autowired
	PiPayPaymentService piPayPaymentService;
	
	@RequestMapping(value = "add", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
	public Response addTransaction(final @RequestBody TransactionRequest request, HttpServletRequest servletRequest) {
		log.info(LogSupport.EXT_TRX_CONTROLLER + "Transaction post service started..");  
		log.info(LogSupport.EXT_TRX_CONTROLLER + "request " + request);
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        TransactionExternalDto transactionExternalDto = new TransactionExternalDto();
        BeanUtils.copyProperties(request, transactionExternalDto);

        CommonExternalResponse response = new CommonExternalResponse();

        try {
        	TransactionExternalDto result = piPayPaymentService.payUpdateByExternalParty(transactionExternalDto, serviceContext);

            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            
            result.setErrorCode(null);
            result.setMessage(null);
            result.setClientIp(null);

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.EXT_TRX_CONTROLLER + "addTransaction() error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setStatus(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("addTransaction() - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("addTransaction() getCustomer [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "verify", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
	public Response verifyTransaction(final @RequestBody TransactionRequest request, HttpServletRequest servletRequest) {
		log.info(LogSupport.EXT_TRX_CONTROLLER + "Verify Transaction service started..");   
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        TransactionExternalDto transactionExternalDto = new TransactionExternalDto();
        BeanUtils.copyProperties(request, transactionExternalDto);
        
        TransactionVerificationResponse response = new TransactionVerificationResponse();
        try {
        	TransactionExternalDto result = piPayPaymentService.verifyTransaction(transactionExternalDto, serviceContext);

            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setTxnInfo(result.getTransactionInfoDto());

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	exception.printStackTrace();
        	log.error(LogSupport.EXT_TRX_CONTROLLER + "verifyTransaction() error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setStatus(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("verifyTransaction() - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("verifyTransaction() [request: {}; response: {}]", request, response);
        }
        return response;
    }

	private void setClientIP(final TransactionRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
