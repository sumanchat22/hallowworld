package lk.ideahub.symphony.controller.sympay.featureSearch;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.featureSearch.entity.FeatureSearchDto;
import lk.ideahub.symphony.product.sympay.featureSearch.service.FeatureSearchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/features", consumes = "application/json", produces = "application/json")
public class FeatureSearchController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(FeatureSearchController.class);

    @Autowired
    FeatureSearchService featureSearchService;

    @RequestMapping(value = "/get/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getFeaturesList(final @RequestBody FeatureSearchRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        FeatureSearchDto featureSearchDto = new FeatureSearchDto();
        BeanUtils.copyProperties(request, featureSearchDto);

        FeatureSearchResponse response = new FeatureSearchResponse();

        try {
            featureSearchDto = featureSearchService.getFeaturesList(featureSearchDto, serviceContext);
            response.setActionTypesSubCategoryList(featureSearchDto.getActionTypesSubCategoryList());
            response.setMessage(featureSearchDto.getMessage());
            response.setStatus(featureSearchDto.getStatus());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service searchFeatures - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service searchFeatures [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final FeatureSearchRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
