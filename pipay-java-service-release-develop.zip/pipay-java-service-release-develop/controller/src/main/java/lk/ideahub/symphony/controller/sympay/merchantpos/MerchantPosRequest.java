package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantPosRequest extends Request {

    private Long merchantId;
    private Long userId;
    private String language;
    private String hardwareId;
    private String deviceName;
    private String devicePin;
    private String channel;
    private String cashierName;
    private Long outletId;
    private Long counterId;
    private String qrCodeDate;
    private String registrationToken;
    private String deviceId;
    private String txnDate;

}
