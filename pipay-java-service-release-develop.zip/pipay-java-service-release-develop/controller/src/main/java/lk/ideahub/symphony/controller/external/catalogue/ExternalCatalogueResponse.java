package lk.ideahub.symphony.controller.external.catalogue;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.external.catalogue.entity.ExternalCatalogueInfo;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class ExternalCatalogueResponse extends Response{

	private String status;
    private String message;
    private List<ExternalCatalogueInfo> externalCatalogueList;
    private String token;
}
