package lk.ideahub.symphony.controller.common;

import java.util.Locale;

import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName(value = "request")
public class Request {

    private Integer pageStart;
    private Integer pageEnd;
    Locale locale;
    
    private String clientIp;

    public Integer getPageStart() {
        return pageStart;
    }

    public void setPageStart(Integer pageStart) {
        this.pageStart = pageStart;
    }

    public Integer getPageEnd() {
        return pageEnd;
    }

    public void setPageEnd(Integer pageEnd) {
        this.pageEnd = pageEnd;
    }

    public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}
	
	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	@Override
    public String toString() {
        return new StringBuilder("Request {")
                .append("pageStart=").append(pageStart).append(", ")
                .append("pageEnd=").append(pageEnd)
                .append('}').toString();
    }
}
