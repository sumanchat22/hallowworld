package lk.ideahub.symphony.controller.sympay.receiver;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Request;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.ReceiverKhqrCodeDto;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.ReceiverQrCodeDto;
import lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentService;
import lk.ideahub.symphony.product.sympay.receiver.entity.KhqrReceiver;
import lk.ideahub.symphony.product.sympay.receiver.entity.SymphonyReceiver;
import lk.ideahub.symphony.product.sympay.receiver.service.SymphonyReceiverService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 12/3/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/receiver", consumes = "application/json", produces = "application/json")
public class SymphonyReceiverController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyReceiverController.class);

    @Autowired
    private SymphonyReceiverService symphonyReceiverService;

    @Autowired
    SymphonyQrCodePaymentService symphonyQrCodePaymentService;

    @RequestMapping(value = "list/business/types", method = RequestMethod.POST)
    @ResponseBody
    public Response listBusinessType(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
            SymphonyReceiver result = symphonyReceiverService.listBusinessType(symphonyReceiver, serviceContext);

            response.setMerchantBusinessTypeList(result.getMerchantBusinessTypeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service listBusinessType - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service listBusinessType [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "add/merchant/profile", method = RequestMethod.POST)
    @ResponseBody
    public Response addMerchantProfile(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
            SymphonyReceiver result = symphonyReceiverService.addMerchantProfile(symphonyReceiver, serviceContext);

            response.setCustomerMerchantProfile(result.getCustomerMerchantProfile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addMerchantProfile - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service addMerchantProfile [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "business/profile", method = RequestMethod.POST)
    @ResponseBody
    public Response getDetails(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
            SymphonyReceiver result = symphonyReceiverService.getDetails(symphonyReceiver, serviceContext);

            response.setMainImageFolderPath(result.getMainImageFolderPath());
            response.setThumbnailImageFolderPath(result.getThumbnailImageFolderPath());
            response.setCustomerMerchantProfile(result.getCustomerMerchantProfile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getBusinessProfile - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getBusinessProfile [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "profile/setting", method = RequestMethod.POST)
    @ResponseBody
    public Response profileSetting(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
            SymphonyReceiver result = symphonyReceiverService.profileSetting(symphonyReceiver, serviceContext);

            response.setCustomerMerchantProfile(result.getCustomerMerchantProfile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service profileSetting - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service profileSetting [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "update/merchant/profile", method = RequestMethod.POST)
    @ResponseBody
    public Response updateProfile(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
            SymphonyReceiver result = symphonyReceiverService.updateProfile(symphonyReceiver, serviceContext);

            response.setCustomerMerchantProfile(result.getCustomerMerchantProfile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateProfile - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service updateProfile [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "qrpay/encryption", method = RequestMethod.POST)
    @ResponseBody
    public Response qrpayEncryption(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
        	ReceiverQrCodeDto receiverQrCodeDto = symphonyQrCodePaymentService.getReceiverEncryptedText(symphonyReceiver, serviceContext);
            response.setStatus(receiverQrCodeDto.getStatus());
            response.setMessage(receiverQrCodeDto.getMessage());
            response.setQrEncryptedText(receiverQrCodeDto.getQrEncryptedText());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Receiver qrEncrypt - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Receiver qrEncrypt [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "khqrpay/encryption", method = RequestMethod.POST)
    @ResponseBody
    public Response khqrpayEncryption(final @RequestBody KhqrReceiverRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        KhqrReceiver khqrReceiver = new KhqrReceiver();
        BeanUtils.copyProperties(request, khqrReceiver);

        KhqrReceiverResponse response = new KhqrReceiverResponse();
        try {
            ReceiverKhqrCodeDto receiverKhqrCodeDto = symphonyQrCodePaymentService.getReceiverKhqrEncryptedText(khqrReceiver, serviceContext);
            response.setStatus(receiverKhqrCodeDto.getStatus());
            response.setMessage(receiverKhqrCodeDto.getMessage());

            if(receiverKhqrCodeDto.getCustomerMerchantProfile() == null){
                response.setCustomer(receiverKhqrCodeDto.getCustomer());
            } else {
                response.setCustomerMerchantProfile(receiverKhqrCodeDto.getCustomerMerchantProfile());
            }

            response.setMerchant(receiverKhqrCodeDto.getMerchant());
            response.setCurrencyCode(receiverKhqrCodeDto.getCurrencyCode());
            response.setQrCodeType(receiverKhqrCodeDto.getQrcodeType());
            response.setAmount(receiverKhqrCodeDto.getAmount());
            response.setTransactionId(receiverKhqrCodeDto.getTransactionId());
            response.setLifetime(receiverKhqrCodeDto.getLifetime());
            response.setQrEncryptedText(receiverKhqrCodeDto.getQrData());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Receiver khqrEncrypt - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Receiver khqrEncrypt [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "merchant/types", method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantTypes(final @RequestBody SymphonyReceiverRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyReceiver symphonyReceiver = new SymphonyReceiver();
        BeanUtils.copyProperties(request, symphonyReceiver);

        SymphonyReceiverResponse response = new SymphonyReceiverResponse();
        try {
            SymphonyReceiver result = symphonyReceiverService.getMerchantTypes(symphonyReceiver, serviceContext);

            response.setMerchantCategoryList(result.getMerchantCategoryList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getMerchantTypes - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getMerchantTypes [request: {}; response: {}]", request, response);
        }
        return response;
    }


    private void setClientIP(final Request request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
