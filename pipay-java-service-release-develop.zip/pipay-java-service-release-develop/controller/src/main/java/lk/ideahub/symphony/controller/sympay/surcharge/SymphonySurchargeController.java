package lk.ideahub.symphony.controller.sympay.surcharge;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.surcharge.entity.SymphonySurchargeDetail;
import lk.ideahub.symphony.product.sympay.surcharge.service.SymphonySurchargeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Madhukara on 12/13/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/surcharge", consumes = "application/json", produces = "application/json")
public class SymphonySurchargeController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonySurchargeController.class);

    @Autowired
    SymphonySurchargeService symphonySurchargeService;

    @RequestMapping(value = "list/details", method = RequestMethod.POST)
    @ResponseBody
    public Response listSurchargeDetails(final @RequestBody SymphonySurchargeDetailRequest _request, HttpServletRequest servletRequest) {

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonySurchargeDetail symphonySurchargeDetail = new SymphonySurchargeDetail();
        BeanUtils.copyProperties(_request, symphonySurchargeDetail);

        SymphonySurchargeDetailResponse response = new SymphonySurchargeDetailResponse();
        try {
            SymphonySurchargeDetail result = symphonySurchargeService.listSurchargeDetails(symphonySurchargeDetail, serviceContext);

            response.setMerchantSurchargeList(result.getMerchantSurchargeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getPayeeList - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getPayeeList [request: {}; response: {}]", _request, response);
        }
        return response;
    }
}
