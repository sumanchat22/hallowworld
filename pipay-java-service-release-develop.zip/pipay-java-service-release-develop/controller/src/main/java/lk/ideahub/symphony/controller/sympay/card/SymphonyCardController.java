package lk.ideahub.symphony.controller.sympay.card;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.*;
import lk.ideahub.symphony.product.sympay.card.entity.SymphonyCard;
import lk.ideahub.symphony.product.sympay.card.service.SymphonyCardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.audit.AuditUtil;

/**
 * Created by samith on 11/3/15.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME  + "/card", consumes = "application/json", produces = "application/json")
public class SymphonyCardController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyCardController.class);
    private static final String CRON_SCHEDULE_EVERY_MIDNIGHT = "cron.schedule.every.midnight";

    private static final String EXPIRE_PAYMENT_OPTION_CRON = "switch.expire.payment.option.cron";
    private static final String ACTIVATION_REMINDER_CRON = "switch.activation.reminder.cron";

    @Autowired
    SymphonyCardService symphonyCardService;

    @Autowired
    private Environment environment;

    @RequestMapping(value = "init/register", method = RequestMethod.POST)
    @ResponseBody
    public Response initializeRegistration(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.initialInsert(symphonyCard, serviceContext);

            response.setPaymentOption(result.getCustomerPaymentOption());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setCardNo(null);
        _request.setPIN(null);
        _request.setExpiryDate(null);
        _request.setCvc(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service card registration - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service card registration [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "approval", method = RequestMethod.POST)
    @ResponseBody
    public Response approverCard(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.approveCard(symphonyCard, serviceContext);

            response.setPaymentOption(result.getCustomerPaymentOption());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service card approval - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service card approval [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response cardList(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }
        
        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.cardList(symphonyCard, serviceContext);

            response.setCasaDetails(result.getCasaDetails());
            response.setPaymentOptionsCount(result.getPaymentOptionsCount());
            response.setPaymentOptions(result.getCustomerPaymentOptions());
            response.setPaymentOptionTypes(result.getPaymentOptionTypes());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service card list - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service card list [request: {}; response: {}]", _request, response);
        }

        return response;
    }
    
    @RequestMapping(value = "payable/list", method = RequestMethod.POST)
    @ResponseBody
    public Response cardPayableList(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if(servletRequest.getHeader("platform")!= null){
            _request.setPlatform(servletRequest.getHeader("platform"));
        }
        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.cardListPayable(symphonyCard, serviceContext);

            response.setCasaDetails(result.getCasaDetails());
            response.setPaymentOptionsCount(result.getPaymentOptionsCount());
            response.setPaymentOptions(result.getCustomerPaymentOptions());
            response.setCardListDetails(result.getCardListDetails());
            response.setUnfilterCardList(result.getUnfilterCardList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setIsAvailablePaymentOptionsBlocked(result.getIsAvailablePaymentOptionsBlocked());
            
            if(result.getIsAvailablePaymentOptionsBlocked() != null && result.getIsAvailablePaymentOptionsBlocked()) {	
            	response.setDisplayMessage(result.getAvailablePaymentOptionsBlockedMessage());
            }

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service card list - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service card list [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "set/default", method = RequestMethod.POST)
    @ResponseBody
    public Response setDefaultPaymentOption(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.setDefaultPaymentOption(symphonyCard, serviceContext);

            response.setPaymentOptionsCount(result.getPaymentOptionsCount());
            response.setPaymentOptions(result.getCustomerPaymentOptions());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service setDefaultPaymentOption - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service setDefaultPaymentOption [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "bank/details", method = RequestMethod.POST)
    @ResponseBody
    public Response getBankDetails(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.getBankDetails(symphonyCard, serviceContext);

            response.setBankIdentificationNumber(result.getBankIdentificationNumber());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getBankDetails - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getBankDetails [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "delete", method = RequestMethod.POST)
    @ResponseBody
    public Response cardDelete(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.deletePaymentOption(symphonyCard, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service cardDelete - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service cardDelete [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    @ResponseBody
    public Response cardUpdate(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.updatePaymentOption(symphonyCard, serviceContext);

            response.setPaymentOption(result.getCustomerPaymentOption());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service cardUpdate - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service cardUpdate [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "deactivate", method = RequestMethod.POST)
    @ResponseBody
    public Response deactivatePaymentOption(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.deactivatePaymentOption(symphonyCard, serviceContext);

            response.setPaymentOption(result.getCustomerPaymentOption());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service deactivatePaymentOption - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service deactivatePaymentOption [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "reactivate", method = RequestMethod.POST)
    @ResponseBody
    public Response reactivatePaymentOption(final @RequestBody SymphonyCardRegisterRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyCard symphonyCard = new SymphonyCard();
        BeanUtils.copyProperties(_request, symphonyCard);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.reactivatePaymentOption(symphonyCard, serviceContext);

            response.setPaymentOption(result.getCustomerPaymentOption());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setCardNo(null);
        _request.setPIN(null);
        _request.setExpiryDate(null);
        _request.setCvc(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service reactivatePaymentOption - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service reactivatePaymentOption [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "set/expired", method = RequestMethod.POST)
    @ResponseBody
    public Response expirePaymentOption() {

        SymphonyCard symphonyCard = new SymphonyCard();
        // Use this setter for audit log
        symphonyCard.setType(AuditUtil.TYPE_CRON);
        SymphonyCardRegisterRequest _request = new SymphonyCardRegisterRequest();

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.expirePaymentOption(symphonyCard, serviceContext);

            response.setPaymentOption(result.getCustomerPaymentOptions());
            response.setPaymentOptionsCount(result.getPaymentOptionsCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service expirePaymentOption - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service expirePaymentOption [request: {}; response: {}]", _request, response);
        }

        return response;

    }

    //@Scheduled(cron = "0 0 0 * * *")
    public void expirePaymentOptionCron() {
        if (environment.getProperty(EXPIRE_PAYMENT_OPTION_CRON).equals("ON")) {
            SymphonyCard symphonyCard = new SymphonyCard();
            // Use this setter for audit log
            symphonyCard.setType(AuditUtil.TYPE_CRON);
            SymphonyCardRegisterRequest _request = new SymphonyCardRegisterRequest();

            ServiceContext serviceContext = getServiceContext(_request, false);

            SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
            try {
                SymphonyCard result = symphonyCardService.expirePaymentOption(symphonyCard, serviceContext);

                response.setPaymentOption(result.getCustomerPaymentOptions());
                response.setPaymentOptionsCount(result.getPaymentOptionsCount());
                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());

            } catch (InvalidRequestException exception) {
                response.setStatus(RequestStatus.FAILURE.getStatus());
                response.setMessage(exception.getMessage());
            }

            if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
                log.warn("Service expirePaymentOption - failure [request: {}; response: {}]", _request, response);
            } else {
                log.debug("Service expirePaymentOption [request: {}; response: {}]", _request, response);
            }
        }
    }

    //Execute using cron tab.
    @RequestMapping(value = "pending/reminder", method = RequestMethod.POST)
    @ResponseBody
    public Response activationReminder() {

        SymphonyCard symphonyCard = new SymphonyCard();
        // Use this setter for audit log
        symphonyCard.setType(AuditUtil.TYPE_CRON);
        SymphonyCardRegisterRequest _request = new SymphonyCardRegisterRequest();

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.activationReminder(symphonyCard, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service activationReminder - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service activationReminder [request: {}; response: {}]", _request, response);
        }

        return response;

    }

    //@Scheduled(cron = "0 0 12 */7 * ?")
    public void activationReminderCron() {
        if (environment.getProperty(ACTIVATION_REMINDER_CRON).equals("ON")) {
            SymphonyCard symphonyCard = new SymphonyCard();
            // Use this setter for audit log
            symphonyCard.setType(AuditUtil.TYPE_CRON);
            SymphonyCardRegisterRequest _request = new SymphonyCardRegisterRequest();

            ServiceContext serviceContext = getServiceContext(_request, false);

            SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
            try {
                SymphonyCard result = symphonyCardService.activationReminder(symphonyCard, serviceContext);

                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());

            } catch (InvalidRequestException exception) {
                response.setStatus(RequestStatus.FAILURE.getStatus());
                response.setMessage(exception.getMessage());
            }

            if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
                log.warn("Service activationReminder - failure [request: {}; response: {}]", _request, response);
            } else {
                log.debug("Service activationReminder [request: {}; response: {}]", _request, response);
            }
        }
    }


    //Execute using cron tab.
    //Remove deleted card data PCI-DSS requirement
    //card_no, expiry_data
    @RequestMapping(value = "remove/data", method = RequestMethod.POST)
    @ResponseBody
    public Response removeDeletedCardData() {

        SymphonyCard symphonyCard = new SymphonyCard();
        // Use this setter for audit log
        symphonyCard.setType(AuditUtil.TYPE_CRON);
        SymphonyCardRegisterRequest _request = new SymphonyCardRegisterRequest();

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.removeDeletedCardData(symphonyCard, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service removeDeletedCardData - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service removeDeletedCardData [request: {}; response: {}]", _request, response);
        }

        return response;

    }

    //@Scheduled(cron = "0 0 0 * * *")
    public void removeDeletedCardDataCron() {

        SymphonyCard symphonyCard = new SymphonyCard();
        // Use this setter for audit log
        symphonyCard.setType(AuditUtil.TYPE_CRON);
        SymphonyCardRegisterRequest _request = new SymphonyCardRegisterRequest();

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCardRegisterResponse response = new SymphonyCardRegisterResponse();
        try {
            SymphonyCard result = symphonyCardService.removeDeletedCardData(symphonyCard, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service removeDeletedCardData - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service removeDeletedCardData [request: {}; response: {}]", _request, response);
        }
    }
    
    private void setClientIP(final SymphonyCardRegisterRequest _request,
			HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}
}
