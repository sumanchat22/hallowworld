package lk.ideahub.symphony.controller.sympay.bill.presentment;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.bill.presentment.entity.BillingInfo;

/**
 * Created by mahesha on 5/22/17.
 */
public class SymphonyBillPresentmentResponse extends Response {

    private BillingInfo billingInfo;

    private String status;
    private String message;

    public BillingInfo getBillingInfo() {
        return billingInfo;
    }

    public void setBillingInfo(BillingInfo billingInfo) {
        this.billingInfo = billingInfo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyBillPresentmentResponse {")
                //.append("billingInfo=").append(billingInfo).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
