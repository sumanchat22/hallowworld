package lk.ideahub.symphony.controller.test;

import java.util.Date;

import lk.ideahub.symphony.controller.common.Response;

public class TestResponse extends Response {

    private Date utc;
    private String dbStatus;
    private String requestData;
    private String headers;
    private String requestDataFormat = "{\"request\":{\"value1\":\"<text>\",\"value2\":<integer>}}";

    public Date getUtc() {
        return utc;
    }

    public void setUtc(Date utc) {
        this.utc = utc;
    }

    public String getDbStatus() {
        return dbStatus;
    }

    public void setDbStatus(String dbStatus) {
        this.dbStatus = dbStatus;
    }

    public String getRequestData() {
        return requestData;
    }

    public void setRequestData(String requestData) {
        this.requestData = requestData;
    }

    public String getHeaders() {
        return headers;
    }

    public void setHeaders(String headers) {
        this.headers = headers;
    }

    public String getRequestDataFormat() {
        return requestDataFormat;
    }

    public void setRequestDataFormat(String requestDataFormat) {
        this.requestDataFormat = requestDataFormat;
    }

    @Override
    public String toString() {
        return new StringBuilder("TestResponse {")
                .append("utc=").append(utc).append(", ")
                .append("dbStatus='").append(dbStatus).append("'").append(", ")
                .append("requestData='").append(requestData).append("'").append(", ")
                .append("headers='").append(headers).append("'").append(", ")
                .append("requestDataFormat='").append(requestDataFormat).append("'")
                .append('}').toString();
    }
}
