package lk.ideahub.symphony.controller.sympay.friend;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 12/18/18.
 */
@Getter
@Setter
@ToString
public class SymphonyFriendRequest extends Request {

    private String friendMobile;
    private Long customerId;
    private Long friendId;
    private String name;
    private List<String> contactList;
    private Long customerFriendId;
    private Boolean isMuted;
    private String encryptedText;
    private Boolean isBlocked;
}
