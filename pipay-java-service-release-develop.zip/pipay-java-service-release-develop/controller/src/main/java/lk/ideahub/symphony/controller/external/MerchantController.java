package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.external.MerchantExternalDto;
import lk.ideahub.symphony.modules.external.MerchantExternalService;
import lk.ideahub.symphony.modules.external.ExternalServiceResponseCodes;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/service/external/merchant")
public class MerchantController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(MerchantController.class);
	
	@Autowired
	MerchantExternalService merchantExternalService;
	
	@RequestMapping(value = "get/data", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public Response getMerchant(final @RequestBody ExternalServiceRequest request, HttpServletRequest servletRequest) {
       
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        MerchantExternalDto merchantExternalDto = new MerchantExternalDto();
        BeanUtils.copyProperties(request, merchantExternalDto);

        MerchantExternalResponse response = new MerchantExternalResponse();
        try {
            MerchantExternalDto result = merchantExternalService.getMerchantData(merchantExternalDto, serviceContext);

            response.setData(result);
            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            
            result.setErrorCode(null);
            result.setMessage(null);
            result.setClientIp(null);

        }catch (InvalidRequestException exception) {
            log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "Invalid request. Get data error:" + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "get data error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setResponseCode(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("merchantExternalService getMerchant - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("merchantExternalService getMerchant [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/store/data", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public Response getStore(final @RequestBody ExternalServiceRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        MerchantExternalDto merchantExternalDto = new MerchantExternalDto();
        BeanUtils.copyProperties(request, merchantExternalDto);

        MerchantExternalResponse response = new MerchantExternalResponse();
        try {
            MerchantExternalDto result = merchantExternalService.getStoreData(merchantExternalDto, serviceContext);

            response.setData(result);
            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());

            result.setErrorCode(null);
            result.setMessage(null);
            result.setClientIp(null);

        }catch (InvalidRequestException exception) {
            log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "Invalid Request data error: " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
            log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "get data error: " + exception.toString());
            response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setResponseCode(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("merchantExternalService getStore - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("merchantExternalService getStore [request: {}; response: {}]", request, response);
        }
        return response;
    }

	private void setClientIP(final ExternalServiceRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
