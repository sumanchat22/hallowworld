package lk.ideahub.symphony.controller.sympay.receiver;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.merchant.entity.Merchant;
import lk.ideahub.symphony.modules.receiver.entity.CustomerMerchantProfile;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.math.BigDecimal;

/**
 * Created by bunleap on 04/05/22.
 */
@Getter
@Setter
@ToString
public class KhqrReceiverResponse extends Response {

    // For customer
    private Customer customer;
    private CustomerMerchantProfile customerMerchantProfile;

    // For POS
    private Merchant merchant;

    private String currencyCode;

    private String qrCodeType;

    // For dynamic QR
    private BigDecimal amount;
    private String transactionId;
    private Long lifetime;

    private String qrEncryptedText;

    private String status;
    private String message;
}
