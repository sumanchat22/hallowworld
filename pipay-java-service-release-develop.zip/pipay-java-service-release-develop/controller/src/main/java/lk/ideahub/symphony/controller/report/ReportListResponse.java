package lk.ideahub.symphony.controller.report;

import com.fasterxml.jackson.annotation.JsonInclude;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.report.entity.ReportColumn;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by Anil on 6/26/19.
 */
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportListResponse extends Response {

    private String reportKey;
    private Long count;
    private List<Object> dataList;
    private List<ReportColumn> headerList;
    private String status;
    private String message;
}
