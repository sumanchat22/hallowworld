package lk.ideahub.symphony.controller.internal;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @author Bhanuka
 *
 */
@Getter
@Setter
@ToString
public class ExternalServiceRequest extends Request{

	private String phoneNo;
	private Boolean isOnlyToCurrentlyLoggedDevice;
	private String notificationType;

	//data
	private BigDecimal rewardAmount;
	private BigDecimal rewardBalance;
	private String storeName;
	private String provider;
	private String biller;
	private Long pointTransactionId;
	private Date expiredDatetime;
	
}
