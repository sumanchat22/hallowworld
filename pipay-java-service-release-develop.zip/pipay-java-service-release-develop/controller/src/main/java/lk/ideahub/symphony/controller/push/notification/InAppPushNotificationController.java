package lk.ideahub.symphony.controller.push.notification;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.common.ActivePushNotifiacationDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.common.InAppPushNotificationEngine;
import lk.ideahub.symphony.product.sympay.common.InAppPushNotificationResponseDto;
import lk.ideahub.symphony.product.sympay.common.LogSupport;


@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/notification/inApp",consumes = "application/json", produces = "application/json")
public class InAppPushNotificationController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(InAppPushNotificationController.class);
	
	@Autowired
    private Environment environment;
    
    @Autowired
	InAppPushNotificationEngine inAppPushNotificationEngine;
    
    /**
     * Send bulk push notifications
     * @param request
     * @param servletRequest
     * @return
     */
    @RequestMapping(value = "send/bulk", method = RequestMethod.POST)
    @ResponseBody
    public Response sendBulk(final @RequestBody InAppPushRequest request, HttpServletRequest servletRequest) {
    	log.info(LogSupport.INAPP_PUSH_STARTED);
    	log.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<BULK PUSH NOTIFICATION STARTED FOR IN APP>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        ServiceContext serviceContext = getServiceContext(request, false);
        InAppPushResponse response = new InAppPushResponse();
        
        try {
        	InAppPushNotificationResponseDto result = inAppPushNotificationEngine.sendBulkPushNotifications(serviceContext,request.getIsAll(),
	        		request.getCustomerIdList(),request.getOsType(),request.getPushNotificationId(),request.getUserId());
	        response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            response.setAndroidData(result.getAndroidStatus());
            response.setIosData(result.getIosStatus());
            response.setTotalRequestedCount(result.getTotalRequestedCount());
            response.setTotalActiveDeviceCount(result.getTotalActiveCount());
            response.setEventId(result.getEventId());
            response.setDeliveryStatus(result.getDeliveryStatus());
            response.setTotalSentCount(result.getTotalSentCount());
            log.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<BULK PUSH NOTIFICATION COMPLETED FOR IN APP>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        }
        catch(Exception ex) {
        	ex.toString();
        	log.error(ex.toString());
        	response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
            log.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<BULK PUSH NOTIFICATION FINISHED WITH ERROR FOR IN APP>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn(LogSupport.INAPP_PUSH_LOG + "Send bulk push - failure [request: {}; response: {}]", request, response);
        } else {
            log.info(LogSupport.INAPP_PUSH_LOG + "Send bulk push [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/active/notifications", method = RequestMethod.POST)
    @ResponseBody
    public Response getActiveNotificationList(final @RequestBody InAppPushRequest request, HttpServletRequest servletRequest){
        ServiceContext serviceContext = getServiceContext(request, false);
        InappNotificationActiveLIstDto response = new InappNotificationActiveLIstDto();

          try {

              ActivePushNotifiacationDto result = inAppPushNotificationEngine.getActiveNotificationList(request.getPageStart(),request.getCustomerId(),request.getPageSize(),request.getOsType(),serviceContext);
              response.setStatus(RequestStatus.SUCCESS.getStatus());
              response.setTotalCount(result.getTotalCount());
              response.setMessage(result.getMessage());
              response.setPushNotifications(result.getPushNotifications());


          }catch (Exception ex){
              log.error(ex.toString());
              response.setStatus(RequestStatus.FAILURE.getStatus());
              response.setMessage(ex.getMessage());
          }


        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn(LogSupport.INAPP_PUSH_LOG + "PushNotification List - failure [request: {}; response: {}]", request, response);
        } else {
            log.info(LogSupport.INAPP_PUSH_LOG + "PushNotification List [request: {}; response: {}]", request, response);
        }

        return response;

    }
    
    /**
     * Event to re trigger failed requests
     * @param request
     * @param servletRequest
     * @return
     */
    @RequestMapping(value = "send/request/failed/notifications", method = RequestMethod.POST)
    @ResponseBody
    public Response sendRequestFailedNotifications(final @RequestBody InAppPushRequest request, HttpServletRequest servletRequest) {
    	log.info(LogSupport.INAPP_PUSH_FAILED_EVENT_STARTED);
    	log.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<IN-APP REQUEST FAILED PUSH NOTIFICATION MANUAL EVENT FIRED>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        ServiceContext serviceContext = getServiceContext(request, false);
        InAppPushResponse response = new InAppPushResponse();
        
        try {
        	InAppPushNotificationResponseDto result = inAppPushNotificationEngine.sendRequestFailedNotifications(request.getEventId(), request.getUserId(), serviceContext);
        	response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            response.setAndroidData(result.getAndroidStatus());
            response.setIosData(result.getIosStatus());
            response.setTotalRequestedCount(result.getTotalRequestedCount());
            response.setTotalActiveDeviceCount(result.getTotalActiveCount());
            response.setEventId(result.getEventId());
            response.setDeliveryStatus(result.getDeliveryStatus());
            response.setTotalSentCount(result.getTotalSentCount());
        	log.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<IN-APP REQUEST FAILED PUSH NOTIFICATION MANUAL EVENT COMPLETED>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        }
        catch(Exception ex) {
        	log.error(ex.toString());
        	response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
            log.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<IN-APP REQUEST FAILED PUSH NOTIFICATION MANUAL EVENT FINISHED WITH ERROR>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn(LogSupport.INAPP_PUSH_LOG + "Failed notification event fire - failure [request: {}; response: {}]", request, response);
        } else {
            log.info(LogSupport.INAPP_PUSH_LOG + "Failed notification event fire [request: {}; response: {}]", request, response);
        }
        return response;
    }

}
