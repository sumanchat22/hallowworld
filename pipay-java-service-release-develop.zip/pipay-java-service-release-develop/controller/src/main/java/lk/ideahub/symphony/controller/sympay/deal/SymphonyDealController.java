package lk.ideahub.symphony.controller.sympay.deal;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.deal.entity.SymphonyDeal;
import lk.ideahub.symphony.product.sympay.deal.service.SymphonyDealService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 12/31/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/deal", consumes = "application/json", produces = "application/json")
public class SymphonyDealController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyDealController.class);

    @Autowired
    private SymphonyDealService symphonyDealService;

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response list(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);

        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.list(symphonyDeal, serviceContext);
            response.setNearbyDealList(result.getNearbyDealList());
            response.setRecommendedDealList(result.getRecommendedDealList());
            response.setFeaturedDealList(result.getFeaturedDealList());
            response.setFilterTagList(result.getFilterTagList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service get deal list - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get deal list - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get deal list [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Response search(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);

        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.search(symphonyDeal, serviceContext);
            response.setDealList(result.getDealList());
            response.setDealCount(result.getDealCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service search deal list - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service search deal list - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service search deal list [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "get/details", method = RequestMethod.POST)
    @ResponseBody
    public Response viewDetail(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.viewDetail(symphonyDeal, serviceContext);

            response.setLikeCount(result.getLikeCount());
            response.setCommentCount(result.getCommentCount());
            response.setDeal(result.getDeal());
            response.setDealCommentList(result.getDealCommentList());
            response.setAvailableBranches(result.getAvailableBranches());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service viewDealDetail - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service viewDealDetail [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "like", method = RequestMethod.POST)
    @ResponseBody
    public Response like(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.like(symphonyDeal, serviceContext);
            response.setLikeCount(result.getLikeCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service like - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service like [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "unlike", method = RequestMethod.POST)
    @ResponseBody
    public Response unlike(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.unlike(symphonyDeal, serviceContext);
            response.setLikeCount(result.getLikeCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service unlike - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service unlike [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "add/comment", method = RequestMethod.POST)
    @ResponseBody
    public Response addComment(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.addComment(symphonyDeal, serviceContext);
            response.setDealCommentList(result.getDealCommentList());
            response.setCommentCount(result.getCommentCount());
            response.setCustomerDto(result.getCustomerDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addComment - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service addComment [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "update/comment", method = RequestMethod.POST)
    @ResponseBody
    public Response updateComment(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.updateComment(symphonyDeal, serviceContext);
            response.setDealComment(result.getDealComment());
            response.setCustomerDto(result.getCustomerDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateComment - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service updateComment [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "remove/comment", method = RequestMethod.POST)
    @ResponseBody
    public Response removeComment(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.removeComment(symphonyDeal, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service removeComment - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service removeComment [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "view/comments", method = RequestMethod.POST)
    @ResponseBody
    public Response viewComments(final @RequestBody SymphonyDealRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyDeal symphonyDeal = new SymphonyDeal();
        BeanUtils.copyProperties(request, symphonyDeal);
        SymphonyDealResponse response = new SymphonyDealResponse();

        try {
            SymphonyDeal result = symphonyDealService.viewComments(symphonyDeal, serviceContext);

            response.setCommentListSize(result.getCommentListSize());
            response.setDealCommentList(result.getDealCommentList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service viewComments - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service viewComments [request: {}; response: {}]", request, response);
        }
        return response;
    }




    private void setClientIP(final SymphonyDealRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }

}
