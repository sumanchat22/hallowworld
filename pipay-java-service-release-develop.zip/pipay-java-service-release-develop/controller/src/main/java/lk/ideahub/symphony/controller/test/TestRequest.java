package lk.ideahub.symphony.controller.test;

import lk.ideahub.symphony.controller.common.Request;

public class TestRequest extends Request {

    private String value1;
    private Integer value2;

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

    public Integer getValue2() {
        return value2;
    }

    public void setValue2(Integer value2) {
        this.value2 = value2;
    }

    @Override
    public String toString() {
        return new StringBuilder("TestRequest {")
                .append("value1='").append(value1).append("'").append(", ")
                .append("value2=").append(value2)
                .append(super.toString().replaceFirst("^.* \\{", ", ").replaceAll("\\}$", ""))
                .append('}').toString();
    }
}
