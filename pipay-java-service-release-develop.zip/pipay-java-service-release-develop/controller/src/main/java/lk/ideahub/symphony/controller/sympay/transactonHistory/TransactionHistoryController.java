package lk.ideahub.symphony.controller.sympay.transactonHistory;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.sympay.surcharge.SymphonySurchargeController;
import lk.ideahub.symphony.controller.sympay.surcharge.SymphonySurchargeDetailResponse;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.surcharge.entity.SymphonySurchargeDetail;
import lk.ideahub.symphony.product.sympay.surcharge.service.SymphonySurchargeService;
import lk.ideahub.symphony.product.sympay.transactionHistory.entity.TransactionHistoryDto;
import lk.ideahub.symphony.product.sympay.transactionHistory.service.TransactionHistoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;


@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/transaction", consumes = "application/json", produces = "application/json")
public class TransactionHistoryController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonySurchargeController.class);

    @Autowired
    private TransactionHistoryService transactionHistoryService;

    @RequestMapping(value = "get/history", method = RequestMethod.POST)
    @ResponseBody
    public Response getTransactionHistory(final @RequestBody TransactionHistoryRequest transactionHistoryRequest, HttpServletRequest servletRequest) {

        ServiceContext serviceContext = getServiceContext(transactionHistoryRequest, false);
        TransactionHistoryDto transactionHistoryDto = new TransactionHistoryDto();
        BeanUtils.copyProperties(transactionHistoryRequest, transactionHistoryDto);
        TransactionHistoryResponse transactionHistoryResponse = new TransactionHistoryResponse();
        try {
            TransactionHistoryDto result = transactionHistoryService.getTransactionHistory(transactionHistoryDto, serviceContext);
            transactionHistoryResponse.setTransactionsList(result.getTransactions());
            transactionHistoryResponse.setStatus(result.getStatus());
            transactionHistoryResponse.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            transactionHistoryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            transactionHistoryResponse.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(transactionHistoryResponse.getStatus())) {
            log.warn("Service  - failure [request: {}; response: {}]", transactionHistoryRequest, transactionHistoryResponse);
        } else {
            log.debug("Service - failure [request: {}; response: {}]", transactionHistoryRequest, transactionHistoryResponse);
        }
        return transactionHistoryResponse;
    }


}
