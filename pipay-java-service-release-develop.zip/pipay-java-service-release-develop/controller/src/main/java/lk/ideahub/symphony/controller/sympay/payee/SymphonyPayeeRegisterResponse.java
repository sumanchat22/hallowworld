package lk.ideahub.symphony.controller.sympay.payee;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.types.entity.BillerCurrency;
import lk.ideahub.symphony.modules.types.entity.PayeeGroupType;
import lk.ideahub.symphony.modules.types.entity.PayeeType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by samith on 11/16/15.
 */
@Getter
@Setter
@ToString
public class SymphonyPayeeRegisterResponse extends Response {

    //payee
    private List customerPayees;

    private Object customerPayee;

    private List<PayeeType> payeeTypeList;

    //get payee group list
    private List<PayeeGroupType> payeeGroupTypeList;

    private PayeeType payeeType;


    // status
    private String status;
    private String message;
}



