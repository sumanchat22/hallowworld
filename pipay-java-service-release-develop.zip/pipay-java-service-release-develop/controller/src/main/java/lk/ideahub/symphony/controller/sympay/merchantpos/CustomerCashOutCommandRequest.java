package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;

@Getter
@Setter
public class CustomerCashOutCommandRequest extends Request {

    private String customerMsisdn;
    private String currencyCode;
    private Long  merchantId;
    private BigDecimal amount;
    private Long  outletId;
    private Long counterId;
    private String customerPin;
    private String devicePin;

}
