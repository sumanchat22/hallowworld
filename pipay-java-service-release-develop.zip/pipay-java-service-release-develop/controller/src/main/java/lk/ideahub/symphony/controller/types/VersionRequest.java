package lk.ideahub.symphony.controller.types;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by mahesha on 5/16/17.
 */
public class VersionRequest extends Request {

    //check version
    private String appTypeName;

    public String getAppTypeName() {
        return appTypeName;
    }

    public void setAppTypeName(String appTypeName) {
        this.appTypeName = appTypeName;
    }

    @Override
    public String toString() {
        return new StringBuilder("VersionRequest {")
                .append("appTypeName='").append(appTypeName).append("'")
                .append('}').toString();
    }
}
