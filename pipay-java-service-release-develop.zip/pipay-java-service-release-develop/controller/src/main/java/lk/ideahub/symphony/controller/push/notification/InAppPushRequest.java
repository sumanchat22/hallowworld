package lk.ideahub.symphony.controller.push.notification;

import java.util.List;

import lk.ideahub.symphony.controller.common.Request;

public class InAppPushRequest extends Request{

	private Long pushNotificationId;
	private Long[] customerIdList;
	private Boolean isAll;
	private String osType;
	private Long userId;
	private Long customerId;
	private Long eventId;
	private Integer pageSize;


	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getPushNotificationId() {
		return pushNotificationId;
	}
	public void setPushNotificationId(Long pushNotificationId) {
		this.pushNotificationId = pushNotificationId;
	}
	public Long[] getCustomerIdList() {
		return customerIdList;
	}
	public void setCustomerIdList(Long[] customerIdList) {
		this.customerIdList = customerIdList;
	}
	public Boolean getIsAll() {
		return isAll;
	}
	public void setIsAll(Boolean isAll) {
		this.isAll = isAll;
	}
	public String getOsType() {
		return osType;
	}
	public void setOsType(String osType) {
		this.osType = osType;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
