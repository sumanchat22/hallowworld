package lk.ideahub.symphony.controller.catalogue.device;

import lk.ideahub.symphony.controller.common.Request;

public class DeviceRequest extends Request {

    //device app registration
    private String uid;
    private String registrationToken;
    private String phone_1;
    private Long customerDeviceStatusId;
    private Long customerDeviceOsTypeId;

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getRegistrationToken() {
        return registrationToken;
    }

    public void setRegistrationToken(String registrationToken) {
        this.registrationToken = registrationToken;
    }

    public String getPhone_1() {
        return phone_1;
    }

    public void setPhone_1(String phone_1) {
        this.phone_1 = phone_1;
    }

    public Long getCustomerDeviceStatusId() {
        return customerDeviceStatusId;
    }

    public void setCustomerDeviceStatusId(Long customerDeviceStatusId) {
        this.customerDeviceStatusId = customerDeviceStatusId;
    }

    public Long getCustomerDeviceOsTypeId() {
        return customerDeviceOsTypeId;
    }

    public void setCustomerDeviceOsTypeId(Long customerDeviceOsTypeId) {
        this.customerDeviceOsTypeId = customerDeviceOsTypeId;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DeviceRequest{");
        sb.append("uid='").append(uid).append('\'');
        sb.append(", registrationToken='").append(registrationToken).append('\'');
        sb.append(", phone_1='").append(phone_1).append('\'');
        sb.append(", customerDeviceStatusId=").append(customerDeviceStatusId);
        sb.append(", customerDeviceOsTypeId=").append(customerDeviceOsTypeId);
        sb.append('}');
        return sb.toString();
    }
}
