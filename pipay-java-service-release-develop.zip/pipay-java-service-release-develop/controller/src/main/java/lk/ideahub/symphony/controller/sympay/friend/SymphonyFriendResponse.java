package lk.ideahub.symphony.controller.sympay.friend;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.friend.entity.CustomerFriend;
import lk.ideahub.symphony.product.sympay.friend.entity.ContactCustomer;
import lk.ideahub.symphony.product.sympay.friend.entity.CustomerDto;
import lk.ideahub.symphony.product.sympay.friend.entity.CustomerFriendDto;
import lk.ideahub.symphony.product.sympay.friend.entity.FriendDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 12/18/18.
 */
@Getter
@Setter
@ToString
public class SymphonyFriendResponse extends Response {

    private CustomerFriendDto customerFriendDto;

    private List<FriendDto> friendList;
    private Customer customer;
    private List<ContactCustomer> contactCustomerList;
    private CustomerDto customerDto;

    //scanning QR code
    private String encryptedText;

    //get friend
    private FriendDto friendDto;

    private List<FriendDto> addedFriendList;

    private String status;
    private String message;
}
