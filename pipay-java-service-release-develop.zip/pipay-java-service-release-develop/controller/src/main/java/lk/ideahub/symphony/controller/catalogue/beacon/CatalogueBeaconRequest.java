package lk.ideahub.symphony.controller.catalogue.beacon;

import java.util.List;

import lk.ideahub.symphony.controller.common.Request;
import lk.ideahub.symphony.modules.beacon.entity.BeaconId;

public class CatalogueBeaconRequest extends Request {

    // common
    private String phone;

    // notification list
    private List<BeaconId> beaconIdList;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<BeaconId> getBeaconIdList() {
        return beaconIdList;
    }

    public void setBeaconIdList(List<BeaconId> beaconIdList) {
        this.beaconIdList = beaconIdList;
    }

    @Override
    public String toString() {
        return new StringBuilder("CatalogueBeaconRequest {")
                .append("phone='").append(phone).append("'").append(", ")
                .append("beaconIdList=").append(beaconIdList)
                .append(super.toString().replaceFirst("^.* \\{", ", ").replaceAll("\\}$", ""))
                .append('}').toString();
    }
}
