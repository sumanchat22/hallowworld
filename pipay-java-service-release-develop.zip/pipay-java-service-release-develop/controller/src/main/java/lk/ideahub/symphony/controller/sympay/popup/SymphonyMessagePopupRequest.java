package lk.ideahub.symphony.controller.sympay.popup;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author somma.soun - PiPay
 * @create 08-Feb-2022
 */
@Setter
@Getter
@ToString
public class SymphonyMessagePopupRequest extends Request {
    private Long customerId;
}
