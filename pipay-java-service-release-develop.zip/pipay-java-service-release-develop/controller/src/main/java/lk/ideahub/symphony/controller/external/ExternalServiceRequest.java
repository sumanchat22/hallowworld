package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class ExternalServiceRequest extends Request{

	private String phoneNo;
	private Long deviceId;
	
	//push send
	private Boolean isOnlyToCurrenltyLoggedDevice;
	private String pushMessage;
	private String pushTitle;
	
	//wallet upgrade
	private String event;
	private String eventDateTime;
	private String existingWalletGroup;
	private String targetWalletGroup;
	
	//process status
	private String process;
	private Boolean isSuccess;

	//merchant
	private Long externalReferenceId;

	//store
	private Long externalReferenceOutletId;

	//device
	private Long externalReferenceOutletCounterId;
	
}
