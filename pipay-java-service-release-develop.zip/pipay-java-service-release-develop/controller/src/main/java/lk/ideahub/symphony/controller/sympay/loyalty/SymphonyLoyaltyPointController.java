package lk.ideahub.symphony.controller.sympay.loyalty;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.controller.pinkpacket.PinkPacketRequest;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.loyalty.entity.SymphonyLoyaltyPoint;
import lk.ideahub.symphony.product.sympay.loyalty.service.SymphonyLoyaltyPointService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 2/26/19.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/loyalty/point", consumes = "application/json", produces = "application/json")
public class SymphonyLoyaltyPointController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyLoyaltyPointController.class);

    @Autowired
    private SymphonyLoyaltyPointService symphonyLoyaltyPointService;


    @RequestMapping(value = "view/balance", method = RequestMethod.POST)
    @ResponseBody
    public Response viewBalance(final @RequestBody SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyLoyaltyPoint symphonyLoyaltyPoint = new SymphonyLoyaltyPoint();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();

        try {
            SymphonyLoyaltyPoint result = symphonyLoyaltyPointService.viewPointBalance(symphonyLoyaltyPoint, serviceContext);
            response.setPointBalance(result.getPointBalance());
            response.setCouponCount(result.getCouponCount());
            response.setLatestExpiryPoint(result.getLatestExpiryPoint());
            response.setExpiryDate(result.getExpiryDate());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service view point balance - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service view point balance [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getPointList(final @RequestBody SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyPoint symphonyLoyaltyPoint = new SymphonyLoyaltyPoint();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();

        try {
            SymphonyLoyaltyPoint result = symphonyLoyaltyPointService.getPointList(symphonyLoyaltyPoint, serviceContext);
            response.setPointTransactionList(result.getPointTransactionList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get point list - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get point list [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "expire", method = RequestMethod.POST)
    @ResponseBody
    public Response expirePoint(final @RequestBody SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();
        try {
            if(request.getIsExpirationProcessDisabled()) {
                log.info(LogSupport.POINT_EXPIRING_CRON + " Cron Job disabled..");
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
                return response;
            }

            // modify: use pageSize to expire point with pagination in order to avoid timeout
            // default 1000
            Integer pageSize = 1000;
            if(request.getPageSize() != null) {
                pageSize = request.getPageSize();
            }
            log.info(LogSupport.POINT_EXPIRING_CRON + " Cron Job Started..");
            SymphonyLoyaltyPoint result = symphonyLoyaltyPointService.expiringPoint(pageSize, serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.POINT_EXPIRING_CRON + " Cron Job Completed..");
        } catch (InvalidRequestException exception) {
            log.error("Service expiring un-utilized points error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.POINT_EXPIRING_CRON + " Cron Job Ended With Errors..");
        }
        return response;
    }

    @RequestMapping(value = "latest/expire", method = RequestMethod.POST)
    @ResponseBody
    public Response getLatestExpiringPoints(final @RequestBody SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyPoint symphonyLoyaltyPoint = new SymphonyLoyaltyPoint();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();

        try {
            SymphonyLoyaltyPoint result = symphonyLoyaltyPointService.getLatestExpiringPoint(symphonyLoyaltyPoint, serviceContext);
            response.setLatestExpiryPoint(result.getLatestExpiryPoint());
            response.setPointBalance(result.getPointBalance());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get latest expiring point - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get latest expiring point [request: {}; response: {}]", request, response);
        }
        return response;
    }

    /*@RequestMapping(value = "transfer", method = RequestMethod.POST)
    @ResponseBody
    public Response transferPoint(final @RequestBody SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyPoint symphonyLoyaltyPoint = new SymphonyLoyaltyPoint();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();

        try {
            SymphonyLoyaltyPoint result = symphonyLoyaltyPointService.transferPoint(symphonyLoyaltyPoint, serviceContext);
            response.setPointBalance(result.getPointBalance());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service transfer point - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service transfer point [request: {}; response: {}]", request, response);
        }
        return response;
    }*/

    @RequestMapping(value = "bulk/reward/transfer", method = RequestMethod.POST)
    @ResponseBody
    public Response bulkRewardsTransfer(final @RequestBody SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        SymphonyLoyaltyPoint symphonyLoyaltyPoint = new SymphonyLoyaltyPoint();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();
        try {
            SymphonyLoyaltyPoint result = symphonyLoyaltyPointService.bulkRewardsTranfer(symphonyLoyaltyPoint, serviceContext);
            response.setRewardTransferList(result.getRewardTransferList());
            response.setSuccessCount(result.getSuccessCount());
            response.setFailedCount(result.getFailedCount());
            response.setStatus(result.getStatus());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service bulk rewards transfer - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service bulk rewards transfer [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyLoyaltyPointRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }

}
