package lk.ideahub.symphony.controller.sympay.cutomer.payment.option;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import lk.ideahub.symphony.modules.wallet.entity.CustomerPiPayWallet;
import lk.ideahub.symphony.modules.wallet.entity.CustomerPiPayWalletDto;
import lk.ideahub.symphony.modules.wallet.entity.PointWalletDto;
import lk.ideahub.symphony.modules.wallet.entity.WalletPaymentOptionDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class CustomerPaymentOptionResponse extends Response{

	
	private Integer totalAvailablePaymentOptions;
	private String status;
    private String message;
    private List<WalletPaymentOptionDto> customerPiPayWalletList;
    private PointWalletDto pointWallet;
    private CustomerPiPayWallet customerPiPayWallet;
    private CustomerPiPayWalletDto customerPiPayWalletDto;
}
