package lk.ideahub.symphony.controller.sympay.payment;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.CustomerDeviceSession;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import lk.ideahub.symphony.modules.customer.service.CustomerDeviceSessionService;
import lk.ideahub.symphony.modules.customer.service.CustomerPaymentOptionService;
import lk.ideahub.symphony.product.sympay.customer.service.SymphonyCustomerService;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchantDiscount;
import lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantDiscountService;
import lk.ideahub.symphony.product.sympay.payment.entity.SymphonyPayment;
import lk.ideahub.symphony.product.sympay.payment.entity.SymphonySurcharge;
import lk.ideahub.symphony.product.sympay.payment.entity.PaymentOptionDisplayNames;
import lk.ideahub.symphony.product.sympay.payment.service.SymphonyPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by samith on 11/19/15.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/pay", consumes = "application/json", produces = "application/json")
public class SymphonyPaymentController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyPaymentController.class);

    private static final String JWT_OTCPAY_EXPIRY_TIME = "sympay.jwt.otcpay.expiry";

    @Autowired
    SymphonyPaymentService symphonyPaymentService;

    @Autowired
    CustomerDeviceSessionService cusDevSessionService;

    @Autowired
    SymphonyCustomerService symphonyCustomerService;

    @Autowired
    SymphonyMerchantDiscountService symphonyMerchantDiscountService;

    @Autowired
    private CustomerPaymentOptionService customerPaymentOptionService;

    @Autowired
    private Environment environment;

    private static final String PAYMENT_OPTION_ISSUER_CRON = "switch.activation.payment.option.issuer.cron";


    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public Response pay(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        log.info("Service pay [customerId: {}; customerPayeeId: {}]", _request.getCustomerId(),_request.getCustomerPayeeId());

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.pay(symphonyPayment, serviceContext);

            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

            checkEligibilityForAppRate(_request.getCustomerId(),response, serviceContext);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setCardNo(null);
        _request.setPIN(null);
        _request.setExpiryDate(null);
        _request.setCvc(null);
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service pay - failure [request: {}; response: {}]", _request, response);
        } else {
            log.info("Service pay [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "wallet", method = RequestMethod.POST)
    @ResponseBody
    public Response payByWallet(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        log.info("Service pay [customerId: {}; customerPayeeId: {}]", _request.getCustomerId(),_request.getCustomerPayeeId());

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.payByWallet(symphonyPayment, serviceContext);

            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

            checkEligibilityForAppRate(_request.getCustomerId(),response, serviceContext);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service pay - failure [request: {}; response: {}]", _request, response);
        } else {
            log.info("Service pay [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Response search(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, true);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.search(symphonyPayment, serviceContext);

            response.setCustomerPaymentListCount(result.getCustomerPaymentListCount());
            response.setCustomerPaymentList(result.getCustomerPaymentList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service search - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service search [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "ext/merchant", method = RequestMethod.POST)
    @ResponseBody
    public Response payFromExternalMerchant(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.payFromExternalMerchant(symphonyPayment, serviceContext);

            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service payFromExternalMerchant - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service payFromExternalMerchant [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "ext/merchant/guest", method = RequestMethod.POST)
    @ResponseBody
    public Response payFromExternalGuestMerchant(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.payFromExternalMerchantGuest(symphonyPayment, serviceContext);

            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setNameOnCard(null);
        _request.setCardNo(null);
        _request.setExpiryDate(null);
        _request.setCvc(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service payFromExternalGuestMerchant - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service payFromExternalGuestMerchant [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "otc", method = RequestMethod.POST)
    @ResponseBody
    public Response payForOtcPayment(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        log.info("Service payForOtcPayment customerPayeeTransactionId: {}", _request.getCustomerPayeeTransactionId());
        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.payOtc(symphonyPayment, serviceContext);

            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

            checkEligibilityForAppRate(_request.getCustomerId(),response, serviceContext);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setCardNo(null);
        _request.setPIN(null);
        _request.setExpiryDate(null);
        _request.setCvc(null);
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.info("Service payForOtcPayment - failure [request: {}; response: {}]", _request, response);
        } else {
            log.info("Service payForOtcPayment [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "otc/wallet", method = RequestMethod.POST)
    @ResponseBody
    public Response payOtcByWallet(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        log.info("Service payForOtcPayment customerPayeeTransactionId: {}", _request.getCustomerPayeeTransactionId());
        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.payOtcByWallet(symphonyPayment, serviceContext);

            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

            checkEligibilityForAppRate(_request.getCustomerId(),response, serviceContext);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.info("Service payForOtcPayment - failure [request: {}; response: {}]", _request, response);
        } else {
            log.info("Service payForOtcPayment [request: {}; response: {}]", _request, response);
        }
        return response;
    }


    @RequestMapping(value = "validate/payment/token", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity validateToken(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);
        SymphonyPaymentResponse response = new SymphonyPaymentResponse();

        HttpHeaders header = new HttpHeaders();
        HttpStatus httpStatus = HttpStatus.OK;
        try {
            SymphonyPayment result = symphonyPaymentService.validateToken(symphonyPayment, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


            if (symphonyPayment.getCustomerId() != null) {

                Long customerId = result.getCustomerId();
                String deviceId = symphonyPayment.getUid();

                CustomerDeviceSession cds = new CustomerDeviceSession();
                cds.setCustomerId(customerId);
                cds.setDeviceId(deviceId);

                List<CustomerDeviceSession> sdssbyCustomerId = cusDevSessionService.findByCustomerId(cds, serviceContext);
                if (sdssbyCustomerId.size() > 0) {

                    CustomerDeviceSession customerDeviceSession = sdssbyCustomerId.get(0);
                    if (customerDeviceSession != null && customerDeviceSession.getDeviceUniqueId() != null) {

                        String jwtToken = symphonyPaymentService.createJWTToken(customerDeviceSession, JWT_OTCPAY_EXPIRY_TIME, serviceContext);
                        header.set("Authorization", "Bearer " + jwtToken);
                    }
                }
            }

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service validatePaymentToken - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service validatePaymentToken [request: {}; response: {}]", _request, response);
        }
        return new ResponseEntity(response, header, httpStatus);

    }

    @RequestMapping(value = "update/commission", method = RequestMethod.POST)
    @ResponseBody
    public Response updateCommission(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            SymphonyPayment result = symphonyPaymentService.updateCommission(symphonyPayment, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateCommission - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service updateCommission [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "calculate/customer/surcharge", method = RequestMethod.POST)
    @ResponseBody
    public Response calculateCustomerCommission(final @RequestBody SymphonySurchargeRequest _request, HttpServletRequest servletRequest) {

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonySurcharge symphonySurcharge = new SymphonySurcharge();
        BeanUtils.copyProperties(_request, symphonySurcharge);

        SymphonySurchargeResponse response = new SymphonySurchargeResponse();
        try {
            SymphonySurcharge result = symphonyPaymentService.calculateCustomerCommission(symphonySurcharge, serviceContext);

            response.setNetAmount(result.getNetAmount());
            response.setCustomerSurchargeAmount(result.getCustomerSurchargeAmount());
            response.setCustomerSurchargePercentage(result.getCustomerSurchargePercentage());
            response.setGrossAmount(result.getGrossAmount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service calculateCustomerCommission - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service calculateCustomerCommission [request: {}; response: {}]", _request, response);
        }
        return response;
    }


    @RequestMapping(value = "listByDisplayName", method = RequestMethod.POST)
    @ResponseBody
    public Response listByDisplayName(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
            List<PaymentOptionDisplayNames> displayNamesList = symphonyPaymentService.getAllDisplayNames(symphonyPayment,serviceContext);

            response.setDisplayNamesList(displayNamesList);
            response.setStatus(symphonyPayment.getStatus());
            response.setMessage(symphonyPayment.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Payment option issuers - failure [request: {}; response: {}]", _request, response);
        } else {
            log.info("Payment option issuers [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "listAdvancedDiscount", method = RequestMethod.POST)
    @ResponseBody
    public Response getDiscountListAdvanced(final @RequestBody SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyPayment symphonyPayment = new SymphonyPayment();
        BeanUtils.copyProperties(_request, symphonyPayment);

        SymphonyPaymentResponse response = new SymphonyPaymentResponse();
        try {
        	int totalCount = 0;
            List<SymphonyMerchantDiscount> symphonyMerchantDiscounts = symphonyMerchantDiscountService.getGroupsDiscountsListWithDiscount(symphonyPayment,serviceContext);
            for(SymphonyMerchantDiscount mercDisc : symphonyMerchantDiscounts) {
            	if(mercDisc.getMerchantDiscounts() != null) {
            		mercDisc.setMerchantDiscountsGroupedCount(mercDisc.getMerchantDiscounts().size());
            		totalCount += mercDisc.getMerchantDiscounts().size();
            	}
            }
            response.setMerchantDiscountsTotalCount(totalCount);
            response.setSymphonyMerchantDiscounts(symphonyMerchantDiscounts);
            response.setStatus(symphonyPayment.getStatus());
            response.setMessage(symphonyPayment.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Payment option issuers - failure [request: {}; response: {}]", _request, response);
        } else {
            log.info("Payment option issuers [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyPaymentRequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }

    /**
     * This checks eligibility of app rate feature
     * @param _customerId
     * @param response
     * @param serviceContext
     */
    private void checkEligibilityForAppRate(Long _customerId, SymphonyPaymentResponse response, ServiceContext serviceContext){
        Boolean isEligibleForAppRate = symphonyCustomerService.isCustomerEligibleForAppRate(_customerId,serviceContext);
        response.setShowRatingPopup(isEligibleForAppRate);
    }


    //@Scheduled(cron = "* */15 * * * *")
    public void addPaymentOptionIssuersCron() {
        if (environment.getProperty(PAYMENT_OPTION_ISSUER_CRON).equals("ON")) {
            log.info("Payment option issuer adding starting");
            SymphonyPayment symphonyPayment = new SymphonyPayment();
            List<CustomerPaymentOption> customerPaymentOptionList = customerPaymentOptionService.findAll();
            symphonyPayment.setCustomerPaymentOptionList(customerPaymentOptionList);
            symphonyPaymentService.paymentOptionIssuersAddCron(symphonyPayment, null);
            log.info("Payment option issuer adding completed");
        }
    }
}
