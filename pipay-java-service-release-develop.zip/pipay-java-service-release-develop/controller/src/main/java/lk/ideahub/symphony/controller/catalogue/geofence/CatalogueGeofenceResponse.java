package lk.ideahub.symphony.controller.catalogue.geofence;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by samith on 8/13/15.
 */
public class CatalogueGeofenceResponse extends Response {

    // geofence list
    private Integer geofenceCount;
    private boolean hasMsisdn;
    private List geofences;

    // status
    private String status;
    private String message;

    public Integer getGeofenceCount() {
        return geofenceCount;
    }

    public void setGeofenceCount(Integer geofenceCount) {
        this.geofenceCount = geofenceCount;
    }

    public boolean isHasMsisdn() {
        return hasMsisdn;
    }

    public void setHasMsisdn(boolean hasMsisdn) {
        this.hasMsisdn = hasMsisdn;
    }

    public List getGeofences() {
        return geofences;
    }

    public void setGeofences(List geofences) {
        this.geofences = geofences;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CatalogueGeofenceResponse{");
        sb.append("geofenceCount=").append(geofenceCount);
        sb.append(", hasMsisdn=").append(hasMsisdn);
        sb.append(", geofences=").append(geofences);
        sb.append(", status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
