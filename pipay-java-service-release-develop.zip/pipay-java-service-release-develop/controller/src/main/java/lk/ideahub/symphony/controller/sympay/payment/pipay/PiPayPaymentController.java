package lk.ideahub.symphony.controller.sympay.payment.pipay;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.controller.sympay.merchantpos.MerchantPosRequest;
import lk.ideahub.symphony.controller.sympay.merchantpos.MerchantPosResponse;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import lk.ideahub.symphony.modules.customer.entity.CustomerPayeeTransaction;
import lk.ideahub.symphony.modules.customer.entity.CustomerPayeeTransactionHistory;
import lk.ideahub.symphony.modules.customer.service.CustomerPayeeTransactionHistoryService;
import lk.ideahub.symphony.modules.customer.service.CustomerPayeeTransactionService;
import lk.ideahub.symphony.modules.internal.InternalNotificationService;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.merchantpos.entity.MerchantPosDevice;
import lk.ideahub.symphony.product.sympay.payment.entity.PiPayPayment;
import lk.ideahub.symphony.product.sympay.payment.service.PiPayPaymentService;
import lk.ideahub.symphony.product.sympay.posttrx.service.ExternalPostTransactionService;

import org.hibernate.HibernateException;
import org.hibernate.StaleObjectStateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 11/23/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/payment", consumes = "application/json", produces = "application/json")
public class PiPayPaymentController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(PiPayPaymentController.class);

    @Autowired
    private PiPayPaymentService piPayPaymentService;
    
    @Autowired
    InternalNotificationService internalNotificationService;
    
    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    CustomerPayeeTransactionService customerPayeeTransactionService;
    
    @Autowired
    Environment environment;

    //push messsages
    private static final String AUAM_PUSH_TITLE = "message.receiver.auam.qr.payment.status.title";
    private static final String AUAM_PUSH_PAY_AUAM_PAYMENT_ERROR = "message.receiver.auam.payment.error.message";

    @RequestMapping(value = "otc" , method = RequestMethod.POST)
    @ResponseBody
    public Response payOtc(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {
        log.info(LogSupport.PIPAY_PAYMENT_CONTROLLER + "OTC start request="+request.toString());
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
        	piPayPayment.setPaymentProcessMode(Constants.PAYMENT_PROCESS_MODE_INTERNAL);
            PiPayPayment result = null;//piPayPaymentService.processPayment(piPayPayment, serviceContext);
            //---------process payment------------------
            log.info(LogSupport.PIPAY_PAYMENT_CONTROLLER + "otc() calling processPayment " +  Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)).toString());
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage("Success");
//            result = piPayPaymentService.processPayment(piPayPayment, serviceContext);
//
//            if(result.getStatus()!= null && result.getStatus().equals(RequestStatus.SUCCESS.getStatus())){
//            	piPayPaymentService.continueExternalPostProcess(piPayPayment, serviceContext);
//            }
            /*try {
            	result = piPayPaymentService.processPayment(piPayPayment, serviceContext);
            }
            catch(PersistenceException ex) {
            	log.error(LogSupport.PIPAY_PAYMENT_CONTROLLER + "otc() PersistenceException:" + ex.toString());
            	result = piPayPaymentService.redoProcessPayment(piPayPayment, serviceContext);
            }
            catch(DataAccessException ex) {
            	log.error(LogSupport.PIPAY_PAYMENT_CONTROLLER + "otc() DataAccessException:" + ex.toString());
            	result = piPayPaymentService.redoProcessPayment(piPayPayment, serviceContext);
            }
            catch(HibernateException ex) {
            	log.error(LogSupport.PIPAY_PAYMENT_CONTROLLER + "otc() HibernateException:" + ex.toString());
            	result = piPayPaymentService.redoProcessPayment(piPayPayment, serviceContext);
            }*/
            //==========================================

//            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
//            response.setStatus(result.getStatus());
//            response.setMessage(result.getMessage());
//            response.setLoyaltyInfo(result.getLoyaltyInfo());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service piPay-payOtc - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service piPay-payOtc [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "inapp" , method = RequestMethod.POST)
    @ResponseBody
    public Response inAppPay(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {
        log.info(LogSupport.PIPAY_PAYMENT_CONTROLLER + "OTC start request="+request.toString());
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
        	piPayPayment.setPaymentProcessMode(Constants.PAYMENT_PROCESS_MODE_INTERNAL);
        	
            PiPayPayment result = null;//piPayPaymentService.processPayment(piPayPayment, serviceContext);
            //---------process payment------------------
            log.info(LogSupport.PIPAY_PAYMENT_CONTROLLER + "inAppPay() calling processPayment " + Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)).toString());
            result = piPayPaymentService.processPayment(piPayPayment, serviceContext);

            if(result.getStatus()!= null && result.getStatus().equals(RequestStatus.SUCCESS.getStatus())){
                piPayPaymentService.continueExternalPostProcess(piPayPayment, serviceContext);
            }
            /*try {
            	result = piPayPaymentService.processPayment(piPayPayment, serviceContext);
            }
            catch(PersistenceException ex) {
            	log.error(LogSupport.PIPAY_PAYMENT_CONTROLLER + "inAppPay() PersistenceException:" + ex.toString());
            	result = piPayPaymentService.redoProcessPayment(piPayPayment, serviceContext);
            }
            catch(DataAccessException ex) {
            	log.error(LogSupport.PIPAY_PAYMENT_CONTROLLER + "inAppPay() DataAccessException:" + ex.toString());
            	result = piPayPaymentService.redoProcessPayment(piPayPayment, serviceContext);
            }
            catch(HibernateException ex) {
            	log.error(LogSupport.PIPAY_PAYMENT_CONTROLLER + "inAppPay() HibernateException:" + ex.toString());
            	result = piPayPaymentService.redoProcessPayment(piPayPayment, serviceContext);
            }*/
            //==========================================
            
            response.setCustomerPayeeTransaction(result.getCustomerPayeeTransaction());
            response.setCoupon(result.getCoupon());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setLoyaltyInfo(result.getLoyaltyInfo());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service piPay-inApp - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service piPay-inApp [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "update/loyalty/reference" , method = RequestMethod.POST)
    @ResponseBody
    public Response updateLoyaltyReference(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.updateLoyaltyReference(piPayPayment, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setCouponInfo(result.getCouponInfo());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateLoyaltyReference - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service updateLoyaltyReference [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "receiver" , method = RequestMethod.POST)
    @ResponseBody
    public Response payReceiver(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.receiverPay(piPayPayment, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        } catch(Exception exception) {
        	response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        	
        	String pushTitle = messageSource.getMessage(AUAM_PUSH_TITLE,null,serviceContext.getLocale());
            String pushMessage = messageSource.getMessage(AUAM_PUSH_PAY_AUAM_PAYMENT_ERROR,null,serviceContext.getLocale());
            Map<String,String> iosAdditionalData = new HashMap<String,String>();
            iosAdditionalData.put(Constants.IOS_CONTENT_AVAILABLE, "1");
            internalNotificationService.sendPushToApp(piPayPayment.getCustomerId(), true, pushTitle, pushMessage, null,
                    RequestStatus.FAILURE.getStatus(), Constants.AUAM_PAYMENT_CONFIRMATION, serviceContext, iosAdditionalData);
            
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service piPay-payReceiver - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service piPay-payReceiver [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "get/receiver/transaction/status" , method = RequestMethod.POST)
    @ResponseBody
    public Response getReceiverPaymentStatus(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.getReceiverPaymentStatus(piPayPayment, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setReceiverTransactionStatus(result.getReceiverTransactionStatus());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        } catch(Exception exception) {
        	response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service piPay-getReceiverPaymentStatus - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service piPay-getReceiverPaymentStatus [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "receiver/cancel" , method = RequestMethod.POST)
    @ResponseBody
    public Response receiverCancelPayment(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.cancelReceiverPay(piPayPayment, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        } catch(Exception exception) {
        	response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        	
        	String pushTitle = messageSource.getMessage(AUAM_PUSH_TITLE,null,serviceContext.getLocale());
            String pushMessage = messageSource.getMessage(AUAM_PUSH_PAY_AUAM_PAYMENT_ERROR,null,serviceContext.getLocale());
            Map<String,String> iosAdditionalData = new HashMap<String,String>();
            iosAdditionalData.put(Constants.IOS_CONTENT_AVAILABLE, "1");
            internalNotificationService.sendPushToApp(piPayPayment.getCustomerId(), true, pushTitle, pushMessage, null,
                    RequestStatus.SUCCESS.getStatus(), Constants.AUAM_PAYMENT_CONFIRMATION, serviceContext, iosAdditionalData);
            
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service piPay-receiverCancelPayment - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service piPay-receiverCancelPayment [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "apply/point" , method = RequestMethod.POST)
    @ResponseBody
    public Response applyPoint(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.applyPoint(piPayPayment, serviceContext);
            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service applyPoint - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service applyPoint [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "get/bank/security/key" , method = RequestMethod.POST)
    @ResponseBody
    public Response getBankSecurityKey(final @RequestBody  PiPayPaymentRequest request, HttpServletRequest servletRequest){

    	setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
        	 PiPayPayment result = piPayPaymentService.getExternalSecurityKey(piPayPayment, serviceContext);
        	 response.setPrivateKey(result.getPrivateKey());
             response.setStatus(result.getStatus());
             response.setMessage(result.getMessage());
             response.setResponseCode(result.getExternalResponseCode());
             response.setResponseCodeMessage(result.getExternalResponseMessage());
            
        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service getBankSecurityKey POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service getBankSecurityKey POS [request: {}; response: {}]",request,response);
        }
        return response;
    }
    
    @RequestMapping(value = "get/txn/status" , method = RequestMethod.POST)
    @ResponseBody
    public Response getTxnStatus(final @RequestBody  PiPayPaymentRequest request, HttpServletRequest servletRequest){

    	setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
        	 PiPayPayment result = piPayPaymentService.getTxnStatus(piPayPayment, serviceContext);
        	 response.setTransactionStatus(result.getTransactionStatus());
             response.setMerchantTransaction(result.getMerchantTransaction());
             response.setStatus(result.getStatus());
             response.setMessage(result.getMessage());
             response.setInstrumentId(piPayPayment.getInstrumentId());
             response.setExternalTxnReference(piPayPayment.getExternalTxnReference());
             response.setOutletName(piPayPayment.getOutletName());
             response.setOutletLogo(piPayPayment.getOutletLogo());
             response.setOutletUuid(piPayPayment.getOutletUuid());
            
        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service getTxnStatus   - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service getTxnStatus  [request: {}; response: {}]",request,response);
        }
        return response;
    }

    @RequestMapping(value = "get/payable/point" , method = RequestMethod.POST)
    @ResponseBody
    public Response getGlobalPointValues(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);
        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.getGlobalPointValues(piPayPayment, serviceContext);
            response.setGlobalPercentageDtoList(result.getGlobalPercentageDtoList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getGlobalPointValues - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service getGlobalPointValues [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/loyalty/discount" , method = RequestMethod.POST)
    @ResponseBody
    public Response getDiscountValues(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {
        log.info("Service getDiscountValues - failure [request: {};]", request);
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);
        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.getDiscountValues(piPayPayment, serviceContext);
            response.setExternalDiscountData(result.getExternalDiscountData());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getDiscountValues - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service getDiscountValues [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "process/incompleted/post/txn" , method = RequestMethod.POST)
    @ResponseBody
    public Response processIncompletedPostTransactions(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {
        log.info("Service processIncompletedPostTransactions started");
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);
        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
        	if(!piPayPayment.getIsProcessDisabled()) {
        		log.info("Service processIncompletedPostTransactions started");
        		piPayPaymentService.continueBulkExternalPostProces(serviceContext);
        		
        		log.info("Service processIncompletedPostTransactions ended");
        	}
            
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getDiscountValues - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service getDiscountValues [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "loyalty/data" , method = RequestMethod.POST)
    @ResponseBody
    public Response getLoyaltyInfo(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest) {
        log.info("Service getLoyaltyInfo - Staring [request: {};]", request);
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);
        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.getLoyaltyInfo(piPayPayment, serviceContext);
            response.setExternalDiscountData(result.getExternalDiscountData());
            response.setGlobalPercentageDtoList(result.getGlobalPercentageDtoList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getDiscountValues - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service getDiscountValues [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final PiPayPaymentRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }


}
