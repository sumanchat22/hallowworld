package lk.ideahub.symphony.controller.sympay.loyalty.coupon;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by mahesha on 3/5/19.
 */
@Getter
@Setter
@ToString
public class SymphonyLoyaltyCouponRequest extends Request {

    //list all coupons
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Long customerId;
    private Long filterTagId;

    //search & show all coupon packs
    private String searchType;
    private String searchText;

    //get coupon details
    private Long couponPackId;
    private Long couponId;

    //list claimed coupons
    private String couponStatus;
    private String couponType;
    private Boolean isExpirationProcessDisabled;
    private Long merchantId;

    private Long userId;

    //payable coupons
    private String eventType;

    //transfer coupons
    private Long receiverId;

    // buy coupon request
    private String sessionToken;
    private Long customerPaymentOptionId;
    private BigDecimal amount;
    private String currencyCode;
    private String externalTxnReference;
    private String externalResponseDesc;
    private String externalResponseCode;

    //release coupons
    private Boolean isReleasingProcessDisabled;

    //customer confirm coupon redemption
    private String customerConfirmation;

    private Boolean isExpirationNotificationDisabled;

    // Modify 2020-9-8
    // Manual Coupon Redemption
//    private Long couponId;
//    private Long customerId;
//    private String currencyCode;s
//    private Long merchantId;
    private Long outletId;
    private Long counterId;
    private Boolean isPushNotification;

}
