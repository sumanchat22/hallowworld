package lk.ideahub.symphony.controller.xssfilter;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class XSSFilter implements Filter {


@Override
public void init(FilterConfig filterConfig) throws ServletException {
}

@Override
public void destroy() {
}

@Override
public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {

    XSSRequestWrapper wrappedRequest = new XSSRequestWrapper(
            (HttpServletRequest) request);

    String body = IOUtils.toString(wrappedRequest.getReader());


    if(!"".equals(body)){
    	String newBody = XSSUtils.stripXSS(body);
        wrappedRequest.resetInputStream(newBody.getBytes());

    }

    chain.doFilter(wrappedRequest, response);
 }
}