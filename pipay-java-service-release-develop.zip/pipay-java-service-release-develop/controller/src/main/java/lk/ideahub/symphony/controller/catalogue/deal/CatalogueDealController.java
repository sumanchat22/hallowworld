package lk.ideahub.symphony.controller.catalogue.deal;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.UnauthorizedRequestException;
import lk.ideahub.symphony.product.catalogue.deal.entity.CatalogueDeal;
import lk.ideahub.symphony.product.catalogue.deal.service.CatalogueDealService;

@Controller
@RequestMapping(value = "catalogue/deals", consumes = "application/json", produces = "application/json")
public class CatalogueDealController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(CatalogueDealController.class);

    @Autowired
    CatalogueDealService catalogueDealService;

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public Response deals(final @RequestBody CatalogueDealRequest _request,
                          final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, true);

        CatalogueDeal catalogueDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, catalogueDeal);

        List deals = catalogueDealService.deals(catalogueDeal, serviceContext);

        CatalogueDealResponse response = new CatalogueDealResponse();
        response.setHasMsisdn(_request.getPhone() != null);
        response.setDeals(deals);
        response.setDealCount(deals != null ? deals.size() : 0);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service deals - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service deals [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "details", method = RequestMethod.POST)
    @ResponseBody
    public Response dealsDetails(final @RequestBody CatalogueDealRequest _request,
                                 final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, true);

        CatalogueDeal catalogueDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, catalogueDeal);

        List deals = catalogueDealService.dealsDetails(catalogueDeal, serviceContext);

        CatalogueDealResponse response = new CatalogueDealResponse();
        response.setHasMsisdn(_request.getPhone() != null);
        response.setDeals(deals);
        response.setDealCount(deals != null ? deals.size() : 0);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service deals - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service deals [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "like", method = RequestMethod.POST)
    @ResponseBody
    public Response like(final @RequestBody CatalogueDealRequest _request,
                         final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueDeal catalogueDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, catalogueDeal);

        CatalogueDealResponse response = new CatalogueDealResponse();
        try {
            CatalogueDeal results = catalogueDealService.like(catalogueDeal, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
            BeanUtils.copyProperties(results, response);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service like - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service like [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "comments", method = RequestMethod.POST)
    @ResponseBody
    public Response comments(final @RequestBody CatalogueDealRequest _request,
                             final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, true);

        CatalogueDeal catalogueDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, catalogueDeal);

        CatalogueDealResponse response = new CatalogueDealResponse();
        try {
            List dealComments = catalogueDealService.comments(catalogueDeal, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
            response.setDealComments(dealComments);
            response.setDealCommentCount(dealComments != null ? dealComments.size() : 0);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service comments - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service comments [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "comments/add", method = RequestMethod.POST)
    @ResponseBody
    public Response addComment(final @RequestBody CatalogueDealRequest _request,
                               final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueDeal catalogueDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, catalogueDeal);

        CatalogueDealResponse response = new CatalogueDealResponse();
        try {
            CatalogueDeal results = catalogueDealService.addComment(catalogueDeal, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
            BeanUtils.copyProperties(results, response);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addComment - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service addComment [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "reserve", method = RequestMethod.POST)
    @ResponseBody
    public Response reserve(final @RequestBody CatalogueDealRequest _request,
                            final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }
        _request.setPhone(_msisdn);
        ServiceContext serviceContext = getServiceContext(_request, false);
        CatalogueDeal catalogueDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, catalogueDeal);

        CatalogueDealResponse response = new CatalogueDealResponse();
        try {
            CatalogueDeal results = catalogueDealService.reserve(catalogueDeal, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
            BeanUtils.copyProperties(results, response);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service reserve - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service reserve [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "buy", method = RequestMethod.POST)
    @ResponseBody
    public Response buy(final @RequestBody CatalogueDealRequest _request,
                        final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }
        _request.setPhone(_msisdn);
        ServiceContext serviceContext = getServiceContext(_request, false);
        CatalogueDeal dAppDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, dAppDeal);

        CatalogueDealResponse response = new CatalogueDealResponse();
        try {
            CatalogueDeal results = catalogueDealService.buy(dAppDeal, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
            BeanUtils.copyProperties(results, response);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service buy - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service buy [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "gift", method = RequestMethod.POST)
    @ResponseBody
    public Response gift(final @RequestBody CatalogueDealRequest _request,
                         final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }
        _request.setPhone(_msisdn);
        ServiceContext serviceContext = getServiceContext(_request, false);
        CatalogueDeal dAppDeal = new CatalogueDeal();
        BeanUtils.copyProperties(_request, dAppDeal);

        CatalogueDealResponse response = new CatalogueDealResponse();
        try {
            CatalogueDeal results = catalogueDealService.gift(dAppDeal, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
            BeanUtils.copyProperties(results, response);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service gift - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service gift [request: {}; response: {}]", _request, response);
        }
        return response;
    }
}
