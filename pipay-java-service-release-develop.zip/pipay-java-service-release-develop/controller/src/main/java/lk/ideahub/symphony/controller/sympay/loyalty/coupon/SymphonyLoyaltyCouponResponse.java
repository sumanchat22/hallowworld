package lk.ideahub.symphony.controller.sympay.loyalty.coupon;

import com.amazonaws.util.json.Jackson;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.couponForCustomer.entity.CustomerGetCoupon;
import lk.ideahub.symphony.modules.couponForCustomer.entity.couponCustomer.PopupData;
import lk.ideahub.symphony.modules.experienceCard.entity.FilterTag;
import lk.ideahub.symphony.modules.loyalty.entity.LoyaltyPointDto;
import lk.ideahub.symphony.modules.loyalty.entity.coupon.Coupon;
import lk.ideahub.symphony.modules.loyalty.entity.coupon.CouponPack;
import lk.ideahub.symphony.product.sympay.loyalty.entity.CouponInfoDto;
import lk.ideahub.symphony.product.sympay.loyalty.entity.CouponPackDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by mahesha on 3/5/19.
 */
@Getter
@Setter
@ToString
public class SymphonyLoyaltyCouponResponse extends Response {

    //list coupon packs
    private List<CouponPackDto> couponPackList;
    private List<CouponPackDto> nearByCouponList;
    private List<CouponPackDto> featuredCouponList;
    private List<CouponPackDto> recommendedCouponList;
    private List<FilterTag> filterTagList;

    //get coupon details
    private CouponPack couponPack;
    private BigDecimal pointBalance;
    private BigDecimal burningRewardsConversionRate;
    private Long burningRewardsConversionRateId;

    //list claimed coupons
    private List<Coupon> couponList;

    private String status;
    private String message;
    
    //coupon QR
    private Long couponCode;
    private String couponQr;

    //buy coupon
    private Coupon coupon;
    private Long couponCount;

    private String couponRedemptionStatus;

    // Modify 2020-9-8
    // Manual Coupon Redemption
    private CouponInfoDto couponInfo;
    private List<PopupData> dialog;
    private CustomerGetCoupon customerGetCoupon;
}
