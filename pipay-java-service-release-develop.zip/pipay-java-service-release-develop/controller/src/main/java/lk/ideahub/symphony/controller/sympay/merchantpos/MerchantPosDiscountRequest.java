package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by mahesha on 1/9/19.
 */
@Getter
@Setter
@ToString
public class MerchantPosDiscountRequest extends Request {

    private Long merchantId;
    private Long counterId;
    private Long outletId;
    private BigDecimal amount;
    private String currencyCode;
}
