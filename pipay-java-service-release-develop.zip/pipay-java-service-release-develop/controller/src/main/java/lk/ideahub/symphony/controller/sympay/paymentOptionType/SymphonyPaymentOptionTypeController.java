package lk.ideahub.symphony.controller.sympay.paymentOptionType;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.card.entity.SymphonyPaymentOptionType;
import lk.ideahub.symphony.product.sympay.card.service.SymphonyCardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Madhukara on 12/5/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME , consumes = "application/json", produces = "application/json")
public class SymphonyPaymentOptionTypeController extends GenericController{

    private static final Logger log = LoggerFactory.getLogger(SymphonyPaymentOptionTypeController.class);

    @Autowired
    SymphonyCardService symphonyCardService;

    @RequestMapping(value = "paymentoptiontype/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getGeneralInfo(HttpServletRequest servletRequest){
        SymphonyPaymentOptionTypeResponse response = new SymphonyPaymentOptionTypeResponse();
        SymphonyPaymentOptionType symphonyPaymentOptionType =new SymphonyPaymentOptionType();
        ServiceContext serviceContext = getServiceContext(null, false);
        try {
            SymphonyPaymentOptionType result = symphonyCardService.paymentOptionTypeList(symphonyPaymentOptionType, serviceContext);

            response.setPaymentOptionTypes(result.getPaymentOptionTypes());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service card registration - failure [ response: {}]", response);
        } else {
            log.debug("Service card registration [ response: {}]", response);
        }
        return response;
    }
}
