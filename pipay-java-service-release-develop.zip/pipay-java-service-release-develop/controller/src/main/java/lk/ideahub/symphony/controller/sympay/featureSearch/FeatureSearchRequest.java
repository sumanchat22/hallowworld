package lk.ideahub.symphony.controller.sympay.featureSearch;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FeatureSearchRequest extends Request {

    private String searchQuery;
    private Long customerId;

}
