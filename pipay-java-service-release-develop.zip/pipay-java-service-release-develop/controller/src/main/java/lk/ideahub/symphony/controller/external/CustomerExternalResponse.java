package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.external.CustomerExternalDto;
import lk.ideahub.symphony.modules.external.PushExternalDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class CustomerExternalResponse  extends Response{

	private CustomerExternalDto data;
	private String status;
	private String message;
	private String responseCode;
}
