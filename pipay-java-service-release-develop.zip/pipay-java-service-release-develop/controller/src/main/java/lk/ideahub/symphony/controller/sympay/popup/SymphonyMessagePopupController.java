package lk.ideahub.symphony.controller.sympay.popup;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.*;
import lk.ideahub.symphony.product.sympay.popup.entity.SymphonyMessagePopup;
import lk.ideahub.symphony.product.sympay.popup.service.SymphonyMessagePopupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * @author somma.soun - PiPay
 * @create 08-Feb-2022
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/popup/message/", consumes = "application/json", produces = "application/json")
public class SymphonyMessagePopupController extends GenericController {
    private static final Logger log = LoggerFactory.getLogger(SymphonyMessagePopupController.class);

    @Autowired
    SymphonyMessagePopupService symphonyMessagePopupService;

    @RequestMapping(value = "sweepstake", method = RequestMethod.POST)
    @ResponseBody
    public Response getMessageSweepstake(final @RequestBody SymphonyMessagePopupRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyMessagePopup symphonyMessagePopup = new SymphonyMessagePopup();
        BeanUtils.copyProperties(request,symphonyMessagePopup);
        SymphonyMessagePopupResponse response = new SymphonyMessagePopupResponse();

        try {
            SymphonyMessagePopup result = symphonyMessagePopupService.getMessageSweepstake(symphonyMessagePopup, serviceContext);

            response.setIsPopup(result.getIsPopup());
            response.setCouponPackId(result.getCouponPackId());
            response.setMessagePopup(result.getMaintenanceMessages());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getMessageSweepstake - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getMessageSweepstake [request: {}; response: {}]", request, response);
        }

        return response;
    }

    private void setClientIP(final SymphonyMessagePopupRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
