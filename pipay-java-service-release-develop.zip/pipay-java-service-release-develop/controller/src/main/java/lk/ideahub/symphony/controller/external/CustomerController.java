package lk.ideahub.symphony.controller.external;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.product.sympay.customerSendVerificationCode.entity.SymphonyCustomerSendVerificationCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.external.CustomerExternalDto;
import lk.ideahub.symphony.modules.external.CustomerExternalService;
import lk.ideahub.symphony.modules.external.ExternalServiceResponseCodes;
import lk.ideahub.symphony.product.sympay.common.LogSupport;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/service/external/customer")
public class CustomerController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(CustomerController.class);	
	
	@Autowired
	CustomerExternalService customerExternalService;
	
	@RequestMapping(value = "get/data", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public Response getCustomer(final @RequestBody ExternalServiceRequest request, HttpServletRequest servletRequest) {
       
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerExternalDto customerExternalDto = new CustomerExternalDto();
        BeanUtils.copyProperties(request, customerExternalDto);

        CustomerExternalResponse response = new CustomerExternalResponse();
        try {
        	CustomerExternalDto result = customerExternalService.getCustomerData(customerExternalDto, serviceContext);

            response.setData(result);
            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            
            result.setErrorCode(null);
            result.setMessage(null);
            result.setClientIp(null);

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "get data error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setResponseCode(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("customerExternalService getCustomer - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("customerExternalService getCustomer [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "change/wallet/group", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public Response changeWalletGroup(final @RequestBody ExternalServiceRequest request, HttpServletRequest servletRequest) {
       
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerExternalDto customerExternalDto = new CustomerExternalDto();
        BeanUtils.copyProperties(request, customerExternalDto);

        CustomerExternalResponse response = new CustomerExternalResponse();
        try {
        	CustomerExternalDto result = customerExternalService.changeWalletGroup(customerExternalDto, serviceContext);

            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "get data error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setResponseCode(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("customerExternalService getCustomer - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("customerExternalService getCustomer [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "update/process/status", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public Response updateProcessStatus(final @RequestBody ExternalServiceRequest request, HttpServletRequest servletRequest) {
       
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerExternalDto customerExternalDto = new CustomerExternalDto();
        BeanUtils.copyProperties(request, customerExternalDto);

        CustomerExternalResponse response = new CustomerExternalResponse();
        try {
        	CustomerExternalDto result = customerExternalService.updateProcessStatus(customerExternalDto, serviceContext);

            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.EXT_CUSTOMER_CONTROLLER + "get data error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setResponseCode(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("customerExternalService getCustomer - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("customerExternalService getCustomer [request: {}; response: {}]", request, response);
        }
        return response;
    }

	private void setClientIP(final ExternalServiceRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
