package lk.ideahub.symphony.controller.sympay.bill.presentment;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.bill.presentment.entity.SymphonyBillPresentment;
import lk.ideahub.symphony.product.sympay.bill.presentment.service.SymphonyBillPresentmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 5/22/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/bill/presentment" , produces = "application/json" , consumes = "application/json")
public class SymphonyBillPresentmentController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyBillPresentmentController.class);

    @Autowired
    SymphonyBillPresentmentService symphonyBillPresentmentService;

    @RequestMapping(value = "view" , method = RequestMethod.POST)
    @ResponseBody
    private Response view(final @RequestBody SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyBillPresentment symphonyBillPresentment = new SymphonyBillPresentment();
        BeanUtils.copyProperties(_request, symphonyBillPresentment);
        SymphonyBillPresentmentResponse response = new SymphonyBillPresentmentResponse();

        try {
            SymphonyBillPresentment result = symphonyBillPresentmentService.view(symphonyBillPresentment,serviceContext);

            response.setBillingInfo(result.getBillingInfo());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException ex){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service view - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service view [request: {}; response: {}]",_request,response);
        }
        return response;

    }

    @RequestMapping(value = "enable" , method = RequestMethod.POST)
    @ResponseBody
    private Response enable(final @RequestBody SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyBillPresentment symphonyBillPresentment = new SymphonyBillPresentment();
        BeanUtils.copyProperties(_request, symphonyBillPresentment);
        SymphonyBillPresentmentResponse response = new SymphonyBillPresentmentResponse();

        try {
            SymphonyBillPresentment result = symphonyBillPresentmentService.enable(symphonyBillPresentment,serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException ex){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service enable - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service enable [request: {}; response: {}]",_request,response);
        }
        return response;

    }

    @RequestMapping(value = "enable/verify/otp" , method = RequestMethod.POST)
    @ResponseBody
    private Response verifyOTP(final @RequestBody SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyBillPresentment symphonyBillPresentment = new SymphonyBillPresentment();
        BeanUtils.copyProperties(_request, symphonyBillPresentment);
        SymphonyBillPresentmentResponse response = new SymphonyBillPresentmentResponse();

        try {
            SymphonyBillPresentment result = symphonyBillPresentmentService.verifyOTP(symphonyBillPresentment,serviceContext);

            response.setBillingInfo(result.getBillingInfo());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException ex){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service verifyOTP - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service verifyOTP [request: {}; response: {}]",_request,response);
        }
        return response;

    }

    @RequestMapping(value = "enable/resend/otp" , method = RequestMethod.POST)
    @ResponseBody
    private Response resendOtp(final @RequestBody SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyBillPresentment symphonyBillPresentment = new SymphonyBillPresentment();
        BeanUtils.copyProperties(_request, symphonyBillPresentment);
        SymphonyBillPresentmentResponse response = new SymphonyBillPresentmentResponse();

        try {
            SymphonyBillPresentment result = symphonyBillPresentmentService.resendOtp(symphonyBillPresentment,serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException ex){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service resendOtp - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service resendOtp [request: {}; response: {}]",_request,response);
        }
        return response;

    }

    @RequestMapping(value = "enable/verify/nic" , method = RequestMethod.POST)
    @ResponseBody
    private Response verifyNIC(final @RequestBody SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyBillPresentment symphonyBillPresentment = new SymphonyBillPresentment();
        BeanUtils.copyProperties(_request, symphonyBillPresentment);
        SymphonyBillPresentmentResponse response = new SymphonyBillPresentmentResponse();

        try {
            SymphonyBillPresentment result = symphonyBillPresentmentService.verifyNIC(symphonyBillPresentment,serviceContext);

            response.setBillingInfo(result.getBillingInfo());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException ex){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        _request.setNic(null);

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service verifyNIC - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service verifyNIC [request: {}; response: {}]",_request,response);
        }
        return response;

    }

    @RequestMapping(value = "enable/none" , method = RequestMethod.POST)
    @ResponseBody
    private Response enableNone(final @RequestBody SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyBillPresentment symphonyBillPresentment = new SymphonyBillPresentment();
        BeanUtils.copyProperties(_request, symphonyBillPresentment);
        SymphonyBillPresentmentResponse response = new SymphonyBillPresentmentResponse();

        try {
            SymphonyBillPresentment result = symphonyBillPresentmentService.enableNoneBillPresentment(symphonyBillPresentment,serviceContext);

            response.setBillingInfo(result.getBillingInfo());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException ex){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service verifyNONE - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service verifyNONE [request: {}; response: {}]",_request,response);
        }
        return response;

    }


    private void setClientIP(final SymphonyBillPresentmentRequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }
}
