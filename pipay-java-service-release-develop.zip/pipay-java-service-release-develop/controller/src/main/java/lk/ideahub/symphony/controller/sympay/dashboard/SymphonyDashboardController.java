package lk.ideahub.symphony.controller.sympay.dashboard;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.dashboard.entity.SymphonyDashboard;
import lk.ideahub.symphony.product.sympay.dashboard.service.SymphonyDashboardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 4/2/19.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/dashboard", consumes = "application/json", produces = "application/json")

public class SymphonyDashboardController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyDashboardController.class);

    @Autowired
    private SymphonyDashboardService symphonyDashboardService;

    @RequestMapping(value = "data", method = RequestMethod.POST)
    @ResponseBody
    public Response getDashboardData(final @RequestBody SymphonyDashboardRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyDashboard symphonyDashboard = new SymphonyDashboard();
        BeanUtils.copyProperties(request,symphonyDashboard);

        SymphonyDashboardResponse response = new SymphonyDashboardResponse();

        try {
            SymphonyDashboard result = symphonyDashboardService.getData(symphonyDashboard, serviceContext);
            response.setFeatureList(result.getFeatureList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getDashboard Data  - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getDashboard Data - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getDashboard Data [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyDashboardRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
