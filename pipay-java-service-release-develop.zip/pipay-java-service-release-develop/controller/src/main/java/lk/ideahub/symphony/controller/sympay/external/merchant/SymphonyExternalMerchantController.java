package lk.ideahub.symphony.controller.sympay.external.merchant;

import lk.ideahub.symphony.controller.sympay.qrcode.payment.QrCodePaymentRequest;
import lk.ideahub.symphony.controller.sympay.qrcode.payment.QrCodePaymentResponse;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchant;
import lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantService;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.SymphonyQrCodePayment;
import lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Gayan on 03/04/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/external/merchant", consumes = "application/json", produces = "application/json")
public class SymphonyExternalMerchantController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyExternalMerchantController.class);

    @Autowired
    SymphonyMerchantService symphonyMerchantService;

    @Autowired
    SymphonyQrCodePaymentService symphonyQrCodePaymentService;

    @RequestMapping(value = "transaction/initiate/push", method = RequestMethod.POST)
    @ResponseBody
    public Response merchantInitOtc(final @RequestBody SymphonyExternalMerchantRequest _request, HttpServletRequest servletRequest) {

        log.info(LogSupport.INIT_OTC_EXTERNAL, _request.getMerchantPgIdentifier(), _request.getExternalMerchantTransactionId());

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);
        piPayCustomer.setIsExternalMerchant(true);

        SymphonyExternalMerchantResponse response = new SymphonyExternalMerchantResponse();
        try {

            SymphonyMerchant result = symphonyMerchantService.initOtc(piPayCustomer, serviceContext);

            response.setSymphonyTransactionId(result.getMerchantTransaction().getSymphonyTransactionId());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setErrorCode(result.getErrorCode());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setErrorCode(exception.getCode());
        }

        _request.setPassword(null);
        _request.setSymphonyAccountNumber(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service merchantInitOtc - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service merchantInitOtc [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "transaction/cancel", method = RequestMethod.POST)
    @ResponseBody
    public Response merchantTransactionCancel(final @RequestBody SymphonyExternalMerchantRequest _request, HttpServletRequest servletRequest) {

        log.info(LogSupport.CANCEL_TRANSACTION_EXTERNAL, _request.getMerchantPgIdentifier(), _request.getExternalMerchantTransactionId(), _request.getSymphonyTransactionId());

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);
        piPayCustomer.setIsExternalMerchant(true);

        SymphonyExternalMerchantResponse response = new SymphonyExternalMerchantResponse();
        try {

        	SymphonyMerchant result = null;

            result = symphonyMerchantService.otcMerchantCancel(piPayCustomer, serviceContext);

            if (!result.getStatus().equals(RequestStatus.FAILURE.getStatus())){
                MerchantTransaction merchantTransaction = result.getMerchantTransaction();
                response.setExternalMerchantTransactionId(merchantTransaction.getExternalMerchantTransactionId());
                response.setSymphonyTransactionId(merchantTransaction.getSymphonyTransactionId());
                response.setMerchantTxnStatusName(result.getMerchantTxnStatusName());
                if(merchantTransaction.getMerchantPgConnection()!=null){
                    response.setMerchantPgIdentifier(merchantTransaction.getMerchantPgConnection().getIdentifier());
                }
                response.setTransactionAmount(merchantTransaction.getChargeTotal());
                response.setInvoiceNumber(merchantTransaction.getInvoiceNumber());
                response.setTransactionDateTime(merchantTransaction.getTransactionDateTime());
            }
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setErrorCode(result.getErrorCode());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setErrorCode(exception.getCode());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service otcMerchantCancel - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service otcMerchantCancel [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "transaction/query", method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantTransaction(final @RequestBody SymphonyExternalMerchantRequest _request, HttpServletRequest servletRequest) {

        log.info(LogSupport.TRANSACTION_QUERY_EXTERNAL +" ExternalMerchantTransactionId = {} , SymphonyTransactionId = {} , fromDate = {} , toDate = {}, counterId = {}, outletId = {}"
                , _request.getMerchantPgIdentifier(), _request.getExternalMerchantTransactionId(), _request.getSymphonyTransactionId(), _request.getFromDate(), _request.getToDate() , _request.getCounterId(), _request.getOutletId());

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, true);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);
        piPayCustomer.setIsExternalMerchant(true);

        SymphonyExternalMerchantResponse response = new SymphonyExternalMerchantResponse();
        try {

            SymphonyMerchant result = symphonyMerchantService.otcMerchantGetTransactions(piPayCustomer, serviceContext);

            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setErrorCode(result.getErrorCode());
            response.setTransactionList(result.getTransactionList());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setErrorCode(exception.getCode());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service otcMerchantGetTransaction - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service otcMerchantGetTransaction [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "transaction/getstatus", method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantTranasctionStatus(final @RequestBody SymphonyExternalMerchantRequest _request, HttpServletRequest servletRequest) {

        log.info(LogSupport.TRANSACTION_STATUS_EXTERNAL, _request.getMerchantPgIdentifier(), _request.getExternalMerchantTransactionId(), _request.getSymphonyTransactionId());

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant symphonyMerchant = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, symphonyMerchant);
        symphonyMerchant.setIsExternalMerchant(true);

        SymphonyExternalMerchantResponse response = new SymphonyExternalMerchantResponse();
        try {

            SymphonyMerchant result = symphonyMerchantService.getStatusOfMerchantTransaction(symphonyMerchant, serviceContext);

            if (!result.getStatus().equals(RequestStatus.FAILURE.getStatus())){
                MerchantTransaction merchantTransaction = result.getMerchantTransaction();
                response.setExternalMerchantTransactionId(merchantTransaction.getExternalMerchantTransactionId());
                response.setSymphonyTransactionId(merchantTransaction.getSymphonyTransactionId());
                response.setMerchantTxnStatusName(result.getMerchantTxnStatusName());
                if(merchantTransaction.getMerchantPgConnection()!=null){
                    response.setMerchantPgIdentifier(merchantTransaction.getMerchantPgConnection().getIdentifier());
                }
                response.setTransactionAmount(merchantTransaction.getChargeTotal());
                response.setInvoiceNumber(merchantTransaction.getInvoiceNumber());
                response.setTransactionDateTime(merchantTransaction.getTransactionDateTime());
                response.setGeneieReferenceNo(result.getSymphonyReferenceNo());
            }

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setErrorCode(result.getErrorCode());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setErrorCode(exception.getCode());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service validate Discount - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service validate Discount [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "transaction/initiate/qr", method = RequestMethod.POST)
    @ResponseBody
    public Response getEncryptedValueDynamic(final @RequestBody QrCodePaymentRequest _request,HttpServletRequest servletRequest){

        log.info(LogSupport.QR_ENCRYPTION_EXTERNAL, _request.getMerchantPgIdentifier(), _request.getExternalMerchantTransactionId());

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyQrCodePayment piPayQrEncrypted = new SymphonyQrCodePayment();
        BeanUtils.copyProperties(_request, piPayQrEncrypted);

        if (_request.getInvoiceNumber() != null){
            piPayQrEncrypted.setInvoice(_request.getInvoiceNumber());
        }
        piPayQrEncrypted.setIsExternalMerchant(true);

        QrCodePaymentResponse response = new QrCodePaymentResponse();
        try {

            piPayQrEncrypted = symphonyQrCodePaymentService.getDynamicEncryptedText(piPayQrEncrypted, serviceContext);
            response.setQrEncryptedText(piPayQrEncrypted.getQrEncryptedText());
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(piPayQrEncrypted.getMessage());
            response.setErrorCode(piPayQrEncrypted.getErrorCode());
            response.setSymphonyTransactionId(piPayQrEncrypted.getSymphonyTransactionId());
            response.setExternalMerchantTransactionId(piPayQrEncrypted.getExternalMerchantTransactionId());
            response.setIsPayeeExist(null);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setErrorCode(exception.getCode());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getEncryptedValue - Dynamic - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getEncryptedValue - Dynamic - [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    private void setClientIP(final SymphonyExternalMerchantRequest _request, HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}

    private void setClientIP(final QrCodePaymentRequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }

}
