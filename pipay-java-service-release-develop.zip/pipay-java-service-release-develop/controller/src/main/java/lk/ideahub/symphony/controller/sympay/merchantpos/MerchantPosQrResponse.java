package lk.ideahub.symphony.controller.sympay.merchantpos;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.product.sympay.loyalty.entity.CouponInfoDto;
import lk.ideahub.symphony.product.sympay.merchantpos.entity.MerchantPosTransactionData;
import lk.ideahub.symphony.product.sympay.payment.entity.PiPayPayment;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantPosQrResponse extends Response{
	
	private String status;
    private String message;
    
    //coupon data
  	private CouponInfoDto couponInfo;
    private List<CouponInfoDto> couponInfoList;
    private String couponRedemptionStatus;

    private MerchantPosTransactionData merchantPosTransactionData;
    private String transactionStatus;
    
    private MerchantTransaction merchantTransaction;
    
    private String customerPhoneNo;
    
    private PiPayPayment piPayPayment;
}
