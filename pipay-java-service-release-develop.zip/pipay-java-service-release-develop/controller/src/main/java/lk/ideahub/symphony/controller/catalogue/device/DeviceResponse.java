package lk.ideahub.symphony.controller.catalogue.device;

import lk.ideahub.symphony.controller.common.Response;

public class DeviceResponse extends Response {

    // status
    private String status;
    private String message;

    private boolean hasMsisdn;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isHasMsisdn() {
        return hasMsisdn;
    }

    public void setHasMsisdn(boolean hasMsisdn) {
        this.hasMsisdn = hasMsisdn;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("DeviceResponse{");
        sb.append("status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append(", hasMsisdn=").append(hasMsisdn);
        sb.append('}');
        return sb.toString();
    }
}
