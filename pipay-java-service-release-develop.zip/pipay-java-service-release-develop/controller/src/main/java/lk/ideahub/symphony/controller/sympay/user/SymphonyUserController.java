package lk.ideahub.symphony.controller.sympay.user;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.user.entity.SymphonyUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.user.service.SymphonyUserService;

/**
 * Created by Sasika on 07/11/16.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/user", consumes = "application/json", produces = "application/json")
public class SymphonyUserController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyUserController.class);

    private static final String EXPIRE_USERS_PASSWORD_CRON = "switch.expire.users.password.cron";

    @Autowired
    SymphonyUserService symphonyUserService;

    @Autowired
    private Environment environment;

    @RequestMapping(value = "password/expired", method = RequestMethod.POST)
    @ResponseBody
    public Response expireUsersPassword(HttpServletRequest servletRequest) {

        SymphonyUser symphonyUser = new SymphonyUser();
        SymphonyUserRequest _request = new SymphonyUserRequest();

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyUserResponse response = new SymphonyUserResponse();
        try {
            SymphonyUser result= symphonyUserService.expireUsersPassword(symphonyUser, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("User password expired - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("User password expired [request: {}; response: {}]", _request, response);
        }

        return response;

    }
    
    /**
     * Blocking inactive users related service
     * @param servletRequest
     * @return Response
     */
    @RequestMapping(value = "block/inactive/users", method = RequestMethod.POST)
    @ResponseBody
    public Response blockInactiveUsers(final @RequestBody SymphonyUserRequest _request, HttpServletRequest servletRequest) {

        ServiceContext serviceContext = getServiceContext(_request, false);
        SymphonyUser symphonyUser = new SymphonyUser();

        SymphonyUserResponse response = new SymphonyUserResponse();
        
        //stop the process, if client has required to do so
        if(_request.getDisableProcessBlockInactiveUsers() != null && _request.getDisableProcessBlockInactiveUsers().equalsIgnoreCase("Y")) {
        	 response.setStatus(RequestStatus.SUCCESS.getStatus());
             response.setMessage("Process Skipped");
             log.info(LogSupport.CRON_BLOCK_INACTIVE_USER_SKIPPED);
             return response;
        }
        
        //if not continue the process
        try {
        	log.info(LogSupport.CRON_BLOCK_INACTIVE_USER_STARTED + new Date().toString());
            SymphonyUser result= symphonyUserService.blockInactiveUsers(symphonyUser, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            
            log.info(LogSupport.CRON_BLOCK_INACTIVE_USER_COMPLETED);

        } catch (Exception exception) {
            log.error(LogSupport.CRON_BLOCK_INACTIVE_USER_FAILURE + " exception: {}", _request, response, exception);
        	log.error(LogSupport.CRON_BLOCK_INACTIVE_USER_ERROR + exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn(LogSupport.CRON_BLOCK_INACTIVE_USER_FAILURE, _request, response);
        } else {
            log.debug(LogSupport.CRON_BLOCK_INACTIVE_USER_DEBUG_SUCCESS, _request, response);
        }

        return response;

    }

    //@Scheduled(cron = "0 0 0 * * *")
    public void expireUsersPasswordCron() {
        if (environment.getProperty(EXPIRE_USERS_PASSWORD_CRON).equals("ON")) {
            SymphonyUser symphonyUser = new SymphonyUser();
            SymphonyUserRequest _request = new SymphonyUserRequest();

            ServiceContext serviceContext = getServiceContext(_request, false);

            SymphonyUserResponse response = new SymphonyUserResponse();
            try {
                SymphonyUser result = symphonyUserService.expireUsersPassword(symphonyUser, serviceContext);

                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());

            } catch (InvalidRequestException exception) {
                response.setStatus(RequestStatus.FAILURE.getStatus());
                response.setMessage(exception.getMessage());
            }

            if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
                log.warn("User password expired - failure [request: {}; response: {}]", _request, response);
            } else {
                log.debug("User password expired [request: {}; response: {}]", _request, response);
            }
        }
    }

}
