package lk.ideahub.symphony.controller.catalogue.voucher;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.voucherApp.FilterObjects.VoucherObject;
import lk.ideahub.symphony.product.voucherApp.FilterObjects.VoucherPackObject;
import lk.ideahub.symphony.product.voucherApp.FilterObjects.VoucherPurchaseObject;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by kalpana on 11/3/15.
 */
@Getter
@Setter
@ToString
public class VoucherResponse extends Response {
    // merchants
    private List merchants;

    // voucher packs
    private List voucherPacks;

    //redeem vouchers
    private VoucherObject voucher;
    private VoucherPackObject voucherPack;

    // reserve vouchers
    private String reserveId;

    // payment methods
    private List paymentMethodList;

    // status
    private String status;
    private String code;
    private String message;

    //calculate voucher purchase value
    private VoucherPurchaseObject purchaseDetails;

    //purchase voucher
    private Long voucherId;

    //initiate transaction
    private String transactionCode;

    //transaction status check
    private String transactionStatus;
    private BigDecimal purchaseValue;

    private List vouchers;
}
