package lk.ideahub.symphony.controller.sympay.dataMigration;

import lk.ideahub.symphony.controller.sympay.customer.SymphonyCustomerResponse;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.dataMigration.service.DataMigrationService;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


import java.io.*;

/**
 * Created by Anil on 6/8/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/data/migration", consumes = "application/json", produces = "application/json")
public class DataMigrationController extends GenericController{

    private static final Logger log = LoggerFactory.getLogger(DataMigrationController.class);

    private static final String DATA_SHEET_FILE_PATH = "ez.data.sheet.file.path";
    private static final String BI_INTEGRATION_CRON_SWITCH = "switch.biintegration.cron";

    @Autowired
    private Environment environment;

    @Autowired
    private DataMigrationService dataMigrationService;

    @RequestMapping(value = "ez/merchant", method = RequestMethod.POST)
    @ResponseBody
    public Response ezDataMigration() {
        log.info(LogSupport.DATA_MIGRATION_STARTING);
        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        String file = environment.getProperty(DATA_SHEET_FILE_PATH);
        log.info(LogSupport.DATA_MIGRATION_FILE_PATH + file);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            dataMigrationService.ezDataMigration(br);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
        } catch (Exception e) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            log.debug(e.getMessage());
        }
        log.info(LogSupport.DATA_MIGRATION_STATUS+response.getStatus());
        return response;
    }


    @RequestMapping(value = "biIntegration/dataExport", method = RequestMethod.POST)
    @ResponseBody
    public Response biIntegrationDataExport() {
        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        if(environment.getProperty(BI_INTEGRATION_CRON_SWITCH).equals("ON")){
            log.info(LogSupport.BI_INTEGRATION_STARTING);
            try {
                dataMigrationService.businessIntelligenceDataExport();
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                log.info(LogSupport.BI_INTEGRATION_CRON_COMPLETED,response.getStatus());
            } catch (Exception e) {
                log.info(LogSupport.BI_INTEGRATION_CRON_NOT_COMPLETED+response.getStatus());
                response.setStatus(RequestStatus.FAILURE.getStatus());
                log.debug(e.getMessage());
            }
        }
        return response;
    }

}
