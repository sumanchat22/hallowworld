package lk.ideahub.symphony.controller.sympay.customer.touchId;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by mahesha on 4/23/17.
 */
public class SymphonyTouchIdRequest extends Request {

    //request touchId
    private Long customerId;
    private String uid;
    private String PIN;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPIN() {
        return PIN;
    }

    public void setPIN(String PIN) {
        this.PIN = PIN;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyTouchIdRequest {")
                .append("customerId=").append(customerId).append(", ")
                .append("uid='").append(uid).append("'").append(", ")
                //.append("PIN='").append(PIN).append("'")
                .append('}').toString();
    }
}
