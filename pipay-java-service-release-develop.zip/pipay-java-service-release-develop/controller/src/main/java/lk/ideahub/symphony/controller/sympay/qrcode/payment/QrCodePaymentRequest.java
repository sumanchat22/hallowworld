package lk.ideahub.symphony.controller.sympay.qrcode.payment;

import java.util.List;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QrCodePaymentRequest extends Request {

    private Boolean isKhqr;
    private String amount;
    private String invoice;
    private String description;
    private Long merchantId;
    private String merchantName;
    private Long userId;

    // payement info
    private Long customerId;
    private String paymentTransactionToken;
    private String productPrice;
    private String qrEncryptedText;
    private String merchantTransactionId;
    private Long customerPaymentOptionId;
    private String PIN;
    //Instant discount only
    private Long paymentOptionIssuersId;
    //Advanced discount only
    private Long merchantDiscountId;

    private String discountType;

    private String externalMerchantTransactionId;
    private String merchantPgIdentifier;
    private String transactionDateTime;
    private String invoiceNumber;
    
    private String currencyCode;
    private String media;
    private Long counterId;
    private Long outletId;
    
    private List<String> offlineTrxTokenList;
    private String offlineTrxToken;
    private Long transactionId;
    private String osType;
}
