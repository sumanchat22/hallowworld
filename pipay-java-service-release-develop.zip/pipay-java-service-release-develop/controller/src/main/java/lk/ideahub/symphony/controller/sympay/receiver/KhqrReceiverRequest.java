package lk.ideahub.symphony.controller.sympay.receiver;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Created by bunleap on 04/05/22.
 */
@Getter
@Setter
public class KhqrReceiverRequest extends Request {

    private String appType;

    // For customer
    private Long customerId;

    // For merchant
    private Long counterId;
    private Long merchantId;
    private Long outletId;
    private String deviceId;

    private String currencyCode;
    private BigDecimal amount;

    @Override
    public String toString() {
        return "KhqrReceiverRequest{" +
                "customerId=" + customerId +
                "counterId=" + counterId +
                "merchantId=" + merchantId +
                "outletId=" + outletId +
                "deviceId=" + deviceId +
                ", currencyCode='" + currencyCode + '\'' +
                ", amount=" + amount +
                '}';
    }
}
