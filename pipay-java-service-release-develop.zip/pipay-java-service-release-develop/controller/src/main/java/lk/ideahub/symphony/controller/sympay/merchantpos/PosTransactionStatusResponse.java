package lk.ideahub.symphony.controller.sympay.merchantpos;

import com.fasterxml.jackson.databind.JsonNode;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.transactionHistory.entity.Transactions;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PosTransactionStatusResponse extends Response{

	private String message;
    private String status;
    
    //status check
    private Boolean isTransactionCompleted;
    private Transactions transaction;
    
}
