package lk.ideahub.symphony.controller.sympay.amex;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by mahesha on 3/9/17.
 */
public class SymphonyAMEXRequest extends Request {

    private Long customerId;
    private Long regTransactionId;
    private String cardAlias;


    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getRegTransactionId() {
        return regTransactionId;
    }

    public void setRegTransactionId(Long regTransactionId) {
        this.regTransactionId = regTransactionId;
    }

    public String getCardAlias() {
        return cardAlias;
    }

    public void setCardAlias(String cardAlias) {
        this.cardAlias = cardAlias;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyAMEXRequest {")
                .append("customerId=").append(customerId).append(", ")
                .append("regTransactionId=").append(regTransactionId).append(", ")
                .append("cardAlias='").append(cardAlias).append("'")
                .append('}').toString();
    }
}
