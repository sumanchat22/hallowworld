package lk.ideahub.symphony.controller.sympay.amex;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by mahesha on 3/9/17.
 */
public class SymphonyAMEXResponse extends Response {

    private String secureUrl;
    private String securityToken;
    private Long regTransactionId;
    private Long customerAMEXCardId;
    private String regStatus;
    private Long customerPaymentOptionId;
    private String status;
    private String message;

    public String getSecureUrl() {
        return secureUrl;
    }

    public void setSecureUrl(String secureUrl) {
        this.secureUrl = secureUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSecurityToken() {
        return securityToken;
    }

    public void setSecurityToken(String securityToken) {
        this.securityToken = securityToken;
    }

    public Long getRegTransactionId() {
        return regTransactionId;
    }

    public void setRegTransactionId(Long regTransactionId) {
        this.regTransactionId = regTransactionId;
    }

    public Long getCustomerAMEXCardId() {
        return customerAMEXCardId;
    }

    public void setCustomerAMEXCardId(Long customerAMEXCardId) {
        this.customerAMEXCardId = customerAMEXCardId;
    }

    public String getRegStatus() {
        return regStatus;
    }

    public void setRegStatus(String regStatus) {
        this.regStatus = regStatus;
    }

    public Long getCustomerPaymentOptionId() {
        return customerPaymentOptionId;
    }

    public void setCustomerPaymentOptionId(Long customerPaymentOptionId) {
        this.customerPaymentOptionId = customerPaymentOptionId;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyAMEXResponse {")
                .append("secureUrl='").append(secureUrl).append("'").append(", ")
               // .append("securityToken='").append(securityToken).append("'").append(", ")
                .append("regTransactionId=").append(regTransactionId).append(", ")
                .append("customerAMEXCardId=").append(customerAMEXCardId).append(", ")
                .append("regStatus='").append(regStatus).append("'").append(", ")
                .append("customerPaymentOptionId=").append(customerPaymentOptionId).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
