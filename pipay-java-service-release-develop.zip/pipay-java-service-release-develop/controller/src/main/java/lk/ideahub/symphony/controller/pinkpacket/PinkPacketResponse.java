package lk.ideahub.symphony.controller.pinkpacket;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacket;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacketFriendDto;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacketGroup;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacketGroupInfoDto;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacketInfoDto;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacketSummaryDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class PinkPacketResponse extends Response{

	private String status;
    private String message;
    private PinkPacket pinkPacket;
    private PinkPacketGroup pinkPacketGroup;
    private PinkPacketInfoDto pinkPacketInfo;
    
    //history
    private PinkPacketGroupInfoDto pinkPacketGroupInfo;
  	private List<PinkPacketInfoDto> pinkPacketList;
  	private List<PinkPacketGroupInfoDto> pinkPacketGroupList;
  	private List<PinkPacketFriendDto> unAcceptedFriends;
  	private List<PinkPacketSummaryDto> summaryInfo;
  	
  	//external responses
  	private String externalResponseCode;
  	private String externalResponseMessage;
  	
  	private String packetMessage;
}
