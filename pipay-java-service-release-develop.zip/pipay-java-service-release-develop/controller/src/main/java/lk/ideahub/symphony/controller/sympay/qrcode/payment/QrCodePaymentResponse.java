package lk.ideahub.symphony.controller.sympay.qrcode.payment;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.merchant.entity.MerchantPgConnection;
import lk.ideahub.symphony.modules.types.entity.MerchantTransactionType;
import lk.ideahub.symphony.modules.types.entity.MerchantTxnStatus;
import lk.ideahub.symphony.product.sympay.customer.entity.SurchargeEnablePO;
import lk.ideahub.symphony.product.sympay.friend.entity.FriendDto;
import lk.ideahub.symphony.product.sympay.payee.entiry.SymphonyPayee;
import lk.ideahub.symphony.product.sympay.pipay.external.entity.ExternalDiscountData;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.DiscountDetail;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.QrCodeVerificationData;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class QrCodePaymentResponse extends Response{

	private String QrEncryptedText;
    private QrCodeVerificationData qrCodeVerificationData;
    private List<String> QrEncryptedTexts;
	private Long transactionId;
	private List<SurchargeEnablePO> surchargeEnablePOList;

	//getTxnStatus
	private MerchantTxnStatus transactionStatus;
	private MerchantTransactionType transactionType;
	private BigDecimal chargeTotal;
	private String currency;
	private String paymentMethod;
	private String invoiceNumber;
	private String otherInfo;
	private String merchantPgIdentifier;
	private String trxnReferenceNumber;
	private MerchantPgConnection merchantPgConnection;
	private SymphonyPayee billQrDetails;
	private Boolean isPayeeExist;

	// status
    private String status;
    private String message;

	private DiscountDetail discountDetail;
	private String errorCode;

	//Value after reduce discount
	private BigDecimal grossAmount;
	private String externalMerchantTransactionId;
	private String symphonyTransactionId;
	private Boolean qrScannedStatus;

	//friend QR code scan
	private FriendDto friendDto;

	@Override
	public String toString() {
		return new StringBuilder("QrCodePaymentResponse {")
				.append("QrEncryptedText='").append(QrEncryptedText).append("'").append(", ")
				.append("qrCodeVerificationData=").append(qrCodeVerificationData).append(", ")
				.append("QrEncryptedTexts=").append(QrEncryptedTexts).append(", ")
				.append("transactionId=").append(transactionId).append(", ")
				.append("surchargeEnablePOList=").append(surchargeEnablePOList).append(", ")
				.append("transactionStatus=").append(transactionStatus).append(", ")
				.append("transactionType=").append(transactionType).append(", ")
				.append("chargeTotal=").append(chargeTotal).append(", ")
				.append("currency='").append(currency).append("'").append(", ")
				.append("paymentMethod='").append(paymentMethod).append("'").append(", ")
				.append("invoiceNumber='").append(invoiceNumber).append("'").append(", ")
				.append("otherInfo='").append(otherInfo).append("'").append(", ")
				.append("merchantPgIdentifier='").append(merchantPgIdentifier).append("'").append(", ")
				.append("trxnReferenceNumber='").append(trxnReferenceNumber).append("'").append(", ")
				.append("merchantPgConnection=").append(merchantPgConnection).append(", ")
				.append("qrScannedStatus=").append(qrScannedStatus).append(", ")
				.append("status='").append(status).append("'").append(", ")
				.append("message='").append(message).append("'")
				.append('}').toString();
	}
}
