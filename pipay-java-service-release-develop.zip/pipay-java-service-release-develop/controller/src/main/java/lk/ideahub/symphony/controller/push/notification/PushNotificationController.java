package lk.ideahub.symphony.controller.push.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.catalogue.notification.entity.PushNotification;
import lk.ideahub.symphony.product.catalogue.notification.service.PushNotificationService;

/**
 * Created by samith on 7/19/15.
 */
@Controller
@RequestMapping(value = "catalogue/notification")
public class PushNotificationController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(PushNotificationController.class);

    @Autowired
    PushNotificationService pushNotificationService;

    @RequestMapping(value = "send/message", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public Response sendPushMessage(final @RequestBody PushRequest _request,
                                final @RequestHeader(value = "msisdn", required = false) String _msisdn){

        /*if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }*/

        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        PushNotification pushNotification = new PushNotification();
        BeanUtils.copyProperties(_request, pushNotification);

        PushResponse response = new PushResponse();
        try {
            pushNotificationService.send(pushNotification, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service send push notification - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service send push notification [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    @RequestMapping(value = "send/quick", method = RequestMethod.GET )
    @ResponseBody
    public Response sendPushQuick(final @RequestParam("id") Long id ,final @RequestParam("message") String message,
                                    final @RequestHeader(value = "msisdn", required = false) String _msisdn){

        /*if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }

        _request.setPhone(_msisdn);*/
        PushRequest _request = new PushRequest();
        _request.setDealId(id.toString());

        ServiceContext serviceContext = getServiceContext(_request, false);

        PushNotification pushNotification = new PushNotification();
        pushNotification.setDealId(id);
        pushNotification.setMessage(message);

        PushResponse response = new PushResponse();
        try {
            pushNotificationService.send(pushNotification, serviceContext);

            response.setHasMsisdn(_request.getPhone() != null);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service send push notification - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service send push notification [request: {}; response: {}]", _request, response);
        }
        return response;

    }
}