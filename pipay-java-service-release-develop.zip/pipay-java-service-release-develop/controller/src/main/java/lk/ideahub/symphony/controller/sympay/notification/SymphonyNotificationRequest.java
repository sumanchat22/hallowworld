package lk.ideahub.symphony.controller.sympay.notification;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 1/24/19.
 */
@Getter
@Setter
@ToString
public class SymphonyNotificationRequest extends Request {

    private Long pushNotificationId;
    private Boolean isAll;
    private Long[] customerIdList;
    private Long userId;
    private Long customerId;
    private Long notificationAuditId;

    private Integer androidTotalSuccessCount;
    private Integer iosTotalSuccessCount;
    private Integer androidTotalFailureCount;
    private Integer iosTotalFailureCount;
    private String androidErrorResponsesList;
    private String iosErrorResponsesList;
    private Boolean isExpirationProcessDisabled;
    private List<Long> osTypeIdList;
    private Boolean isTopic;
}
