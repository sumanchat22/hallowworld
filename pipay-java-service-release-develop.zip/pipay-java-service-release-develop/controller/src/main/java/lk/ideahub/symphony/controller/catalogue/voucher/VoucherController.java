package lk.ideahub.symphony.controller.catalogue.voucher;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.voucherApp.voucher.entity.VoucherApp;
import lk.ideahub.symphony.product.voucherApp.voucher.service.VoucherAppService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 * Created by kalpana on 11/3/15.
 */

@Controller
@RequestMapping(value = "vouchers/1.0/voucher", consumes = "application/json", produces = "application/json")
@Configuration
public class VoucherController extends GenericController
{
    private static final Logger log = LoggerFactory.getLogger(VoucherController.class);

    @Autowired
    VoucherAppService voucherAppService;

    // -------------------------- Get Merchants -------------------------------------
    @RequestMapping(value = "merchants", method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchants(final @RequestBody VoucherRequest _request) {

       ServiceContext serviceContext = getServiceContext(_request, true);

       VoucherApp voucherApp = new VoucherApp();

       BeanUtils.copyProperties(_request, voucherApp);

       VoucherResponse response = new VoucherResponse();

        try
        {

            VoucherApp result = voucherAppService.getMerchants(voucherApp, serviceContext);
            response.setMerchants(result.getMerchants());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getMerchants - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getMerchants [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    // -------------------------- Get Voucher Packs -------------------------------------
    @RequestMapping(value = "packs", method = RequestMethod.POST)
    @ResponseBody
    public Response getVoucherPacks(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.getVoucherPacks(voucherApp, serviceContext);

                response.setVoucherPacks(result.getVoucherPacks());
                response.setStatus(result.getStatus());
                response.setCode(result.getStatusCode());
                response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getVoucherPacks - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getVoucherPacks [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //url mapping for reserve vouchers
    @RequestMapping(value = "reserve", method = RequestMethod.POST)
    @ResponseBody
    public Response reserveVoucherPacks(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.reserveVoucherPacks(voucherApp, serviceContext);

            response.setPurchaseDetails(result.getPurchaseDetails());
            response.setReserveId(result.getReserveId());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());

        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service reserveVoucherPacks - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service reserveVoucherPacks [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //url mapping for get payment methods for vouchers packs
    @RequestMapping(value = "payment-methods", method = RequestMethod.POST)
    @ResponseBody
    public Response getPaymentMethods(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);
        VoucherApp voucherApp = new VoucherApp();
        BeanUtils.copyProperties(_request, voucherApp);
        VoucherResponse response = new VoucherResponse();

        try {
            VoucherApp result = voucherAppService.getPaymentMethods(voucherApp, serviceContext);

            response.setPaymentMethodList(result.getPaymentMethods());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getPaymentMethods - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getPaymentMethods [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //url mapping for purchase vouchers
    @RequestMapping(value = "purchase", method = RequestMethod.POST)
    @ResponseBody
    public Response purchaseVoucher(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.purchaseVoucher(voucherApp, serviceContext);

            response.setVoucherId(result.getVoucherId());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service purchaseVoucher - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service purchaseVoucher [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //url mapping for calculate purchased value for vouchers
    @RequestMapping(value = "calculate/purchase/value", method = RequestMethod.POST)
    @ResponseBody
    public Response calculatePurchasedValue(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.calculatePurchasedValue(voucherApp, serviceContext);

            response.setPurchaseDetails(result.getPurchaseDetails());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service calculatePurchasedValue - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service calculatePurchasedValue [request: {}; response: {}]", _request, response);
        }
        return response;

    }


    //url mapping for release vouchers
    @RequestMapping(value = "release", method = RequestMethod.POST)
    @ResponseBody
    public Response releaseVoucher(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.releaseVoucher(voucherApp, serviceContext);

            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service releaseVoucher - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service releaseVoucher [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //url mapping for redeem vouchers
    @RequestMapping(value = "redeem", method = RequestMethod.POST)
    @ResponseBody
    public Response redeemVoucher(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.redeemVoucher(voucherApp, serviceContext);

            response.setVoucher(result.getVoucher());
            response.setVoucherPack(result.getVoucherPack());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service redeemVoucher - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service redeemVoucher [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //url mapping for redeem voucher confirmation
    @RequestMapping(value = "redeem/confirm", method = RequestMethod.POST)
    @ResponseBody
    public Response confirmRedeemVoucher(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.confirmRedeemVoucher(voucherApp, serviceContext);

            response.setVoucher(result.getVoucher());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service redeemConfirmVoucher - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service redeemConfirmVoucher [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //--------------- release voucher cron ---------------------------------
    //@Scheduled(fixedRate=420000)
    @RequestMapping(value = "release/cron", method = RequestMethod.POST)
    @ResponseBody
    public void releaseVoucherCron() {

        ServiceContext serviceContext = new ServiceContext();

        VoucherApp voucherApp = new VoucherApp();

        VoucherResponse response = new VoucherResponse();

        try {

            log.info("every 3 minutes");
            VoucherApp result = voucherAppService.releaseVoucherCron(voucherApp, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }

        catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service releaseVoucherCron - failure [response: {}]", response);
        } else {
            log.debug("Service releaseVoucherCron [response: {}]", response);
        }

    }

    //--------------- Resend Voucher Details ---------------------------------
    @RequestMapping(value = "resend", method = RequestMethod.POST)
    @ResponseBody
    public Response resendVoucher(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.resendVoucher(voucherApp, serviceContext);

            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service redeemConfirmVoucher - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service redeemConfirmVoucher [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //--------------- Initiate Transaction in Open IPG ---------------------------------
    @RequestMapping(value = "initiate/transaction", method = RequestMethod.POST)
    @ResponseBody
    public Response initiateTransaction(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.initiateTransaction(voucherApp, serviceContext);

            response.setTransactionCode(result.getTransactionCode());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service initiateTransaction - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service initiateTransaction [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //--------------- Complete Transaction in Open IPG ---------------------------------
    @RequestMapping(value = "complete/transaction", method = RequestMethod.POST)
    @ResponseBody
    public Response completeTransaction(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.completeTransaction(voucherApp, serviceContext);

            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service completeTransaction - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service completeTransaction [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    //--------------- Transaction status Check in Open IPG ---------------------------------
    @RequestMapping(value = "transaction/status/check", method = RequestMethod.POST)
    @ResponseBody
    public Response transactionStatusCheck(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.transactionStatusCheck(voucherApp, serviceContext);

            response.setTransactionStatus(result.getTransactionStatus());
            response.setPurchaseValue(result.getPurchaseValue());
            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service transactionStatusCheck - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service transactionStatusCheck [request: {}; response: {}]", _request, response);
        }
        return response;

    }
    //--------------- Resend Voucher Details ---------------------------------
    @RequestMapping(value = "check/timedOut/payment", method = RequestMethod.POST)
    @ResponseBody
    public Response checkTimedOutPayment(final @RequestBody VoucherRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        VoucherApp voucherApp = new VoucherApp();

        BeanUtils.copyProperties(_request, voucherApp);

        VoucherResponse response = new VoucherResponse();

        try {

            VoucherApp result = voucherAppService.checkTimedOutPayment(voucherApp, serviceContext);

            response.setStatus(result.getStatus());
            response.setCode(result.getStatusCode());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service checkTimedOutPayment - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service checkTimedOutPayment [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    @RequestMapping(value = "list/purchased/vouchers", method = RequestMethod.POST)
    @ResponseBody
    public Response listVouchers(final @RequestBody VoucherRequest _request) {
        ServiceContext serviceContext = getServiceContext(_request, true);
        VoucherApp voucherApp = new VoucherApp();
        BeanUtils.copyProperties(_request, voucherApp);
        VoucherResponse response = new VoucherResponse();
        try {
            VoucherApp result = voucherAppService.listVouchers(voucherApp, serviceContext);

            response.setVouchers(result.getVouchers());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }


        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service voucher listVouchers - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service voucher listVouchers [request: {}; response: {}]", _request, response);
        }
        return response;

    }

    @RequestMapping(value = "gift/purchased/voucher", method = RequestMethod.POST)
    @ResponseBody
    public Response giftVoucher(final @RequestBody VoucherRequest _request) {
        ServiceContext serviceContext = getServiceContext(_request, false);
        VoucherApp voucherApp = new VoucherApp();
        BeanUtils.copyProperties(_request, voucherApp);
        VoucherResponse response = new VoucherResponse();
        try {
            VoucherApp result = voucherAppService.giftVoucher(voucherApp, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }


        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service voucher giftVoucher - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service voucher giftVoucher [request: {}; response: {}]", _request, response);
        }
        return response;
    }


}
