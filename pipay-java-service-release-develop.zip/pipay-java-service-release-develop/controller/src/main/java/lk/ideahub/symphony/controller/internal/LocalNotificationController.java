package lk.ideahub.symphony.controller.internal;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.service.CustomerService;
import lk.ideahub.symphony.modules.external.ExternalServiceResponseCodes;
import lk.ideahub.symphony.modules.external.PushExternalDto;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.notification.entity.LoyaltyNotificationDto;
import lk.ideahub.symphony.product.sympay.notification.service.helper.NotificationHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Locale;

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/service/internal/notification")
public class LocalNotificationController extends GenericController{

private static final Logger log = LoggerFactory.getLogger(LocalNotificationController.class);

	@Autowired
	private NotificationHelper notificationHelper;

    @Autowired
    private CustomerService customerService;
	
	@RequestMapping(value = "send/push", method = RequestMethod.POST)
    @ResponseBody
    public Response sendPush(final @RequestBody ExternalServiceRequest request, HttpServletRequest servletRequest) {

		log.info(LogSupport.EXT_NOTIFICATION_CONTROLLER + "send push phone no: " + request.getPhoneNo());
		log.info(LogSupport.EXT_NOTIFICATION_CONTROLLER + "Notification type: " + request.getNotificationType());

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);



        LoyaltyNotificationDto loyaltyNotificationDto = new LoyaltyNotificationDto();
        BeanUtils.copyProperties(request, loyaltyNotificationDto);

        Customer customer = new Customer();
        customer.setPhone1(loyaltyNotificationDto.getPhoneNo());
        List<Customer> customerList = customerService.findActiveCustomerFromMsisdn(customer,serviceContext);

        if (customerList.size() == 1) {
            customer = customerList.get(0);
            String customerLanguage = customer.getLanguage().getCode();
            Locale localeCustomer = Locale.ENGLISH;
            if(Constants.LANG_CHINESE.equalsIgnoreCase(customerLanguage)) {
                localeCustomer = Locale.CHINESE;
            } else if(Constants.LANG_KHMER.equalsIgnoreCase(customerLanguage)) {
                localeCustomer = new Locale("km");
            }
            serviceContext.setLocale(localeCustomer);
        }

        PushExternalResponse response = new PushExternalResponse();
        try {
        	PushExternalDto result = notificationHelper.callExternalNotification(loyaltyNotificationDto, serviceContext);

            response.setTotalDeviceCount(result.getTotalDeviceCount());
            response.setSentDeviceCount(result.getSentDeviceCount());
            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.EXT_NOTIFICATION_CONTROLLER + "send push error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setStatus(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("notificationHelper callExternalNotification - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("notificationHelper callExternalNotification [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	private void setClientIP(final ExternalServiceRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
