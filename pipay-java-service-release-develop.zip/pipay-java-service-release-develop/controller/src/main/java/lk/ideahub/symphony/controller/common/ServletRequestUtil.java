package lk.ideahub.symphony.controller.common;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServletRequestUtil {

	private static final Logger log = LoggerFactory.getLogger(ServletRequestUtil.class);

	public static String getClientIP(HttpServletRequest request) {
		String ipAddress = "";
		try {
			ipAddress = request.getHeader("X-FORWARDED-FOR");
			if (ipAddress == null) {
				ipAddress = request.getRemoteAddr();
			}

		} catch (Exception e) {
			log.error("Client IP adress access error" + e);
		}
		return ipAddress;
	}
}
