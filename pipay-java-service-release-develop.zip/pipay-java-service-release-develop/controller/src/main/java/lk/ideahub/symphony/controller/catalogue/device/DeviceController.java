package lk.ideahub.symphony.controller.catalogue.device;

import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.product.catalogue.device.entity.CatalogueDeviceToken;
import lk.ideahub.symphony.product.catalogue.device.service.CatalogueDeviceTokenService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;

import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Controller
@RequestMapping(value = "catalogue/device", consumes = "application/json", produces = "application/json")
public class DeviceController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(DeviceController.class);

    @Autowired
    CatalogueDeviceTokenService catalogueDeviceTokenService;

    @RequestMapping(value = "add/token", method = RequestMethod.POST)
    @ResponseBody
    public Response addAppToken(final @RequestBody DeviceRequest _request,
                                final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        /*if (_msisdn == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }*/
        _request.setPhone_1(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueDeviceToken deviceToken = new CatalogueDeviceToken();
        BeanUtils.copyProperties(_request, deviceToken);

        DeviceResponse response = new DeviceResponse();
        try {
            catalogueDeviceTokenService.add(deviceToken, serviceContext);

            response.setHasMsisdn(_request.getPhone_1() != null);
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service add app token - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service add app token [request: {}; response: {}]", _request, response);
        }
        return response;
    }
}