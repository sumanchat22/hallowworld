package lk.ideahub.symphony.controller.sympay.device;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by samith on 6/7/16.
 */
public class SymphonyDeviceResponse extends Response{

    // status
    private String errorCode;
    private String status;
    private String message;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyDeviceResponse{");
        sb.append("status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
