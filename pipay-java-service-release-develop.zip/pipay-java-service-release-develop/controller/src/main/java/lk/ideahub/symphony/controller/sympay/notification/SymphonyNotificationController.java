package lk.ideahub.symphony.controller.sympay.notification;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.notification.entity.SymphonyNotification;
import lk.ideahub.symphony.product.sympay.notification.service.SymphonyNotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 1/24/19.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/notification", consumes = "application/json", produces = "application/json")
public class SymphonyNotificationController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyNotificationController.class);

    @Autowired
    private SymphonyNotificationService symphonyNotificationService;

    @RequestMapping(value = "send/marketing/bulk", method = RequestMethod.POST)
    @ResponseBody
    public Response sendBulk(final @RequestBody SymphonyNotificationRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);

        try {
            SymphonyNotification result = symphonyNotificationService.sendBulkPushNotifications(symphonyNotification, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service send bulk notifications - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service send bulk notifications [request: {}; response: {}]", request, response);
        }
        return response;
    }
    @RequestMapping(value = "send/payment/reminder/bulk", method = RequestMethod.POST)
    @ResponseBody
    public Response sendPaymentReminderBulk(final @RequestBody SymphonyNotificationRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);

        try {
            SymphonyNotification result = symphonyNotificationService.sendPaymentReminderNotifications(symphonyNotification, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service send bulk notifications - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service send bulk notifications [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/summary", method = RequestMethod.POST)
    @ResponseBody
    public Response getSummary(final @RequestBody SymphonyNotificationRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);

        try {
            SymphonyNotification result = symphonyNotificationService.getSummary(symphonyNotification, serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            response.setDeliveryStatus(result.getDeliveryStatus());
            response.setTotalActiveCount(result.getTotalActiveCount());
            response.setTotalRequestedCount(result.getTotalRequestedCount());
            response.setAndroidStatus(result.getAndroidStatus());
            response.setIosStatus(result.getIosStatus());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getSummary - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getSummary [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "push/event", method = RequestMethod.POST)
    @ResponseBody
    public Response sendPushForEvent(final @RequestBody SymphonyNotificationRequest request,  HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);
        try {
            if(request.getIsExpirationProcessDisabled()) {
                log.info(LogSupport.NOTIFICATION_SEND_PUSH_FOR_BDAY_CUSTOMERS + " Cron Job disabled..");
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
            }
            log.info(LogSupport.NOTIFICATION_SEND_PUSH_FOR_BDAY_CUSTOMERS + " Cron Job Started..");
            SymphonyNotification result = symphonyNotificationService.sendPushForEvent(serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.NOTIFICATION_SEND_PUSH_FOR_BDAY_CUSTOMERS + " Cron Job Completed..");
        } catch (InvalidRequestException exception) {
            log.error("Service sendPushForEvent - failure [exception: {}]", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.NOTIFICATION_SEND_PUSH_FOR_BDAY_CUSTOMERS + " Cron Job Ended With Errors..");
        }
        return response;
    }

    @RequestMapping(value = "send/push", method = RequestMethod.POST)
    @ResponseBody
    public Response sendPush(final @RequestBody SymphonyNotificationRequest request,  HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);
        try{
            if(request.getIsExpirationProcessDisabled()) {
                log.info(LogSupport.NOTIFICATION_COMMON_CRON + " Cron Job disabled..");
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
            }
            log.info(LogSupport.NOTIFICATION_COMMON_CRON + " Cron Job Started..");
            SymphonyNotification result = symphonyNotificationService.sendPush(serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.NOTIFICATION_COMMON_CRON + " Cron Job Completed..");
        } catch (InvalidRequestException exception) {
            log.error("Service sendPush - failure [exception: {}]", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.NOTIFICATION_COMMON_CRON + " Cron Job Ended With Errors..");
        }
        return response;
    }

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response listNotifications(final @RequestBody SymphonyNotificationRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);

        try {
            SymphonyNotification result = symphonyNotificationService.listNotifications(symphonyNotification, serviceContext);
            response.setCode(result.getErrorCode());
            response.setNotificationList(result.getNotificationList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service listNotifications - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service listNotifications [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    @ResponseBody
    public Response updateNotification(final @RequestBody SymphonyNotificationRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        SymphonyNotificationResponse response = new SymphonyNotificationResponse();
        SymphonyNotification symphonyNotification = new SymphonyNotification();
        BeanUtils.copyProperties(request, symphonyNotification);

        try {
            SymphonyNotification result = symphonyNotificationService.updateNotifications(symphonyNotification, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateNotifications - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service updateNotifications [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyNotificationRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }


}

