package lk.ideahub.symphony.controller.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import lk.ideahub.symphony.modules.test.service.TestService;

@Controller
@RequestMapping(value = "test", consumes = "application/json", produces = "application/json")
public class TestController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(TestController.class);

    @Autowired
    TestService testService;

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public Response test(final @RequestBody TestRequest _request, final @RequestHeader HttpHeaders _headers) {
        ServiceContext serviceContext = getServiceContext(_request, false);

        TestResponse response = new TestResponse();
        response.setUtc(Utils.getCurrentUtcDate());
        response.setHeaders(_headers.toString());
        response.setRequestData(_request != null ? _request.toString().replaceFirst("^TestRequest \\{", "{") : "");
        response.setDbStatus(testService.getDbStatus(serviceContext));

        log.debug("Service test [request: {}; response: {}]", _request, response);
        return response;
    }
}
