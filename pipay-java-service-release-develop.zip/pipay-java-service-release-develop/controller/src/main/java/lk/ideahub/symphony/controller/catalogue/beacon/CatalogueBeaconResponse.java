package lk.ideahub.symphony.controller.catalogue.beacon;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;

public class CatalogueBeaconResponse extends Response {

    // notification list
    private Integer notificationCount;
    private boolean hasMsisdn;
    private List beaconNotifications;

    // status
    private String status;
    private String message;

    public Integer getNotificationCount() {
        return notificationCount;
    }

    public void setNotificationCount(Integer notificationCount) {
        this.notificationCount = notificationCount;
    }

    public boolean isHasMsisdn() {
        return hasMsisdn;
    }

    public void setHasMsisdn(boolean hasMsisdn) {
        this.hasMsisdn = hasMsisdn;
    }

    public List getBeaconNotifications() {
        return beaconNotifications;
    }

    public void setBeaconNotifications(List beaconNotifications) {
        this.beaconNotifications = beaconNotifications;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return new StringBuilder("CatalogueBeaconResponse {")
                .append("notificationCount=").append(notificationCount).append(", ")
                .append("hasMsisdn=").append(hasMsisdn).append(", ")
                .append("beaconNotifications=").append(beaconNotifications).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
