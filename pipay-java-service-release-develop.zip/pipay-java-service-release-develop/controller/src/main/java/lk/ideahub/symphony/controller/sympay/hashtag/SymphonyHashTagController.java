package lk.ideahub.symphony.controller.sympay.hashtag;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.*;
import lk.ideahub.symphony.product.sympay.hashtag.entity.SymphonyHashTag;
import lk.ideahub.symphony.product.sympay.hashtag.service.SymphonyHashTagService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 12/7/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/hash/tag", consumes = "application/json", produces = "application/json")
public class SymphonyHashTagController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyHashTagController.class);

    @Autowired
    private SymphonyHashTagService symphonyHashTagService;

    @RequestMapping(value = "get/active/tags", method = RequestMethod.POST)
    @ResponseBody
    public Response getActiveTags(final @RequestBody SymphonyHashTagRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyHashTag symphonyHashTag = new SymphonyHashTag();
        BeanUtils.copyProperties(request, symphonyHashTag);

        SymphonyHashTagResponse response = new SymphonyHashTagResponse();

        try {
            SymphonyHashTag result = symphonyHashTagService.getActiveTags(symphonyHashTag, serviceContext);
            response.setHashTagList(result.getHashTagList());
            response.setTotalTags(result.getTotalTags());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getActiveTags - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getActiveTags - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getActiveTags [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyHashTagRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
