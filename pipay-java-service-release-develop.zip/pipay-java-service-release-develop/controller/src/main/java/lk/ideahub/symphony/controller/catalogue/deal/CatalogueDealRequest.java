package lk.ideahub.symphony.controller.catalogue.deal;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CatalogueDealRequest extends Request {

    // common
    private String phone;
    private Long dealId;
    private List<Long> dealIdList;

    // deal list
    private String category;
    private String searchText;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private BigDecimal maxDistance;
    private String isVoucher;
    private List<Long> currentIdList;

    // reserve, purchase, gift
    private String reserveId;
    private String paymentMethod;
    private Long outletId;
    private String receiverPhone;
    private String giftMessage;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "IST")
    private Date deliveryDate;

    // comments
    private String author;
    private String commentText;
    private String authenticationId;
    private String authenticationMethod;

    //like , comment
    private Long customerId;
}
