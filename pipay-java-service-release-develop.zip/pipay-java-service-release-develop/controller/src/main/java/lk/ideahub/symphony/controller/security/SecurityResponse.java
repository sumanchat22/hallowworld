package lk.ideahub.symphony.controller.security;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;

import javax.servlet.http.HttpServletResponse;

@Getter
@Setter
@JsonRootName(value = "response")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SecurityResponse extends Response{

    String status;
    String message;
    String code= "10001";
    String description="Your session has timed out. Please sign in again.";

}
