package lk.ideahub.symphony.controller.sympay.card;

import java.util.List;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.card.entity.CASADetails;
import lk.ideahub.symphony.product.sympay.card.entity.CardListDetails;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lk.ideahub.symphony.modules.types.entity.PaymentOptionType;

/**
 * Created by samith on 11/4/15.
 */
@Getter
@Setter
@ToString
public class SymphonyCardRegisterResponse extends Response {

    //payment options list
    private int paymentOptionsCount;
    private List paymentOptions;
    private Object bankIdentificationNumber;
    private Object paymentOption;
    private Object cardListDetails;
    private CASADetails casaDetails;
    private CardListDetails unfilterCardList;
    private Boolean isAvailablePaymentOptionsBlocked;

    // status
    private String status;
    private String message;
    private List<PaymentOptionType> paymentOptionTypes;
    private String displayMessage;

}

