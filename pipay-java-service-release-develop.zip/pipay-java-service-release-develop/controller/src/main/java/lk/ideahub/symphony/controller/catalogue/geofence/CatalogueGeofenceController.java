package lk.ideahub.symphony.controller.catalogue.geofence;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.catalogue.geofence.entity.CatalogueGeofence;
import lk.ideahub.symphony.product.catalogue.geofence.entity.CatalogueGeofenceNotification;
import lk.ideahub.symphony.product.catalogue.geofence.service.CatalogueGeofenceBeaconNotificationService;
import lk.ideahub.symphony.product.catalogue.geofence.service.CatalogueGeofenceNotificationService;
import lk.ideahub.symphony.product.catalogue.geofence.service.CatalogueGeofenceService;

/**
 * Created by samith on 8/13/15.
 */
@Controller
@RequestMapping(value = "catalogue/geofences", consumes = "application/json", produces = "application/json")
public class CatalogueGeofenceController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(CatalogueGeofenceController.class);

    @Autowired
    CatalogueGeofenceService catalogueGeofenceService;

    @Autowired
    CatalogueGeofenceNotificationService catalogueGeofenceNotificationService;

    @Autowired
    CatalogueGeofenceBeaconNotificationService catalogueGeofenceBeaconNotificationService;

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public Response geofences(final @RequestBody CatalogueGeofenceRequest _request,
                                  final @RequestHeader(value = "msisdn", required = false) String _msisdn) {

        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueGeofence catalogueGeofence = new CatalogueGeofence();
        BeanUtils.copyProperties(_request, catalogueGeofence);

        List geofences = catalogueGeofenceService.geofences(catalogueGeofence, serviceContext);

        CatalogueGeofenceResponse response = new CatalogueGeofenceResponse();
        response.setGeofences(geofences);
        response.setHasMsisdn(_request.getPhone() != null);
        response.setGeofenceCount(geofences != null ? geofences.size() : 0);


        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service geofences - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service geofences [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "notifications", method = RequestMethod.POST)
    @ResponseBody
    public Response notifications(final @RequestBody CatalogueGeofenceNotificationRequest _request,
                              final @RequestHeader(value = "msisdn", required = false) String _msisdn) {

        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueGeofenceNotification catalogueGeofenceNotification = new CatalogueGeofenceNotification();
        BeanUtils.copyProperties(_request, catalogueGeofenceNotification);

        List notifications = catalogueGeofenceNotificationService.notifications(catalogueGeofenceNotification, serviceContext);

        CatalogueGeofenceNotificationResponse response = new CatalogueGeofenceNotificationResponse();
        response.setGeofenceNotifications(notifications);
        response.setHasMsisdn(_request.getPhone() != null);
        response.setGeofenceNotificationCount(notifications != null ? notifications.size() : 0);


        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service geofenceNotification - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service geofencesNotification [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "beacon/notifications", method = RequestMethod.POST)
    @ResponseBody
    public Response geofenceBeaconNotifications(final @RequestBody CatalogueGeofenceNotificationRequest _request,
                                  final @RequestHeader(value = "msisdn", required = false) String _msisdn) {

        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueGeofenceNotification catalogueGeofenceNotification = new CatalogueGeofenceNotification();
        BeanUtils.copyProperties(_request, catalogueGeofenceNotification);

        List notifications = catalogueGeofenceBeaconNotificationService.geofenceBeaconNotification(catalogueGeofenceNotification, serviceContext);

        CatalogueGeofenceNotificationResponse response = new CatalogueGeofenceNotificationResponse();
        response.setGeofenceBeaconNotifications(notifications);
        response.setHasMsisdn(_request.getPhone() != null);
        response.setGeofenceBeaconNotificationCount(notifications != null ? notifications.size() : 0);


        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service geofenceBeaconNotification - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service geofencesBeaconNotification [request: {}; response: {}]", _request, response);
        }
        return response;
    }

}
