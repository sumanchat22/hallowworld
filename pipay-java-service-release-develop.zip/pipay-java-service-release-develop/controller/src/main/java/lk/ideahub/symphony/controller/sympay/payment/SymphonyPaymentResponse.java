package lk.ideahub.symphony.controller.sympay.payment;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchantDiscount;
import lk.ideahub.symphony.product.sympay.payment.entity.PaymentOptionDisplayNames;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by samith on 11/19/15.
 */
@Getter
@Setter
@ToString
public class SymphonyPaymentResponse extends Response {

    private Object customerPayeeTransaction;
    private List customerPaymentList;
    private Long customerPaymentListCount;
    private Integer merchantDiscountsTotalCount;

    // status
    private String status;
    private String message;
    private Boolean showRatingPopup;

    List<PaymentOptionDisplayNames> displayNamesList;

    List<SymphonyMerchantDiscount> symphonyMerchantDiscounts;

}
