package lk.ideahub.symphony.controller.sympay.wallet;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.wallet.entity.SymphonyWallet;
import lk.ideahub.symphony.product.sympay.wallet.service.SymphonyWalletService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by kalpana on 3/1/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/wallet", consumes = "application/json", produces = "application/json")

public class SymphonyWalletController extends GenericController
{
    private static final Logger log = LoggerFactory.getLogger(SymphonyWalletController.class);

    @Autowired
    SymphonyWalletService symphonyWalletService;

    @RequestMapping(value = "ez/add", method = RequestMethod.POST)
    @ResponseBody
    public Response addEzWallet(final @RequestBody SymphonyWalletRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyWallet symphonyWallet = new SymphonyWallet();
        BeanUtils.copyProperties(_request, symphonyWallet);

        SymphonyWalletResponse response = new SymphonyWalletResponse();
        try {
            SymphonyWallet result = symphonyWalletService.addEzWallet(symphonyWallet, serviceContext);

            response.setEzWalletStatus(result.getEzWalletStatus());
            response.setCustomerEzWallet(result.getCustomerEzWallet());
            response.setEzDescription(result.getDescription());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addEzWallet - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service addEzWallet [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //--------------------------------------------------------------------------------------------------
    @RequestMapping(value = "ez/remove", method = RequestMethod.POST)
    @ResponseBody
    public Response removeEzWallet(final @RequestBody SymphonyWalletRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyWallet symphonyWallet = new SymphonyWallet();
        BeanUtils.copyProperties(_request, symphonyWallet);

        SymphonyWalletResponse response = new SymphonyWalletResponse();
        try {
            SymphonyWallet result = symphonyWalletService.removeEzWallet(symphonyWallet, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service RemoveEzWallet - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service RemoveEzWallet [request: {}; response: {}]", _request, response);
        }
        return response;
    }


    private void setClientIP(final SymphonyWalletRequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }

}
