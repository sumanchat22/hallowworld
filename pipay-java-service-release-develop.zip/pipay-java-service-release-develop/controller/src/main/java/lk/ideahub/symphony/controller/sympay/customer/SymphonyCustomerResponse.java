package lk.ideahub.symphony.controller.sympay.customer;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.currency.entity.Currency;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.entity.CustomerAction;
import lk.ideahub.symphony.modules.customer.entity.CustomerDocument;
import lk.ideahub.symphony.modules.customer.entity.CustomerType;
import lk.ideahub.symphony.modules.enterprise.entity.Enterprise;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.modules.types.entity.ActionType;
import lk.ideahub.symphony.modules.types.entity.SystemConfig;
import lk.ideahub.symphony.modules.types.entity.UserStatus;
import lk.ideahub.symphony.product.sympay.card.entity.CardListDetails;
import lk.ideahub.symphony.product.sympay.customer.entity.SurchargeEnablePO;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.DiscountDetail;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by samith on 9/29/15.
 */
@Getter
@Setter
@ToString
public class SymphonyCustomerResponse extends Response {

    private Long customerId;

    private Customer customer;
    private CustomerAction customerAction;

    //session token
    private String sessionToken;

    //dashboard data
    private List paymentHistoryList;
    private List payeeList;
    private Object ezCashData;
    private List customerApprovals;
    private BigDecimal monthlyPaymentAmount;
    private List<String> touchIdEnabledDevices;
    private Integer payeeCount;
    private CardListDetails cardListDetails;
    private Integer maximumMultipleBillerCount;

    //otc
    private MerchantTransaction merchantTransaction;

    //sms
    private String smsSendCode;

    //request touchId
    private String aliasPIN;

    //upload document
    private List<CustomerDocument> customerDocumentList;

    // status
    private String status;
    private String message;
    private String errorCode;
    private String versionTage;

    //general
    private String keepSessionExpiryDays;
    private String keepSessionExpiryMessage;

    private List<SurchargeEnablePO> surchargeEnablePOList;

    private DiscountDetail discountDetail;

    //view
    private String mainImageFolderPath;
    private String thumbnailImageFolderPath;

    private List<SystemConfig> systemConfigList;

	private String imageUrl;

    
    public void setCustomerAction(CustomerAction customerAction) {
    	if(customerAction != null) {
    		CustomerAction tempCustomerAction = new CustomerAction();
    		tempCustomerAction.setCustomerActionId(customerAction.getCustomerActionId());
    		if(customerAction.getActionType() != null) {
    			ActionType actionType = new ActionType();
    			actionType.setName(customerAction.getActionType().getName());
    			actionType.setDescription(customerAction.getActionType().getDescription());
    			tempCustomerAction.setActionType(actionType);
    		}
    		this.customerAction = tempCustomerAction;
    	}
    }
    
    public void setCustomer(Customer customer) {
    	if(customer != null) {
    		customer.setVersion(null);
    		customer.setCorporate(null);
    		customer.setRatePendingRequestDate(null);
    		customer.setModifiedDatetime(null);
    		
    		if(customer.getUserStatus() != null) {
    			UserStatus userStatus = new UserStatus();
    			userStatus.setName(customer.getUserStatus().getName());
    			userStatus.setDescription(customer.getUserStatus().getDescription());
    			customer.setUserStatus(userStatus);
    		}
    		if(customer.getEnterprise() != null) {
    			Enterprise enterprise = new Enterprise();
    			enterprise.setName(customer.getEnterprise().getName());
    			enterprise.setRegisteredName(customer.getEnterprise().getRegisteredName());
    			customer.setEnterprise(enterprise);
    		}
    		if(customer.getCustomerType() != null) {
    			CustomerType customerType = new CustomerType();
    			customerType.setName(customer.getCustomerType().getName());
    			customerType.setCode(customer.getCustomerType().getCode());
    			customer.setCustomerType(customerType);
    		}
    		if(customer.getCurrency() != null) {
    			Currency currency = new Currency();
    			currency.setIsoCurrencyCode(customer.getCurrency().getIsoCurrencyCode());
    			customer.setCurrency(currency);
    		}
    		
    		this.customer = customer;
    	}
    }
}
