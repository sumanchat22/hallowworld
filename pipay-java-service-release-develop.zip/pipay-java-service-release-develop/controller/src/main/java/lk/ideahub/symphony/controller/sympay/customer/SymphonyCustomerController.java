package lk.ideahub.symphony.controller.sympay.customer;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.*;
import lk.ideahub.symphony.modules.customer.entity.CustomerDeviceSession;
import lk.ideahub.symphony.modules.customer.service.CustomerDeviceService;
import lk.ideahub.symphony.modules.customer.service.CustomerDeviceSessionService;
import lk.ideahub.symphony.modules.types.entity.CustomerDeviceStatus;
import lk.ideahub.symphony.modules.types.service.CustomerDeviceStatusService;
import lk.ideahub.symphony.product.sympay.common.JWTUtil;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.customer.entity.SymphonyCustomer;
import lk.ideahub.symphony.product.sympay.customer.service.SymphonyCustomerService;
import lk.ideahub.symphony.product.sympay.wirecard.external.service.WireCardWalletService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.core.env.Environment;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by samith on 9/29/15.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/customer", consumes = "application/json", produces = "application/json")
public class SymphonyCustomerController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyCustomerController.class);

    private static final String REGISTRATION_ABORT_CRON_SWITCH = "switch.registration.abort.cron";
    private static final String REMOVE_CUSTOMER_CRON_SWITCH = "switch.remove.customer.cron";
    private static final String CUSTOMER_DEVICE_ACTIVE_STATUS = "Active";

    @Autowired
    private Environment environment;

    @Autowired
    SymphonyCustomerService symphonyCustomerService;

    @Autowired
    CustomerDeviceSessionService cusDevSessionService;

    @Autowired
    CustomerDeviceService customerDeviceService;
    
    @Autowired
    CustomerDeviceStatusService customerDeviceStatusService;

    @Autowired
    private JWTUtil jwtUtil;

    @Autowired
    private WireCardWalletService wireCardWalletService;

    @RequestMapping(value = "init/register", method = RequestMethod.POST)
    @ResponseBody
    public Response initializeRegistration(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {
        if (request.getMsisdn() == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.initialInsert(symphonyCustomer, serviceContext);
            response.setErrorCode(result.getErrorCode());
            response.setSmsSendCode(result.getSmsSendCode());
            response.setCustomerId(result.getCustomerId());
            response.setCustomer(result.getCustomer());
            response.setCustomerAction(result.getCustomerAction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setCode(symphonyCustomer.getErrorCode());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service initialize registration - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service initialize registration [request: {}; response: {}]", request, response);
        }
        return response;
    }

	@RequestMapping(value = "confirm/otp", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity confirmOTP(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        HttpHeaders header = new HttpHeaders();
        HttpStatus httpStatus = HttpStatus.OK;
        
        try {
            SymphonyCustomer result = symphonyCustomerService.otpConfirm(symphonyCustomer, serviceContext);

            response.setCustomerId(result.getCustomerId());
            response.setCustomerAction(result.getCustomerAction());
            response.setCode(result.getErrorCode());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            
            if(!RequestStatus.FAILURE.getStatus().equals(result.getStatus())) {
            	response.setCustomer(result.getCustomer());
            	
            	//get JWT Token 
                String jwtToken = symphonyCustomerService.createJWTTokenForOpenServices(result.getCustomerId(), jwtUtil.getOpenExpiryTime(), serviceContext);
                header.set("Authorization", "Bearer " + jwtToken);
            }
            

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service confirm OTP - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service confirm OTP [request: {}; response: {}]", request, response);
        }
        //return response;
        return new ResponseEntity(response, header, httpStatus);
    }

    @RequestMapping(value = "otp/resend", method = RequestMethod.POST)
    @ResponseBody
    public Response resendOTP(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.resendOTP(symphonyCustomer, serviceContext);

            response.setSmsSendCode(result.getSmsSendCode());
            response.setCustomerId(result.getCustomerId());
            if(!RequestStatus.FAILURE.getStatus().equals(result.getStatus())) {
            	response.setCustomer(result.getCustomer());
            }
            response.setErrorCode(result.getErrorCode());
            response.setCustomerAction(result.getCustomerAction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setCode(symphonyCustomer.getErrorCode());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service resend OTP - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service resend OTP [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "confirm/kyc", method = RequestMethod.POST)
    @ResponseBody
    public Response confirmKYC(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.confirmKYC(symphonyCustomer, serviceContext);

            if(!RequestStatus.FAILURE.getStatus().equals(result.getStatus())) {
            	response.setCustomer(result.getCustomer());
            }
            response.setCustomerId(result.getCustomerId());
            response.setCustomerAction(result.getCustomerAction());
            response.setErrorCode(result.getErrorCode());
            response.setCode(result.getErrorCode());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        request.setPassword(null);
        request.setNewPassword(null);
        request.setMothersMaidenName(null);
        request.setPIN(null);
        request.setPersonalId(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service confirm KYC - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service confirm KYC [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "update/profile", method = RequestMethod.POST)
    @ResponseBody
    public Response updateProfile(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.updateProfile(symphonyCustomer, serviceContext);

            if(!RequestStatus.FAILURE.getStatus().equals(result.getStatus())) {
                response.setCustomer(result.getCustomer());
            }
            response.setCustomerId(result.getCustomerId());
            response.setCustomerAction(result.getCustomerAction());
            response.setErrorCode(result.getErrorCode());
            response.setCode(result.getErrorCode());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        request.setPassword(null);
        request.setNewPassword(null);
        request.setMothersMaidenName(null);
        request.setPIN(null);
        request.setPersonalId(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service update profile - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service update profile [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "add/auth", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity addAuth(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        HttpHeaders header = new HttpHeaders();
        HttpStatus httpStatus = HttpStatus.OK;

        try {
            SymphonyCustomer result = symphonyCustomerService.addAuth(symphonyCustomer, serviceContext);

            response.setCustomerId(result.getCustomerId());
            if(!RequestStatus.FAILURE.getStatus().equals(result.getStatus())) {
            	response.setCustomer(result.getCustomer());
            }
            response.setCustomerAction(result.getCustomerAction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

            if (result.getCustomer() != null) {
                String deviceId = symphonyCustomer.getUid();
                Long customerId = result.getCustomerId();

                CustomerDeviceSession cds = new CustomerDeviceSession();
                cds.setCustomerId(customerId);
                cds.setDeviceId(deviceId);


                List<CustomerDeviceSession> sdssbyCustomerId = cusDevSessionService.findByCustomerId(cds, serviceContext);

                if (sdssbyCustomerId.size() > 0) {

                    CustomerDeviceSession customerDeviceSession = sdssbyCustomerId.get(0);
                    if (customerDeviceSession != null && customerDeviceSession.getDeviceUniqueId() != null) {

                        String jwtToken = symphonyCustomerService.createJWTToken(customerDeviceSession, jwtUtil.getGeneralExpiryTime(), serviceContext);
                        header.set("Authorization", "Bearer " + jwtToken);
                    }
//                    httpStatus = HttpStatus.OK;
                }
            }
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
//            httpStatus = HttpStatus.OK;
        }

        request.setPassword(null);
        request.setNewPassword(null);
        request.setMothersMaidenName(null);
        request.setPIN(null);
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service add auth(password, pin) - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service add auth(password, pin) [request: {}; response: {}]", request, response);
        }
        return new ResponseEntity(response, header, httpStatus);
    }
    
    @RequestMapping(value = "login/otp/send", method = RequestMethod.POST)
    @ResponseBody
    public Response sendLoginOtp(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.sendResendLoginOTP(symphonyCustomer, serviceContext);

            response.setSmsSendCode(result.getSmsSendCode());
            response.setCustomerId(result.getCustomerId());
            response.setCustomer(result.getCustomer());
            response.setCustomerAction(result.getCustomerAction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setCode(symphonyCustomer.getErrorCode());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service send login OTP - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service send login OTP [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "login", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity login(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        String remote_ipAddress = servletRequest.getRemoteAddr();
        String x_F_ipAddress = servletRequest.getHeader("X-FORWARDED-FOR");

        log.info("Remote : " + remote_ipAddress);
        log.info("X-FORWARDED-FOR : " + x_F_ipAddress);

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);
        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        HttpHeaders header = new HttpHeaders();
        HttpStatus httpStatus = HttpStatus.OK;

        try {
            SymphonyCustomer result = symphonyCustomerService.login(symphonyCustomer, serviceContext);

            response.setCustomerId(result.getCustomerId());
            response.setCustomer(result.getCustomer());
            response.setCustomerAction(result.getCustomerAction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setCode(result.getErrorCode());

            if (result.getCustomer() != null) {

                Long customerId = result.getCustomerId();
                String deviceId = symphonyCustomer.getUid();

                CustomerDeviceSession cds = new CustomerDeviceSession();
                cds.setCustomerId(customerId);
                cds.setDeviceId(deviceId);

                List<CustomerDeviceSession> sdssbyCustomerId = cusDevSessionService.findByCustomerId(cds, serviceContext);
                if (sdssbyCustomerId.size() > 0) {

                    CustomerDeviceSession customerDeviceSession = sdssbyCustomerId.get(0);
                    if (customerDeviceSession != null && customerDeviceSession.getDeviceUniqueId() != null) {

                        String isKeepLogged = symphonyCustomer.getKeepMeLogged();
                        String expiaryTime = jwtUtil.getGeneralExpiryTime();

                        if ("true".equalsIgnoreCase(isKeepLogged)) {

                            expiaryTime = jwtUtil.getSessionExpiryTime();
                        }

                        String jwtToken = symphonyCustomerService.createJWTToken(customerDeviceSession, expiaryTime, serviceContext);
                        header.set("Authorization", "Bearer " + jwtToken);
                    }
                }
//                httpStatus = HttpStatus.OK;
                
                //----After Success login, If the customer has push notification inactive device, then activate it.------
                try {
                	CustomerDeviceStatus customerDeviceStatus = new CustomerDeviceStatus();
                	customerDeviceStatus.setName(CUSTOMER_DEVICE_ACTIVE_STATUS);
                	List<CustomerDeviceStatus> deviceStatuses = customerDeviceStatusService.find(customerDeviceStatus, serviceContext);
                	
                	if(deviceStatuses != null && deviceStatuses.size() > 0) {
                		customerDeviceService.activatePushNotification(customerId, deviceStatuses.get(0).getCustomerDeviceStatusId());
                	}
                }
                catch(Exception ex) {
                	log.error(LogSupport.CUSTOMER_LOGIN_ACTIVATE_INACTIVE_PUSH + ex.toString());
                }
            }
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
//            httpStatus = HttpStatus.OK;
        }

        // Add version tag for check update Java Core
        response.setVersionTage(Constants.VERSION_TAG);
        _request.setPassword(null);
        _request.setNewPassword(null);
        _request.setMothersMaidenName(null);
        _request.setPIN(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service login - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service login [request: {}; response: {}]", _request, response);
        }
        return new ResponseEntity(response, header, httpStatus);
    }

    @RequestMapping(value = "upgrade", method = RequestMethod.POST)
    @ResponseBody
    public Response upgradeCustomer(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.upgradeCustomer(symphonyCustomer, serviceContext);

            response.setCustomerId(result.getCustomerId());
            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service upgrade customer - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service upgrade customer [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "upload/document", method = RequestMethod.POST)
    @ResponseBody
    public Response uploadDocument(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.uploadDocument(symphonyCustomer, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service upload document - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service upload document [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "reset/password", method = RequestMethod.POST)
    @ResponseBody
    public Response resetPassword(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.resetPassword(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service resetPassword - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service resetPassword [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "reset/password/validate/link", method = RequestMethod.POST)
    @ResponseBody
    public Response validatePasswordLink(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.validatePasswordLink(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service validatePasswordLink - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service validatePasswordLink [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "reset/password/confirm", method = RequestMethod.POST)
    @ResponseBody
    public Response resetPasswordConfirm(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.resetPasswordConfirm(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPassword(null);
        _request.setPIN(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service resetPasswordConfirm - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service resetPasswordConfirm [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "reset/pin", method = RequestMethod.POST)
    @ResponseBody
    public Response resetPin(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.resetPin(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setMothersMaidenName(null);
        _request.setPersonalId(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service resetPin - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service resetPin [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "reset/pin/check/otp", method = RequestMethod.POST)
    @ResponseBody
    public Response resetPinCheckOTP(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.resetPinCheckOTP(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service resetPinCheckOTP - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service resetPinCheckOTP [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "reset/pin/confirm", method = RequestMethod.POST)
    @ResponseBody
    public Response resetPinOtpConfirm(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.resetPinConfirm(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPIN(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service resetPinOtpConfirm - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service resetPinOtpConfirm [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "change/password", method = RequestMethod.POST)
    @ResponseBody
    public Response changePassword(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.changePassword(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPassword(null);
        _request.setNewPassword(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service changePassword - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service changePassword [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "masked/details", method = RequestMethod.POST)
    @ResponseBody
    public Response customerDetailsMasked(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.customerDetailsMasked(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service customer Details Masked - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service customer Details Masked [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "unmasked/details", method = RequestMethod.POST)
    @ResponseBody
    public Response customerDetailsUnMasked(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.customerDetailsUnMasked(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPassword(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service Customer Details Unmasked - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service Customer Details Unmasked [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "update/kyc", method = RequestMethod.POST)
    @ResponseBody
    public Response updateKYC(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.updateKYC(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setMothersMaidenName(null);
        _request.setPersonalId(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service update KYC - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service update KYC [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "ext/merchant/login", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity loginFromExtMerchant(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        HttpHeaders header = new HttpHeaders();
        HttpStatus httpStatus = HttpStatus.OK;

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.loginFromExtMerchant(symphonyCustomer, serviceContext);

            response.setSessionToken(result.getSessionToken());
            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


            if (result.getCustomer() != null) {

                Long customerId = result.getCustomerId();
                String deviceId = symphonyCustomer.getUid();

                CustomerDeviceSession cds = new CustomerDeviceSession();
                cds.setCustomerId(customerId);
                cds.setDeviceId(deviceId);

                List<CustomerDeviceSession> sdssbyCustomerId = cusDevSessionService.findByCustomerId(cds, serviceContext);
                if (sdssbyCustomerId.size() > 0) {

                    CustomerDeviceSession customerDeviceSession = sdssbyCustomerId.get(0);
                    if (customerDeviceSession != null && customerDeviceSession.getDeviceUniqueId() != null) {

                        String jwtToken = symphonyCustomerService.createJWTToken(customerDeviceSession, jwtUtil.getExtPgExpiryTime(), serviceContext);
                        header.set("Authorization", "Bearer " + jwtToken);
                    }
                }
            }
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPIN(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service login From Ext Merchant - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service login From Ext Merchant [request: {}; response: {}]", _request, response);
        }
        return new ResponseEntity(response, header, httpStatus);
    }

    @RequestMapping(value = "change/msisdn", method = RequestMethod.POST)
    @ResponseBody
    public Response changeMsisdn(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.changeMsisdn(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service changeMsisdn - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service changeMsisdn [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "change/msisdn/otp/check", method = RequestMethod.POST)
    @ResponseBody
    public Response changeMsisdnCheckOtp(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.changeMsisdnCheckOtp(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service changeMsisdnCheckOtp - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service changeMsisdnCheckOtp [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "register/abort", method = RequestMethod.POST)
    @ResponseBody
    public Response registrationAbort(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.registrationAbort(symphonyCustomer, serviceContext);

            response.setCustomerId(result.getCustomerId());
            response.setCustomer(result.getCustomer());
            response.setCustomerAction(result.getCustomerAction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service registrationAbort - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service registrationAbort [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //@Scheduled(cron = "0 */5 * * * *")
    public void registrationAbortCron() {
        if (environment.getProperty(REGISTRATION_ABORT_CRON_SWITCH).equals("ON")) {
            SymphonyCustomerRegisterRequest _request = new SymphonyCustomerRegisterRequest();
            _request.setIsAbort("N");

            //setClientIP(_request, servletRequest);
            ServiceContext serviceContext = getServiceContext(_request, false);

            SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
            BeanUtils.copyProperties(_request, symphonyCustomer);

            SymphonyCustomerResponse response = new SymphonyCustomerResponse();
            try {
                SymphonyCustomer result = symphonyCustomerService.registrationAbort(symphonyCustomer, serviceContext);

                response.setCustomerId(result.getCustomerId());
                response.setCustomer(result.getCustomer());
                response.setCustomerAction(result.getCustomerAction());
                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());

            } catch (InvalidRequestException exception) {
                response.setStatus(RequestStatus.FAILURE.getStatus());
                response.setMessage(exception.getMessage());

            }

            if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
                log.warn("Service registrationAbort - failure [request: {}; response: {}]", _request, response);
            } else {
                log.debug("Service registrationAbort [request: {}; response: {}]", _request, response);
            }
        }
    }

    //customer dashboard data service
    @RequestMapping(value = "dashboard", method = RequestMethod.POST)
    @ResponseBody
    public Response dashboardData(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.dashBoardData(symphonyCustomer, serviceContext);

            //response.setCustomerApprovals(result.getCustomerApprovals());
            response.setPaymentHistoryList(result.getPaymentHistoryList());
            response.setPayeeList(result.getPayeeList());
            //response.setMonthlyPaymentAmount(result.getMonthlyPaymentAmount());
            response.setTouchIdEnabledDevices(result.getTouchIdEnabledDevices());
            response.setPayeeCount(result.getPayeeCount());
            response.setCardListDetails(result.getCardListDetails());
            response.setMaximumMultipleBillerCount(result.getMaximumMultipleBillerCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service dashboardData - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service dashboardData [request: {}; response: {}]", _request, response);
        }
        return response;
    }


    @RequestMapping(value = "merchantTransaction", method = RequestMethod.POST)
    @ResponseBody
    public Response merchantTransactionData(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, true);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.merchantTransactionData(symphonyCustomer, serviceContext);

            response.setCustomerApprovals(result.getCustomerApprovals());
            response.setPaymentHistoryList(result.getPaymentHistoryList());
            response.setPayeeList(result.getPayeeList());
            response.setMonthlyPaymentAmount(result.getMonthlyPaymentAmount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service dashboardData - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service dashboardData [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //customer reject/approve txn
    @RequestMapping(value = "otc/change/status", method = RequestMethod.POST)
    @ResponseBody
    public Response otcCustomerChangeStatus(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.otcCustomerChangeStatus(symphonyCustomer, serviceContext);

            response.setDiscountDetail(result.getDiscountDetail());
            response.setSurchargeEnablePOList(result.getSurchargeEnablePOList());
            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service otcCustomerChangeStatus - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service otcCustomerChangeStatus [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //customer get current txn
    @RequestMapping(value = "otc/get/transaction", method = RequestMethod.POST)
    @ResponseBody
    public Response otcCustomerGetTransaction(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.otcCustomerGetTransaction(symphonyCustomer, serviceContext);

            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service otcCustomerGetTransaction - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service otcCustomerGetTransaction [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "init/register/guest", method = RequestMethod.POST)
    @ResponseBody
    public Response initializeGuestRegistration(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {
        if (_request.getToken() == null) {
            throw new UnauthorizedRequestException("Required authorization criteria has not been matched");
        }

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.findGuestCustomerFromToken(symphonyCustomer, serviceContext);

            response.setCustomerId(result.getCustomerId());
            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service initialize registration - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service initialize registration [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "remove", method = RequestMethod.POST)
    @ResponseBody
    public Response removeCustomer(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.removeCustomer(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service remove customer - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service remove customer [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "rate", method = RequestMethod.POST)
    @ResponseBody
    public Response rateApp(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.rateApp(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service app rate - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service app rate [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "init/merchanttransaction", method = RequestMethod.POST)
    @ResponseBody
    public Response initMerchantTransaction(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.initMerchantTransaction(symphonyCustomer, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setMerchantTransaction(result.getMerchantTransaction());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service init merchant transaction - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service init merchant transaction [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    //@Scheduled(cron = "0 0 0 * * *")
    public void removeCustomerCron() {
        if (environment.getProperty(REMOVE_CUSTOMER_CRON_SWITCH).equals("ON")) {
            SymphonyCustomerRegisterRequest _request = new SymphonyCustomerRegisterRequest();
            ServiceContext serviceContext = getServiceContext(_request, false);

            SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
            BeanUtils.copyProperties(_request, symphonyCustomer);

            SymphonyCustomerResponse response = new SymphonyCustomerResponse();
            try {
                SymphonyCustomer result = symphonyCustomerService.removeCustomer(symphonyCustomer, serviceContext);

                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());
            } catch (InvalidRequestException exception) {
                response.setStatus(RequestStatus.FAILURE.getStatus());
                response.setMessage(exception.getMessage());
            }

            if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
                log.warn("Service remove customer - failure [request: {}; response: {}]", _request, response);
            } else {
                log.debug("Service remove customer [request: {}; response: {}]", _request, response);
            }
        }
    }

    @RequestMapping(value = "merchant/alias", method = RequestMethod.POST)
    @ResponseBody
    public Response ezMerchantVerification(final @RequestBody SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(_request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try{
            SymphonyCustomer result = symphonyCustomerService.ezMerchantVerification(symphonyCustomer,serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            response.setMerchantTransaction(result.getMerchantTransaction());
        }catch(InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn(LogSupport.EZ_MERCHANT_VERIFICATION_FAILURE,_request,response);
        }else{
            log.debug(LogSupport.EZ_MERCHANT_VERIFICATION_SUCCESS,_request,response);
        }
        return response;
    }


    private void setClientIP(final SymphonyCustomerRegisterRequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }


    @RequestMapping(value = "general", method = RequestMethod.GET)
    @ResponseBody
    public Response getGeneralInfo(HttpServletRequest servletRequest){
        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        SymphonyCustomer symphonyCustomer =new SymphonyCustomer();
        ServiceContext serviceContext = getServiceContext(null, false);
        symphonyCustomerService.getGeneralInfo(symphonyCustomer, serviceContext);
        response.setKeepSessionExpiryDays(symphonyCustomer.getKeepMeLogged());
        response.setKeepSessionExpiryMessage(symphonyCustomer.getMessage());
        return response;
    }

    @RequestMapping(value = "view", method = RequestMethod.POST)
    @ResponseBody
    public Response viewCustomer(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.viewCustomer(symphonyCustomer, serviceContext);

            response.setMainImageFolderPath(result.getMainImageFolderPath());
            response.setThumbnailImageFolderPath(result.getThumbnailImageFolderPath());
            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service edit getCustomerDetail - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service edit getCustomerDetail [request: {}; response: {}]", request, response);
        }
        return response;
    }
    @RequestMapping(value = "operator/status", method = RequestMethod.POST)
    @ResponseBody
    public Response viewCustomerOperator(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerOperatorResponse response = new SymphonyCustomerOperatorResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.viewCustomerOperator(symphonyCustomer, serviceContext);

            response.setSmartOperator(result.isSmartOperator());
            response.setSmartVip(result.isSmartVIP());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service edit getCustomerDetail - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service edit getCustomerDetail [request: {}; response: {}]", request, response);
        }
        return response;
    }


    @RequestMapping(value = "edit/profile", method = RequestMethod.POST)
    @ResponseBody
    public Response editProfile(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.editProfile(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        request.setMothersMaidenName(null);
        request.setPersonalId(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service edit profile - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service edit profile [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "profile/picture/update", method = RequestMethod.POST)
    @ResponseBody
    public Response updateProfilePicture(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.updateProfilePicture(symphonyCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateProfilePicture - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service updateProfilePicture [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/system/config", method = RequestMethod.POST)
    @ResponseBody
    public Response getSysConfig(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.getSysConfig(symphonyCustomer, serviceContext);

            response.setSystemConfigList(result.getSystemConfigList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        request.setMothersMaidenName(null);
        request.setPersonalId(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service edit profile - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service edit profile [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "image/resubmit", method = RequestMethod.POST)
    @ResponseBody
    public Response imageResubmit(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.imageResubmit(symphonyCustomer, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service imageResubmit - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service imageResubmit [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "enable/quickpay", method = RequestMethod.POST)
    @ResponseBody
    public Response enableQuickPay(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.enableQuickPay(symphonyCustomer, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service enableQuickPay - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service enableQuickPay [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "upload/chatgroupimage", method = RequestMethod.POST)
    @ResponseBody
    public Response imageUpload(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.uploadImage(symphonyCustomer, serviceContext);
            response.setImageUrl(result.getImageUrl());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service uploadImage - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service uploadImage [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/data", method = RequestMethod.POST)
    @ResponseBody
    public Response getCustomerData(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.getCustomerData(symphonyCustomer, serviceContext);
            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getCustomerData - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getCustomerData [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "close/wallet", method = RequestMethod.POST)
    @ResponseBody
    public Response closeCustomerWallet(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();

        try {
            SymphonyCustomer result = wireCardWalletService.closeWallet(symphonyCustomer, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            if(StringUtils.isNotBlank(exception.getCode())) {
                response.setErrorCode(exception.getCode());
            }
        } catch (Exception exception) {
            log.error("Service closeCustomerWallet - failure {}", exception.getMessage());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage("Sorry, something went wrong.");
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service closeCustomerWallet - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service closeCustomerWallet [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "add/customergroup", method = RequestMethod.POST)
    @ResponseBody
    public Response addCustomerToCustomerGroup(final @RequestBody SymphonyCustomerRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomer symphonyCustomer = new SymphonyCustomer();
        BeanUtils.copyProperties(request, symphonyCustomer);

        SymphonyCustomerResponse response = new SymphonyCustomerResponse();
        try {
            SymphonyCustomer result = symphonyCustomerService.addCustomerToCustomerGroup(symphonyCustomer, serviceContext);
            response.setCustomer(result.getCustomer());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getCustomerData - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getCustomerData [request: {}; response: {}]", request, response);
        }
        return response;
    }

}





