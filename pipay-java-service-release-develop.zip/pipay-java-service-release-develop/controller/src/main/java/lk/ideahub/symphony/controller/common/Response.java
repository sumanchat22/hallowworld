package lk.ideahub.symphony.controller.common;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonRootName(value = "response")
public class Response {

    private String errorCode;
	private String responseCode;
    private String responseCodeMessage;
    private String code;
}
