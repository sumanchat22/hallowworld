package lk.ideahub.symphony.controller.sympay.merchant.transaction;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantTransactionService;

/**
 * Created by Sasika on 30/6/16.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/merchant/transaction", consumes = "application/json", produces = "application/json")
public class SymphonyMerchantTransactionController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyMerchantTransactionController.class);

    @Autowired
    SymphonyMerchantTransactionService symphonyMerchantTransactionService;

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantTransactionListByMerchantId(final @RequestBody SymphonyMerchantTransactionRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, true);

        SymphonyMerchant symphonyMerchant = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, symphonyMerchant);

        SymphonyMerchantTransactionResponse response = new SymphonyMerchantTransactionResponse();
        try {
            SymphonyMerchant result = symphonyMerchantTransactionService.findMerchantTransactionList(symphonyMerchant, serviceContext);
            response.setMerchantTransactionsList(result.getMerchantTransactionsList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getMerchantTransactionListByMerchantId - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getMerchantTransactionListByMerchantId [request: {}; response: {}]", _request, response);
        }
        return response;
    }
    
    /**
     * Get OTC daily transaction report
     * @param _request
     * @param servletRequest
     * @return Response
     */
    @RequestMapping(value = "otc/report/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantTransactionListForOtcReports(final @RequestBody SymphonyMerchantTransactionRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, true);

        SymphonyMerchant symphonyMerchant = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, symphonyMerchant);
        
        symphonyMerchant.setOtcSummarydate(_request.getOtcSummaryDate());

        SymphonyMerchantTransactionResponse response = new SymphonyMerchantTransactionResponse();
        try {
            SymphonyMerchant result = symphonyMerchantTransactionService.findMerchantTransactionsWithSummary(symphonyMerchant, serviceContext);
            response.setOtcReportTransactionsList(result.getOtcReportTxnList());
            response.setSummary(result.getPiPayMerchantTransactionSummary());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        catch (Exception ex) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(ex.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getMerchantTransactionListForOtcReports - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getMerchantTransactionListForOtcReports [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyMerchantTransactionRequest _request, HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}
}
