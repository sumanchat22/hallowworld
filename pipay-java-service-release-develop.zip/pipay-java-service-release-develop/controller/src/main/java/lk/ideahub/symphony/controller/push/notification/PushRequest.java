package lk.ideahub.symphony.controller.push.notification;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by samith on 7/19/15.
 */
public class PushRequest extends Request {

    private Boolean push;
    private String phone;
    private String dealId;

    public Boolean getPush() {
        return push;
    }

    public void setPush(Boolean push) {
        this.push = push;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDealId() {
        return dealId;
    }

    public void setDealId(String dealId) {
        this.dealId = dealId;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PushRequest{");
        sb.append("push=").append(push);
        sb.append(", phone='").append(phone).append('\'');
        sb.append(", dealId='").append(dealId).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
