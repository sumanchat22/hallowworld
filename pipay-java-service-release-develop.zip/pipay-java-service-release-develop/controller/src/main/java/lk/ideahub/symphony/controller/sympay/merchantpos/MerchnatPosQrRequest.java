package lk.ideahub.symphony.controller.sympay.merchantpos;

import java.math.BigDecimal;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchnatPosQrRequest extends Request{

	private Long counterId;
	private String qrCode;
    private Long couponCode;
    
    private Long reservedCustomerId;
    private Long couponId;
    private Long outletId;
    private Long merchantId;
    private String currencyCode;
    private BigDecimal amount;
    
    private Long merchantTransactionId;
    private Boolean isPosCall;
}
