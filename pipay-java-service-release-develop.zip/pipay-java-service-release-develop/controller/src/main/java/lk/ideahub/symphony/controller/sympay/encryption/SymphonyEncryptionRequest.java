package lk.ideahub.symphony.controller.sympay.encryption;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by samith on 1/7/16.
 */
public class SymphonyEncryptionRequest extends Request {

    private Long userId;
    private Long keyStoreFileId;
    private String password;
    private String userName;
    private String statusName;

    private long id;
    private String val;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public Long getKeyStoreFileId() {
		return keyStoreFileId;
	}

	public void setKeyStoreFileId(Long keyStoreFileId) {
		this.keyStoreFileId = keyStoreFileId;
	}

	@Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyEncryptionRequest{");
        sb.append("userId=").append(userId);
        sb.append(", statusName='").append(statusName).append('\'');
        sb.append(", id=").append(id);
        sb.append(", val='").append(val).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
