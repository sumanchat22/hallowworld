package lk.ideahub.symphony.controller.sympay.favourite;

import java.math.BigDecimal;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class FavouriteRequest extends Request{

	private Long customerId;
	private String shortcutSubType;
	private String shortcutType;
	private String data;
	private Long customerShortcutId;
	private Long osTypeId;
	private String osType;
	private Long billerId;
	private Long referenceId;
	private BigDecimal fromLongitude;
	private BigDecimal fromLatitude;
	private String path;
}
