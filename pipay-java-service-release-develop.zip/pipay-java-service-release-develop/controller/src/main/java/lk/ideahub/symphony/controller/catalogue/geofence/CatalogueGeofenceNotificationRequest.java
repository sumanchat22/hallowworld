package lk.ideahub.symphony.controller.catalogue.geofence;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by samith on 8/14/15.
 */
public class CatalogueGeofenceNotificationRequest extends Request {

    private String phone;

    private long geofenceId;
    private String transitionType;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public long getGeofenceId() {
        return geofenceId;
    }

    public void setGeofenceId(long geofenceId) {
        this.geofenceId = geofenceId;
    }

    public String getTransitionType() {
        return transitionType;
    }

    public void setTransitionType(String transitionType) {
        this.transitionType = transitionType;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CatalogueGeofenceNotificationRequest{");
        sb.append("phone='").append(phone).append('\'');
        sb.append(", geofenceId=").append(geofenceId);
        sb.append(", transitionType='").append(transitionType).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
