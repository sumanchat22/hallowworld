package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class MerchantPosCouponRequest extends Request {
    private Long counterId;
    private Date startDate;
    private Date endDate;
    private Long couponTransactionId;
}
