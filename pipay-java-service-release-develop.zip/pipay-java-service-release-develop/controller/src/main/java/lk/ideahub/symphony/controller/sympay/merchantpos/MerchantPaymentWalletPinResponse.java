package lk.ideahub.symphony.controller.sympay.merchantpos;

public class MerchantPaymentWalletPinResponse {
}
