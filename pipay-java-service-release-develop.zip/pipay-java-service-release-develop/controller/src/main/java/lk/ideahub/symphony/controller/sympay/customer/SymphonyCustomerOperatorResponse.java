package lk.ideahub.symphony.controller.sympay.customer;

import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class SymphonyCustomerOperatorResponse extends Response {
    private long customerId;
    private boolean isSmartOperator;
    private boolean isSmartVip;

    // status
    private String status;
    private String message;
    private String errorCode;
}
