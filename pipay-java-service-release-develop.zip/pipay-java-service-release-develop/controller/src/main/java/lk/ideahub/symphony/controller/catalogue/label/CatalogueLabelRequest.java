package lk.ideahub.symphony.controller.catalogue.label;

import lk.ideahub.symphony.controller.common.Request;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by kalpana on 8/4/16.
 */
public class CatalogueLabelRequest extends Request
{
    //dashboard
    private String appId;
    private String appType;

    //listDealsForMenuLabel
    private String labelId;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private List<Long> currentIdList;
    private String dealCategory;

    //dashboard banner label
    private Long bannerReferenceTypeId;
    private Long bannerReferenceId;

    //dashboard search text
    private String searchText;
    private List<Long> searchLabelList;

    public String getAppId() { return appId; }

    public void setAppId(String appId) { this.appId = appId; }

    public String getLabelId() { return labelId; }

    public void setLabelId(String labelId) { this.labelId = labelId; }

    public String getAppType() { return appType; }

    public void setAppType(String appType) { this.appType = appType; }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public List<Long> getCurrentIdList() { return currentIdList; }

    public void setCurrentIdList(List<Long> currentIdList) { this.currentIdList = currentIdList; }

    public Long getBannerReferenceTypeId() { return bannerReferenceTypeId; }

    public void setBannerReferenceTypeId(Long bannerReferenceTypeId) { this.bannerReferenceTypeId = bannerReferenceTypeId; }

    public Long getBannerReferenceId() { return bannerReferenceId; }

    public void setBannerReferenceId(Long bannerReferenceId) { this.bannerReferenceId = bannerReferenceId; }

    public String getSearchText() { return searchText; }

    public void setSearchText(String searchText) { this.searchText = searchText; }

    public List<Long> getSearchLabelList() { return searchLabelList; }

    public void setSearchLabelList(List<Long> searchLabelList) { this.searchLabelList = searchLabelList; }

    public String getDealCategory() { return dealCategory; }

    public void setDealCategory(String dealCategory) { this.dealCategory = dealCategory; }

    @Override
    public String toString() {
        return new StringBuilder("CatalogueLabelRequest {")
                .append("appId='").append(appId).append("'").append(", ")
                .append("appType='").append(appType).append("'").append(", ")
                .append("labelId='").append(labelId).append("'").append(", ")
                .append("latitude=").append(latitude).append(", ")
                .append("longitude=").append(longitude).append(", ")
                .append("currentIdList=").append(currentIdList).append(", ")
                .append("dealCategory='").append(dealCategory).append("'").append(", ")
                .append("bannerReferenceTypeId=").append(bannerReferenceTypeId).append(", ")
                .append("bannerReferenceId=").append(bannerReferenceId).append(", ")
                .append("searchText='").append(searchText).append("'").append(", ")
                .append("searchLabelList=").append(searchLabelList)
                .append('}').toString();
    }
}
