package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.product.sympay.payment.entity.TransactionInfoDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TransactionVerificationResponse extends CommonExternalResponse{

	TransactionInfoDto txnInfo;
}
