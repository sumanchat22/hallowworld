package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class ChangeMerchantPosPinRequest extends Request {

    private Long   merchantId;
    private Long outletId;
    private Long counterId;
    private String merchantPosOldPin;
    private String merchantPosNewPin;
    private String merchantPosNewPinConfirmation;
}
