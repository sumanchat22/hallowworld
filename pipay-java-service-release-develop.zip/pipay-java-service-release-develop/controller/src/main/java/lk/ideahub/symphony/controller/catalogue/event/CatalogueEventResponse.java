package lk.ideahub.symphony.controller.catalogue.event;

import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by samith on 2/26/16.
 */
@Getter
@Setter
@ToString
public class CatalogueEventResponse extends Response {

    // status
    private String status;
    private String message;

    //list event
    private List events;
    private Integer eventCount;
}
