package lk.ideahub.symphony.controller.sympay.merchant;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.merchant.entity.Merchant;
import lk.ideahub.symphony.modules.merchant.entity.MerchantPgConnection;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.modules.user.entity.User;
import lk.ideahub.symphony.product.sympay.merchant.entity.BankDto;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by samith on 12/20/15.
 */
@Getter
@Setter
public class SymphonyMerchantResponse extends Response{

    //merchantPgConnection object
    private MerchantPgConnection merchantPgConnection;
    private MerchantTransaction merchantTransaction;
    private User user;
    private Merchant merchant;

    //customer
    private Customer customer;

    //sessionToken
    private String sessionToken;
    private Long merchantDiscountId;

    //QR Code
    private String QrEncryptedText;

    //validate card discount
    private Boolean validDiscount;
    private String invalidReason;
    private BigDecimal chargeTotal;
    // status
    private String status;
    private String message;
    
    //bank list
    private List<BankDto> bankList;

    public MerchantTransaction getMerchantTransaction() {
        return merchantTransaction;
    }

    public void setMerchantTransaction(MerchantTransaction merchantTransaction) {
        this.merchantTransaction = merchantTransaction;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Merchant getMerchant() {
        return merchant;
    }

    public void setMerchant(Merchant merchant) {
        this.merchant = merchant;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public MerchantPgConnection getMerchantPgConnection() {
        return merchantPgConnection;
    }

    public void setMerchantPgConnection(MerchantPgConnection merchantPgConnection) {
        this.merchantPgConnection = merchantPgConnection;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getQrEncryptedText() {
		return QrEncryptedText;
	}

	public void setQrEncryptedText(String qrEncryptedText) {
		QrEncryptedText = qrEncryptedText;
	}

    public Long getMerchantDiscountId() {
        return merchantDiscountId;
    }

    public void setMerchantDiscountId(Long merchantDiscountId) {
        this.merchantDiscountId = merchantDiscountId;
    }

    public Boolean getValidDiscount() {
        return validDiscount;
    }

    public void setValidDiscount(Boolean validDiscount) {
        this.validDiscount = validDiscount;
    }

    public String getInvalidReason() {
        return invalidReason;
    }

    public void setInvalidReason(String invalidReason) {
        this.invalidReason = invalidReason;
    }

    public BigDecimal getChargeTotal() {
        return chargeTotal;
    }

    public void setChargeTotal(BigDecimal chargeTotal) {
        this.chargeTotal = chargeTotal;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyMerchantResponse {")
                .append("merchantPgConnection=").append(merchantPgConnection).append(", ")
                .append("merchantTransaction=").append(merchantTransaction).append(", ")
                .append("user=").append(user).append(", ")
                .append("merchant=").append(merchant).append(", ")
                .append("customer=").append(customer).append(", ")
                .append("sessionToken='").append(sessionToken).append("'").append(", ")
                .append("merchantDiscountId=").append(merchantDiscountId).append(", ")
                .append("QrEncryptedText='").append(QrEncryptedText).append("'").append(", ")
                .append("validDiscount=").append(validDiscount).append(", ")
                .append("invalidReason='").append(invalidReason).append("'").append(", ")
                .append("chargeTotal=").append(chargeTotal).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
