package lk.ideahub.symphony.controller.sympay.casa;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import lk.ideahub.symphony.modules.types.entity.Bank;
import lk.ideahub.symphony.modules.types.entity.BankBranch;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by kalpana on 3/24/17.
 */
@Getter
@Setter
@ToString
public class SymphonyCASAResponse extends Response
{
    // status
    private String status;
    private String message;

    private String responseCode;
    private String responseCodeDescription;
    private String referenceId;
    private String challenge;
    private String LCComment;

    //list banks
    private List<Bank> bankList;

    //list branches
    private List<BankBranch> branchList;

    //get consent
    private String consent;
    private String showConsent;
    private Bank bank;

    //validate random amount/otp
    private String customerToken;
    private String accountRef1;
    private String accountRef2;
    private String accountRef3;
    private String accountRef4;
    private String accountRef5;

    //confirm registration
    private CustomerPaymentOption paymentOption;

    private String comment;
    private Long accountId;
    private CargillsCustomerCasaAccount cargillsCustomerCasaAccount;

}
