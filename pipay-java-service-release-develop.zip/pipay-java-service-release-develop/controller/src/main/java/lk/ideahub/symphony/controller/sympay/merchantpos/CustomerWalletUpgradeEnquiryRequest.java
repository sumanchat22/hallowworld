package lk.ideahub.symphony.controller.sympay.merchantpos;


import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerWalletUpgradeEnquiryRequest  extends Request{

    private Long merchantId;
    private Long outletId;
    private String customerMsisdn;
    private String customerPin;
    private Long counterId;
}
