package lk.ideahub.symphony.controller.sympay.customer.touchId;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by mahesha on 4/23/17.
 */
public class SymphonyTouchIdResponse extends Response {

    //request touchId
    private String aliasPIN;

    // status
    private String status;
    private String message;

    public String getAliasPIN() {
        return aliasPIN;
    }

    public void setAliasPIN(String aliasPIN) {
        this.aliasPIN = aliasPIN;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyTouchIdResponse {")
                .append("aliasPIN='").append(aliasPIN).append("'").append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
