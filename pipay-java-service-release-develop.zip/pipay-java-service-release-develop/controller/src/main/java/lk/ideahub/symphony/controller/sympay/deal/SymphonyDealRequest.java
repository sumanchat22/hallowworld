package lk.ideahub.symphony.controller.sympay.deal;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by mahesha on 12/31/18.
 */
@Getter
@Setter
@ToString
public class SymphonyDealRequest extends Request {

    //like
    private Long dealId;
    private Long customerId;

    //comment
    private String commentText;
    private Long commentId;

    //get deal list
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Long filterTagId;

    //search deal & show all
    private String searchText;
    private String searchType;

}
