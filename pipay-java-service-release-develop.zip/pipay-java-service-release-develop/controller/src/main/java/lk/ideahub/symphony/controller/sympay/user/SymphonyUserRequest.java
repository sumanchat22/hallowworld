package lk.ideahub.symphony.controller.sympay.user;

import lk.ideahub.symphony.controller.common.Request;


/**
 * Created by Sasika on 07/11/16.
 */
public class SymphonyUserRequest extends Request {

	private String disableProcessBlockInactiveUsers;

	public String getDisableProcessBlockInactiveUsers() {
		return disableProcessBlockInactiveUsers;
	}

	public void setDisableProcessBlockInactiveUsers(String disableProcessBlockInactiveUsers) {
		this.disableProcessBlockInactiveUsers = disableProcessBlockInactiveUsers;
	}

	@Override
	public String toString() {
		return "SymphonyUserRequest [disableProcessBlockInactiveUsers=" + disableProcessBlockInactiveUsers + "]";
	}

}
