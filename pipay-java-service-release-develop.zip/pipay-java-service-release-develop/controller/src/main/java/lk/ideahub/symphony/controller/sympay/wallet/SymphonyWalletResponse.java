package lk.ideahub.symphony.controller.sympay.wallet;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.wallet.entity.CustomerEzWallet;

/**
 * Created by kalpana on 3/1/17.
 */
public class SymphonyWalletResponse extends Response
{
    // status
    private String status;
    private String message;

    //add ez Wallet
    private String ezWalletStatus;
    private CustomerEzWallet customerEzWallet;
    private String ezDescription;

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }

    public void setMessage(String message) { this.message = message; }

    public String getEzWalletStatus() { return ezWalletStatus; }

    public void setEzWalletStatus(String ezWalletStatus) { this.ezWalletStatus = ezWalletStatus; }

    public CustomerEzWallet getCustomerEzWallet() { return customerEzWallet; }

    public void setCustomerEzWallet(CustomerEzWallet customerEzWallet) { this.customerEzWallet = customerEzWallet; }

    public String getEzDescription() { return ezDescription; }

    public void setEzDescription(String ezDescription) { this.ezDescription = ezDescription; }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyWalletResponse {")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'").append(", ")
                .append("ezWalletStatus='").append(ezWalletStatus).append("'").append(", ")
                .append("customerEzWallet=").append(customerEzWallet).append(", ")
                .append("ezDescription='").append(ezDescription).append("'")
                .append('}').toString();
    }
}
