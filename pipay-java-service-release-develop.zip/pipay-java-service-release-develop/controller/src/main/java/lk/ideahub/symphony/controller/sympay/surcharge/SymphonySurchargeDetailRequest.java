package lk.ideahub.symphony.controller.sympay.surcharge;

import lk.ideahub.symphony.controller.common.Request;

import java.util.ArrayList;

/**
 * Created by Madhukara on 12/13/17.
 */
public class SymphonySurchargeDetailRequest extends Request {

    private Long customerId;
    private ArrayList<Long> merchantIdList;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public ArrayList<Long> getMerchantIdList() {
        return merchantIdList;
    }

    public void setMerchantIdList(ArrayList<Long> merchantIdList) {
        this.merchantIdList = merchantIdList;
    }
}
