package lk.ideahub.symphony.controller.sympay.user;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by Sasika on 07/11/16.
 */
public class SymphonyUserResponse extends Response {

    // status
    private String status;
    private String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}

