package lk.ideahub.symphony.controller.report;

import com.fasterxml.jackson.annotation.JsonInclude;
import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by Anil on 6/26/19.
 */
@Getter
@Setter
@ToString
public class ReportResponse extends Response {

    private String status;
    private String message;
    private String reportFile;
}
