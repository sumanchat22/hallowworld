package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
public class MerchantCashInInquiryRequest extends Request{

    private String merchantMsisdn;
    private String currencyCode;
    private Long  merchantId;
    private BigDecimal amount;
    private Long  outletId;
    private Long counterId;

}
