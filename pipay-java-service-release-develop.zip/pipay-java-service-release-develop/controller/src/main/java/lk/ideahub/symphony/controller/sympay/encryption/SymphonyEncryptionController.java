package lk.ideahub.symphony.controller.sympay.encryption;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.encryption.entity.SymphonyEncryption;
import lk.ideahub.symphony.product.sympay.encryption.service.SymphonyEncryptionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;

/**
 * Created by samith on 1/6/16.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/encryption", consumes = "application/json", produces = "application/json")
public class SymphonyEncryptionController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyEncryptionController.class);

    @Autowired
    SymphonyEncryptionService symphonyEncryptionService;

    @RequestMapping(value = "init/deks", method = RequestMethod.POST)
    @ResponseBody
    public Response initialDeks(final @RequestBody SymphonyEncryptionRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryption symphonyEncryption = new SymphonyEncryption();
        BeanUtils.copyProperties(_request, symphonyEncryption);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();

        try {
            SymphonyEncryption result = symphonyEncryptionService.initialDeks(symphonyEncryption, serviceContext);

            response.setIsMainMasterKeyLive(result.isMainMasterKeyLive());
            response.setIsTempMasterKeyLive(result.isTempMasterKeyLive());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service initialDeks - failure [response: {}]", response);
        } else {
            log.debug("Service initialDeks [response: {}]", response);
        }
        return response;
    }

    /*@RequestMapping(value = "set/data", method = RequestMethod.POST)
    @ResponseBody
    public Response encryptedData(final @RequestBody SymphonyEncryptionRequest _request,HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            String result = symphonyEncryptionService.encryptData(_request.getId(), _request.getVal(), serviceContext);

            //response.setStatus(result.getStatus());
            response.setMessage(result);

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service encryptedData - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service encryptedData [request: {}; response: {}]", _request, response);
        }
        return response;
    }*/

    /*@RequestMapping(value = "get/data", method = RequestMethod.POST)
    @ResponseBody
    public Response decryptedData(final @RequestBody SymphonyEncryptionRequest _request,HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            String result = symphonyEncryptionService.decryptedData(_request.getId(), _request.getVal(), serviceContext);

            //response.setStatus(result.getStatus());
            response.setMessage(result);


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service decryptedData - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service decryptedData [request: {}; response: {}]", _request, response);
        }
        return response;
    }*/

    @RequestMapping(value = "init/master/key", method = RequestMethod.POST)
    @ResponseBody
    public Response initMasterKey(final @RequestBody SymphonyEncryptionRequest _request, HttpSession session, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryption symphonyEncryption = new SymphonyEncryption();
        BeanUtils.copyProperties(_request, symphonyEncryption);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            SymphonyEncryption result = symphonyEncryptionService.masterKey(symphonyEncryption, serviceContext);

            response.setIsMainMasterKeyLive(result.isMainMasterKeyLive());
            response.setIsTempMasterKeyLive(result.isTempMasterKeyLive());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service initMasterKey - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service initMasterKey [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "init/user/key", method = RequestMethod.POST)
    @ResponseBody
    public Response initUserKeys(final @RequestBody SymphonyEncryptionRequest _request, HttpSession session, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryption symphonyEncryption = new SymphonyEncryption();
        BeanUtils.copyProperties(_request, symphonyEncryption);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            SymphonyEncryption result = symphonyEncryptionService.initUserKeys(symphonyEncryption, serviceContext);

            response.setIsMainMasterKeyLive(result.isMainMasterKeyLive());
            response.setIsTempMasterKeyLive(result.isTempMasterKeyLive());
            response.setCustodiansStatuses(result.getCustodiansStatuses());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPassword(null);
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service initUserKeys - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service initUserKeys [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/user/key/statuses", method = RequestMethod.POST)
    @ResponseBody
    public Response getUserKeyStatuses(final @RequestBody SymphonyEncryptionRequest _request, HttpSession session, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryption symphonyEncryption = new SymphonyEncryption();
        BeanUtils.copyProperties(_request, symphonyEncryption);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            SymphonyEncryption result = symphonyEncryptionService.getUserKeyStatuses(symphonyEncryption, serviceContext);

            response.setIsMainMasterKeyLive(result.isMainMasterKeyLive());
            response.setIsTempMasterKeyLive(result.isTempMasterKeyLive());
            response.setCustodiansStatuses(result.getCustodiansStatuses());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getUserKeyStatuses - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getUserKeyStatuses [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "create/key/store/file", method = RequestMethod.POST)
    @ResponseBody
    public Response createKeyStoreFile(final @RequestBody SymphonyEncryptionRequest _request, HttpSession session, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryption symphonyEncryption = new SymphonyEncryption();
        BeanUtils.copyProperties(_request, symphonyEncryption);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            SymphonyEncryption result = symphonyEncryptionService.createKeyStoreFile(symphonyEncryption, serviceContext);

            response.setIsMainMasterKeyLive(result.isMainMasterKeyLive());
            response.setIsTempMasterKeyLive(result.isTempMasterKeyLive());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service createKeyStoreFile - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service createKeyStoreFile [request: {}; response: {}]", _request, response);
        }
        return response;
    }


    @RequestMapping(value = "/key/rotation", method = RequestMethod.POST)
    @ResponseBody
    public Response keyRotation(final @RequestBody SymphonyEncryptionRequest _request, HttpSession session, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(false);

        SymphonyEncryption symphonyEncryption = new SymphonyEncryption();
        BeanUtils.copyProperties(_request, symphonyEncryption);

        SymphonyEncryptionResponse response = new SymphonyEncryptionResponse();
        try {

            SymphonyEncryption result = symphonyEncryptionService.keyRotation(symphonyEncryption, serviceContext);

            response.setIsMainMasterKeyLive(result.isMainMasterKeyLive());
            response.setIsTempMasterKeyLive(result.isTempMasterKeyLive());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service keyRotation - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service keyRotation [request: {}; response: {}]", _request, response);
        }
        return response;
    }
    
    private void setClientIP(final SymphonyEncryptionRequest _request,
			HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}
}