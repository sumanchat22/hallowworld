package lk.ideahub.symphony.controller.sympay.deal;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.deal.entity.Deal;
import lk.ideahub.symphony.modules.deal.entity.DealComment;
import lk.ideahub.symphony.modules.experienceCard.entity.FilterTag;
import lk.ideahub.symphony.modules.outlet.entity.Outlet;
import lk.ideahub.symphony.product.catalogue.filterObject.DealImageFilter;
import lk.ideahub.symphony.product.sympay.deal.entity.DealDto;
import lk.ideahub.symphony.product.sympay.friend.entity.CustomerDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 12/31/18.
 */
@Getter
@Setter
@ToString
public class SymphonyDealResponse extends Response {

    //add comment
    private DealComment dealComment;

    //view comments
    private List<DealComment> dealCommentList;
    private Integer commentListSize;

    private CustomerDto customerDto;

    //view deal details
    private Deal deal;
    private List<Outlet> availableBranches;
    private Long commentCount;
    private Long likeCount;
    private List<DealImageFilter> dealImageList;

    //deal list
    private List<DealDto> nearbyDealList;
    private List<DealDto> recommendedDealList;
    private List<DealDto> featuredDealList;
    private List<FilterTag> filterTagList;

    //search deal
    private List<DealDto> dealList;

    private Long dealCount;

    private String status;
    private String message;
}
