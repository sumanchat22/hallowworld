package lk.ideahub.symphony.controller.sympay.merchant;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by mahesha on 11/28/18.
 */
@Getter
@Setter
@ToString
public class SymphonyMerchantRegisterRequest extends Request {

    // register merchant user
    private String firstName;
    private String lastName;
    private String email;
    private String msisdn;
    private String password;
}
