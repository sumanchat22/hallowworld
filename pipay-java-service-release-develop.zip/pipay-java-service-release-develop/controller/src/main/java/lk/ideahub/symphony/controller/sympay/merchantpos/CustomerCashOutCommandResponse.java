package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.merchantpos.entity.MerchantPosTransactionData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerCashOutCommandResponse extends Response{

    private String status;
    private String message;
    private MerchantPosTransactionData merchantPosTransactionData;

}
