package lk.ideahub.symphony.controller.sympay.surcharge;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.surcharge.entity.MerchantSurcharge;

import java.util.List;

/**
 * Created by Madhukara on 12/13/17.
 */
public class SymphonySurchargeDetailResponse extends Response {

    private List<MerchantSurcharge> merchantSurchargeList;

    // status
    private String status;
    private String message;

    public List<MerchantSurcharge> getMerchantSurchargeList() {
        return merchantSurchargeList;
    }

    public void setMerchantSurchargeList(List<MerchantSurcharge> merchantSurchargeList) {
        this.merchantSurchargeList = merchantSurchargeList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
