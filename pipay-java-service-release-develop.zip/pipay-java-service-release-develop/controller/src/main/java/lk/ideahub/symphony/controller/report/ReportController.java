package lk.ideahub.symphony.controller.report;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.controller.sympay.cutomer.payment.option.CustomerPaymentOptionRequest;
import lk.ideahub.symphony.controller.sympay.cutomer.payment.option.CustomerPaymentOptionResponse;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.report.entity.ReportDto;
import lk.ideahub.symphony.product.report.entity.ReportListDto;
import lk.ideahub.symphony.product.report.service.ReportGeneratorService;
import lk.ideahub.symphony.product.report.service.ReportListGeneratorService;
import lk.ideahub.symphony.product.sympay.payment.option.CustomerPaymentOptionDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by Anil on 6/25/19.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/report", consumes = "application/json", produces = "application/json")
public class ReportController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(ReportController.class);

    @Autowired
    private ReportGeneratorService reportGeneratorService;

    @Autowired
    private ReportListGeneratorService reportListGeneratorService;

    @RequestMapping(value = "generatefile/couponstatus", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponStatusReport(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        ReportResponse response = new ReportResponse();
        try {
        	ReportDto result = reportGeneratorService.generateCouponStatusReport(reportDto, serviceContext);

            response.setReportFile(result.getReportFile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Status Report Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Status Report Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "generatefile/couponclaimed", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponClaimedReport(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        ReportResponse response = new ReportResponse();
        try {
            ReportDto result = reportGeneratorService.generateCouponClaimedReport(reportDto, serviceContext);

            response.setReportFile(result.getReportFile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Status Report Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Status Report Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "list/couponstatus", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponStatusList(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, true);

        ReportListResponse response= new ReportListResponse();
        try {
            ReportListDto result = reportListGeneratorService.generateCouponStatusList(reportDto, serviceContext);

            response.setReportKey(result.getReportKey());
            response.setCount(result.getCount());
            response.setDataList(result.getReportList());
            response.setHeaderList(result.getHeaderList());
            response.setStatus(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Status List Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Status List Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }
    @RequestMapping(value = "generatefile/couponstatusreport", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponStatusReportFile(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        ReportResponse response = new ReportResponse();
        try {
            ReportDto result = reportGeneratorService.generateCouponStatusReportFile(reportDto, serviceContext);

            response.setReportFile(result.getReportFile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Status Report Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Status Report Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }
    @RequestMapping(value = "list/couponstatusreport", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponStatusReportList(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, true);

        ReportListResponse response= new ReportListResponse();
        try {
            ReportListDto result = reportListGeneratorService.generateCouponStatusReportList(reportDto, serviceContext);

            response.setReportKey(result.getReportKey());
            response.setCount(result.getCount());
            response.setDataList(result.getReportList());
            response.setHeaderList(result.getHeaderList());
            response.setStatus(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Status List Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Status List Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "list/couponclaimed", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponClaimedList(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, true);

        ReportListResponse response= new ReportListResponse();
        try {
            ReportListDto result = reportListGeneratorService.generateCouponClaimedList(reportDto, serviceContext);

            response.setReportKey(result.getReportKey());
            response.setCount(result.getCount());
            response.setDataList(result.getReportList());
            response.setHeaderList(result.getHeaderList());
            response.setStatus(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Claimed List Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Claimed List Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "list/couponburnt", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponBurntList(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, true);

        ReportListResponse response= new ReportListResponse();
        try {
            ReportListDto result = reportListGeneratorService.generateCouponBurntList(reportDto, serviceContext);

            response.setReportKey(result.getReportKey());
            response.setCount(result.getCount());
            response.setDataList(result.getReportList());
            response.setHeaderList(result.getHeaderList());
            response.setStatus(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
        	exception.printStackTrace();
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Burnt List Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Burnt List Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "generatefile/couponburnt", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponBurntReport(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        ReportResponse response = new ReportResponse();
        try {
            ReportDto result = reportGeneratorService.generateCouponBurntReport(reportDto, serviceContext);

            response.setReportFile(result.getReportFile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Burnt Report Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Burnt Report Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }


    @RequestMapping(value = "list/headers", method = RequestMethod.POST)
    @ResponseBody
    public Response getHeaderList(final @RequestBody ReportRequest request) {

        ReportListResponse response= new ReportListResponse();
        try {
            List<Object> result = reportGeneratorService.getHeadersList(request.getReportCode());

            response.setReportKey(request.getReportCode());
            response.setDataList(result);
            response.setStatus(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Report Header List Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Report Header List Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }


    @RequestMapping(value = "generatefile/coupontrxinquiry", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponTransactionInquiryReport(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {
        log.warn("generateCouponTransactionInquiryReport   [request: {};]", request);
        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        ReportResponse response = new ReportResponse();
        try {
            ReportDto result = reportGeneratorService.generateCouponTransactionInquiryReport(reportDto, serviceContext);

            response.setReportFile(result.getReportFile());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Transaction Inquiry Report Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Transaction Inquiry Report Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }


    private void setClientIP(final ReportRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
        
        Date fromDate = request.getTransactionFromDate();
        if(fromDate != null) {
        	Calendar cal = Calendar.getInstance();
        	cal.setTime(fromDate);
        	cal.set(Calendar.MILLISECOND, 0);
        	cal.set(Calendar.MINUTE, 0);
        	cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            request.setTransactionFromDate(cal.getTime());
        }
        
        Date toDate = request.getTransactionToDate();
        if(toDate != null) {
        	Calendar cal = Calendar.getInstance();
        	cal.setTime(toDate);
        	cal.set(Calendar.MILLISECOND, 999);
        	cal.set(Calendar.MINUTE, 59);
        	cal.set(Calendar.SECOND, 59);
            cal.set(Calendar.HOUR_OF_DAY, 23);
            request.setTransactionToDate(cal.getTime());
        }
    }


    @RequestMapping(value = "list/coupontrxinquiry", method = RequestMethod.POST)
    @ResponseBody
    public Response generateCouponTransactionInquiryList(final @RequestBody ReportRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ReportDto reportDto = new ReportDto();
        BeanUtils.copyProperties(request, reportDto);

        ServiceContext serviceContext = getServiceContext(request, true);

        ReportListResponse response= new ReportListResponse();
        try {
            ReportListDto result = reportListGeneratorService.generateCouponTransactionInquiryList(reportDto, serviceContext);

            response.setReportKey(result.getReportKey());
            response.setCount(result.getCount());
            response.setDataList(result.getReportList());
            response.setHeaderList(result.getHeaderList());
            response.setStatus(RequestStatus.SUCCESS.getStatus());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Coupon Transaction Inquiry List Generator  - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Coupon Transaction Inquiry List Generator [request: {}; response: {}]", request, response);
        }
        return response;
    }



}

