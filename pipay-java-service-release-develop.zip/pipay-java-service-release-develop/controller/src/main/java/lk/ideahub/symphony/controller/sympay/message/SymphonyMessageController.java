package lk.ideahub.symphony.controller.sympay.message;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.message.entity.SymphonyMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.message.service.SymphonyMessageService;

/**
 * Created by samith on 2/15/16.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/message", consumes = "application/json", produces = "application/json")
public class SymphonyMessageController extends GenericController {

        private static final Logger log = LoggerFactory.getLogger(SymphonyMessageController.class);

        @Autowired
        SymphonyMessageService symphonyMessageService;

        @RequestMapping(method = RequestMethod.POST)
        @ResponseBody
        public Response message(final @RequestBody SymphonyMessageRequest _request) {

            ServiceContext serviceContext = getServiceContext(_request, false);

            SymphonyMessage symphonyMessage = new SymphonyMessage();
            BeanUtils.copyProperties(_request, symphonyMessage);

            SymphonyMessageResponse response = new SymphonyMessageResponse();
            try {
                SymphonyMessage result = symphonyMessageService.sendAdminMail(symphonyMessage, serviceContext);

                response.setSuccesCount(result.getSuccessCount());
                response.setFailCount(result.getFailCount());
                response.setSendingResponses(result.getMessageSendResponses());
                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());

            } catch (InvalidRequestException exception) {
                response.setStatus(RequestStatus.FAILURE.getStatus());
                response.setMessage(exception.getMessage());
            }

            if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
                log.warn("Service message - failure [request: {}; response: {}]", _request, response);
            } else {
                log.debug("Service message [request: {}; response: {}]", _request, response);
            }
            return response;
        }

}
