package lk.ideahub.symphony.controller.sympay.loyalty;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.loyalty.entity.CustomerLoyaltyPoint;
import lk.ideahub.symphony.modules.loyalty.entity.PointTransaction;
import lk.ideahub.symphony.product.sympay.loyalty.entity.PointTransactionDto;
import lk.ideahub.symphony.product.sympay.loyalty.entity.RewardTransferDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by mahesha on 2/26/19.
 */
@Getter
@Setter
@ToString
public class SymphonyLoyaltyPointResponse extends Response {

    //view point balance
    private BigDecimal pointBalance;
    private Integer couponCount;
    private BigDecimal latestExpiryPoint;
    private Date expiryDate;

    //get point list
    private List<PointTransactionDto> pointTransactionList;

    private String status;
    private String message;

    //bulk reward transfer
    private List<RewardTransferDto> rewardTransferList;
    private Integer successCount;
    private Integer failedCount;
}
