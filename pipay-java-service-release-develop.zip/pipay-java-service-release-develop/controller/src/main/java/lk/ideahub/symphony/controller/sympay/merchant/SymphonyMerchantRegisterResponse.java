package lk.ideahub.symphony.controller.sympay.merchant;

/**
 * Created by mahesha on 11/28/18.
 */
public class SymphonyMerchantRegisterResponse {
}
