package lk.ideahub.symphony.controller.sympay.experienceCard;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.experienceCard.entity.SymphonyExperienceCard;
import lk.ideahub.symphony.product.sympay.experienceCard.service.SymphonyExperienceCardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 12/13/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/experience/card", consumes = "application/json", produces = "application/json")
public class SymphonyExperienceCardController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyExperienceCardController.class);

    @Autowired
    private SymphonyExperienceCardService symphonyExperienceCardService;

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response getCardList(final @RequestBody SymphonyExperienceCardRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyExperienceCard symphonyExperienceCard = new SymphonyExperienceCard();
        BeanUtils.copyProperties(request, symphonyExperienceCard);

        SymphonyExperienceCardResponse response = new SymphonyExperienceCardResponse();

        try {
            SymphonyExperienceCard result = symphonyExperienceCardService.getCardList(symphonyExperienceCard, serviceContext);
            response.setExperienceCardList(result.getExperienceCardList());
            response.setFilterTagList(result.getFilterTagList());
            response.setHashTagExpCard(result.getHashTagExpCard());
            response.setTotalExpCards(result.getTotalExpCards());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getExpCardList - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getExpCardList - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getExpCardList [request: {}; response: {}]", request, response);
        }
        return response;
    }


    @RequestMapping(value = "get/filters", method = RequestMethod.POST)
    @ResponseBody
    public Response getFilterTags(final @RequestBody SymphonyExperienceCardRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyExperienceCard symphonyExperienceCard = new SymphonyExperienceCard();
        BeanUtils.copyProperties(request, symphonyExperienceCard);

        SymphonyExperienceCardResponse response = new SymphonyExperienceCardResponse();

        try {
            SymphonyExperienceCard result = symphonyExperienceCardService.getFilterTags(symphonyExperienceCard, serviceContext);

            response.setFilterTagList(result.getFilterTagList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getFilterTags - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getFilterTags - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getFilterTags [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyExperienceCardRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }

}
