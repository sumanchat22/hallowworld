package lk.ideahub.symphony.controller.sympay.merchantpos;


import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.controller.sympay.receiver.KhqrReceiverRequest;
import lk.ideahub.symphony.controller.sympay.receiver.KhqrReceiverResponse;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.internal.InternalNotificationService;
import lk.ideahub.symphony.modules.receiver.entity.ReceiverTransactionPushContent;
import lk.ideahub.symphony.product.sympay.common.JWTUtil;
import lk.ideahub.symphony.product.sympay.merchantpos.entity.MerchantPosDevice;
import lk.ideahub.symphony.product.sympay.merchantpos.service.MerchantPosService;
import lk.ideahub.symphony.product.sympay.payment.entity.PiPayPayment;
import lk.ideahub.symphony.product.sympay.payment.service.PiPayPaymentService;

import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.ReceiverKhqrCodeDto;
import lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentService;
import lk.ideahub.symphony.product.sympay.receiver.entity.KhqrReceiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/merchantpos", consumes = "application/json", produces = "application/json")
public class MerchantPosController extends GenericController{

    private static final Logger log = LoggerFactory.getLogger(MerchantPosController.class);

    @Autowired
    MerchantPosService merchantPosService;

    @Autowired
    private JWTUtil jwtUtil;

    @Autowired
    SymphonyQrCodePaymentService symphonyQrCodePaymentService;

    @Autowired
    private PiPayPaymentService piPayPaymentService;

    @Autowired
    private InternalNotificationService internalNotificationService;

    @Autowired
    private MessageSource messageSource;

    private static final String COUPON_REDEEM_PUSH_TITLE = "message.receiver.coupon.redeem.title";

    @RequestMapping(value = "request/addPosDevice" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchantPosDevice(final @RequestBody MerchantPosRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosResponse merchantPosResponse = new MerchantPosResponse();
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.add(merchantPosDevice,serviceContext);
            if(!RequestStatus.FAILURE.getStatus().equals(merchantPos.getStatus())){
            	String jwtToken = createJWTToken(merchantPos.getCounterId().toString());
                jwtToken = "Bearer " + jwtToken;
                merchantPosResponse.setJwtToken(jwtToken);
            }
            merchantPosResponse.setOutletCounter(merchantPos.getOutletCounter());
            merchantPosResponse.setOutlet(merchantPos.getOutlet());
            merchantPosResponse.setMerchant(merchantPos.getMerchant());
            merchantPosResponse.setMessage(merchantPos.getMessage());
            merchantPosResponse.setStatus(merchantPos.getStatus());
            merchantPosResponse.setResponseCode(merchantPos.getResponseCode());
            merchantPosResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantPosResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantPosResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantPosResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantPosResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantPosResponse);
        }
        return merchantPosResponse;
    }

    @RequestMapping(value = "request/getPosDevice" , method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantPosDevice(final @RequestBody MerchantPosRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosResponse merchantPosResponse = new MerchantPosResponse();
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.get(merchantPosDevice,serviceContext);
            if(!RequestStatus.FAILURE.getStatus().equals(merchantPos.getStatus())){
                String jwtToken = createJWTToken(merchantPos.getCounterId().toString());
                jwtToken = "Bearer " + jwtToken;
                merchantPosResponse.setJwtToken(jwtToken);
            }
            merchantPosResponse.setOutletCounter(merchantPos.getOutletCounter());
            merchantPosResponse.setOutlet(merchantPos.getOutlet());
            merchantPosResponse.setMerchant(merchantPos.getMerchant());
            merchantPosResponse.setMessage(merchantPos.getMessage());
            merchantPosResponse.setStatus(merchantPos.getStatus());
            merchantPosResponse.setResponseCode(merchantPos.getResponseCode());
            merchantPosResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantPosResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantPosResponse.setMessage(exception.getMessage());
        }
        if(RequestStatus.FAILURE.getStatus().equals(merchantPosResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantPosResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantPosResponse);
        }
        return merchantPosResponse;
    }

    @RequestMapping(value = "request/updatePosDevice" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchantPosDeviceUpdate(final @RequestBody MerchantPosRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDeviceUpdate = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDeviceUpdate);
        MerchantPosResponse merchantPosResponse = new MerchantPosResponse();
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.update(merchantPosDeviceUpdate,serviceContext);
            merchantPosResponse.setOutletCounter(merchantPos.getOutletCounter());
            merchantPosResponse.setOutlet(merchantPos.getOutlet());
            merchantPosResponse.setMerchant(merchantPos.getMerchant());
            merchantPosResponse.setMessage(merchantPos.getMessage());
            merchantPosResponse.setStatus(merchantPos.getStatus());
            merchantPosResponse.setResponseCode(merchantPos.getResponseCode());
            merchantPosResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantPosResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantPosResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantPosResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantPosResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantPosResponse);
        }
        return merchantPosResponse;
    }


    @RequestMapping(value = "request/merchantPaymentWalletPin" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchanPaymentWalletPin(final @RequestBody MerchantPaymentWalletPinRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosResponse merchantPosResponse = new MerchantPosResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.merchantPaymentWalletPin(merchantPosDevice,serviceContext);
            merchantPosResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            merchantPosResponse.setResponseCode(merchantPos.getResponseCode());
            merchantPosResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
            merchantPosResponse.setMessage(merchantPos.getMessage());
            merchantPosResponse.setStatus(merchantPos.getStatus());
            
            merchantPosResponse.setNoOfPoints(merchantPos.getNoOfPoints());
            merchantPosResponse.setPointCashValue(merchantPos.getPointCashValue());
            merchantPosResponse.setDiscountAmount(merchantPos.getDiscountAmount());
            merchantPosResponse.setDiscountType(merchantPos.getDiscountType());
            
        }catch (InvalidRequestException exception){
            merchantPosResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantPosResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantPosResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantPosResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantPosResponse);
        }
        return merchantPosResponse;
    }

    @RequestMapping(value = "request/customerWalletUpgradeEnquiry" , method = RequestMethod.POST)
    @ResponseBody
    public Response customerWalletUpgradeEnquiry(final @RequestBody CustomerWalletUpgradeEnquiryRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        CustomerWalletUpgradeEnquiryResponse customerWalletUpgradeEnquiryResponse = new CustomerWalletUpgradeEnquiryResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.customerWalletUpgradeEnquiry(merchantPosDevice,serviceContext);
            customerWalletUpgradeEnquiryResponse.setMessage(merchantPos.getMessage());
            customerWalletUpgradeEnquiryResponse.setStatus(merchantPos.getStatus());
            customerWalletUpgradeEnquiryResponse.setCustomerWalletUpgradeEnquiry(merchantPos.getCustomerWalletBalanceEnquiry());
            customerWalletUpgradeEnquiryResponse.setResponseCode(merchantPos.getResponseCode());
            customerWalletUpgradeEnquiryResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            customerWalletUpgradeEnquiryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            customerWalletUpgradeEnquiryResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(customerWalletUpgradeEnquiryResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,customerWalletUpgradeEnquiryResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,customerWalletUpgradeEnquiryResponse);
        }
        return customerWalletUpgradeEnquiryResponse;
    }

    @RequestMapping(value = "request/customerCashInEnquiry" , method = RequestMethod.POST)
    @ResponseBody
    public Response customerCashInEnquiry(final @RequestBody  CustomerCashInInquiryRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        CustomerCashInInquiryResponse customerCashInInquiryResponse = new CustomerCashInInquiryResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.customerCashInEnquiry(merchantPosDevice,serviceContext);
            customerCashInInquiryResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            customerCashInInquiryResponse.setMessage(merchantPos.getMessage());
            customerCashInInquiryResponse.setStatus(merchantPos.getStatus());
            customerCashInInquiryResponse.setResponseCode(merchantPos.getResponseCode());
            customerCashInInquiryResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            customerCashInInquiryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            customerCashInInquiryResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(customerCashInInquiryResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,customerCashInInquiryResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,customerCashInInquiryResponse);
        }
        return customerCashInInquiryResponse;
    }

    @RequestMapping(value = "request/customerWalletUpgrade",method = RequestMethod.POST)
    @ResponseBody
    public Response customerWalletUpgrade(final @RequestBody CustomerWalletUpgradeRequest request,HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        CustomerWalletUpgradeResponse customerWalletUpgradeResponse = new CustomerWalletUpgradeResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.customerWalletUpgrade(merchantPosDevice, serviceContext);
            customerWalletUpgradeResponse.setMessage(merchantPos.getMessage());
            customerWalletUpgradeResponse.setStatus(merchantPos.getStatus());
            customerWalletUpgradeResponse.setCustomerWalletUpgrade(merchantPos.getCustomerWalletUpgrade());
            customerWalletUpgradeResponse.setResponseCode(merchantPos.getResponseCode());
            customerWalletUpgradeResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            customerWalletUpgradeResponse.setStatus(RequestStatus.FAILURE.getStatus());
            customerWalletUpgradeResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(customerWalletUpgradeResponse.getStatus())){
            log.warn("Service Customer Wallet Upgrade  POS  - failure [request : {}; response: {}]",request,customerWalletUpgradeResponse);
        }else {
            log.debug("Service Customer Wallet Upgrade POS [request: {}; response: {}]",request,customerWalletUpgradeResponse);
        }
        return customerWalletUpgradeResponse;

    }

    @RequestMapping(value = "request/customerCashInCommand" , method = RequestMethod.POST)
    @ResponseBody
    public Response customerCashInCommand(final @RequestBody  CustomerCashInCommandRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        CustomerCashInCommandResponse customerCashInCommandResponse = new CustomerCashInCommandResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.customerCashInCommand(merchantPosDevice,serviceContext);
            customerCashInCommandResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            customerCashInCommandResponse.setMessage(merchantPos.getMessage());
            customerCashInCommandResponse.setStatus(merchantPos.getStatus());
            customerCashInCommandResponse.setResponseCode(merchantPos.getResponseCode());
            customerCashInCommandResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            customerCashInCommandResponse.setStatus(RequestStatus.FAILURE.getStatus());
            customerCashInCommandResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(customerCashInCommandResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,customerCashInCommandResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,customerCashInCommandResponse);
        }
        return customerCashInCommandResponse;
    }

    @RequestMapping(value = "request/customerCashOutEnquiry" , method = RequestMethod.POST)
    @ResponseBody
    public Response customerCashOutEnquiry(final @RequestBody  CustomerCashOutInquiryRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        CustomerCashOutInquiryResponse customerCashOutInquiryResponse = new CustomerCashOutInquiryResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.customerCashOutEnquiry(merchantPosDevice,serviceContext);
            customerCashOutInquiryResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            customerCashOutInquiryResponse.setMessage(merchantPos.getMessage());
            customerCashOutInquiryResponse.setStatus(merchantPos.getStatus());
            customerCashOutInquiryResponse.setResponseCode(merchantPos.getResponseCode());
            customerCashOutInquiryResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            customerCashOutInquiryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            customerCashOutInquiryResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(customerCashOutInquiryResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,customerCashOutInquiryResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,customerCashOutInquiryResponse);
        }
        return customerCashOutInquiryResponse;
    }


    @RequestMapping(value = "request/customerCashOutCommand" , method = RequestMethod.POST)
    @ResponseBody
    public Response customerCashOutCommand(final @RequestBody  CustomerCashOutCommandRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        CustomerCashOutCommandResponse customerCashOutCommandResponse = new CustomerCashOutCommandResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.customerCashOutCommand(merchantPosDevice,serviceContext);
            customerCashOutCommandResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            customerCashOutCommandResponse.setMessage(merchantPos.getMessage());
            customerCashOutCommandResponse.setStatus(merchantPos.getStatus());
            customerCashOutCommandResponse.setResponseCode(merchantPos.getResponseCode());
            customerCashOutCommandResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            customerCashOutCommandResponse.setStatus(RequestStatus.FAILURE.getStatus());
            customerCashOutCommandResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(customerCashOutCommandResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,customerCashOutCommandResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,customerCashOutCommandResponse);
        }
        return customerCashOutCommandResponse;
    }

    @RequestMapping(value = "request/changeMerchantWalletPin" , method = RequestMethod.POST)
    @ResponseBody
    public Response changeMerchantWalletPin(final @RequestBody  ChangeMerchantWalletPinRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        ChangeMerchantWalletPinResponse changeMerchantWalletPinResponse = new ChangeMerchantWalletPinResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.changeMerchantWalletPin(merchantPosDevice,serviceContext);
            changeMerchantWalletPinResponse.setMessage(merchantPos.getMessage());
            changeMerchantWalletPinResponse.setStatus(merchantPos.getStatus());
            changeMerchantWalletPinResponse.setChangeMerchantWalletPinStatus(merchantPos.getMerchantWalletPinChangeStatus());
            changeMerchantWalletPinResponse.setResponseCode(merchantPos.getResponseCode());
            changeMerchantWalletPinResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            changeMerchantWalletPinResponse.setStatus(RequestStatus.FAILURE.getStatus());
            changeMerchantWalletPinResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(changeMerchantWalletPinResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,changeMerchantWalletPinResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,changeMerchantWalletPinResponse);
        }
        return changeMerchantWalletPinResponse;
    }


    @RequestMapping(value = "request/changeMerchantPosPin" , method = RequestMethod.POST)
    @ResponseBody
    public Response changeMerchantPosPin(final @RequestBody  ChangeMerchantPosPinRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        ChangeMerchantPosPinResponse changeMerchantPosPinResponse = new ChangeMerchantPosPinResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.changeMerchantPosPin(merchantPosDevice,serviceContext);
            changeMerchantPosPinResponse.setMessage(merchantPos.getMessage());
            changeMerchantPosPinResponse.setStatus(merchantPos.getStatus());
            changeMerchantPosPinResponse.setChangeMerchantPosPinStatus(merchantPos.getMerchantPosPinChangeStatus());
            changeMerchantPosPinResponse.setResponseCode(merchantPos.getResponseCode());
            changeMerchantPosPinResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            changeMerchantPosPinResponse.setStatus(RequestStatus.FAILURE.getStatus());
            changeMerchantPosPinResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(changeMerchantPosPinResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,changeMerchantPosPinResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,changeMerchantPosPinResponse);
        }
        return changeMerchantPosPinResponse;
    }

    @RequestMapping(value = "request/getMerchantWalletBalance" , method = RequestMethod.POST)
    @ResponseBody
    public Response getMerchantWalletBalance(final @RequestBody MerchantWalletBalanceRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantWalletBalanceResponse merchantWalletBalanceResponse = new MerchantWalletBalanceResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.getMerchantWalletBalance(merchantPosDevice,serviceContext);
            merchantWalletBalanceResponse.setMessage(merchantPos.getMessage());
            merchantWalletBalanceResponse.setStatus(merchantPos.getStatus());
            merchantWalletBalanceResponse.setMerchantWalletBalanceEnquiry(merchantPos.getMerchantWalletBalanceEnquiry());
            merchantWalletBalanceResponse.setResponseCode(merchantPos.getResponseCode());
            merchantWalletBalanceResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantWalletBalanceResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantWalletBalanceResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantWalletBalanceResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantWalletBalanceResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantWalletBalanceResponse);
        }
        return merchantWalletBalanceResponse;
    }


    @RequestMapping(value = "request/merchantCashInInquiry" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchantCashInInquiry(final @RequestBody  MerchantCashInInquiryRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantCashInInquiryResponse merchantCashInInquiryResponse = new MerchantCashInInquiryResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.merchantCashInEnquiry(merchantPosDevice,serviceContext);
            merchantCashInInquiryResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            merchantCashInInquiryResponse.setMessage(merchantPos.getMessage());
            merchantCashInInquiryResponse.setStatus(merchantPos.getStatus());
            merchantCashInInquiryResponse.setResponseCode(merchantPos.getResponseCode());
            merchantCashInInquiryResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantCashInInquiryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantCashInInquiryResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantCashInInquiryResponse.getStatus())){
            log.warn("Service Request Merchant Cash In POS  - failure [request : {}; response: {}]",request,merchantCashInInquiryResponse);
        }else {
            log.debug("Service Request Merchant Cash In POS [request: {}; response: {}]",request,merchantCashInInquiryResponse);
        }
        return merchantCashInInquiryResponse;
    }

    @RequestMapping(value = "request/merchantCashInCommand" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchantCashInCommand(final @RequestBody  MerchantCashInCommandRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantCashInCommandResponse merchantCashInCommandResponse = new MerchantCashInCommandResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.merchantCashInCommand(merchantPosDevice,serviceContext);
            merchantCashInCommandResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            merchantCashInCommandResponse.setMessage(merchantPos.getMessage());
            merchantCashInCommandResponse.setStatus(merchantPos.getStatus());
            merchantCashInCommandResponse.setResponseCode(merchantPos.getResponseCode());
            merchantCashInCommandResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantCashInCommandResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantCashInCommandResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantCashInCommandResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantCashInCommandResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantCashInCommandResponse);
        }
        return merchantCashInCommandResponse;
    }

    @RequestMapping(value = "request/merchantCashOutInquiry" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchantCashOutInquiry(final @RequestBody  MerchantCashOutInquiryRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantCashOutInquiryResponse merchantCashOutInquiryResponse = new MerchantCashOutInquiryResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.merchantCashOutEnquiry(merchantPosDevice,serviceContext);
            merchantCashOutInquiryResponse.setMessage(merchantPos.getMessage());
            merchantCashOutInquiryResponse.setStatus(merchantPos.getStatus());
            merchantCashOutInquiryResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            merchantCashOutInquiryResponse.setResponseCode(merchantPos.getResponseCode());
            merchantCashOutInquiryResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantCashOutInquiryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantCashOutInquiryResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantCashOutInquiryResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantCashOutInquiryResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantCashOutInquiryResponse);
        }
        return merchantCashOutInquiryResponse;
    }

    @RequestMapping(value = "request/merchantCashOutCommand" , method = RequestMethod.POST)
    @ResponseBody
    public Response merchantCashOutCommand(final @RequestBody MerchantCashOutCommandRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantCashOutCommandResponse merchantCashOutCommandResponse = new MerchantCashOutCommandResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.merchantCashOutCommand(merchantPosDevice,serviceContext);
            merchantCashOutCommandResponse.setMessage(merchantPos.getMessage());
            merchantCashOutCommandResponse.setStatus(merchantPos.getStatus());
            merchantCashOutCommandResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            merchantCashOutCommandResponse.setResponseCode(merchantPos.getResponseCode());
            merchantCashOutCommandResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            merchantCashOutCommandResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantCashOutCommandResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantCashOutCommandResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantCashOutCommandResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantCashOutCommandResponse);
        }
        return merchantCashOutCommandResponse;
    }

    @RequestMapping(value = "request/transactionSummaryReport" , method = RequestMethod.POST)
    @ResponseBody
    public Response posTransactionSummaryReport(final @RequestBody TransactionSummaryReportRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        TransactionSummaryReportResponse transactionSummaryReportResponse = new TransactionSummaryReportResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.transactionSummaryReport(merchantPosDevice,serviceContext);
            transactionSummaryReportResponse.setOutlet(merchantPos.getOutlet());
            transactionSummaryReportResponse.setMessage(merchantPos.getMessage());
            transactionSummaryReportResponse.setStatus(merchantPos.getStatus());
            transactionSummaryReportResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            transactionSummaryReportResponse.setResponseCode(merchantPos.getResponseCode());
            transactionSummaryReportResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            transactionSummaryReportResponse.setStatus(RequestStatus.FAILURE.getStatus());
            transactionSummaryReportResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(transactionSummaryReportResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,transactionSummaryReportResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,transactionSummaryReportResponse);
        }
        return transactionSummaryReportResponse;
    }


    @RequestMapping(value = "request/getTransactionStatement" , method = RequestMethod.POST)
    @ResponseBody
    public Response getTransactionStatement(final @RequestBody GetTransactionStatementRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        GetTransactionStatementResponse getMiniStatementResponse = new GetTransactionStatementResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.getTransactionStatement(merchantPosDevice,serviceContext);
            getMiniStatementResponse.setMessage(merchantPos.getMessage());
            getMiniStatementResponse.setStatus(merchantPos.getStatus());
            getMiniStatementResponse.setMerchantPosTransactionData(merchantPos.getMerchantPosTransactionData());
            getMiniStatementResponse.setResponseCode(merchantPos.getResponseCode());
            getMiniStatementResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            getMiniStatementResponse.setStatus(RequestStatus.FAILURE.getStatus());
            getMiniStatementResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(getMiniStatementResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,getMiniStatementResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,getMiniStatementResponse);
        }
        return getMiniStatementResponse;
    }


    @RequestMapping(value = "get/transaction/payment/status" , method = RequestMethod.POST)
    @ResponseBody
    public Response getTransactionPaymentStatus(final @RequestBody  MerchantPosRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        PosTransactionStatusResponse posTransactionStatusResponse = new PosTransactionStatusResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.checkTransactionStatus(merchantPosDevice, serviceContext);
            posTransactionStatusResponse.setMessage(merchantPos.getMessage());
            posTransactionStatusResponse.setStatus(merchantPos.getStatus());
            posTransactionStatusResponse.setTransaction(merchantPos.getTransaction());
            posTransactionStatusResponse.setResponseCode(merchantPos.getResponseCode());
            posTransactionStatusResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
            posTransactionStatusResponse.setIsTransactionCompleted(merchantPos.getIsTransactionCompleted());
        }catch (InvalidRequestException exception){
        	posTransactionStatusResponse.setStatus(RequestStatus.FAILURE.getStatus());
        	posTransactionStatusResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(posTransactionStatusResponse.getStatus())){
            log.warn("Service getTransactionPaymentStatus POS  - failure [request : {}; response: {}]",request,posTransactionStatusResponse);
        }else {
            log.debug("Service getTransactionPaymentStatus POS [request: {}; response: {}]",request,posTransactionStatusResponse);
        }
        return posTransactionStatusResponse;
    }

    @RequestMapping(value = "get/discount" , method = RequestMethod.POST)
    @ResponseBody
    public Response getDiscount(final @RequestBody  MerchantPosDiscountRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosDiscountResponse response = new MerchantPosDiscountResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice result =  merchantPosService.getDiscount(merchantPosDevice, serviceContext);
            response.setExternalDiscountData(result.getExternalDiscountData());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service getDiscount POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service getDiscount POS [request: {}; response: {}]",request,response);
        }
        return response;
    }
    
    @RequestMapping(value = "get/pos/details" , method = RequestMethod.POST)
    @ResponseBody
    public Response getPosDetails(final @RequestBody  MerchantPosDiscountRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosDiscountResponse response = new MerchantPosDiscountResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice result =  merchantPosService.getPosDetails(merchantPosDevice, serviceContext);
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setOutlet(result.getOutlet());
            response.setMerchant(result.getMerchant());
            response.setPosReleaseDate(result.getPosReleaseDate());
            response.setPosVersion(result.getPosVersion());
            
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service getPosDetails POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service getPosDetails POS [request: {}; response: {}]",request,response);
        }
        return response;
    }
    
    @RequestMapping(value = "qr/verification" , method = RequestMethod.POST)
    @ResponseBody
    public Response qrVerification(final @RequestBody  MerchnatPosQrRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosQrResponse response = new MerchantPosQrResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice result =  merchantPosService.qrVerification(merchantPosDevice, serviceContext);
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setCouponInfo(result.getCouponInfo());
            response.setMerchantPosTransactionData(result.getMerchantPosTransactionData());
            //External message & code
            response.setResponseCode(result.getResponseCode());
            response.setResponseCodeMessage(result.getResponseCodeMessage());
            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setCustomerPhoneNo(result.getCustomerPhoneNo());

        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service qrVerification POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service qrVerification POS [request: {}; response: {}]",request,response);
        }
        return response;
    }
    
    @RequestMapping(value = "redeem/coupon" , method = RequestMethod.POST)
    @ResponseBody
    public Response redeemCoupon(final @RequestBody  MerchnatPosQrRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosQrResponse response = new MerchantPosQrResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice result =  merchantPosService.redeemCoupon(merchantPosDevice, serviceContext);
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setCouponInfo(result.getCouponInfo());
            
        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            //send push
            ReceiverTransactionPushContent receiverTransactionPushContent = new ReceiverTransactionPushContent();
            receiverTransactionPushContent.setStatus(Constants.COUPON_REDEEM_FAILED);
            String pushTitle = messageSource.getMessage(COUPON_REDEEM_PUSH_TITLE,null,serviceContext.getLocale());
            String pushMessage = messageSource.getMessage(COUPON_REDEEM_PUSH_TITLE,null,serviceContext.getLocale());
            Map<String,String> iosAdditionalData = new HashMap<String,String>();
            iosAdditionalData.put(Constants.IOS_CONTENT_AVAILABLE, "1");
            internalNotificationService.sendPushToApp(request.getReservedCustomerId(), true,pushTitle ,pushMessage, receiverTransactionPushContent,
                    Constants.COUPON_REDEEM_FAILED, Constants.COUPON_REDEEM, serviceContext, iosAdditionalData);
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service redeemCoupon POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service redeemCoupon POS [request: {}; response: {}]",request,response);
        }
        return response;
    }
    

    @RequestMapping(value = "get/txn/status" , method = RequestMethod.POST)
    @ResponseBody
    public Response getTxnStatus(final @RequestBody  MerchnatPosQrRequest request, HttpServletRequest servletRequest){

        MerchantPosQrResponse response = new MerchantPosQrResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        PiPayPayment piPayPayment = new PiPayPayment();
        piPayPayment.setMerchantTransactionId(request.getMerchantTransactionId());
        piPayPayment.setIsPosCall(request.getIsPosCall());
        piPayPayment.setQrCode(request.getQrCode());

        try {
        	PiPayPayment result = piPayPaymentService.getTxnStatus(piPayPayment, serviceContext);
       	 	response.setTransactionStatus(result.getTransactionStatus());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setPiPayPayment(piPayPayment);

        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service getTxnStatus POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service getTxnStatus POS [request: {}; response: {}]",request,response);
        }
        return response;
    }



    @RequestMapping(value = "redeem/status" , method = RequestMethod.POST)
    @ResponseBody
    public Response checkCouponRedeemStatus(final @RequestBody  MerchnatPosQrRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosQrResponse response = new MerchantPosQrResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice result =  merchantPosService.checkCouponRedeemStatus(merchantPosDevice, serviceContext);
            response.setCouponRedemptionStatus(result.getCouponRedemptionStatus());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setCouponInfo(result.getCouponInfo());

        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service checkCouponRedeemStatus POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service checkCouponRedeemStatus POS [request: {}; response: {}]",request,response);
        }
        return response;
    }

    @RequestMapping(value = "request/pos/transaction/history" , method = RequestMethod.POST)
    @ResponseBody
    public Response getPosTransactionsHistory(final @RequestBody PosTransactionHistoryRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        PosTransactionHistoryResponse posTransactionHistoryResponse = new PosTransactionHistoryResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.getPosTransactionHistory(merchantPosDevice,serviceContext);
            posTransactionHistoryResponse.setMessage(merchantPos.getMessage());
            posTransactionHistoryResponse.setStatus(merchantPos.getStatus());
            posTransactionHistoryResponse.setTransactionsList(merchantPos.getTransactionList());
            posTransactionHistoryResponse.setResponseCode(merchantPos.getResponseCode());
            posTransactionHistoryResponse.setResponseCodeMessage(merchantPos.getResponseCodeMessage());
        }catch (InvalidRequestException exception){
            posTransactionHistoryResponse.setStatus(RequestStatus.FAILURE.getStatus());
            posTransactionHistoryResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(posTransactionHistoryResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,posTransactionHistoryResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,posTransactionHistoryResponse);
        }
        return posTransactionHistoryResponse;
    }

    private void setClientIP(final MerchantPosRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
    
    public String createJWTToken(String counterId) {
        long nowMillis = System.currentTimeMillis();
        Long expiaryTime = Long.parseLong(jwtUtil.getPOSExpiryTime());

        long expMillis = nowMillis + expiaryTime;
        Date exp = new Date(expMillis);

        String token = Jwts.builder().setSubject(counterId)
                .setIssuedAt(new Date())
                .signWith(SignatureAlgorithm.HS256, jwtUtil.getSecretCode())

                .setExpiration(exp)
                .compact();
        return token;
    }

    @RequestMapping(value = "coupon/summary/report" , method = RequestMethod.POST)
    @ResponseBody
    public Response posCouponSummaryReport(final @RequestBody MerchantPosCouponRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosCouponResponse response = new MerchantPosCouponResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.posCouponSummaryReport(merchantPosDevice,serviceContext);
            response.setMessage(merchantPos.getMessage());
            response.setStatus(merchantPos.getStatus());
            response.setCounterId(merchantPos.getCounterId());
            response.setGiftCouponCount(merchantPos.getGiftCouponCount());
            response.setStartDate(merchantPos.getStartDate());
            response.setEndDate(merchantPos.getEndDate());
            response.setMerchantId(merchantPos.getMerchantId());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,response);
        }
        return response;
    }



    @RequestMapping(value = "coupon/redemption/history" , method = RequestMethod.POST)
    @ResponseBody
    public Response posCouponRedemptionHistory(final @RequestBody MerchantPosCouponRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosCouponResponse response = new MerchantPosCouponResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.posCouponRedemptionHistory(merchantPosDevice,serviceContext);
            response.setMessage(merchantPos.getMessage());
            response.setStatus(merchantPos.getStatus());
            response.setCounterId(merchantPos.getCounterId());
            response.setCouponCount(merchantPos.getCouponCount());
            response.setStartDate(merchantPos.getStartDate());
            response.setEndDate(merchantPos.getEndDate());
            response.setCouponPosHistoryList(merchantPos.getCouponPosHistoryDtoList());
            response.setCouponPackPosHistoryDtoList(merchantPos.getCouponPackPosHistoryDtoList());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,response);
        }
        return response;
    }

    @RequestMapping(value = "coupon/redemption/history/details" , method = RequestMethod.POST)
    @ResponseBody
    public Response posCouponRedemptionHistoryDetails(final @RequestBody MerchantPosCouponRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosCouponResponse response = new MerchantPosCouponResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.posCouponRedemptionHistoryDetails(merchantPosDevice,serviceContext);
            response.setMessage(merchantPos.getMessage());
            response.setStatus(merchantPos.getStatus());
            response.setCouponPosHistoryDetails(merchantPos.getCouponPosHistoryDetailsDto());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,response);
        }
        return response;
    }

    @RequestMapping(value = "request/changeLanguage" , method = RequestMethod.POST)
    @ResponseBody
    public Response changeLanguage(final @RequestBody MerchantPosRequest request, HttpServletRequest servletRequest){

        MerchantPosDevice merchantPosDevice = new MerchantPosDevice();
        BeanUtils.copyProperties(request, merchantPosDevice);
        MerchantPosResponse merchantPosResponse = new MerchantPosResponse();
        ServiceContext serviceContext = getServiceContext(request, false);

        try {
            MerchantPosDevice merchantPos =  merchantPosService.changeLanguage(merchantPosDevice,serviceContext);
            merchantPosResponse.setLanguage(merchantPos.getLanguage());
            merchantPosResponse.setStatus(merchantPos.getStatus());
            merchantPosResponse.setMessage(merchantPos.getMessage());
        }catch (InvalidRequestException exception){
            merchantPosResponse.setStatus(RequestStatus.FAILURE.getStatus());
            merchantPosResponse.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(merchantPosResponse.getStatus())){
            log.warn("Service Request Merchant POS  - failure [request : {}; response: {}]",request,merchantPosResponse);
        }else {
            log.debug("Service Request Merchant POS [request: {}; response: {}]",request,merchantPosResponse);
        }
        return merchantPosResponse;
    }

    @RequestMapping(value = "khqrpay/encryption" , method = RequestMethod.POST)
    @ResponseBody
    public Response khqrPayEncryption(final @RequestBody KhqrReceiverRequest request, HttpServletRequest servletRequest){
        ServiceContext serviceContext = getServiceContext(request, false);

        KhqrReceiver khqrReceiver = new KhqrReceiver();
        BeanUtils.copyProperties(request, khqrReceiver);

        KhqrReceiverResponse response = new KhqrReceiverResponse();
        try {
            ReceiverKhqrCodeDto receiverKhqrCodeDto = symphonyQrCodePaymentService.getReceiverKhqrEncryptedText(khqrReceiver, serviceContext);
            response.setStatus(receiverKhqrCodeDto.getStatus());
            response.setMessage(receiverKhqrCodeDto.getMessage());

            if(receiverKhqrCodeDto.getCustomerMerchantProfile() == null){
                response.setCustomer(receiverKhqrCodeDto.getCustomer());
            } else {
                response.setCustomerMerchantProfile(receiverKhqrCodeDto.getCustomerMerchantProfile());
            }

            response.setMerchant(receiverKhqrCodeDto.getMerchant());
            response.setCurrencyCode(receiverKhqrCodeDto.getCurrencyCode());
            response.setQrCodeType(receiverKhqrCodeDto.getQrcodeType());
            response.setAmount(receiverKhqrCodeDto.getAmount());
            response.setTransactionId(receiverKhqrCodeDto.getTransactionId());
            response.setLifetime(receiverKhqrCodeDto.getLifetime());
            response.setQrEncryptedText(receiverKhqrCodeDto.getQrData());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Receiver khqrEncrypt - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Receiver khqrEncrypt [request: {}; response: {}]", request, response);
        }
        return response;
    }

}



