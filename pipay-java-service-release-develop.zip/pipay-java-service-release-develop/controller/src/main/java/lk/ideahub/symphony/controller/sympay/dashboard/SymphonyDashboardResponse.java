package lk.ideahub.symphony.controller.sympay.dashboard;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.dashboard.entity.Feature;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 4/2/19.
 */
@Getter
@Setter
@ToString
public class SymphonyDashboardResponse extends Response {

    private List<Feature> featureList;

    private String status;
    private String message;
}
