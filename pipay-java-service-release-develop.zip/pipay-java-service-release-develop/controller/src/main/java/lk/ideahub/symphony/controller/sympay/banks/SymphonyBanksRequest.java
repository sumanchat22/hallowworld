package lk.ideahub.symphony.controller.sympay.banks;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */

@Getter
@Setter
@ToString
public class SymphonyBanksRequest extends Request {
    private Long customerId;
    private Long banksId;
    private String transferType;
    private String integrationType;
}
