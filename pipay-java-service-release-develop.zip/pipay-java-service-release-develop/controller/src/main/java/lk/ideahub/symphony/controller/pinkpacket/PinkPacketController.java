package lk.ideahub.symphony.controller.pinkpacket;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.favourite.entity.CustomerShortcutDto;
import lk.ideahub.symphony.modules.favourite.service.FavouriteService;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacketDto;
import lk.ideahub.symphony.modules.pinkpacket.service.PinkPacketManagerService;
import lk.ideahub.symphony.product.sympay.common.LogSupport;

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/pink/packet", consumes = "application/json", produces = "application/json")
public class PinkPacketController extends GenericController{

private static final Logger log = LoggerFactory.getLogger(PinkPacketController.class);
	
	@Autowired
	PinkPacketManagerService pinkPacketManagerService;
	
	@RequestMapping(value = "create", method = RequestMethod.POST)
    @ResponseBody
    public Response createPinkPacket(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.createPinkPacket(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setPinkPacketGroup(result.getPinkPacketGroup());
            response.setPinkPacketList(result.getPinkPacketList());

        } catch (Exception exception) {
        	log.error("Service createPinkPacket error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service createPinkPacket - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service createPinkPacket [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "complete/creation/process", method = RequestMethod.POST)
    @ResponseBody
    public Response completeCreationProcess(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.completeCreationProcess(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
        	log.error("Service completeCreationProcess error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service completeCreationProcess - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service completeCreationProcess [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "accept", method = RequestMethod.POST)
    @ResponseBody
    public Response acceptPinkPacket(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.acceptPinkPacket(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setCode(result.getErrorCode());
            response.setPinkPacket(result.getPinkPacket());
            response.setPacketMessage(result.getPacketMessage());

        } catch (Exception exception) {
        	log.error("Service acceptPinkPacket error - " + exception.toString());
        	response.setCode(pinkPacketDto.getErrorCode());
        	response.setPinkPacket(pinkPacketDto.getPinkPacket());
        	response.setPinkPacketInfo(pinkPacketDto.getPinkPacketInfoDto());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        
        response.setExternalResponseCode(pinkPacketDto.getExternalResponseCode());
        response.setExternalResponseMessage(pinkPacketDto.getExternalResponseMessage());

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service acceptPinkPacket - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service acceptPinkPacket [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	/*@RequestMapping(value = "process/accept/result", method = RequestMethod.POST)
    @ResponseBody
    public Response processAcceptance(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.processAcceptance(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service processAcceptance - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service processAcceptance [request: {}; response: {}]", request, response);
        }
        return response;
    }*/
	
	@RequestMapping(value = "get/latest/info", method = RequestMethod.POST)
    @ResponseBody
    public Response getLatestInfo(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.getLatestInfo(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setPinkPacketInfo(result.getPinkPacketInfoDto());

        } catch (Exception exception) {
        	log.error("Service getLatestInfo error - " + exception.toString());
        	response.setCode(pinkPacketDto.getErrorCode());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getLatestInfo - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getLatestInfo [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "get/sent/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getSentList(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.getSentList(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setPinkPacketGroupList(result.getPinkPacketGroupList());

        } catch (Exception exception) {
        	log.error("Service getSentList error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getSentList - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getSentList [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "get/received/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getReceivedList(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.getReceivedList(pinkPacketDto, serviceContext);
        	response.setPinkPacketList(result.getPinkPacketList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
        	log.error("Service getReceivedList error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getReceivedList - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getReceivedList [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "get/group/info", method = RequestMethod.POST)
    @ResponseBody
    public Response getGroupInfo(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.getGroupInfo(pinkPacketDto, serviceContext);
        	response.setPinkPacketList(result.getPinkPacketList());
        	response.setPinkPacketGroupInfo(result.getPinkPacketGroupInfo());
        	response.setUnAcceptedFriends(result.getUnAcceptedFriends());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
        	log.error("Service getGroupInfo error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getGroupInfo - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getGroupInfo [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "expire/invalid/packets", method = RequestMethod.POST)
	@ResponseBody
    public Response expireInvalidPackets(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	if(request.getIsExpirationProcessDisabled()) {
        		log.info(LogSupport.EXPIRE_INVALID_PACKETS + " Cron Job disabled..");
        		response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
        	}
        	log.info(LogSupport.EXPIRE_INVALID_PACKETS + " Cron Job Started..");
        	PinkPacketDto result = pinkPacketManagerService.expireInvalidPackets(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.EXPIRE_INVALID_PACKETS + " Cron Job Completed..");

        } catch (Exception exception) {
        	log.error("Service expireInvalidPackets error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.EXPIRE_INVALID_PACKETS + " Cron Job Ended With Errors..");
        }
        
        response.setExternalResponseCode(pinkPacketDto.getExternalResponseCode());
        response.setExternalResponseMessage(pinkPacketDto.getExternalResponseMessage());

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service expireInvalidPackets - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service expireInvalidPackets [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "get/summary/info", method = RequestMethod.POST)
    @ResponseBody
    public Response getSummaryInfo(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	PinkPacketDto result = pinkPacketManagerService.getSummaryInfo(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setSummaryInfo(result.getSummaryInfo());

        } catch (Exception exception) {
        	log.error("Service getSummaryInfo error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getSummaryInfo - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getSummaryInfo [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "manually/refund/expired/packets", method = RequestMethod.POST)
	@ResponseBody
    public Response manuallyRefundExpiredPackets(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
        	log.info(LogSupport.MANUALLY_REFUND_EXPIRED_PACKETS + "Started..");
        	PinkPacketDto result = pinkPacketManagerService.expireInvalidPackets(pinkPacketDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.MANUALLY_REFUND_EXPIRED_PACKETS + "Completed..");

        } catch (Exception exception) {
        	log.error("Service manuallyRefundExpiredPackets error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.MANUALLY_REFUND_EXPIRED_PACKETS + "Ended With Errors..");
        }
        
        response.setExternalResponseCode(pinkPacketDto.getExternalResponseCode());
        response.setExternalResponseMessage(pinkPacketDto.getExternalResponseMessage());

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service manuallyRefundExpiredPackets - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service manuallyRefundExpiredPackets [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "manually/expire/invalid/packets", method = RequestMethod.POST)
    @ResponseBody
    public Response manuallyExpireInvalidPackets(final @RequestBody PinkPacketRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        PinkPacketDto pinkPacketDto = new PinkPacketDto();
        BeanUtils.copyProperties(request, pinkPacketDto);
        PinkPacketResponse response = new PinkPacketResponse();

        try {
            if(!request.getIsExpirationProcessDisabled()) {
                log.info(LogSupport.EXPIRE_INVALID_PACKETS + " Cron Job disabled..");
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
            }
            else {
                log.info(LogSupport.EXPIRE_INVALID_PACKETS + "Started..");
                PinkPacketDto result = pinkPacketManagerService.expireInvalidPackets(pinkPacketDto, serviceContext);
                response.setStatus(result.getStatus());
                response.setMessage(result.getMessage());
            }

        } catch (Exception exception) {
            log.error("Service expireInvalidPackets error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        response.setExternalResponseCode(pinkPacketDto.getExternalResponseCode());
        response.setExternalResponseMessage(pinkPacketDto.getExternalResponseMessage());

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service manuallyExpireInvalidPackets - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service manuallyExpireInvalidPackets [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	private void setClientIP(final PinkPacketRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
