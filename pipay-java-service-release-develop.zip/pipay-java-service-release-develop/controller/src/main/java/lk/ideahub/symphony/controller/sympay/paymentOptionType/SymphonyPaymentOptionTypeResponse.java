package lk.ideahub.symphony.controller.sympay.paymentOptionType;

import lk.ideahub.symphony.controller.common.Response;

import java.util.List;

/**
 * Created by Madhukara on 12/5/17.
 */
public class SymphonyPaymentOptionTypeResponse extends Response {

    private List paymentOptionTypes;

    // status
    private String status;
    private String message;

    public List getPaymentOptionTypes() {
        return paymentOptionTypes;
    }

    public void setPaymentOptionTypes(List paymentOptionTypes) {
        this.paymentOptionTypes = paymentOptionTypes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyPaymentOptionTypeResponse {")
                .append("paymentOptionTypes=").append(paymentOptionTypes).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
