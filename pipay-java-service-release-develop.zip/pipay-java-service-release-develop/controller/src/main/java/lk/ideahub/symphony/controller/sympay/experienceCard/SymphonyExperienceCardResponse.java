package lk.ideahub.symphony.controller.sympay.experienceCard;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.experienceCard.entity.ExperienceCard;
import lk.ideahub.symphony.modules.experienceCard.entity.FilterTag;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 12/13/18.
 */
@Getter
@Setter
@ToString
public class SymphonyExperienceCardResponse extends Response {

    private List<ExperienceCard> experienceCardList;
    private ExperienceCard hashTagExpCard;
    private List<FilterTag> filterTagList;
    private Integer totalExpCards;
    private String status;
    private String message;
}
