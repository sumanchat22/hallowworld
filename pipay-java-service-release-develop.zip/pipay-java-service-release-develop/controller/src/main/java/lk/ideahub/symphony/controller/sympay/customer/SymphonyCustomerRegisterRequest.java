package lk.ideahub.symphony.controller.sympay.customer;

import com.fasterxml.jackson.annotation.JsonFormat;
import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by samith on 9/29/15.
 */
@Getter
@Setter
@ToString
public class SymphonyCustomerRegisterRequest extends Request {

    //common
    private Long customerId;
    private Long symphonyCustomerId;

    //init register
    private String msisdn;

    //confirm otp
    private String otp;

    //confirm kyc
    private String firstName;
    private String lastName;
    private String email;
    private String personalId;
    private String streetLine1;
    private String gender;
    private String language;

    //upgrade customer
    private String country;
    private String identityNumber;
    private String idType;

    //upload document
    private List<String> documentTypeList;
    private List<String> imageTypeList;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "UTC")
    private Date dateOfBirth;
    private String mothersMaidenName;

    //add auth
    private String password;
    private String PIN;
    private String responseCode;
    private String externalResponseDesc;
    private String externalResponseCode;

    //change
    private String newPassword;

    //reset auth
    private String token;

    //session token
    private String sessionToken;

    //abort
    private String isAbort;

    //otc
    private Long merchantTransactionId;
    private String merchantTxnStatusName;

    //request touchId
    private String uid;

    //generate device session
    private String deviceType;
    private String deviceName;

    //Remember me session
    private String keepMeLogged;

    private String rateStatus;

    //init merchant transaction
    private Long merchantId;
    private BigDecimal amount;
    private String walletAlias;
    private String currency;

    //login
    private String loginType;
    private String loginOtp;
    private String loginTouchId;

    //update profile
    private String editField;

    //upload profile picture
    private byte[] mainImageByte;
    private String mainImageType;
    private byte[] thumbnailImageByte;
    private String thumbnailImageType;

    //get app details
    private String requiredData;

    //image re-submit
    private List<byte[]> imageByteList;
    
    private String transactionType;
    private String deviceOsType;

    private String uuid;
    private String registrationToken;
    private String osTypeName; //Android,IOS

    private Long couponPackId;

    private Long pointGlobalPercentageId;
    
    //Quick Pay
    private Boolean isEnabled;

    private byte[] imageByte;
    private String imageType;

    // Close Wallet
    private String closedWalletRemark;

}
