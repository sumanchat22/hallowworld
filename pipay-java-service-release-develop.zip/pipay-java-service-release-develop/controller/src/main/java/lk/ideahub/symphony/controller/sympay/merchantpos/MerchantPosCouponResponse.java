package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.loyalty.entity.coupon.CouponPackPosHistoryDto;
import lk.ideahub.symphony.modules.loyalty.entity.coupon.CouponTransaction;
import lk.ideahub.symphony.product.sympay.loyalty.entity.CouponPosHistoryDetailsDto;
import lk.ideahub.symphony.product.sympay.loyalty.entity.CouponPosHistoryDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@ToString
public class MerchantPosCouponResponse extends Response {
    private Long giftCouponCount;
    private Date startDate;
    private Date endDate;
    private Long counterId;
    private Long merchantId;
    private String message;
    private String status;

    private Long couponCount;
    private List<CouponPosHistoryDto> couponPosHistoryList;
    private CouponPosHistoryDetailsDto couponPosHistoryDetails;

    //coupon pack
    private  List<CouponPackPosHistoryDto> couponPackPosHistoryDtoList;

    //coupon txn
    private List<CouponTransaction> couponRedemptionHistoryList;
}
