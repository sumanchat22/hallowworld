package lk.ideahub.symphony.controller.sympay.merchant;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantService;

/**
 * Created by samith on 12/20/15.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/merchant", consumes = "application/json", produces = "application/json")
public class SymphonyMerchantController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyMerchantController.class);

    @Autowired
    SymphonyMerchantService symphonyMerchantService;

    @RequestMapping(value = "verification", method = RequestMethod.POST)
    @ResponseBody
    public Response verification(final @RequestBody SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant symphonyMerchant = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, symphonyMerchant);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();
        try {
            SymphonyMerchant result = symphonyMerchantService.verification(symphonyMerchant, serviceContext);

            response.setSessionToken(result.getSessionToken());
            response.setMerchantDiscountId(result.getMerchantDiscountId());
            response.setChargeTotal(result.getChargeTotal());
            response.setMerchantPgConnection(result.getMerchantPgConnection());
            response.setQrEncryptedText(result.getQrEncryptedText());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service verification - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service verification [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "login", method = RequestMethod.POST)
    @ResponseBody
    public Response merchantLogin(final @RequestBody SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
    	ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();
        try {
            SymphonyMerchant result = symphonyMerchantService.login(piPayCustomer, serviceContext);

            response.setMerchant(result.getMerchant());
            response.setUser(result.getUser());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPassword(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service merchantLogin - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service merchantLogin [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "init/otc", method = RequestMethod.POST)
    @ResponseBody
    public Response merchantInitOtc(final @RequestBody SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {
        log.info(LogSupport.INIT_OTC+"{} init merchantInitOtc",_request.getUserId());
    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);
        piPayCustomer.setIsExternalMerchant(false);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();

        try {
            SymphonyMerchant result = symphonyMerchantService.initOtc(piPayCustomer, serviceContext);

            response.setCustomer(result.getCustomer());
            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service merchantInitOtc - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service merchantInitOtc [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "otc/change/status", method = RequestMethod.POST)
    @ResponseBody
    public Response otcMerchantCancel(final @RequestBody SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);
        piPayCustomer.setIsExternalMerchant(false);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();
        try {
        	SymphonyMerchant result = new SymphonyMerchant();
        	if (piPayCustomer.getMerchantTxnStatusName().equals("Merchant Cancel")) {
        		result = symphonyMerchantService.otcMerchantCancel(piPayCustomer, serviceContext);
        	}else if(piPayCustomer.getMerchantTxnStatusName().equals("Reversed")){
        		result = symphonyMerchantService.otcMerchantVoid(piPayCustomer, serviceContext);
        	}
            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service otcMerchantCancel - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service otcMerchantCancel [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "otc/get/transaction", method = RequestMethod.POST)
    @ResponseBody
    public Response otcMerchantGetTransaction(final @RequestBody SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant piPayCustomer = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, piPayCustomer);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();
        try {
            SymphonyMerchant result = symphonyMerchantService.otcMerchantGetTransaction(piPayCustomer, serviceContext);

            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service otcMerchantGetTransaction - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service otcMerchantGetTransaction [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "validate/card/discount", method = RequestMethod.POST)
    @ResponseBody
    public Response validateDiscount(final @RequestBody SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyMerchant symphonyMerchant = new SymphonyMerchant();
        BeanUtils.copyProperties(_request, symphonyMerchant);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();
        try {
            SymphonyMerchant result = symphonyMerchantService.validateCardDiscount(symphonyMerchant, serviceContext);
            response.setValidDiscount(result.getValidDiscount());
            response.setInvalidReason(result.getInvalidReason());
            response.setMerchantTransaction(result.getMerchantTransaction());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setCardIdentifier(null);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service validate Discount - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service validate Discount [request: {}; response: {}]", _request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "get/banks", method = RequestMethod.POST)
    @ResponseBody
    public Response getBanks(final @RequestBody SymphonyMerchantRequest request, HttpServletRequest servletRequest) {

    	setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyMerchant symphonyMerchant = new SymphonyMerchant();
        BeanUtils.copyProperties(request, symphonyMerchant);

        SymphonyMerchantResponse response = new SymphonyMerchantResponse();
        try {
            SymphonyMerchant result = symphonyMerchantService.getBankList(symphonyMerchant, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setBankList(result.getBankList());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getBanks - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getBanks [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    private void setClientIP(final SymphonyMerchantRequest _request, HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}

}
