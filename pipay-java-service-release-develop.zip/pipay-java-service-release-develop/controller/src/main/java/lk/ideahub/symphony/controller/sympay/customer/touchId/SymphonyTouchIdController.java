package lk.ideahub.symphony.controller.sympay.customer.touchId;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.touchId.entity.SymphonyTouchId;
import lk.ideahub.symphony.product.sympay.touchId.service.SymphonyTouchIdService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 4/23/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/customer", consumes = "application/json", produces = "application/json")
public class SymphonyTouchIdController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyTouchIdController.class);

    @Autowired
    SymphonyTouchIdService symphonyTouchIdService;

    @RequestMapping(value = "request/touchId" , method = RequestMethod.POST)
    @ResponseBody
    public Response requestTouchId(final @RequestBody SymphonyTouchIdRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);

        SymphonyTouchId symphonyTouchId = new SymphonyTouchId();
        BeanUtils.copyProperties(_request, symphonyTouchId);

        SymphonyTouchIdResponse response = new SymphonyTouchIdResponse();

        try {
            SymphonyTouchId result = symphonyTouchIdService.requestTouchId(symphonyTouchId,serviceContext);

            response.setAliasPIN(result.getAliasPIN());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setPIN(null);

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service requestTouchId - failure [request : {}; response: {}]",_request,response);
        }else {
            log.debug("Service requestTouchId [request: {}; response: {}]",_request,response);
        }
        return response;
    }

    @RequestMapping(value = "disable/touchId" , method = RequestMethod.POST)
    @ResponseBody
    public Response disableTochId(final @RequestBody SymphonyTouchIdRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);

        SymphonyTouchId symphonyTouchId = new SymphonyTouchId();
        BeanUtils.copyProperties(_request, symphonyTouchId);

        SymphonyTouchIdResponse response = new SymphonyTouchIdResponse();
        try {
            SymphonyTouchId result = symphonyTouchIdService.disableTouchId(symphonyTouchId,serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service disableTouchId - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service disableTouchId [request: {}; response: {}]",_request,response);
        }
        return response;

    }

    private void setClientIP(final SymphonyTouchIdRequest _request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }

    @RequestMapping(value = "request/enableLoginTouchId" , method = RequestMethod.POST)
    @ResponseBody
    public Response enableLoginTouchId(final @RequestBody SymphonyTouchIdRequest request, HttpServletRequest servletRequest){

        setClientIP(request,servletRequest);
        ServiceContext serviceContext = getServiceContext(request,false);

        SymphonyTouchId symphonyTouchId = new SymphonyTouchId();
        BeanUtils.copyProperties(request, symphonyTouchId);

        SymphonyTouchIdResponse response = new SymphonyTouchIdResponse();

        try {
            SymphonyTouchId result = symphonyTouchIdService.enableLoginTouchId(symphonyTouchId,serviceContext);

            response.setAliasPIN(result.getAliasPIN());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        request.setPIN(null);

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service enableLoginTouchId - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service enableLoginTouchId [request: {}; response: {}]",request,response);
        }
        return response;
    }



    @RequestMapping(value = "request/disableLoginTouchId" , method = RequestMethod.POST)
    @ResponseBody
    public Response disableLoginTouchId(final @RequestBody SymphonyTouchIdRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);

        SymphonyTouchId symphonyTouchId = new SymphonyTouchId();
        BeanUtils.copyProperties(_request, symphonyTouchId);

        SymphonyTouchIdResponse response = new SymphonyTouchIdResponse();

        try {
            SymphonyTouchId result = symphonyTouchIdService.disableTouchId(symphonyTouchId,serviceContext);

            response.setAliasPIN(result.getAliasPIN());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        _request.setPIN(null);

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service disableLoginTouchId - failure [request : {}; response: {}]",_request,response);
        }else {
            log.debug("Service disableLoginTouchId [request: {}; response: {}]",_request,response);
        }
        return response;
    }


}
