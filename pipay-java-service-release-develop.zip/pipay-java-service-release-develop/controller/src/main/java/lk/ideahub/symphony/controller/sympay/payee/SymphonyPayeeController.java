package lk.ideahub.symphony.controller.sympay.payee;


import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.payee.entiry.SymphonyPayee;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.payee.service.SymphonyPayeeService;


/**
 * Created by samith on 11/16/15.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/payee", consumes = "application/json", produces = "application/json")
public class SymphonyPayeeController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyPayeeController.class);

    @Autowired
    SymphonyPayeeService symphonyPayeeService;

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response getPayeeList(final @RequestBody SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.customerPayeeList(symphonyPayee, serviceContext);

            response.setCustomerPayees(result.getCustomerPayeeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getPayeeList - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getPayeeList [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "set/default", method = RequestMethod.POST)
    @ResponseBody
    public Response setPayeeDefault(final @RequestBody SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.setDefaultPayee(symphonyPayee, serviceContext);

            response.setCustomerPayees(result.getCustomerPayeeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service setPayeeDefault - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service setPayeeDefault [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Response addPayee(final @RequestBody SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.addPayee(symphonyPayee, serviceContext);

            response.setCustomerPayee(result.getCustomerPayee());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }
        _request.setPayeeAccountNo(null);
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addPayee - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service addPayee [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "types", method = RequestMethod.POST)
    @ResponseBody
    public Response getPayeeTypes(final @RequestBody SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.getPayeeTypes(symphonyPayee, serviceContext);

            response.setPayeeTypeList(result.getPayeeTypeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getPayeeTypes - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getPayeeTypes [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "delete", method = RequestMethod.POST)
    @ResponseBody
    public Response deletePayee(final @RequestBody SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.deletePayee(symphonyPayee, serviceContext);

            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service deletePayee - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service deletePayee [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "update", method = RequestMethod.POST)
    @ResponseBody
    public Response updatePayee(final @RequestBody SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.updatePayee(symphonyPayee, serviceContext);

            response.setCustomerPayee(result.getCustomerPayee());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        _request.setPayeeAccountNo(null);
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updatePayee - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service updatePayee [request: {}; response: {}]", _request, response);
        }
        return response;
    }
    
    private void setClientIP(final SymphonyPayeeRegisterRequest _request, HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}

    @RequestMapping(value = "utility/validate", method = RequestMethod.POST)
    @ResponseBody
    public Response validateUtilityPayee(final @RequestBody SymphonyPayeeRegisterRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(_request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.validateUtilityPayee(symphonyPayee, serviceContext);

            response.setCustomerPayee(result.getCustomerPayee());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service Validate Utility Payee - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service Validate Utility Payee [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "group/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getPayeeGroupList(final @RequestBody SymphonyPayeeRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.getPayeeGroupList(symphonyPayee, serviceContext);

            response.setPayeeGroupTypeList(result.getPayeeGroupTypeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getPayeeGroupList - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getPayeeGroupList [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Response searchPayee(final @RequestBody SymphonyPayeeRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.searchPayee(symphonyPayee, serviceContext);

            response.setPayeeTypeList(result.getPayeeTypeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service search payee - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service search payee [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "validate/account", method = RequestMethod.POST)
    @ResponseBody
    public Response validateAccount(final @RequestBody SymphonyPayeeRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.validateAccount(symphonyPayee, serviceContext);

            response.setPayeeType(result.getPayeeType());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service validateAccount - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service validateAccount [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get", method = RequestMethod.POST)
    @ResponseBody
    public Response getPayee(final @RequestBody SymphonyPayeeRegisterRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyPayee symphonyPayee = new SymphonyPayee();
        BeanUtils.copyProperties(request, symphonyPayee);

        SymphonyPayeeRegisterResponse response = new SymphonyPayeeRegisterResponse();
        try {
            SymphonyPayee result = symphonyPayeeService.findPayeeById(symphonyPayee, serviceContext);

            response.setPayeeType(result.getPayeeType());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get payee - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get payee [request: {}; response: {}]", request, response);
        }
        return response;
    }
}
