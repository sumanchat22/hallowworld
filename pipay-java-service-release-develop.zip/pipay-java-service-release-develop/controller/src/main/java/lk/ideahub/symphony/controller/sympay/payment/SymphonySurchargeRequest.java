package lk.ideahub.symphony.controller.sympay.payment;

import lk.ideahub.symphony.controller.common.Request;

import java.math.BigDecimal;

/**
 * Created by Madhukara on 12/7/17.
 */
public class SymphonySurchargeRequest extends Request {

    private Long customerId;
    private Long merchantId;
    private Long paymentOptionTypeId;
    private BigDecimal netAmount;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }

    public Long getPaymentOptionTypeId() {
        return paymentOptionTypeId;
    }

    public void setPaymentOptionTypeId(Long paymentOptionTypeId) {
        this.paymentOptionTypeId = paymentOptionTypeId;
    }

    public BigDecimal getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(BigDecimal netAmount) {
        this.netAmount = netAmount;
    }


    @Override
    public String toString() {
        return new StringBuilder("SymphonySurchargeRequest {")
                .append("customerId=").append(customerId).append(", ")
                .append("merchantId=").append(merchantId).append(", ")
                .append("paymentOptionTypeId=").append(paymentOptionTypeId).append(", ")
                .append("netAmount=").append(netAmount)
                .append('}').toString();
    }
}
