package lk.ideahub.symphony.controller.types;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.types.entity.SymphonyVersion;
import lk.ideahub.symphony.product.sympay.types.service.SymphonyVersionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by mahesha on 5/16/17.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/version", consumes = "application/json", produces = "application/json")
public class VersionController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(VersionController.class);

    @Autowired
    SymphonyVersionService symphonyVersionService;


    @RequestMapping(value = "check" , method = RequestMethod.POST)
    @ResponseBody
    public Response checkVersion(){

        SymphonyVersion symphonyVersion = new SymphonyVersion();
        VersionResponse response = new VersionResponse();

        try {
            SymphonyVersion result = symphonyVersionService.checkVersion(symphonyVersion);
            response.setAndroid(result.getAndroid());
            response.setIos(result.getIos());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service checkVersion - failure");
        }else {
            log.debug("Service checkVersion");
        }
        return response;

    }
}
