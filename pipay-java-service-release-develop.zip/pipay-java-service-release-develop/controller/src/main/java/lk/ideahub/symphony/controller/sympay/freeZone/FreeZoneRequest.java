package lk.ideahub.symphony.controller.sympay.freeZone;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by Madhukara on 4/9/18.
 */
@Getter
@Setter
@ToString
public class FreeZoneRequest extends Request {

    private Long customerId;
    private String redeemCode;
    private String platform;
}
