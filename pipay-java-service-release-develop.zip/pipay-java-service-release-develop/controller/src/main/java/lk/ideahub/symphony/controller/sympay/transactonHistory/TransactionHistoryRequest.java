package lk.ideahub.symphony.controller.sympay.transactonHistory;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TransactionHistoryRequest extends Request {

    private Long customerId;
    private String transactionType;
    private String numberOfTransactions;
    private String offset;
    private String paymentInstrumentId;

}
