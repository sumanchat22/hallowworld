package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class PushExternalResponse extends Response{

	private int totalDeviceCount;
	private int sentDeviceCount;
	private String status;
	private String message;
	private String responseCode;
}
