package lk.ideahub.symphony.controller.sympay.generate.khqr;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Request;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.controller.sympay.payment.pipay.PiPayPaymentRequest;
import lk.ideahub.symphony.controller.sympay.payment.pipay.PiPayPaymentResponse;
import lk.ideahub.symphony.controller.sympay.qrcode.payment.QrCodePaymentRequest;
import lk.ideahub.symphony.controller.sympay.qrcode.payment.QrCodePaymentResponse;
import lk.ideahub.symphony.controller.sympay.receiver.KhqrReceiverRequest;
import lk.ideahub.symphony.controller.sympay.receiver.KhqrReceiverResponse;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.internal.InternalNotificationService;
import lk.ideahub.symphony.product.sympay.payment.entity.PiPayPayment;
import lk.ideahub.symphony.product.sympay.payment.service.PiPayPaymentService;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.ReceiverKhqrCodeDto;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.SymphonyQrCodePayment;
import lk.ideahub.symphony.product.sympay.qrcode.payment.service.PiPayQrCodePaymentService;
import lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentService;
import lk.ideahub.symphony.product.sympay.receiver.entity.KhqrReceiver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * @author somma.soun - PiPay
 * @create 22-Apr-2022
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/generate", consumes = "application/json", produces = "application/json")
public class SymphonyGenerateKhqrController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyGenerateKhqrController.class);

    //push messsages
    private static final String AUAM_PUSH_TITLE = "message.receiver.auam.qr.payment.status.title";
    private static final String AUAM_PUSH_PAY_AUAM_PAYMENT_ERROR = "message.receiver.auam.payment.error.message";

    @Autowired
    SymphonyQrCodePaymentService symphonyQrCodePaymentService;

    @Autowired
    private PiPayQrCodePaymentService piPayQrCodePaymentService;

    @Autowired
    private PiPayPaymentService piPayPaymentService;

    @Autowired
    InternalNotificationService internalNotificationService;

    @Autowired
    private MessageSource messageSource;

    @RequestMapping(value = "khqrpay/encryption" , method = RequestMethod.POST)
    @ResponseBody
    public Response khqrPayEncryption(final @RequestBody KhqrReceiverRequest request, HttpServletRequest servletRequest){
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        KhqrReceiver khqrReceiver = new KhqrReceiver();
        BeanUtils.copyProperties(request, khqrReceiver);

        KhqrReceiverResponse response = new KhqrReceiverResponse();
        try {
            ReceiverKhqrCodeDto receiverKhqrCodeDto = symphonyQrCodePaymentService.getReceiverKhqrEncryptedText(khqrReceiver, serviceContext);
            response.setStatus(receiverKhqrCodeDto.getStatus());
            response.setMessage(receiverKhqrCodeDto.getMessage());

            if (receiverKhqrCodeDto.getCustomerMerchantProfile() == null) {
                response.setCustomer(receiverKhqrCodeDto.getCustomer());
            } else {
                response.setCustomerMerchantProfile(receiverKhqrCodeDto.getCustomerMerchantProfile());
            }

            response.setMerchant(receiverKhqrCodeDto.getMerchant());
            response.setCurrencyCode(receiverKhqrCodeDto.getCurrencyCode());
            response.setQrCodeType(receiverKhqrCodeDto.getQrcodeType());
            response.setAmount(receiverKhqrCodeDto.getAmount());
            response.setTransactionId(receiverKhqrCodeDto.getTransactionId());
            response.setLifetime(receiverKhqrCodeDto.getLifetime());
            response.setQrEncryptedText(receiverKhqrCodeDto.getQrData());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Receiver khqrEncrypt - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Receiver khqrEncrypt [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "khqrpay/verification", method = RequestMethod.POST)
    @ResponseBody
    public Response paymentVerification(final @RequestBody QrCodePaymentRequest qrCodePaymentRequest,HttpServletRequest servletRequest){

        setClientIP(qrCodePaymentRequest, servletRequest);
        ServiceContext serviceContext = getServiceContext(qrCodePaymentRequest, false);

        SymphonyQrCodePayment symphonyQrCodePayment = new SymphonyQrCodePayment();
        BeanUtils.copyProperties(qrCodePaymentRequest, symphonyQrCodePayment);

        QrCodePaymentResponse response = new QrCodePaymentResponse();
        try{
            SymphonyQrCodePayment result = piPayQrCodePaymentService.externalPaymentKhqrVerification(symphonyQrCodePayment, serviceContext);
            response.setFriendDto(result.getFriendDto());
            response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service paymentVerification - failure [request: {}; response: {}]", qrCodePaymentRequest, response);
        } else {
            log.debug("Service paymentVerification [request: {}; response: {}]", qrCodePaymentRequest, response);
        }
        return response;
    }

    @RequestMapping(value = "khqrpay/payment/cancel", method = RequestMethod.POST)
    @ResponseBody
    public Response receiverCancelPayment(final @RequestBody PiPayPaymentRequest request, HttpServletRequest servletRequest){

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        PiPayPayment piPayPayment = new PiPayPayment();
        BeanUtils.copyProperties(request, piPayPayment);

        PiPayPaymentResponse response = new PiPayPaymentResponse();

        try {
            PiPayPayment result = piPayPaymentService.cancelReceiverPay(piPayPayment, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        } catch(Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

            String pushTitle = messageSource.getMessage(AUAM_PUSH_TITLE,null,serviceContext.getLocale());
            String pushMessage = messageSource.getMessage(AUAM_PUSH_PAY_AUAM_PAYMENT_ERROR,null,serviceContext.getLocale());
            Map<String,String> iosAdditionalData = new HashMap<String,String>();
            iosAdditionalData.put(Constants.IOS_CONTENT_AVAILABLE, "1");
            internalNotificationService.sendPushToApp(piPayPayment.getCustomerId(), true, pushTitle, pushMessage, null,
                    RequestStatus.SUCCESS.getStatus(), Constants.AUAM_PAYMENT_CONFIRMATION, serviceContext, iosAdditionalData);

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service piPay-receiverCancelPayment - failure [request: {}; response: {}]", request, response);
        } else {
            log.info("Service piPay-receiverCancelPayment [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final Request request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }

}
