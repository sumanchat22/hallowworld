package lk.ideahub.symphony.controller.types;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.types.entity.Android;
import lk.ideahub.symphony.product.sympay.types.entity.IOS;

/**
 * Created by mahesha on 5/16/17.
 */
public class VersionResponse extends Response {

    private Android android;
    private IOS ios;

    private String status;
    private String message;

    public Android getAndroid() {
        return android;
    }

    public void setAndroid(Android android) {
        this.android = android;
    }

    public IOS getIos() {
        return ios;
    }

    public void setIos(IOS ios) {
        this.ios = ios;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return new StringBuilder("VersionResponse {")
                .append("android=").append(android).append(", ")
                .append("ios=").append(ios).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
