package lk.ideahub.symphony.controller.catalogue.voucher;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by kalpana on 11/3/15.
 */
@Getter
@Setter
@ToString
public class VoucherRequest extends Request {
    // merchants
    private String code;
    private String appId;

    // voucher packs
    private String merchantId;
    private String category;

    // reserve vouchers
    private Long voucherPackId;

    // purchase vouchers
    private String reserveId;
    private String buyerMSISDN;
    private int paymentOption;

    // redeem vouchers
    private String voucherPin;
    private String counterType;
    private String counterReference;

    //redeemConfirm vouchers
    private String outletCounterId;

    //resend voucher
    private Long voucherId;

    //get payment methods
    private Long customerId;

    //initiate transaction
    private BigDecimal purchaseValue;

    //complete transaction
    private Long transactionStatusId;
    private String transactionCode;
    private String transactionResponse;

    private String receiverMobileNumber;
    private String receiverName;
    private String greeting;
    private String sendersName;
}
