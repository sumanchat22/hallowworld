package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.external.ExternalServiceResponseCodes;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.modules.customerSendVerificationCode.service.CustomerSendVerificationCodeService;
import lk.ideahub.symphony.product.sympay.customerSendVerificationCode.entity.SymphonyCustomerSendVerificationCode;
import lk.ideahub.symphony.product.sympay.customerSendVerificationCode.service.SymphonyCustomerSendVerificationCodeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * 
 * @author Bunna Hoeun
 *
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/service/external/customer")
public class CustomerSendVerificationCodeController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(CustomerSendVerificationCodeController.class);
	
	@Autowired
    CustomerSendVerificationCodeService customerSendVerificationCodeService;

	@Autowired
    SymphonyCustomerSendVerificationCodeService symphonyCustomerSendVerificationCodeService;
	
	@RequestMapping(value = "get/code", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
	public Response getVerificationCode(final @RequestBody CustomerSendVerificationCodeRequest request, HttpServletRequest servletRequest) {
		log.info(LogSupport.CUSTOMER_REQUEST_VERIFICATION_CODE + "Push verification code post service started..");
		log.info(LogSupport.CUSTOMER_REQUEST_VERIFICATION_CODE + "request " + request);
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomerSendVerificationCode symphonyCustomerSendVerificationCode = new SymphonyCustomerSendVerificationCode();
        BeanUtils.copyProperties(request, symphonyCustomerSendVerificationCode);
        
        CommonExternalResponse response = new CommonExternalResponse();
        try {
            SymphonyCustomerSendVerificationCode result = symphonyCustomerSendVerificationCodeService.customerRequestVerificationCode(symphonyCustomerSendVerificationCode, serviceContext);

            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setGlobalPercentageDtoList(result.getGlobalPercentageDtoList());

            result.setErrorCode(null);
            result.setMessage(null);
            result.setClientIp(null);

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	log.error(LogSupport.CUSTOMER_REQUEST_VERIFICATION_CODE + "getVerificationCode() error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setStatus(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("customer request verification code() - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("customer request verification getCustomer [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "verify/code", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
	public Response verifyCode(final @RequestBody CustomerSendVerificationCodeRequest request, HttpServletRequest servletRequest) {
		log.info(LogSupport.CUSTOMER_REQUEST_VERIFICATION_CODE + "Verify Code service started..");
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyCustomerSendVerificationCode symphonyCustomerSendVerificationCode = new SymphonyCustomerSendVerificationCode();
        BeanUtils.copyProperties(request, symphonyCustomerSendVerificationCode);

        CommonExternalResponse response = new CommonExternalResponse();
        try {
            SymphonyCustomerSendVerificationCode result = symphonyCustomerSendVerificationCodeService.customerVerifyCode(symphonyCustomerSendVerificationCode, serviceContext);

            response.setResponseCode(result.getErrorCode());
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());

        }catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            response.setResponseCode(exception.getCode());
        }catch (Exception exception) {
        	exception.printStackTrace();
        	log.error(LogSupport.CUSTOMER_REQUEST_VERIFICATION_CODE + "verifyCode() error: " + exception.toString());
        	response.setResponseCode(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR);
            response.setMessage(ExternalServiceResponseCodes.INTERNAL_SERVER_ERROR_MSG);
            response.setStatus(RequestStatus.FAILURE.getStatus());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("verifyCode() - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("verifyCode() [request: {}; response: {}]", request, response);
        }
        return response;
    }

	private void setClientIP(final CustomerSendVerificationCodeRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
