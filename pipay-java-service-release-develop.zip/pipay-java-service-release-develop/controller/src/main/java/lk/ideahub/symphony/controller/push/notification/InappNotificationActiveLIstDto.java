package lk.ideahub.symphony.controller.push.notification;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.notification.entity.dto.InAppPushNotificationCommonDto;
import lk.ideahub.symphony.modules.notification.entity.dto.InAppPushNotificationData;

import java.util.List;

public class InappNotificationActiveLIstDto  extends Response {

    private String status;
    private String message;
    private long totalCount;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<InAppPushNotificationData> getPushNotifications() {
        return pushNotifications;
    }

    public void setPushNotifications(List<InAppPushNotificationData> pushNotifications) {
        this.pushNotifications = pushNotifications;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

    private List<InAppPushNotificationData> pushNotifications;

}
