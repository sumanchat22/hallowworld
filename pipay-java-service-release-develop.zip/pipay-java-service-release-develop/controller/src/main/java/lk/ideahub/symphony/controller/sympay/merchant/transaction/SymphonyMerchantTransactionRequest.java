package lk.ideahub.symphony.controller.sympay.merchant.transaction;

import java.util.Arrays;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by samith on 12/20/15.
 */
public class SymphonyMerchantTransactionRequest extends Request {

    //common
    private Long merchantId;
    private Long userId;
    private String summaryStatus;
    private String[] transactionStatuses;
    private String isSummaryOnly;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "UTC")
    private Date otcSummarydate;

    public Long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }

    public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Date getOtcSummaryDate() {
		return otcSummarydate;
	}

	public void setOtcSummaryDate(Date otcSummarydate) {
		this.otcSummarydate = otcSummarydate;
	}

	public String getSummaryStatus() {
		return summaryStatus;
	}

	public void setSummaryStatus(String summaryStatus) {
		this.summaryStatus = summaryStatus;
	}

	public String[] getTransactionStatuses() {
		return transactionStatuses;
	}

	public void setTransactionStatuses(String[] transactionStatuses) {
		this.transactionStatuses = transactionStatuses;
	}

	public String getIsSummaryOnly() {
		return isSummaryOnly;
	}

	public void setIsSummaryOnly(String isSummaryOnly) {
		this.isSummaryOnly = isSummaryOnly;
	}

	@Override
	public String toString() {
		return "SymphonyMerchantTransactionRequest [merchantId=" + merchantId + ", userId=" + userId + ", summaryStatus="
				+ summaryStatus + ", transactionStatuses=" + Arrays.toString(transactionStatuses) + ", isSummaryOnly="
				+ isSummaryOnly + ", otcSummarydate=" + otcSummarydate + "]";
	}
	
}
