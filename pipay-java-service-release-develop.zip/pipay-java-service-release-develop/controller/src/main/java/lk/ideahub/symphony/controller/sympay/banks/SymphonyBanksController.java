package lk.ideahub.symphony.controller.sympay.banks;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.*;

import lk.ideahub.symphony.product.sympay.banks.entity.SymphonyBanks;
import lk.ideahub.symphony.product.sympay.banks.service.SymphonyBanksService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * @author somma.soun - PiPay
 * @create 07-Dec-2021
 */

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/banks", consumes = "application/json", produces = "application/json")
public class SymphonyBanksController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyBanksController.class);

    @Autowired
    private SymphonyBanksService symphonyBanksService;

    @RequestMapping(value = "/integrationtype/get/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getBanksListByIntegrationType(final @RequestBody SymphonyBanksRequest _request, HttpServletRequest servletRequest) {

        if (_request.getCustomerId() == null) {
            throw new UnauthorizedRequestException("Customer id can't be null");
        }

        setClientIP(_request, servletRequest);
        SymphonyBanks symphonyBanks = new SymphonyBanks();
        BeanUtils.copyProperties(_request, symphonyBanks);

        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyBanksResponse response = new SymphonyBanksResponse();
        try {
            SymphonyBanks result = symphonyBanksService.getBanksListByIntegrationType(symphonyBanks, serviceContext);

            response.setBankIntegrationTypeList(result.getBankIntegrationTypeList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getBanksList - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service getBanksList [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    private void setClientIP(final SymphonyBanksRequest _request,
                             HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
    }

}
