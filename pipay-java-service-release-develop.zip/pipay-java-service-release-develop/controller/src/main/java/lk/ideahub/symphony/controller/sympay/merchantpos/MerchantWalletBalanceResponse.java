package lk.ideahub.symphony.controller.sympay.merchantpos;

import com.fasterxml.jackson.annotation.JsonRawValue;
import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantWalletBalanceResponse extends Response{

    private String status;
    private String message;

    @JsonRawValue
    private String merchantWalletBalanceEnquiry;
}
