package lk.ideahub.symphony.controller.catalogue.event;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.catalogue.event.entity.CatalogueEvent;
import lk.ideahub.symphony.product.catalogue.event.service.CatalogueEventService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Created by samith on 2/26/16.
 */
@Controller
@RequestMapping(value = "rs/dapp/event", consumes = "application/json", produces = "application/json")
public class CatalogueEventController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(CatalogueEventController.class);

    @Autowired
    CatalogueEventService dAppEventService;

    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Response addEvent(final @RequestBody CatalogueEventRequest _request,
                             final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, true);

        CatalogueEvent dAppEvent = new CatalogueEvent();
        BeanUtils.copyProperties(_request, dAppEvent);

        if (_request.getEventList() != null) {
            dAppEvent.setEventDataList(_request.getEventList());
        }

        CatalogueEventResponse response = new CatalogueEventResponse();

        try {

            CatalogueEvent result = dAppEventService.add(dAppEvent, serviceContext);

            response.setStatus(result.getStatus());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }



        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addEvent - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service addEvent [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response listEvent(final @RequestBody CatalogueEventRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        CatalogueEvent dAppEvent = new CatalogueEvent();
        BeanUtils.copyProperties(_request, dAppEvent);

        if (_request.getEventList() != null) {
            dAppEvent.setEventDataList(_request.getEventList());
        }

        CatalogueEventResponse response = new CatalogueEventResponse();

        try {

            CatalogueEvent result = dAppEventService.listEvent(dAppEvent, serviceContext);

            response.setEvents(result.getEvents());
            response.setEventCount(result.getEvents() != null ? result.getEvents().size() : 0);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }



        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service listEvent - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service listEvent [request: {}; response: {}]", _request, response);
        }
        return response;
    }

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Response searchEvent(final @RequestBody CatalogueEventRequest _request) {

        ServiceContext serviceContext = getServiceContext(_request, true);

        CatalogueEvent dAppEvent = new CatalogueEvent();
        BeanUtils.copyProperties(_request, dAppEvent);

        if (_request.getEventList() != null) {
            dAppEvent.setEventDataList(_request.getEventList());
        }

        CatalogueEventResponse response = new CatalogueEventResponse();

        try {

            CatalogueEvent result = dAppEventService.searchEvent(dAppEvent, serviceContext);

            response.setEvents(result.getEvents());
            response.setEventCount(result.getEvents() != null ? result.getEvents().size() : 0);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());


        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }



        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service listEvent - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service listEvent [request: {}; response: {}]", _request, response);
        }
        return response;
    }

}
