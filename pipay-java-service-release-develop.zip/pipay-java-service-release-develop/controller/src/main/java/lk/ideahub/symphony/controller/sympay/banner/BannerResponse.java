package lk.ideahub.symphony.controller.sympay.banner;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.banner.entity.BannerSlide;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class BannerResponse extends Response{

	private String status;
    private String message;
	private List<BannerSlide> bannerSlides;
}
