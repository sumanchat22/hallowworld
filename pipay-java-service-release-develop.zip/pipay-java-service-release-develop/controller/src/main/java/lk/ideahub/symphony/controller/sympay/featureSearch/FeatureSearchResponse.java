package lk.ideahub.symphony.controller.sympay.featureSearch;


import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.featureSearch.entity.ActionTypesSubCategory;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@ToString
@Setter
@Getter
public class FeatureSearchResponse extends Response{

    private List<ActionTypesSubCategory> actionTypesSubCategoryList;
    private String status;
    private String message;
}
