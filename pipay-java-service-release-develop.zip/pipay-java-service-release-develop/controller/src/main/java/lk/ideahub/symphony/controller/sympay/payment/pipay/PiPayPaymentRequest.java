package lk.ideahub.symphony.controller.sympay.payment.pipay;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by mahesha on 11/23/18.
 */
@Getter
@Setter
@ToString
public class PiPayPaymentRequest extends Request {

    //pay otc
    private String sessionToken;
    private Long customerId;
    private Long customerPaymentOptionId;
    private Long merchantTransactionId;
    private String qrType;
    private BigDecimal amount;
    private String currency;
    private String description;
    private String externalResponseDesc;
    private String externalResponseCode;
    private String externalTxnReference;
    private BigDecimal netAmount;
    private BigDecimal discountAmount;
    private BigDecimal chargeTotal;

    // pay
    private String billerId;
    private String paymentReference;
    
    //receiver
    private Long receiverId;
    private Long receiverMerchantProfileId;
    private Long receiverTransactionId;
    private String externalMessage;
    private Boolean isPaymentSuccess;

    //apply discount
    private String platform;
    
    private Long loyaltyReference;
    private String loyaltyReferenceType;
    private Long merchantId;
    private Long outletId;

    //apply point
    private Long pointGlobalPercentageId;
    
    //quick pay
    private String osType;
    private String qrCode;
    
    //cron
    private Boolean isProcessDisabled;

    //remark
    private String remark;

}
