package lk.ideahub.symphony.controller.sympay.merchantpos;


import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
public class MerchantPaymentWalletPinRequest extends Request {

    private String customerMsisdn;
    private String currencyCode;
    private Long   merchantId;
    private String customerPin;
    private BigDecimal amount;
    private Long userId;
    private String channel;
    private String deviceId;
    private Long counterId;
    private Long outletId;
    private String txnDate;
}
