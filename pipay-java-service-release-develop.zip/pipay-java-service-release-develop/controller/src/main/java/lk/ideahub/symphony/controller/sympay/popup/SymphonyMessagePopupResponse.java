package lk.ideahub.symphony.controller.sympay.popup;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.maintenaceMessages.entity.MaintenanceMessages;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author somma.soun - PiPay
 * @create 08-Feb-2022
 */
@Setter
@Getter
@ToString
public class SymphonyMessagePopupResponse extends Response {
     private MaintenanceMessages messagePopup;
     private Boolean isPopup;
     private String status;
     private String message;
     private Long couponPackId;
}
