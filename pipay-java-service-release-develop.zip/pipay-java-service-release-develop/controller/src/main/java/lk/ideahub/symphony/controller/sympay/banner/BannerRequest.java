package lk.ideahub.symphony.controller.sympay.banner;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class BannerRequest extends Request{

}
