package lk.ideahub.symphony.controller.sympay.payment.pipay;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.CustomerPayeeTransaction;
import lk.ideahub.symphony.modules.loyalty.entity.LoyaltyInfo;
import lk.ideahub.symphony.modules.loyalty.entity.coupon.Coupon;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.product.sympay.loyalty.entity.CouponInfoDto;
import lk.ideahub.symphony.product.sympay.loyalty.entity.GlobalPercentageDto;
import lk.ideahub.symphony.product.sympay.payment.entity.PaymentOptionDisplayNames;
import lk.ideahub.symphony.product.sympay.pipay.external.entity.ExternalDiscountData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 11/23/18.
 */
@Getter
@Setter
@ToString
public class PiPayPaymentResponse extends Response {

    private CustomerPayeeTransaction customerPayeeTransaction;
    private List customerPaymentList;
    private Long customerPaymentListCount;
    private Integer merchantDiscountsTotalCount;

    // status
    private String status;
    private String message;
    private Boolean showRatingPopup;

    List<PaymentOptionDisplayNames> displayNamesList;
    
    private String receiverTransactionStatus;

    //loyalty
    private LoyaltyInfo loyaltyInfo;
    private CouponInfoDto CouponInfo;

    //apply points
    private MerchantTransaction merchantTransaction;
    
    //external keys
    private String privateKey;
    
    //quick pay
    private String transactionStatus;
    private String outletName;
    private String outletLogo;
    private String outletUuid;
    
    private String instrumentId;
    private String externalTxnReference;

    private List<GlobalPercentageDto> globalPercentageDtoList;

    //getDiscountValues
    private ExternalDiscountData externalDiscountData;

    //buy coupon
    private Coupon coupon;
}
