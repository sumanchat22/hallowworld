package lk.ideahub.symphony.controller.pinkpacket;

import java.math.BigDecimal;
import java.util.List;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class PinkPacketRequest extends Request{

	private Long customerId;
	private BigDecimal totalAmount;
	private String currencyCode;
	private String splitType;
	private Long quantity;
	private String message;
	private String groupType;
	private String groupTypeReference;
	private Long[] receiverCustomerList; 
	private Long pinkPacketGroupId;
	private Long pinkPacketId;
	private Boolean isProcessSucceeded;
	private Boolean isExpirationProcessDisabled;
	private String summaryType;
}
