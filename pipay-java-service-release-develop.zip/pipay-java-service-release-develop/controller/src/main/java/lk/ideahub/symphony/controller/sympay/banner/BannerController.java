package lk.ideahub.symphony.controller.sympay.banner;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.banner.entity.BannerDto;
import lk.ideahub.symphony.modules.banner.service.BannerManagerService;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/banner", consumes = "application/json", produces = "application/json")
public class BannerController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(BannerController.class);
	
	@Autowired
	BannerManagerService bannerManagerService;
	
	@RequestMapping(value = "get/home/slides", method = RequestMethod.POST)
    @ResponseBody
    public Response getHomeSlides() {

        /*setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
*/
        BannerDto bannerDto = new BannerDto();
        //BeanUtils.copyProperties(request, bannerDto);
        BannerResponse response = new BannerResponse();

        try {
        	BannerDto result = bannerManagerService.getHomeBanner(bannerDto);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setBannerSlides(result.getBannerSlides());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getHomeSlides - failure [request: {}; response: {}]",  response);
        } else {
            log.debug("Service getHomeSlides [request: {}; response: {}]",  response);
        }
        return response;
    }
	
	private void setClientIP(final BannerRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
