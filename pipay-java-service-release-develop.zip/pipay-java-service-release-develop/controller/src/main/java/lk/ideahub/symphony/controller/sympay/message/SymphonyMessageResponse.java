package lk.ideahub.symphony.controller.sympay.message;

import java.util.ArrayList;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by samith on 2/15/16.
 */
public class SymphonyMessageResponse extends Response {

    private ArrayList sendingResponses;

    private long succesCount;
    private long failCount;

    // status
    private String status;
    private String message;

    public ArrayList getSendingResponses() {
        return sendingResponses;
    }

    public void setSendingResponses(ArrayList sendingResponses) {
        this.sendingResponses = sendingResponses;
    }

    public long getSuccesCount() {
        return succesCount;
    }

    public void setSuccesCount(long succesCount) {
        this.succesCount = succesCount;
    }

    public long getFailCount() {
        return failCount;
    }

    public void setFailCount(long failCount) {
        this.failCount = failCount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyMessageResponse{");
        sb.append("sendingResponses=").append(sendingResponses);
        sb.append(", succesCount=").append(succesCount);
        sb.append(", failCount=").append(failCount);
        sb.append(", status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
