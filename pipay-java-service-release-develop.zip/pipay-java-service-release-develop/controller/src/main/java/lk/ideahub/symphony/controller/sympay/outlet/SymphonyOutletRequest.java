package lk.ideahub.symphony.controller.sympay.outlet;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by mahesha on 1/2/19.
 */
@Getter
@Setter
@ToString
public class SymphonyOutletRequest extends Request {

    //add review
    private Long customerId;
    private Long outletId;
    private String review;

    //update review
    private Long outletReviewId;

    //add rate
    private BigDecimal rate;

    //list outlet
    private BigDecimal latitude;
    private BigDecimal longitude;

    //search outlets
    private String searchText;
    private String searchType;
    private Long filterTagId;

    //get outlet by action
    private Long actionGroupId;

    // Modify 2020-9-3
    private Long couponPackId;
}
