package lk.ideahub.symphony.controller.sympay.wallet;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by kalpana on 3/1/17.
 */
public class SymphonyWalletRequest extends Request
{
    //common, add wallet
    private Long customerId;
    private String msisdn;
    private String ezAlias;

    //remove wallet
    private Long walletId;

    public Long getCustomerId() { return customerId; }

    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getMsisdn() { return msisdn; }

    public void setMsisdn(String msisdn) { this.msisdn = msisdn; }

    public Long getWalletId() { return walletId; }

    public void setWalletId(Long walletId) { this.walletId = walletId; }

    public String getEzAlias() { return ezAlias; }

    public void setEzAlias(String ezAlias) { this.ezAlias = ezAlias; }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyWalletRequest {")
                .append("customerId=").append(customerId).append(", ")
                .append("msisdn='").append(msisdn).append("'").append(", ")
                .append("ezAlias='").append(ezAlias).append("'").append(", ")
                .append("walletId=").append(walletId)
                .append('}').toString();
    }
}
