package lk.ideahub.symphony.controller.sympay.favourite;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lk.ideahub.symphony.modules.types.entity.PayeeGroupType;
import lk.ideahub.symphony.modules.types.entity.PayeeType;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.favourite.entity.CustomerShortcutDto;
import lk.ideahub.symphony.modules.favourite.service.FavouriteService;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/favourite", consumes = "application/json", produces = "application/json")
public class FavouriteController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(FavouriteController.class);
	
	@Autowired
	FavouriteService favouriteService;

    @RequestMapping(value = "/images", method = RequestMethod.GET)
    public void redirectToImageS3(final @RequestParam("path") String path, HttpServletResponse httpServletResponse, HttpServletRequest servletRequest) throws IOException {
        FavouriteRequest request = new FavouriteRequest();
        request.setPath(path);
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);
        CustomerShortcutDto customerShortcutDto = new CustomerShortcutDto();
        BeanUtils.copyProperties(request, customerShortcutDto);
        String result = favouriteService.getS3LinkImage(customerShortcutDto,serviceContext);
        httpServletResponse.sendRedirect(result);
    }

	@RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Response addFavourite(final @RequestBody FavouriteRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerShortcutDto customerShortcutDto = new CustomerShortcutDto();
        BeanUtils.copyProperties(request, customerShortcutDto);
        FavouriteResponse response = new FavouriteResponse();

        try {
        	CustomerShortcutDto result = favouriteService.addFavourite(customerShortcutDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addFavourite - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service addFavourite [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "get/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getCustomerFavouriteList(final @RequestBody FavouriteRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        CustomerShortcutDto customerShortcutDto = new CustomerShortcutDto();
        BeanUtils.copyProperties(request, customerShortcutDto);
        FavouriteResponse response = new FavouriteResponse();

        try {
        	CustomerShortcutDto result = favouriteService.getCustomerFavouriteList(customerShortcutDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setCustomerFavouriteList(result.getCustomerFavouriteList());
            response.setOutletList(result.getOutletList());
            response.setDealList(result.getDealList());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addFavourite - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service addFavourite [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	@RequestMapping(value = "delete", method = RequestMethod.POST)
    @ResponseBody
    public Response deleteFavourite(final @RequestBody FavouriteRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerShortcutDto customerShortcutDto = new CustomerShortcutDto();
        BeanUtils.copyProperties(request, customerShortcutDto);
        FavouriteResponse response = new FavouriteResponse();

        try {
        	CustomerShortcutDto result = favouriteService.deleteFavourite(customerShortcutDto, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service deleteFavourite - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service deleteFavourite [request: {}; response: {}]", request, response);
        }
        return response;
    }
	
	private void setClientIP(final FavouriteRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
