package lk.ideahub.symphony.controller.catalogue.beacon;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.catalogue.beacon.entity.CatalogueBeacon;
import lk.ideahub.symphony.product.catalogue.beacon.service.CatalogueBeaconService;

@Controller
@RequestMapping(value = "catalogue/beacons", consumes = "application/json", produces = "application/json")
public class CatalogueBeaconController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(CatalogueBeaconController.class);

    @Autowired
    CatalogueBeaconService catalogueBeaconService;

    @RequestMapping(value = "notifications", method = RequestMethod.POST)
    @ResponseBody
    public Response notifications(final @RequestBody CatalogueBeaconRequest _request,
                                  final @RequestHeader(value = "msisdn", required = false) String _msisdn) {
        _request.setPhone(_msisdn);

        ServiceContext serviceContext = getServiceContext(_request, false);

        CatalogueBeacon catalogueBeacon = new CatalogueBeacon();
        BeanUtils.copyProperties(_request, catalogueBeacon);

        List notifications = catalogueBeaconService.notifications(catalogueBeacon, serviceContext);

        CatalogueBeaconResponse response = new CatalogueBeaconResponse();
        response.setHasMsisdn(_request.getPhone() != null);
        response.setBeaconNotifications(notifications);
        response.setNotificationCount(notifications != null ? notifications.size() : 0);

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service notifications - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service notifications [request: {}; response: {}]", _request, response);
        }
        return response;
    }
}
