package lk.ideahub.symphony.controller.types;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;

/**
 * Created by samith on 10/29/15.
 */
public class CountryCodeResponse extends Response {

    private List countryList;

    // status
    private String status;
    private String message;

    public List getCountryList() {
        return countryList;
    }

    public void setCountryList(List countryList) {
        this.countryList = countryList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CountryCodeResponse{");
        sb.append("countryList=").append(countryList);
        sb.append(", status='").append(status).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
