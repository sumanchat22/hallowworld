package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;


@Setter
@Getter
@ToString
public class CustomerCashInInquiryRequest extends Request{

    private String customerMsisdn;
    private String currencyCode;
    private Long  merchantId;
    private BigDecimal amount;
    private Long  outletId;
    private Long counterId;

}
