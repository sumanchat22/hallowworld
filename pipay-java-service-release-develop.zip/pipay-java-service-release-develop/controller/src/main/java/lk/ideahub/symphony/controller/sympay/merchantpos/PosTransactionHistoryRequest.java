package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class PosTransactionHistoryRequest extends Request {

    private Long merchantId;
    private Long counterId;
    private String fromDate;
    private String toDate;
    private Long outletId;
    private String  offset;
    private String numOfTransactions;
    private String showPending;
    private String searchTransaction;
    //pos coupon report
    private Long giftCouponCount;

}
