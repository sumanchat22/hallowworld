package lk.ideahub.symphony.controller.sympay.favourite;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.favourite.entity.CustomerFavouriteDto;
import lk.ideahub.symphony.modules.favourite.entity.FavouriteDto;
import lk.ideahub.symphony.product.sympay.deal.entity.DealDto;
import lk.ideahub.symphony.product.sympay.outlet.entity.OutletDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class FavouriteResponse extends Response{

	private String status;
    private String message;
    private List<FavouriteDto> favouriteList;
    private List<CustomerFavouriteDto> customerFavouriteList;
    private List<DealDto> dealList;
	private List<OutletDto> outletList;
}
