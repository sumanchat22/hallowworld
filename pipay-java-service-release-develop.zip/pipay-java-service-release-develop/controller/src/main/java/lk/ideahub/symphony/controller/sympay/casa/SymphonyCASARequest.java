package lk.ideahub.symphony.controller.sympay.casa;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by kalpana on 3/24/17.
 */
@Getter
@Setter
@ToString
public class SymphonyCASARequest extends Request
{
    //account Registration
    private Long customerId;
    private String branchCode;
    private String accountNumber;
    private String deviceId;
    private String platform;
    private String sdkVersion;

    //list branches
    private String bankCode;

    //validate account
    private String validationType;
    private String value;
    private String referenceId;

    //confirm registration
    private String custConsent;
    private String cardAlias;

    // device signature
    private  String signature;

    //verification
    private Long accountId;

    private Long paymentOptionId;
}
