package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.merchantpos.entity.MerchantPosTransactionData;
import lk.ideahub.symphony.product.sympay.transactionHistory.entity.Transactions;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class PosTransactionHistoryResponse extends Response {

    private String message;
    private String status;
    private List<Transactions> transactionsList;
}
