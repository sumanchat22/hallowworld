package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.external.MerchantExternalDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Bunna Hoeun
 *
 */
@Getter
@Setter
@ToString
public class MerchantExternalResponse extends Response{

	private MerchantExternalDto data;
	private String status;
	private String message;
	private String responseCode;
}
