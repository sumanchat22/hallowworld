package lk.ideahub.symphony.controller.sympay.friend;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.friend.entity.SymphonyFriend;
import lk.ideahub.symphony.product.sympay.friend.service.SymphonyFriendService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 12/18/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/friend", consumes = "application/json", produces = "application/json")
public class SymphonyFriendController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyFriendController.class);

    @Autowired
    private SymphonyFriendService symphonyFriendService;

    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Response addFriend(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.addFriend(symphonyFriend, serviceContext);
            response.setCustomerFriendDto(result.getCustomerFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service add friend - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service add friend [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response listFriend(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.listFriend(symphonyFriend, serviceContext);
            response.setCustomerDto(result.getCustomerDto());
            response.setFriendList(result.getFriendList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service show friends - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service show friends [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "accept/request", method = RequestMethod.POST)
    @ResponseBody
    public Response acceptRequest(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.acceptRequest(symphonyFriend, serviceContext);
            response.setCustomerFriendDto(result.getCustomerFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service acceptRequest - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service acceptRequest [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "reject/request", method = RequestMethod.POST)
    @ResponseBody
    public Response rejectRequest(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.rejectRequest(symphonyFriend, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service rejectRequest - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service rejectRequest [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "cancel/request", method = RequestMethod.POST)
    @ResponseBody
    public Response cancelRequest(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.cancelRequest(symphonyFriend, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service cancelRequest - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service cancelRequest [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "view", method = RequestMethod.POST)
    @ResponseBody
    public Response view(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.view(symphonyFriend, serviceContext);
            response.setCustomerFriendDto(result.getCustomerFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service add friend - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service add friend [request: {}; response: {}]", request, response);
        }
        return response;
    }



    @RequestMapping(value = "sync", method = RequestMethod.POST)
    @ResponseBody
    public Response syncFriend(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.syncFriend(symphonyFriend, serviceContext);
            response.setCustomerDto(result.getCustomerDto());
            response.setContactCustomerList(result.getContactCustomerList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service sync friends - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service sync friends [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "create/qr", method = RequestMethod.POST)
    @ResponseBody
    public Response createQR(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.createQR(symphonyFriend, serviceContext);
            response.setEncryptedText(result.getEncryptedText());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service createQR - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service createQR [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "scan/qr", method = RequestMethod.POST)
    @ResponseBody
    public Response scanQR(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.scanQR(symphonyFriend, serviceContext);
            response.setFriendDto(result.getFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service scanQR - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service scanQR [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "change/notification/status", method = RequestMethod.POST)
    @ResponseBody
    public Response changeNotificationStatus(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.changeNotificationStatus(symphonyFriend, serviceContext);
            response.setCustomerFriendDto(result.getCustomerFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service changeNotificationStatus - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service changeNotificationStatus [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get", method = RequestMethod.POST)
    @ResponseBody
    public Response getFriend(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.getFriend(symphonyFriend, serviceContext);
            response.setFriendDto(result.getFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get friend - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get friend [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "add/contact", method = RequestMethod.POST)
    @ResponseBody
    public Response addContact(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.addContact(symphonyFriend, serviceContext);
            response.setAddedFriendList(result.getAddedFriendList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service add contact - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service add contact [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "change/block/status", method = RequestMethod.POST)
    @ResponseBody
    public Response changeBlockStatus(final @RequestBody SymphonyFriendRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyFriend symphonyFriend = new SymphonyFriend();
        BeanUtils.copyProperties(request, symphonyFriend);
        SymphonyFriendResponse response = new SymphonyFriendResponse();

        try {
            SymphonyFriend result = symphonyFriendService.changeBlockStatus(symphonyFriend, serviceContext);
            response.setCustomerFriendDto(result.getCustomerFriendDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service changeBlockStatus - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service changeBlockStatus [request: {}; response: {}]", request, response);
        }
        return response;
    }


    private void setClientIP(final SymphonyFriendRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
