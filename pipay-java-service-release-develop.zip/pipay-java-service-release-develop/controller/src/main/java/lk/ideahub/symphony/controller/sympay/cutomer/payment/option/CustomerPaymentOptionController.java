package lk.ideahub.symphony.controller.sympay.cutomer.payment.option;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.wallet.service.CustomerPiPayWalletService;
import lk.ideahub.symphony.product.sympay.payment.option.CustomerPaymentOptionDto;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME  + "/customer/payment/option", consumes = "application/json", produces = "application/json")
public class CustomerPaymentOptionController extends GenericController{

	private static final Logger log = LoggerFactory.getLogger(CustomerPaymentOptionController.class);
	
	@Autowired
	CustomerPiPayWalletService customerPiPayWalletService;
	
	@Autowired
	MessageSource messageSource;
	
	@RequestMapping(value = "payable/list", method = RequestMethod.POST)
    @ResponseBody
    public Response getPayableList(final @RequestBody CustomerPaymentOptionRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        CustomerPaymentOptionDto customerPaymentOptionDto = new CustomerPaymentOptionDto();
        BeanUtils.copyProperties(request, customerPaymentOptionDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerPaymentOptionResponse response = new CustomerPaymentOptionResponse();
        try {
        	CustomerPaymentOptionDto result = customerPiPayWalletService.getPayablePiPayWallets(customerPaymentOptionDto, serviceContext);

            response.setCustomerPiPayWalletList(result.getCustomerPiPayWalletList());
            response.setTotalAvailablePaymentOptions(result.getTotalAvailablePaymentOptions());
            response.setPointWallet(result.getPointWallet());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setErrorCode(result.getErrorCode());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("CustomerPaymentOptionController getPayableList - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("CustomerPaymentOptionController getPayableList [request: {}; response: {}]", request, response);
        }

        return response;
    }
	
	@RequestMapping(value = "financial/default", method = RequestMethod.POST)
    @ResponseBody
    public Response updateDefaultPayOption(final @RequestBody CustomerPaymentOptionRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        CustomerPaymentOptionDto customerPaymentOptionDto = new CustomerPaymentOptionDto();
        BeanUtils.copyProperties(request, customerPaymentOptionDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerPaymentOptionResponse response = new CustomerPaymentOptionResponse();
        try {
        	CustomerPaymentOptionDto result = customerPiPayWalletService.updateDefaultPayOption(customerPaymentOptionDto,serviceContext);
            response.setCustomerPiPayWalletDto(result.getCustomerPiPayWalletDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(messageSource.getMessage(Constants.FAILED_MSG, null, serviceContext.getLocale()));
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("updateDefaultPayOption setDefault - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("updateDefaultPayOption setDefault [request: {}; response: {}]", request, response);
        }

        return response;
    }

    @RequestMapping(value = "set/default", method = RequestMethod.POST)
    @ResponseBody
    public Response setDefault(final @RequestBody CustomerPaymentOptionRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        CustomerPaymentOptionDto customerPaymentOptionDto = new CustomerPaymentOptionDto();
        BeanUtils.copyProperties(request, customerPaymentOptionDto);

        ServiceContext serviceContext = getServiceContext(request, false);

        CustomerPaymentOptionResponse response = new CustomerPaymentOptionResponse();
        try {
            CustomerPaymentOptionDto result = customerPiPayWalletService.setDefaultPaymentOption(customerPaymentOptionDto,serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(messageSource.getMessage(Constants.FAILED_MSG, null, serviceContext.getLocale()));
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("CustomerPaymentOptionController setDefault - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("CustomerPaymentOptionController setDefault [request: {}; response: {}]", request, response);
        }

        return response;
    }
	
	private void setClientIP(final CustomerPaymentOptionRequest request, HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
		request.setClientIp(clientIp);
	}

}
