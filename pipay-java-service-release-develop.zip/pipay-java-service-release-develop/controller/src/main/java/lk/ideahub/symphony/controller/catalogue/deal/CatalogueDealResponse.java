package lk.ideahub.symphony.controller.catalogue.deal;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;

public class CatalogueDealResponse extends Response {

    // deal list
    private Integer dealCount;
    private boolean hasMsisdn;
    private List deals;

    // reserve, purchase, gift
    private String reserveId;

    // comments
    private Integer dealCommentCount;
    private List dealComments;

    // status
    private String status;
    private String message;

    public Integer getDealCount() {
        return dealCount;
    }

    public void setDealCount(Integer dealCount) {
        this.dealCount = dealCount;
    }

    public boolean getHasMsisdn() {
        return hasMsisdn;
    }

    public void setHasMsisdn(boolean hasMsisdn) {
        this.hasMsisdn = hasMsisdn;
    }

    public List getDeals() {
        return deals;
    }

    public void setDeals(List deals) {
        this.deals = deals;
    }

    public String getReserveId() {
        return reserveId;
    }

    public void setReserveId(String reserveId) {
        this.reserveId = reserveId;
    }

    public Integer getDealCommentCount() {
        return dealCommentCount;
    }

    public void setDealCommentCount(Integer dealCommentCount) {
        this.dealCommentCount = dealCommentCount;
    }

    public List getDealComments() {
        return dealComments;
    }

    public void setDealComments(List dealComments) {
        this.dealComments = dealComments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return new StringBuilder("CatalogueDealResponse {")
                .append("dealCount=").append(dealCount).append(", ")
                .append("hasMsisdn=").append(hasMsisdn).append(", ")
                .append("deals=").append(deals).append(", ")
                .append("reserveId='").append(reserveId).append("'").append(", ")
                .append("dealCommentCount=").append(dealCommentCount).append(", ")
                .append("dealComments=").append(dealComments).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
