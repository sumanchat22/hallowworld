package lk.ideahub.symphony.controller.security;

/**
 * Created by lakmal on 5/6/2017.
 */
public class SecurityResponseWrapper {
    SecurityResponse response;

    public SecurityResponse getResponse() {
        return response;
    }

    public void setResponse(SecurityResponse response) {
        this.response = response;
    }
}
