package lk.ideahub.symphony.controller.sympay.payee;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by samith on 11/16/15.
 */
@Getter
@Setter
@ToString
public class SymphonyPayeeRegisterRequest extends Request {

    //common
    private Long customerId;
    private Long customerPayeeId;

    //register
    private Long payeeTypeId;
    private String payeeAccountNo;
    private String payeeAlias;

    //un register payee
    private String isUnregister;

    //transaction history count
    private Long transactionHistoryLimit;

    //search payee
    private String payeeGroup;
    private List<String> integrationTypeList;
}
