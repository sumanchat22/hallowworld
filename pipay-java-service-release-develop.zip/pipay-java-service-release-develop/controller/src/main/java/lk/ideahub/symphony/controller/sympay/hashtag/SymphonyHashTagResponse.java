package lk.ideahub.symphony.controller.sympay.hashtag;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.hashtag.entity.HashTag;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 12/7/18.
 */
@Getter
@Setter
@ToString
public class SymphonyHashTagResponse extends Response {

    private String status;
    private String message;
    private Integer totalTags;
    private List<HashTag> hashTagList;
}
