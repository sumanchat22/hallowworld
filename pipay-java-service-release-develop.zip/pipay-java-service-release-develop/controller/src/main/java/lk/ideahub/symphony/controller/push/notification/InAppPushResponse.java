package lk.ideahub.symphony.controller.push.notification;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.notification.entity.dto.InAppPushNotificationCommonDto;
import lk.ideahub.symphony.modules.notification.entity.dto.InAppPushNotificationData;

import java.util.List;

public class InAppPushResponse extends Response{

	private String status;
    private String message;
    private String totalRequestedCount;
	private Long totalActiveDeviceCount;
	private Long totalSentCount;
	private String deliveryStatus;
	private Long eventId;
    private InAppPushNotificationCommonDto androidData;
    private InAppPushNotificationCommonDto iosData;


	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public InAppPushNotificationCommonDto getAndroidData() {
		return androidData;
	}
	public void setAndroidData(InAppPushNotificationCommonDto androidData) {
		this.androidData = androidData;
	}
	public InAppPushNotificationCommonDto getIosData() {
		return iosData;
	}
	public void setIosData(InAppPushNotificationCommonDto iosData) {
		this.iosData = iosData;
	}
	public String getTotalRequestedCount() {
		return totalRequestedCount;
	}
	public void setTotalRequestedCount(String totalRequestedCount) {
		this.totalRequestedCount = totalRequestedCount;
	}
	public Long getTotalActiveDeviceCount() {
		return totalActiveDeviceCount;
	}
	public void setTotalActiveDeviceCount(Long totalActiveDeviceCount) {
		this.totalActiveDeviceCount = totalActiveDeviceCount;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Long getEventId() {
		return eventId;
	}
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}
	public Long getTotalSentCount() {
		return totalSentCount;
	}
	public void setTotalSentCount(Long totalSentCount) {
		this.totalSentCount = totalSentCount;
	}

}
