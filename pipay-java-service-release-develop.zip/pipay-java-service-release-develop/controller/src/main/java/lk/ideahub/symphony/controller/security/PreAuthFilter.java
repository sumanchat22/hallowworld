package lk.ideahub.symphony.controller.security;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureException;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.counter.entity.OutletCounter;
import lk.ideahub.symphony.modules.counter.service.OutletCounterService;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.entity.CustomerDeviceSession;
import lk.ideahub.symphony.modules.customer.service.CustomerDeviceSessionService;
import lk.ideahub.symphony.modules.customer.service.CustomerService;
import lk.ideahub.symphony.modules.merchant.entity.Merchant;
import lk.ideahub.symphony.modules.merchant.entity.MerchantStatus;
import lk.ideahub.symphony.modules.merchant.service.MerchantService;
import lk.ideahub.symphony.modules.merchant.service.MerchantStatusService;
import lk.ideahub.symphony.modules.outlet.entity.Outlet;
import lk.ideahub.symphony.modules.outlet.service.OutletService;
import lk.ideahub.symphony.modules.types.entity.Language;
import lk.ideahub.symphony.modules.types.entity.OutletCounterStatus;
import lk.ideahub.symphony.modules.types.entity.OutletStatus;
import lk.ideahub.symphony.modules.types.service.LanguageService;
import lk.ideahub.symphony.modules.types.service.MerchantTxnStatusService;
import lk.ideahub.symphony.modules.types.service.OutletCounterStatusService;
import lk.ideahub.symphony.modules.types.service.OutletStatusService;
import lk.ideahub.symphony.product.sympay.common.JWTUtil;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;


@Component
public class PreAuthFilter extends GenericFilterBean {
    private static final Logger log = LoggerFactory.getLogger(PreAuthFilter.class);
    private static final String JWT_TOKEN_EXP_MASSAGE ="bluesky.jwt.token.keepSession.expiry.massage";
    private static final String JWT_TOKEN_EXP_MASSAGE_MINUTE="bluesky.jwt.token.keepSession.expiry.minute.massage";
    
    @Autowired
    CustomerDeviceSessionService cusDevSessionService;

    @Autowired
    private Environment environment;

    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private LanguageService languageService;
    
    @Autowired
    private OutletCounterService outletCounterService;
    
    @Autowired
    OutletCounterStatusService outletCounterStatusService;
    
    @Autowired
    OutletService outletService;

    @Autowired
    private JWTUtil jwtUtil;
    
    @Autowired
    OutletStatusService outletStatusService;
    
    @Autowired
    MerchantService merchantService;
    
    @Autowired
    MerchantStatusService merchantStatusService;
    
    private static final String JWT_AUTH_HEADER = "Authorization-IH";
    
    private static final String STATUS_ACTIVE = "Active";

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);

        final String commonErrorMessage = "Authentication Failure";
        final HttpServletRequest request = (HttpServletRequest) req;
        final HttpServletResponse response = (HttpServletResponse) res;
        SecurityRequestWrapper wrappedRequest = null; //used wrapped request since getting data from inputstream twice is not possible.

        if (//request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/add/auth") > -1
                request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/login") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/version/check") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/init/register") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/otp/resend") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/confirm/otp") > -1
                //|| request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/confirm/kyc") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/register/abort") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/reset/password") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/reset/password/validate/link") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/reset/password/confirm") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/ext/merchant/login") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/general") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pay/ext/merchant/guest") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/verification") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/login") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/init/otc") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/otc/change/status") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/otc/get/transaction") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/transaction/list") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/qrpay/encryption") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/qrpay/encryption/") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/message") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/card/set/expired") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/card/pending/reminder") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/card/remove/data") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/user/password/expired") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/remove") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/encryption/init/master/key") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/encryption/init/user/key") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/encryption/get/user/key/statuses") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/encryption/create/key/store/file") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/encryption/init/deks") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/encryption/key/rotation") > -1
                || request.getRequestURL().indexOf("/rs/country/code") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/qrpay/get/txn/status") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pay/validate/payment/token") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pay/update/commission") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pay/listByDisplayName") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pay/listAdvancedDiscount") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/validate/card/discount") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/external/") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/transaction/otc/report/list") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/user/block/inactive/users") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/data/migration/ez/merchant") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/data/migration/biIntegration/dataExport") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/inApp/send/bulk") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/inApp/send/request/failed/notifications") > -1
                || request.getRequestURL().indexOf("/rs/vouchers/1.0/voucher/merchants") > -1
                || request.getRequestURL().indexOf("/rs/vouchers/1.0/voucher/packs") > -1
                || request.getRequestURL().indexOf("/rs/vouchers/1.0/voucher/reserve") > -1
                || request.getRequestURL().indexOf("/rs/vouchers/1.0/voucher/payment-methods") > -1
                || request.getRequestURL().indexOf("/rs/catalogue/deals") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/login/otp/send") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pink/packet/expire/invalid/packets") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/banner/get/home/slides") > -1
//                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/payment/inapp") > -1
//                        || request.getRequestURL().indexOf("/rs/" + Constants.SYSTEM_NAME + "/customer/init/merchanttransaction") > -1
                        || request.getRequestURL().indexOf("/rs/" + Constants.SYSTEM_NAME + "/payee/validate/account") > -1
//                        || request.getRequestURL().indexOf("/rs/" + Constants.SYSTEM_NAME + "/customer/payment/option/payable/list") > -1
                        || request.getRequestURL().indexOf("/rs/" + Constants.SYSTEM_NAME + "/payment/process/incompleted/post/txn") > -1
                        || request.getRequestURL().indexOf("/rs/" + Constants.SYSTEM_NAME + "/receiver/update/merchant/profile") > -1
//                        || request.getRequestURL().indexOf("/rs/" + Constants.SYSTEM_NAME + "/favourite/get/list") > -1



                        //External Services
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/service/external/") > -1
                
                //merchant portal
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/portal/init/register") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchant/portal/user/login") > -1

                //OAuth token generation
                || request.getRequestURL().indexOf("/rs/oauth/token") > -1

                //notification
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/send/marketing/bulk") > -1
                        || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/send/payment/reminder/bulk") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/push/event") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/send/push") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/get/summary") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/notification/update") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/service/internal/") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/pink/packet/manually/expire/invalid/packets") > -1

                //loyalty
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/point/expire") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/coupon/expire") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/coupon/release") > -1
                        || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/coupon/search") > -1

                //admin portal
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/coupon/create") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/coupon/manual/redeem") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/loyalty/point/bulk/reward/transfer") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/report") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/close/wallet") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/generate/khqrpay") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/notification/inApp/get/active/notifications") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/casa/register/account") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/casa/validate/account") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/casa/confirm/register") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/pay") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/bill/presentment/enable/verify/otp") > -1
                //|| request.getRequestURL().indexOf("/rs/sympay/bill/presentment/view") > -1
                ) {

            chain.doFilter(req, res);
            return;
        }
        
        //merchant POS
        if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchantpos/") > -1) {
        	if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchantpos/request/addPosDevice") > -1) {
        		chain.doFilter(req, res);
                return;
        	}
            if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchantpos/get/pos/details") > -1) {
                chain.doFilter(req, res);
                return;
            }
            if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchantpos/request/getPosDevice") > -1) {
                chain.doFilter(req, res);
                return;
            }
            if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchantpos/request/pos/transaction/history") > -1) {
                chain.doFilter(req, res);
                return;
            }
            if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/merchantpos/coupon/redemption/history") > -1) {
                chain.doFilter(req, res);
                return;
            }
        	authenticateMerchantPosServices(request, response, chain, res);
        	return;
        }
        
        //Open services 
        if(request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/confirm/kyc") > -1
                || request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/update/profile") > -1
        		|| request.getRequestURL().indexOf("/rs/"+ Constants.SYSTEM_NAME+"/customer/add/auth") > -1) {
        	authenticateOpenServices(request, response, chain, res);
        	return;
        }
        
        final String authHeader = request.getHeader(JWT_AUTH_HEADER);
        log.info("AuthHeader = " + authHeader);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setContentType("application/json");
//            response.getOutputStream().write(getResponseBytes("Missing or invalid Authorization header."));
            response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            return;
        }

        final String token = authHeader.substring(7); // The part after "Bearer "
        try {
            final Claims claims = Jwts.parser().setSigningKey(jwtUtil.getSecretCode())
                    .parseClaimsJws(token).getBody();

            if (!new Date().before(claims.getExpiration())) {
                response.setContentType("application/json");
                long diff=claims.getExpiration().getTime() - claims.getIssuedAt().getTime();
                long diffDays = diff / (60 * 1000);
                log.info("diffDays = " + diffDays);
                response.getOutputStream().write(getResponseBytes(commonErrorMessage,diffDays));
                return;
            }

            request.setAttribute("claims", claims);
            log.info("Claims from Authorization Header = " + claims);

            String deviceUniqueId = claims.getSubject();
            if (deviceUniqueId == null) {

                log.debug("deviceUniqueId is null ");
                response.setContentType("application/json");
//                response.getOutputStream().write(getResponseBytes("Token is not valied"));
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }

            CustomerDeviceSession cds = new CustomerDeviceSession();
            cds.setDeviceUniqueId(deviceUniqueId);
            List<CustomerDeviceSession> custDevSessionByDeviceUUId = cusDevSessionService.findByDeviceUUId(cds, null);

            if (custDevSessionByDeviceUUId == null) {

                log.debug("Device unique id is not in the cus_device_session table");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
//                response.getOutputStream().write(getResponseBytes("Token is not valied"));
                return;
            }
            CustomerDeviceSession cdsObj = custDevSessionByDeviceUUId.get(0);
            if (cdsObj == null || cdsObj.getDeviceUniqueId() == null) {

                log.debug("Device unique id is not in the cus_device_session table");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
//                response.getOutputStream().write(getResponseBytes("Token is not valied"));
                return;
            }

            wrappedRequest = new SecurityRequestWrapper((HttpServletRequest) request);
            String body = IOUtils.toString(wrappedRequest.getReader());
            //wrappedRequest.resetInputStream(body.getBytes());

            ObjectMapper mapper = new ObjectMapper();
            JsonNode mainObj = mapper.readTree(body);
            JsonNode requestObj = mainObj.get("request");
            
            String customerId = String.valueOf(requestObj.get("customerId"));
            String customerIdDB = String.valueOf(cdsObj.getCustomerId());

            if (customerId != null) {
                customerId = customerId.replaceAll("\"", "");
            }


            if (customerId != null && !customerId.equals(customerIdDB)) {
                log.debug("Customer ID is not matched with the database.");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
//                response.getOutputStream().write(getResponseBytes("Token is not valied"));
                return;
            }
            
            //set customer default language (if not specified)
            if(requestObj.get("locale") == null) {
            	Customer customer = customerService.get(cdsObj.getCustomerId(), null);
                if(customer != null && customer.getLanguage() != null) {
                	Language language = languageService.get(customer.getLanguage().getLanguageId(), null);
                	if(language != null) {
                		ObjectNode objNode = (ObjectNode)requestObj;
                		objNode.put("locale", language.getCode());
                		String modifiedRequest = mainObj.toString();
                		wrappedRequest.resetInputStream(modifiedRequest.getBytes());
                	}
                }
            }
            else {
            	wrappedRequest.resetInputStream(body.getBytes());
            }
            
        } catch (final SignatureException e) {

//            response.getOutputStream().write(getResponseBytes("Invalid token."));
            response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            return;
        } catch (Exception e) {

            String message = e.getMessage();
            log.debug("Exception " + e);
            if (message != null && message.indexOf("JWT expired at") > -1) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                long diff= ((ExpiredJwtException) e).getClaims().getExpiration().getTime() - ((ExpiredJwtException) e).getClaims().getIssuedAt().getTime();
                long minute = diff / (60 * 1000);
                log.info("diffDays = " + minute);
                response.getOutputStream().write(getResponseBytes(commonErrorMessage,minute));
            } else {
                response.setContentType("application/json");
//                response.getOutputStream().write(getResponseBytes(e.getMessage()));
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            }
            return;
        }
        chain.doFilter(wrappedRequest, res);
    }

    private byte[] getResponseBytes(String msg) throws IOException {
        SecurityResponse res = new SecurityResponse();
        res.setMessage(msg);
        res.setStatus(RequestStatus.FAILURE.getStatus());

        SecurityResponseWrapper wrapper = new SecurityResponseWrapper();
        wrapper.setResponse(res);
        String serialized = new ObjectMapper().writeValueAsString(wrapper);
        return serialized.getBytes();
    }

    private byte[] getResponseBytes(String msg,Long minute) throws IOException {
        SecurityResponse res = new SecurityResponse();
        res.setMessage(msg);
        res.setStatus(RequestStatus.FAILURE.getStatus());
        String message= null;
        if(minute<(24*60)) {
            message = messageSource.getMessage(JWT_TOKEN_EXP_MASSAGE_MINUTE, new String[]{ Long.toString(minute)}, null);
        }else{
            long days=minute/(60*24);
            message = messageSource.getMessage(JWT_TOKEN_EXP_MASSAGE, new Object[]{days}, null);
        }
        res.setDescription(message);
        res.setCode("10002");
        SecurityResponseWrapper wrapper = new SecurityResponseWrapper();
        wrapper.setResponse(res);
        String serialized = new ObjectMapper().writeValueAsString(wrapper);
        return serialized.getBytes();
    }


    public static String stripString(String value) {
        if (value != null) {
            // NOTE: It's highly recommended to use the ESAPI library and uncomment the following line to
            // avoid encoded attacks.
            // value = ESAPI.encoder().canonicalize(value);

            // Avoid null characters
            value = value.replaceAll("", "");

            // Avoid anything between script tags
            Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
            value = scriptPattern.matcher(value).replaceAll("");

            // Avoid anything in a src='...' type of expression
            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            value = scriptPattern.matcher(value).replaceAll("");

            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            value = scriptPattern.matcher(value).replaceAll("");

            // Remove any lonesome </script> tag
            scriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);
            value = scriptPattern.matcher(value).replaceAll("");

            // Remove any lonesome <script ...> tag
            scriptPattern = Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            value = scriptPattern.matcher(value).replaceAll("");

            // Avoid eval(...) expressions
            scriptPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            value = scriptPattern.matcher(value).replaceAll("");

            // Avoid expression(...) expressions
            scriptPattern = Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            value = scriptPattern.matcher(value).replaceAll("");

            // Avoid javascript:... expressions
            scriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);
            value = scriptPattern.matcher(value).replaceAll("");

            // Avoid vbscript:... expressions
            scriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);
            value = scriptPattern.matcher(value).replaceAll("");

            // Avoid onload= expressions
            scriptPattern = Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            value = scriptPattern.matcher(value).replaceAll("");
        }
        return value;
    }
    
    private void authenticateMerchantPosServices(final HttpServletRequest request,final HttpServletResponse response,FilterChain chain,ServletResponse res) throws IOException, ServletException{
    	
    	final String commonErrorMessage = "Authentication Failure";
    	final String authHeader = request.getHeader(JWT_AUTH_HEADER);
    	SecurityRequestWrapper wrappedRequest; //used wrapped request since getting data from inputstream twice is not possible.
        log.info("AuthHeader = " + authHeader);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setContentType("application/json");
            response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            return;
        }

        final String token = authHeader.substring(7); // The part after "Bearer "
        try {
            final Claims claims = Jwts.parser().setSigningKey(jwtUtil.getSecretCode())
                    .parseClaimsJws(token).getBody();

            if (!new Date().before(claims.getExpiration())) {
                response.setContentType("application/json");
                long diff=claims.getExpiration().getTime() - claims.getIssuedAt().getTime();
                long diffDays = diff / (60 * 1000);
                log.info("diffDays = " + diffDays);
                response.getOutputStream().write(getResponseBytes(commonErrorMessage,diffDays));
                return;
            }

            request.setAttribute("claims", claims);
            log.info("Claims from Authorization Header = " + claims);

            String subject = claims.getSubject();
            if (subject == null) {
                log.debug("counterId is null ");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            wrappedRequest = new SecurityRequestWrapper((HttpServletRequest) request);
            String body = IOUtils.toString(wrappedRequest.getReader());
            wrappedRequest.resetInputStream(body.getBytes());

            ObjectMapper mapper = new ObjectMapper();
            JsonNode mainObj = mapper.readTree(body);
            JsonNode requestObj = mainObj.get("request");
            
            String counterId = String.valueOf(requestObj.get("counterId"));

            if (counterId != null) {
            	counterId = counterId.replaceAll("\"", "");
            }
            Long tokenOutletCounterId = new Long(subject);
            Long requestOutletCounterId = new Long(counterId);
            
            if(tokenOutletCounterId.compareTo(requestOutletCounterId) != 0) {
            	log.info("token and request counter IDs are not matched.");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            OutletCounter outletCounter = outletCounterService.get(tokenOutletCounterId, null);

            if (outletCounter == null) {
                log.info("Counter ID is not matched with the database.");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            
            //validate active statuses
            OutletCounterStatus outletCounterStatus = outletCounterStatusService.get(outletCounter.getOutletCounterStatus().getOutletCounterStatusId(),null);
            if(!STATUS_ACTIVE.equals(outletCounterStatus.getName())){
            	log.info("Outlet Counter is not in active status");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
           
            Outlet outlet = outletService.get(outletCounter.getOutletId(),null);
            OutletStatus outletStatus = outletStatusService.get(outlet.getOutletStatus().getOutletStatusId(), null);
            if(!STATUS_ACTIVE.equals(outletStatus.getName())){
            	log.info("Outlet is not in active status");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            
            Merchant merchant = merchantService.get(outletCounter.getMerchantId(),null);
            MerchantStatus MerchantStatus = merchantStatusService.get(merchant.getMerchantStatus().getMerchantStatusId(), null);
            if(!STATUS_ACTIVE.equals(MerchantStatus.getName())){
            	log.info("Merchant is not in active status");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            
        } catch (final SignatureException e) {
            response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            return;
        } catch (Exception e) {
            String message = e.getMessage();
            log.info("Exception " + e);
            if (message != null && message.indexOf("JWT expired at") > -1) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                long diff= ((ExpiredJwtException) e).getClaims().getExpiration().getTime() - ((ExpiredJwtException) e).getClaims().getIssuedAt().getTime();
                long minute = diff / (60 * 1000);
                log.info("diffDays = " + minute);
                response.getOutputStream().write(getResponseBytes(commonErrorMessage,minute));
            } else {
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            }
            return;
        }
        chain.doFilter(wrappedRequest, res);
    }

    private void authenticateOpenServices(final HttpServletRequest request,final HttpServletResponse response,FilterChain chain,ServletResponse res) throws IOException, ServletException{
    	
    	final String commonErrorMessage = "Authentication Failure";
    	final String authHeader = request.getHeader(JWT_AUTH_HEADER);
    	SecurityRequestWrapper wrappedRequest; //used wrapped request since getting data from inputstream twice is not possible.
        log.info("AuthHeader = " + authHeader);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setContentType("application/json");
            response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            return;
        }

        final String token = authHeader.substring(7); // The part after "Bearer "
        try {
            final Claims claims = Jwts.parser().setSigningKey(jwtUtil.getSecretCode())
                    .parseClaimsJws(token).getBody();

            if (!new Date().before(claims.getExpiration())) {
                response.setContentType("application/json");
                long diff=claims.getExpiration().getTime() - claims.getIssuedAt().getTime();
                long diffDays = diff / (60 * 1000);
                log.info("diffDays = " + diffDays);
                response.getOutputStream().write(getResponseBytes(commonErrorMessage,diffDays));
                return;
            }

            request.setAttribute("claims", claims);
            log.info("Claims from Authorization Header = " + claims);

            String subject = claims.getSubject();
            if (subject == null) {
                log.debug("customerId is null ");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            wrappedRequest = new SecurityRequestWrapper((HttpServletRequest) request);
            String body = IOUtils.toString(wrappedRequest.getReader());
            wrappedRequest.resetInputStream(body.getBytes());

            ObjectMapper mapper = new ObjectMapper();
            JsonNode mainObj = mapper.readTree(body);
            JsonNode requestObj = mainObj.get("request");
            
            String customerId = String.valueOf(requestObj.get("customerId"));

            if (customerId != null) {
            	customerId = customerId.replaceAll("\"", "");
            }
            Long tokenCustomerId = new Long(subject);
            Long requestCustomerId = new Long(customerId);
            
            if(tokenCustomerId.compareTo(requestCustomerId) != 0) {
            	log.debug("token and request customer IDs are not matched.");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            Customer customer = customerService.get(tokenCustomerId, null);

            if (customer == null) {
                log.debug("Customer ID is not matched with the database.");
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
                return;
            }
            
        } catch (final SignatureException e) {
            response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            return;
        } catch (Exception e) {
            String message = e.getMessage();
            log.debug("Exception " + e);
            if (message != null && message.indexOf("JWT expired at") > -1) {
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                long diff= ((ExpiredJwtException) e).getClaims().getExpiration().getTime() - ((ExpiredJwtException) e).getClaims().getIssuedAt().getTime();
                long minute = diff / (60 * 1000);
                log.info("diffDays = " + minute);
                response.getOutputStream().write(getResponseBytes(commonErrorMessage,minute));
            } else {
                response.setContentType("application/json");
                response.getOutputStream().write(getResponseBytes(commonErrorMessage));
            }
            return;
        }
        chain.doFilter(wrappedRequest, res);
    }
}
