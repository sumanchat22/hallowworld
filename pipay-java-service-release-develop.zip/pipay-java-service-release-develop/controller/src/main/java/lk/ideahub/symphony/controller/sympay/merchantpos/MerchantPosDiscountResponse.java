package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.counter.entity.OutletCounter;
import lk.ideahub.symphony.modules.merchant.entity.Merchant;
import lk.ideahub.symphony.modules.outlet.entity.Outlet;
import lk.ideahub.symphony.product.sympay.pipay.external.entity.ExternalDiscountData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by mahesha on 1/9/19.
 */
@Getter
@Setter
@ToString
public class MerchantPosDiscountResponse extends Response {

    //get discount data
    private ExternalDiscountData externalDiscountData;
    
    //pos details
    private String posVersion;
    private String posReleaseDate;
    private Merchant merchant;
    private Outlet outlet;

    private String status;
    private String message;
}
