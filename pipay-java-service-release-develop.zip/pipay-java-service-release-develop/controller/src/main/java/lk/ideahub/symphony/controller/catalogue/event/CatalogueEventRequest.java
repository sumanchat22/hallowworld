package lk.ideahub.symphony.controller.catalogue.event;

import lk.ideahub.symphony.controller.common.Request;
import lk.ideahub.symphony.product.catalogue.event.entity.CatalogueEventData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by samith on 2/26/16.
 */
@Getter
@Setter
@ToString
public class CatalogueEventRequest extends Request {

    private List<CatalogueEventData> eventList;
    private String phone;

    //list event
    private BigDecimal latitude;
    private BigDecimal longitude;
    private List<Long> currentIdList;

    //search event
    private String searchText;

    //add event
    private Long customerId;
}
