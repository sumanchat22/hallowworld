package lk.ideahub.symphony.controller.sympay.merchantpos;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MerchantWalletBalanceRequest extends Request{

    private Long merchantId;
    private Long counterId;
    private String merchantWalletPin;
    private String merchantMsisdn;
    private Long outletId;

}
