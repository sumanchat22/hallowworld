package lk.ideahub.symphony.controller.external;

import com.fasterxml.jackson.annotation.JsonFormat;
import lk.ideahub.symphony.controller.common.Request;
import lk.ideahub.symphony.modules.common.Constants;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @author Bunna Hoeun
 *
 */
@Getter
@Setter
@ToString
public class CustomerSendVerificationCodeRequest extends Request{

	private String customerWalletNumber;
	private Long merchantId;
	private Long storeId;
	private Long deviceId;
	private BigDecimal orderAmount;
	private String currency;
	private String orderItemId;
	private String transId;
	private String verificationCode;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = Constants.TIME_ZONE)
	private Date orderDateTime;

}
