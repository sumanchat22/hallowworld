package lk.ideahub.symphony.controller.external;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.loyalty.entity.GlobalPercentageDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class CommonExternalResponse extends Response{

	private String status;
	private String message;
	private String responseCode;
	private List<GlobalPercentageDto> globalPercentageDtoList;
}
