package lk.ideahub.symphony.controller.sympay.merchant.transaction;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchantTransactionSummaryDto;
import lk.ideahub.symphony.product.sympay.merchant.entity.SymphonyMerchantOtcReportDto;

/**
 * Created by samith on 12/20/15.
 */
public class SymphonyMerchantTransactionResponse extends Response{

    private List<MerchantTransaction> merchantTransactionsList;
    private SymphonyMerchantTransactionSummaryDto summary;
    private List<SymphonyMerchantOtcReportDto> otcReportTransactionsList;
    // status
    private String status;
    private String message;


	public List<MerchantTransaction> getMerchantTransactionsList() {
		return merchantTransactionsList;
	}

	public void setMerchantTransactionsList(
			List<MerchantTransaction> merchantTransactionsList) {
		this.merchantTransactionsList = merchantTransactionsList;
	}

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
	public SymphonyMerchantTransactionSummaryDto getSummary() {
		return summary;
	}

	public void setSummary(SymphonyMerchantTransactionSummaryDto summary) {
		this.summary = summary;
	}
	
	public List<SymphonyMerchantOtcReportDto> getOtcReportTransactionsList() {
		return otcReportTransactionsList;
	}

	public void setOtcReportTransactionsList(List<SymphonyMerchantOtcReportDto> otcReportTransactionsList) {
		this.otcReportTransactionsList = otcReportTransactionsList;
	}

	@Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyMerchantResponse{");
        sb.append("merchantTransactionsList=").append(merchantTransactionsList);
        sb.append(",summary=").append(summary);
        sb.append(",otcReportTransactionsList=").append(otcReportTransactionsList);
        sb.append('}');
        return sb.toString();
    }
}
