package lk.ideahub.symphony.controller.security;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.merchant.entity.MerchantPgConnection;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.modules.merchant.service.MerchantPgConnectionService;
import lk.ideahub.symphony.modules.merchant.service.MerchantTransactionService;
import lk.ideahub.symphony.modules.types.service.ErrorCodesService;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


@Component
public class ExternalMerchantFilter extends GenericFilterBean {

    private static final Logger log = LoggerFactory.getLogger(ExternalMerchantFilter.class);

    @Autowired
    private Environment environment;

    @Autowired
    private MerchantPgConnectionService merchantPgConnectionService;

    @Autowired
    private MerchantTransactionService merchantTransactionService;

    @Autowired
    private ErrorCodesService errorCodesService;

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);

        final String commonErrorMessage = "Authentication Failure";
        final HttpServletRequest request = (HttpServletRequest) req;
        final HttpServletResponse response = (HttpServletResponse) res;
        SecurityRequestWrapper wrappedRequest = null;

        String url = request.getRequestURL().toString();
        response.setContentType("application/json");

        if (url.contains("/rs/sympay/external/merchant/transaction/initiate/push")
                || url.contains("/rs/sympay/external/merchant/transaction/cancel")
                || url.contains("/rs/sympay/external/merchant/transaction/query")
                || url.contains("/rs/sympay/external/merchant/transaction/initiate/qr")
                || url.contains("/rs/sympay/external/merchant/transaction/getstatus")) {

            final String secretCode = request.getHeader("X-IH-SECRETCODE");
            final String authPassword = request.getHeader("X-IH-PSW");
            log.info("AuthHeader = " + secretCode);
            log.info("AuthHeader = " + authPassword);

            if (secretCode == null || authPassword == null) {
                response.getOutputStream().write(getResponseBytes("5001",commonErrorMessage));
                return;
            }

            wrappedRequest = new SecurityRequestWrapper((HttpServletRequest) request);
            String body = IOUtils.toString(wrappedRequest.getReader());
            wrappedRequest.resetInputStream(body.getBytes());

            ObjectMapper mapper = new ObjectMapper();
            JsonNode requestObj = mapper.readTree(body).get("request");

            //MerchantPgIdentifier validation
            if (!requestObj.has("merchantPgIdentifier")) {
                response.getOutputStream().write(getResponseBytes("5015",commonErrorMessage));
                return;
            }

            String merchantPgIdentifier = requestObj.get("merchantPgIdentifier").textValue();

            MerchantPgConnection merchantPgConnection = merchantPgConnectionService.findByExternalMerchantUsingPgIdentifier(merchantPgIdentifier, null);

            if (merchantPgConnection == null) {
                response.getOutputStream().write(getResponseBytes("5015",commonErrorMessage));
                return;
            }

            if (url.contains("/rs/sympay/external/merchant/transaction/initiate/push") ||
                    url.contains("/rs/sympay/external/merchant/transaction/initiate/qr")) {

                if (!requestObj.has("externalMerchantTransactionId")) {
                    response.getOutputStream().write(getResponseBytes("5016","Validaion failure "));
                    return;
                }

                String externalMerchantTransactionId = requestObj.get("externalMerchantTransactionId").textValue();

                //ExternalMerchantTransactionId validation
                if (externalMerchantTransactionId == null || externalMerchantTransactionId.trim().equals("")) {
                    log.info(LogSupport.VALIDATE_EXTERNAL_MERCHANT_ID);
                    response.getOutputStream().write(getResponseBytes("5016",commonErrorMessage));
                    return;
                }

                //Check whether there are not exist MerchantTransaction record with same externalMerchantTransactionId for same Merchant
                List<MerchantTransaction> merchantTransactionList = merchantTransactionService.findByExternalMerchantTransactionAndMerchantPgConnection(externalMerchantTransactionId, merchantPgConnection, null);
                if (!merchantTransactionList.isEmpty()) {
                    response.getOutputStream().write(getResponseBytes("5000",commonErrorMessage));
                    return;
                }

            }

            String passwordHash = merchantPgConnection.getPassword();
            if (merchantPgConnection.getPassword().charAt(2) == 'y') {
                passwordHash = merchantPgConnection.getPassword().replaceFirst("y", "a");
            }

            Boolean validPassword;
            try{
                validPassword = BCrypt.checkpw(authPassword, passwordHash);
            } catch (IllegalArgumentException e){
                response.getOutputStream().write(getResponseBytes("5001",commonErrorMessage));
                return;
            }

            if (!validPassword) {
                response.getOutputStream().write(getResponseBytes("5001",commonErrorMessage));
                return;
            }
            chain.doFilter(wrappedRequest, res);
            return;
        }else{
            chain.doFilter(req, res);
            return;
        }
    }

    private byte[] getResponseBytes(String errCode, String msg) throws IOException {
        SecurityResponse res = new SecurityResponse();
        res.setStatus(RequestStatus.FAILURE.getStatus());
        String errorCode = errCode;
        String errorDescription = errorCodesService.getDescriptionUsingErrorCode(errorCode);
        res.setMessage(errorDescription);
        res.setDescription(null);
        res.setCode(errCode);
        SecurityResponseWrapper wrapper = new SecurityResponseWrapper();
        wrapper.setResponse(res);
        String serialized = new ObjectMapper().writeValueAsString(wrapper);
        return serialized.getBytes();
    }

}
