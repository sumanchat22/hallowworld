package lk.ideahub.symphony.controller.sympay.device;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by samith on 6/7/16.
 */
public class SymphonyDeviceRequest extends Request {

    private String uuid;
    private String registrationToken;
    private Long customerId;
    private String osTypeName; //Android,IOS

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getRegistrationToken() {
        return registrationToken;
    }

    public void setRegistrationToken(String registrationToken) {
        this.registrationToken = registrationToken;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getOsTypeName() {
        return osTypeName;
    }

    public void setOsTypeName(String osTypeName) {
        this.osTypeName = osTypeName;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyDeviceRequest{");
        sb.append("uuid='").append(uuid).append('\'');
        sb.append(", registrationToken='").append(registrationToken).append('\'');
        sb.append(", customerId=").append(customerId);
        sb.append(", osTypeName='").append(osTypeName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
