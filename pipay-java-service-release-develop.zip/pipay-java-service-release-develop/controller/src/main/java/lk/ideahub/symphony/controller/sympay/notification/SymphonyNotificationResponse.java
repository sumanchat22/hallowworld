package lk.ideahub.symphony.controller.sympay.notification;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.notification.entity.NotificationDataDto;
import lk.ideahub.symphony.product.sympay.notification.entity.NotificationSummary;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 1/24/19.
 */
@Getter
@Setter
@ToString
public class SymphonyNotificationResponse extends Response {

    private List<NotificationDataDto> notificationList;

    private String androidStatus;
    private String iosStatus;
    private String totalRequestedCount;
    private Long totalActiveCount;
    private String deliveryStatus;

    private String status;
    private String message;
}
