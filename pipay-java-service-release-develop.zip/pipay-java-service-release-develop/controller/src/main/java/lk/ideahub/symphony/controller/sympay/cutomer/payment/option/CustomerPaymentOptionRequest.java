package lk.ideahub.symphony.controller.sympay.cutomer.payment.option;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class CustomerPaymentOptionRequest extends Request{

	private Long customerId;
	private String currencyCode;
	private String event;
	private Long customerPaymentOptionId;
	private Boolean isRemoveDefault;

	//update payment option
	private String currency;

	private Boolean isZeroAmountNeeded;
}
