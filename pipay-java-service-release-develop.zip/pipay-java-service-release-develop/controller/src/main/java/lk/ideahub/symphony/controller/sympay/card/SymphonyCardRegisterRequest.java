package lk.ideahub.symphony.controller.sympay.card;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * Created by samith on 11/3/15.
 */
@ToString
@Getter
@Setter
public class SymphonyCardRegisterRequest extends Request {

    private Long customerId;
    private String cardNo;
    private Long customerPaymentOptionId;

    private String approvalMethod;
    private String approvalValue;
    private String PIN;

    // add this to support backward compatibility to card add 
    private String approvalCode;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM", timezone = "UTC")
    private Date expiryDate;

    private String cvc;
    private String optionAlias;

    private String paymentOptionStatusName;
    private Long payeeId;

    private Long merchantId;
    private Long paymentOptionIssuersId;
    private Long merchantDiscountId;
    private  String platform;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Long getCustomerPaymentOptionId() {
        return customerPaymentOptionId;
    }

    public void setCustomerPaymentOptionId(Long customerPaymentOptionId) {
        this.customerPaymentOptionId = customerPaymentOptionId;
    }

    public String getApprovalValue() {
        return approvalValue;
    }

    public void setApprovalValue(String approvalValue) {
        this.approvalValue = approvalValue;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public String getCvc() {
        return cvc;
    }

    public void setCvc(String cvc) {
        this.cvc = cvc;
    }

    public String getOptionAlias() {
        return optionAlias;
    }

    public void setOptionAlias(String optionAlias) {
        this.optionAlias = optionAlias;
    }

    public String getPaymentOptionStatusName() {
        return paymentOptionStatusName;
    }

    public void setPaymentOptionStatusName(String paymentOptionStatusName) {
        this.paymentOptionStatusName = paymentOptionStatusName;
    }

    public String getApprovalMethod() {
        return approvalMethod;
    }

    public void setApprovalMethod(String approvalMethod) {
        this.approvalMethod = approvalMethod;
    }

    public String getPIN() {
        return PIN;
    }

    public void setPIN(String PIN) {
        this.PIN = PIN;
    }

    public String getApprovalCode() {
		return approvalCode;
	}

	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}

    public Long getPayeeId() {
        return payeeId;
    }

    public void setPayeeId(Long payeeId) {
        this.payeeId = payeeId;
    }

    public Long getMerchantId() { return merchantId;  }

    public void setMerchantId(Long merchantId) { this.merchantId = merchantId;   }

    public Long getPaymentOptionIssuersId() {     return paymentOptionIssuersId;    }

    public void setPaymentOptionIssuersId(Long paymentOptionIssuersId) {    this.paymentOptionIssuersId = paymentOptionIssuersId;    }

    public Long getMerchantDiscountId() {    return merchantDiscountId;    }

    public void setMerchantDiscountId(Long merchantDiscountId) {    this.merchantDiscountId = merchantDiscountId;    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyCardRegisterRequest{");
        sb.append("customerId=").append(customerId);
        //sb.append(", cardNo='").append(cardNo).append('\'');
        sb.append(", customerPaymentOptionId=").append(customerPaymentOptionId);
        //sb.append(", approvalCode='").append(approvalCode).append('\'');
        //sb.append(",PIN= ").append(PIN).append('\'');
        //sb.append(", expiryDate=").append(expiryDate);
        //sb.append(", cvc='").append(cvc).append('\'');
        sb.append(", optionAlias='").append(optionAlias).append('\'');
        sb.append(", paymentOptionStatusName='").append(paymentOptionStatusName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
