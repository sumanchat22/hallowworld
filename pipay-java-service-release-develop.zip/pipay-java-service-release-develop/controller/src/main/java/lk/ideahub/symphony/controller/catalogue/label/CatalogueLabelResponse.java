package lk.ideahub.symphony.controller.catalogue.label;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.banner.entity.Banner;
import lk.ideahub.symphony.modules.deal.entity.Deal;
import lk.ideahub.symphony.modules.label.entity.Label;
import lk.ideahub.symphony.product.catalogue.filterObject.DealCategoryCount;

import java.util.List;

/**
 * Created by kalpana on 8/4/16.
 */
public class CatalogueLabelResponse extends Response
{
    // status
    private String status;
    private String message;

    //list menu labels
    private List<Label> menuLabelList;

    //dashboard
    private DealCategoryCount dealCategoryCount;
    private String appVersion;
    private Banner homeBanner;
    private List searchLabels;

    //listDealsForMenuLabel
    private List<Deal> dealList;

    private List deals;
    private Integer dealCount;

    //dashboard banner label
    private Object bannerReference;

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }

    public void setMessage(String message) { this.message = message; }

    public List<Label> getMenuLabelList() { return menuLabelList; }

    public void setMenuLabelList(List<Label> menuLabelList) { this.menuLabelList = menuLabelList; }

    public Banner getHomeBanner() { return homeBanner; }

    public void setHomeBanner(Banner homeBanner) { this.homeBanner = homeBanner; }

    public DealCategoryCount getDealCategoryCount() { return dealCategoryCount; }

    public void setDealCategoryCount(DealCategoryCount dealCategoryCount) { this.dealCategoryCount = dealCategoryCount; }

    public String getAppVersion() { return appVersion; }

    public void setAppVersion(String appVersion) { this.appVersion = appVersion; }

    public List<Deal> getDealList() { return dealList; }

    public void setDealList(List<Deal> dealList) { this.dealList = dealList; }

    public List getDeals() { return deals; }

    public void setDeals(List deals) { this.deals = deals; }

    public Integer getDealCount() { return dealCount; }

    public void setDealCount(Integer dealCount) { this.dealCount = dealCount; }

    public List getSearchLabels() { return searchLabels; }

    public void setSearchLabels(List searchLabels) { this.searchLabels = searchLabels; }

    public Object getBannerReference() { return bannerReference; }

    public void setBannerReference(Object bannerReference) { this.bannerReference = bannerReference; }

    @Override
    public String toString() {
        return new StringBuilder("CatalogueLabelResponse {")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'").append(", ")
                .append("menuLabelList=").append(menuLabelList).append(", ")
                .append("dealCategoryCount=").append(dealCategoryCount).append(", ")
                .append("appVersion='").append(appVersion).append("'").append(", ")
                .append("homeBanner=").append(homeBanner).append(", ")
                .append("searchLabels=").append(searchLabels).append(", ")
                .append("dealList=").append(dealList).append(", ")
                .append("deals=").append(deals).append(", ")
                .append("dealCount=").append(dealCount).append(", ")
                .append("bannerReference=").append(bannerReference)
                .append('}').toString();
    }
}
