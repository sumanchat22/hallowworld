package lk.ideahub.symphony.controller.sympay.merchantpos;

import java.util.List;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.CustomerPayeeTransaction;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class OfflineQrSyncResponse extends Response {

    // status
    private String status;
    private String message;
    
    private List<MerchantTransaction> merchantTransactionList;
    private CustomerPayeeTransaction customerPayeeTransaction;
	private String offlinePaymentStatus;
}
