package lk.ideahub.symphony.controller.sympay.freeZone;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.freeZone.entity.FreeZoneRewardRequest;
import lk.ideahub.symphony.product.sympay.freeZone.service.FreeZoneService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Madhukara on 4/9/18.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME  + "/freezone", consumes = "application/json", produces = "application/json")
public class FreeZoneController extends GenericController{
    private static final Logger log = LoggerFactory.getLogger(FreeZoneController.class);

    @Autowired
    FreeZoneService freeZoneService;

    @RequestMapping(value = "redeem/reward", method = RequestMethod.POST)
    @ResponseBody
    public Response redeemReward(final @RequestBody FreeZoneRequest _request, HttpServletRequest servletRequest) {

        ServiceContext serviceContext = getServiceContext(false);

        FreeZoneRewardRequest freeZoneRewardRequest = new FreeZoneRewardRequest();
        BeanUtils.copyProperties(_request, freeZoneRewardRequest);

        FreeZoneResponse response = new FreeZoneResponse();

        try {
            FreeZoneRewardRequest result = freeZoneService.redeemReward(freeZoneRewardRequest, serviceContext);

            response.setRedeemSuccess(result.getSuccess());
            response.setStatus(result.getStatus());
            if (result.getMessageCode() != null){
                response.setCode(result.getMessageCode());
            }
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service redeem reward - failure [response: {}]", response);
        } else {
            log.debug("Service redeem reward [response: {}]", response);
        }
        return response;
    }

}
