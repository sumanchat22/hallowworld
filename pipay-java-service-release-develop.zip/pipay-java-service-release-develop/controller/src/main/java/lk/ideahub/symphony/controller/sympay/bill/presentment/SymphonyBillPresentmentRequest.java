package lk.ideahub.symphony.controller.sympay.bill.presentment;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by mahesha on 5/22/17.
 */
public class SymphonyBillPresentmentRequest extends Request {

    private Long customerId;
    private Long customerPayeeId;
    private Boolean isEnable;
    private String otp;
    private String nic;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getCustomerPayeeId() {
        return customerPayeeId;
    }

    public void setCustomerPayeeId(Long customerPayeeId) {
        this.customerPayeeId = customerPayeeId;
    }

    public Boolean getEnable() {
        return isEnable;
    }

    public void setEnable(Boolean enable) {
        isEnable = enable;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }


    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    @Override
    public String toString() {
        return new StringBuilder("SymphonyBillPresentmentRequest {")
                .append("customerId=").append(customerId).append(", ")
                .append("customerPayeeId=").append(customerPayeeId).append(", ")
                .append("isEnable=").append(isEnable).append(", ")
                //.append("otp='").append(otp).append("'")
                .append('}').toString();
    }
}
