package lk.ideahub.symphony.controller.catalogue.label;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.catalogue.label.entity.CatalogueLabel;
import lk.ideahub.symphony.product.catalogue.label.service.CatalogueLabelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by kalpana on 8/4/16.
 */

@Controller
@RequestMapping(value = "rs/catalogue", consumes = "application/json", produces = "application/json")
public class CatalogueLabelController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(CatalogueLabelController.class);

    @Autowired
    CatalogueLabelService dAppLabelService;

// ------------------------------- list menu labels --------------------------------------

    @RequestMapping(value = "labels/menu/list", method = RequestMethod.POST)
    @ResponseBody

    public Response listMenuLabels(final @RequestBody CatalogueLabelRequest _request) {

        ServiceContext _serviceContext = getServiceContext(_request, false);
        CatalogueLabel CatalogueLabel = new CatalogueLabel();
        BeanUtils.copyProperties(_request, CatalogueLabel);

        CatalogueLabelResponse response = new CatalogueLabelResponse();
        try {
            CatalogueLabel result = dAppLabelService.listMenuLabels(CatalogueLabel, _serviceContext);

            response.setMenuLabelList(result.getMenuLabelList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service catalogue listMenuLabels - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service catalogue listMenuLabels [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    @RequestMapping(value = "dashboard", method = RequestMethod.POST)
    @ResponseBody

    public Response dashboard(final @RequestBody CatalogueLabelRequest _request)
    {
        ServiceContext _serviceContext = getServiceContext(_request, false);

        CatalogueLabel CatalogueLabel = new CatalogueLabel();
        BeanUtils.copyProperties(_request, CatalogueLabel);

        CatalogueLabelResponse response = new CatalogueLabelResponse();

        try
        {
            CatalogueLabel result = dAppLabelService.dashboard(CatalogueLabel, _serviceContext);

            response.setHomeBanner(result.getBanner());
            response.setSearchLabels(result.getSearchLabels());
            response.setDealCategoryCount(result.getDealCategoryCount());
            response.setAppVersion(result.getAppVersion());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service catalogue dashboardService - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service catalogue dashboardService [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    // ------------------------------- list deals relevant to menu label id --------------------------------------

    @RequestMapping(value = "labels/menu/deal/list", method = RequestMethod.POST)
    @ResponseBody

    public Response listDealsForMenuLabel(final @RequestBody CatalogueLabelRequest _request)
    {
        ServiceContext _serviceContext = getServiceContext(_request, true);

        CatalogueLabel CatalogueLabel = new CatalogueLabel();
        BeanUtils.copyProperties(_request, CatalogueLabel);

        CatalogueLabelResponse response = new CatalogueLabelResponse();

        try
        {
            CatalogueLabel result = dAppLabelService.listDealsForMenuLabel(CatalogueLabel, _serviceContext);

            response.setDeals(result.getDeals());
            response.setDealCount(result.getDeals() != null ? result.getDeals().size() : 0);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service catalogue listDealsForMenuLabelService - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service catalogue listDealsForMenuLabelService [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    // ------------------------------- list search labels --------------------------------------

    @RequestMapping(value = "labels/search/list", method = RequestMethod.POST)
    @ResponseBody

    public Response listSearchLabels(final @RequestBody CatalogueLabelRequest _request)
    {
        ServiceContext _serviceContext = getServiceContext(_request, false);

        CatalogueLabel CatalogueLabel = new CatalogueLabel();
        BeanUtils.copyProperties(_request, CatalogueLabel);

        CatalogueLabelResponse response = new CatalogueLabelResponse();

        try
        {
            CatalogueLabel result = dAppLabelService.listSearchLabels(CatalogueLabel, _serviceContext);

            response.setMenuLabelList(result.getMenuLabelList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service catalogue listSearchLabels - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service catalogue listSearchLabels [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    // ------------------------------- get Deal in banner --------------------------------------

    @RequestMapping(value = "dashboard/banner/reference", method = RequestMethod.POST)
    @ResponseBody

    public Response dashboardBannerReference(final @RequestBody CatalogueLabelRequest _request)
    {
        ServiceContext _serviceContext = getServiceContext(_request, false);

        CatalogueLabel CatalogueLabel = new CatalogueLabel();
        BeanUtils.copyProperties(_request, CatalogueLabel);

        CatalogueLabelResponse response = new CatalogueLabelResponse();

        try
        {
            CatalogueLabel result = dAppLabelService.dashboardBannerReference(CatalogueLabel, _serviceContext);

            response.setBannerReference(result.getBannerReference());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service catalogue dashboardBannerReferenceService - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service catalogue dashboardBannerReferenceService [request: {}; response: {}]", _request, response);
        }

        return response;
    }

    // ------------------------------- search text --------------------------------------

    @RequestMapping(value = "dashboard/search", method = RequestMethod.POST)
    @ResponseBody

    public Response dashboardSearch(final @RequestBody CatalogueLabelRequest _request)
    {
        ServiceContext _serviceContext = getServiceContext(_request, true);

        CatalogueLabel CatalogueLabel = new CatalogueLabel();
        BeanUtils.copyProperties(_request, CatalogueLabel);

        CatalogueLabelResponse response = new CatalogueLabelResponse();

        try
        {
            CatalogueLabel result = dAppLabelService.dashboardSearch(CatalogueLabel, _serviceContext);

            response.setDeals(result.getDeals());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }
        catch (InvalidRequestException exception)
        {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service catalogue dashboardSearchService - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service catalogue dashboardSearchService [request: {}; response: {}]", _request, response);
        }

        return response;
    }


}
