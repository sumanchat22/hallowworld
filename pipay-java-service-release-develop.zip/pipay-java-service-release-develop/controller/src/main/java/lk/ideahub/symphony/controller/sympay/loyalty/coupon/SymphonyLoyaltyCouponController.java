package lk.ideahub.symphony.controller.sympay.loyalty.coupon;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.controller.sympay.loyalty.SymphonyLoyaltyPointResponse;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import lk.ideahub.symphony.product.sympay.loyalty.entity.SymphonyLoyaltyCoupon;
import lk.ideahub.symphony.product.sympay.loyalty.service.SymphonyLoyaltyCouponService;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 3/5/19.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/loyalty/coupon", consumes = "application/json", produces = "application/json")
public class SymphonyLoyaltyCouponController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyLoyaltyCouponController.class);

    @Autowired
    private SymphonyLoyaltyCouponService symphonyLoyaltyCouponService;

    @RequestMapping(value = "list/pack", method = RequestMethod.POST)
    @ResponseBody
    public Response listCouponPack(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.listAllCoupon(symphonyLoyaltyPoint, serviceContext);
            response.setNearByCouponList(result.getNearByCouponList());
            response.setRecommendedCouponList(result.getRecommendedCouponList());
            response.setFeaturedCouponList(result.getFeaturedCouponList());
            response.setFilterTagList(result.getFilterTagList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service list all coupons - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service list all coupons [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Response search(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.searchPack(symphonyLoyaltyPoint, serviceContext);
            response.setCouponPackList(result.getCouponPackList());
            response.setCouponCount(result.getCouponCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service search coupon pack - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service search coupon pack [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "get/detail", method = RequestMethod.POST)
    @ResponseBody
    public Response getDetail(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.getDetail(symphonyLoyaltyPoint, serviceContext);
            response.setCouponPack(result.getCouponPack());
            response.setPointBalance(result.getPointBalance());
            response.setBurningRewardsConversionRateId(result.getBurningRewardsConversionRateId());
            response.setBurningRewardsConversionRate(result.getBurningRewardsConversionRate());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get details - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get details [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "buy/point", method = RequestMethod.POST)
    @ResponseBody
    public Response buyCoupon(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.buyCouponPoint(symphonyLoyaltyPoint, serviceContext);
            response.setCoupon(result.getCoupon());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service buy coupon - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service buy coupon [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "buy/couponCash", method = RequestMethod.POST)
    @ResponseBody
    public Response buyCouponCash(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.buyCouponCash(symphonyLoyaltyPoint, serviceContext);
            response.setCoupon(result.getCoupon());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            log.error("error {} ", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service buy coupon cash - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service buy coupon cash [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "claimed/list", method = RequestMethod.POST)
    @ResponseBody
    public Response listClaimedCoupons(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.listClaimedCoupons(symphonyLoyaltyPoint, serviceContext);
            response.setCouponCount(result.getCouponCount());
            response.setCouponList(result.getCouponList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service list claimed coupons - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service list claimed coupons [request: {}; response: {}]", request, response);
        }
        return response;
    }
    
    @RequestMapping(value = "get/qrcode", method = RequestMethod.POST)
    @ResponseBody
    public Response getQrCode(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyCoupon = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyCoupon);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.getCouponQrCode(symphonyLoyaltyCoupon, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
            response.setCouponQr(result.getCouponQr());
            response.setCouponCode(result.getCouponCode());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service list coupons getQrCode- failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service list coupons getQrCode [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "expire", method = RequestMethod.POST)
    @ResponseBody
    public Response expirePoint(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyLoyaltyPointResponse response = new SymphonyLoyaltyPointResponse();
        SymphonyLoyaltyCoupon symphonyLoyaltyCoupon = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyCoupon);
        try {
            if(request.getIsExpirationProcessDisabled()) {
                log.info(LogSupport.POINT_EXPIRING_CRON + " Cron Job disabled..");
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
                return response;
            }
            log.info(LogSupport.COUPON_EXPIRE_CRON + " Cron Job Started..");
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.expiringCoupon(request.getIsExpirationNotificationDisabled(),serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.COUPON_EXPIRE_CRON + " Cron Job Completed..");
        } catch (InvalidRequestException exception) {
            log.error("Service expiring coupons  - failure [exception: {}]", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.COUPON_EXPIRE_CRON + " Cron Job Ended With Errors..");

        }
        return response;
    }

    @RequestMapping(value = "create", method = RequestMethod.POST)
    @ResponseBody
    public Response crateCoupon(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyCoupon = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyCoupon);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.crateCoupon(symphonyLoyaltyCoupon, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service create coupons - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service create coupons [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "payable/list", method = RequestMethod.POST)
    @ResponseBody
    public Response payableCoupons(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.payableCoupons(symphonyLoyaltyPoint, serviceContext);
            response.setCouponList(result.getCouponList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service payable coupons - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service payable coupons [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "transfer", method = RequestMethod.POST)
    @ResponseBody
    public Response transferCoupon(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.transferCoupon(symphonyLoyaltyPoint, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service transfer coupons - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service transfer coupons [request: {}; response: {}]", request, response);
        }
        return response;
    }

    private void setClientIP(final SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }


    @RequestMapping(value = "release", method = RequestMethod.POST)
    @ResponseBody
    public Response releaseCoupons(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();
        try {
            if(request.getIsReleasingProcessDisabled()) {
                log.info(LogSupport.COUPON_RELEASING_CRON + " Cron Job disabled..");
                response.setStatus(RequestStatus.SUCCESS.getStatus());
                response.setMessage(RequestStatus.SUCCESS.getStatus());
                return response;
            }
            log.info(LogSupport.COUPON_RELEASING_CRON + " Cron Job Started..");
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.releaseUnClaimedCoupons(serviceContext);
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(result.getMessage());
            log.info(LogSupport.COUPON_RELEASING_CRON + " Cron Job Completed..");
        } catch (InvalidRequestException exception) {
            log.error("Service release assigned coupons error - " + exception.toString());
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
            log.info(LogSupport.COUPON_RELEASING_CRON + " Cron Job Ended With Errors..");
        }
        return response;
    }

    @RequestMapping(value = "customer/confirm", method = RequestMethod.POST)
    @ResponseBody
    public Response couponRedeemCustomerConfirm(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyCoupon = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyCoupon);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.couponRedeemCustomerConfirm(symphonyLoyaltyCoupon, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service couponRedeemCustomerConfirm- failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service couponRedeemCustomerConfirm [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "redeem/status", method = RequestMethod.POST)
    @ResponseBody
    public Response checkCouponRedeemStatus(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        log.info("call- failure [request: {}; ]", request);
        SymphonyLoyaltyCoupon symphonyLoyaltyCoupon = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyCoupon);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.checkCouponRedeemStatus(symphonyLoyaltyCoupon, serviceContext);
            response.setCouponRedemptionStatus(result.getCouponRedemptionStatus());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service checkCouponRedeemStatus- failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service checkCouponRedeemStatus [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "buy/free", method = RequestMethod.POST)
    @ResponseBody
    public Response buyCouponFree(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.buyCouponFree(symphonyLoyaltyPoint, serviceContext);
            response.setCoupon(result.getCoupon());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service buy coupon - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service buy coupon [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "manual/redeem" , method = RequestMethod.POST)
    @ResponseBody
    public Response redeemCoupon(final @RequestBody SymphonyLoyaltyCouponRequest request, HttpServletRequest servletRequest){
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result =  symphonyLoyaltyCouponService.operatorRedeemCoupon(symphonyLoyaltyPoint, serviceContext);
            response.setMessage(result.getMessage());
            response.setStatus(result.getStatus());
            response.setCouponInfo(result.getCouponInfo());

        }catch (Exception exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service redeemCoupon Manual  - failure [request : {}; response: {}]",request,response);
        }else {
            log.debug("Service redeemCoupon Manual [request: {}; response: {}]",request,response);
        }
        return response;
    }

    @RequestMapping(value = "get/free", method = RequestMethod.POST)
    @ResponseBody
    public Response getCouponFree(final @RequestBody SymphonyLoyaltyCouponRequest request, @RequestHeader (value = "Version", required = true) String version,
                                  @RequestHeader (value = "Os", required = true) String os,
                                  HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);

        symphonyLoyaltyPoint.setVersion(version);
        symphonyLoyaltyPoint.setOsType(os);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.getCouponFree(symphonyLoyaltyPoint, serviceContext);
            response.setDialog(result.getDialog());
            response.setCustomerGetCoupon(result.getCustomerGetCoupon());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException | JSONException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service buy coupon - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service buy coupon [request: {}; response: {}]", request, response);
        }
        return response;
    }

    @RequestMapping(value = "customer/verifyCoupon", method = RequestMethod.POST)
    @ResponseBody
    public Response customerVerifyCoupon(final @RequestBody SymphonyLoyaltyCouponRequest request, @RequestHeader (value = "Version", required = true) String version,
                                  @RequestHeader (value = "Os", required = true) String os,
                                  HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyLoyaltyCoupon symphonyLoyaltyPoint = new SymphonyLoyaltyCoupon();
        BeanUtils.copyProperties(request, symphonyLoyaltyPoint);

        symphonyLoyaltyPoint.setVersion(version);
        symphonyLoyaltyPoint.setOsType(os);
        SymphonyLoyaltyCouponResponse response = new SymphonyLoyaltyCouponResponse();

        try {
            SymphonyLoyaltyCoupon result = symphonyLoyaltyCouponService.customerVerifyCoupon(symphonyLoyaltyPoint, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException | JSONException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service buy coupon - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service buy coupon [request: {}; response: {}]", request, response);
        }
        return response;
    }


}
