package lk.ideahub.symphony.controller.sympay.external.merchant;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.merchant.entity.Merchant;
import lk.ideahub.symphony.modules.merchant.entity.MerchantPgConnection;
import lk.ideahub.symphony.modules.merchant.entity.MerchantTransaction;
import lk.ideahub.symphony.modules.user.entity.User;
import lk.ideahub.symphony.product.sympay.merchant.entity.Transaction;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * Created by Gayan on 03/04/18..
 */
@Getter
@Setter
@ToString
public class SymphonyExternalMerchantResponse extends Response{

    //merchantPgConnection object
    private MerchantPgConnection merchantPgConnection;
    private MerchantTransaction merchantTransaction;
    private User user;
    private Merchant merchant;

    //customer
    private Customer customer;

    //sessionToken
    private String sessionToken;
    private Long merchantDiscountId;

    //QR Code
    private String QrEncryptedText;

    //validate card discount
    private Boolean validDiscount;
    private String invalidReason;
    // status
    private String status;
    private String message;
    private String errorCode;

    private String externalMerchantTransactionId;
    private String merchantTxnStatusName;
    private List<MerchantTransaction> merchantTransactionList;

    private Long merchantTransactionId;
    private String symphonyTransactionId;
    private Long merchantId;
    private BigDecimal transactionAmount;
    private String invoiceNumber;
    private Date transactionDateTime;
    private List<Transaction> transactionList;
    private String merchantPgIdentifier;
    
    private String geneieReferenceNo;

}
