package lk.ideahub.symphony.controller.sympay.qrcode.payment;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.SymphonyQrCodePayment;
import lk.ideahub.symphony.product.sympay.qrcode.payment.entity.QRType;
import lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/merchant/qrpay", consumes = "application/json", produces = "application/json")
public class SymphonyQrCodePaymentController extends GenericController {

	@Autowired
	private SymphonyQrCodePaymentService symphonyQrCodePaymentService;
	
    private static final Logger log = LoggerFactory.getLogger(SymphonyQrCodePaymentController.class);
    
    private static final String VALIDATION_FAILURE_INVALID_QR_CODE = "message.failure.qrcode.invalid";
    
    @Autowired
    private MessageSource messageSource;

    @RequestMapping(value = "encryption", method = RequestMethod.POST)
    @ResponseBody
    public Response getEncryptedValueDynamic(final @RequestBody QrCodePaymentRequest qrCodePaymentRequest,HttpServletRequest servletRequest){
        
    	setClientIP(qrCodePaymentRequest, servletRequest);
        ServiceContext serviceContext = getServiceContext(qrCodePaymentRequest, false);
        
        SymphonyQrCodePayment piPayQrEncrypted = new SymphonyQrCodePayment();
        BeanUtils.copyProperties(qrCodePaymentRequest, piPayQrEncrypted);
        if (!qrCodePaymentRequest.getAmount().trim().equals("") && qrCodePaymentRequest.getAmount() != null){
            piPayQrEncrypted.setChargeTotal(new BigDecimal(qrCodePaymentRequest.getAmount()));
        }
        piPayQrEncrypted.setIsExternalMerchant(false);

        QrCodePaymentResponse response = new QrCodePaymentResponse();
        try {
        	piPayQrEncrypted = symphonyQrCodePaymentService.getDynamicEncryptedText(piPayQrEncrypted, serviceContext);
        	response.setQrEncryptedText(piPayQrEncrypted.getQrEncryptedText());
            response.setSymphonyTransactionId(piPayQrEncrypted.getSymphonyTransactionId());
            response.setTransactionId(piPayQrEncrypted.getTransactionId());
            response.setGrossAmount(piPayQrEncrypted.getGrossAmount());
            //response.setExternalDiscountData(piPayQrEncrypted.getExternalDiscountData());
            response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(piPayQrEncrypted.getMessage());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getEncryptedValue - Dynamic - failure [request: {}; response: {}]", qrCodePaymentRequest, response);
        } else {
            log.debug("Service getEncryptedValue - Dynamic - [request: {}; response: {}]", qrCodePaymentRequest, response);
        }
        return response;
    }
    
    /**=================================THIS IS ALTERED FOR PI PAY=======================================**/
    /*@RequestMapping(value = "verification", method = RequestMethod.POST)
    @ResponseBody
    public Response paymentVerification(final @RequestBody QrCodePaymentRequest qrCodePaymentRequest,HttpServletRequest servletRequest){

    	setClientIP(qrCodePaymentRequest, servletRequest);
        ServiceContext serviceContext = getServiceContext(qrCodePaymentRequest, false);
        
        SymphonyQrCodePayment symphonyQrCodePayment = new SymphonyQrCodePayment();
        BeanUtils.copyProperties(qrCodePaymentRequest, symphonyQrCodePayment);
        
        QrCodePaymentResponse response = new QrCodePaymentResponse();
        try{
        	
        	String encryptedTextPrefix = symphonyQrCodePayment.getQrEncryptedText().substring(0, 8);
        	String encryptedText = symphonyQrCodePayment.getQrEncryptedText().replace(encryptedTextPrefix, "");
        	symphonyQrCodePayment.setQrEncryptedText(encryptedText);

	        String qrType= symphonyQrCodePaymentService.decrypteData(symphonyQrCodePayment, serviceContext);
	        if( QRType.Dynamic.getDescription().equals(qrType) && encryptedTextPrefix.equals(Constants.DY_MR_NL)){
	            symphonyQrCodePaymentService.paymentDynamicVerification(symphonyQrCodePayment, serviceContext);
	            response.setDiscountDetail(symphonyQrCodePayment.getDiscountDetail());
	            response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
                response.setSurchargeEnablePOList(symphonyQrCodePayment.getSurchargeEnablePOList());
	        	response.setStatus(RequestStatus.SUCCESS.getStatus());
	            response.setMessage(RequestStatus.SUCCESS.getStatus());
	        }
	        else if(QRType.GuestDynamic.getDescription().equals(qrType) && encryptedTextPrefix.equals(Constants.DY_MR_GT)){
	        	symphonyQrCodePaymentService.paymentGuestDynamicVerification(symphonyQrCodePayment, serviceContext);
                response.setDiscountDetail(symphonyQrCodePayment.getDiscountDetail());
                response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
                response.setSurchargeEnablePOList(symphonyQrCodePayment.getSurchargeEnablePOList());
                response.setStatus(RequestStatus.SUCCESS.getStatus());
	            response.setMessage(RequestStatus.SUCCESS.getStatus());
	        }
	        else if(encryptedTextPrefix.equals(Constants.DY_MR_OL)){//Dynamic QR (Offline)
	        	symphonyQrCodePayment.setMedia(Constants.MERCHANT_POS);
	        	symphonyQrCodePaymentService.paymentDynamicOfflineVerification(symphonyQrCodePayment, serviceContext);
                response.setDiscountDetail(symphonyQrCodePayment.getDiscountDetail());
                response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
                response.setSurchargeEnablePOList(symphonyQrCodePayment.getSurchargeEnablePOList());
                response.setStatus(RequestStatus.SUCCESS.getStatus());
	            response.setMessage(RequestStatus.SUCCESS.getStatus());
	        }
	        else if(qrType == null){
	        	if(encryptedTextPrefix.equals(Constants.ST_MR_NL)) {//merchant-without amount and currency
	        		symphonyQrCodePaymentService.paymentStaticVerification(symphonyQrCodePayment, serviceContext,Constants.ST_MR_NL);
	        		response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
	                response.setSurchargeEnablePOList(symphonyQrCodePayment.getSurchargeEnablePOList());
	                response.setStatus(RequestStatus.SUCCESS.getStatus());
	                response.setMessage(RequestStatus.SUCCESS.getStatus());
	        	}
	        	else if(encryptedTextPrefix.equals(Constants.ST_MR_HB)) {//merchant-with amount and currency
	        		symphonyQrCodePaymentService.paymentStaticVerification(symphonyQrCodePayment, serviceContext,Constants.ST_MR_HB);
	        		response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
	                response.setSurchargeEnablePOList(symphonyQrCodePayment.getSurchargeEnablePOList());
	                response.setStatus(RequestStatus.SUCCESS.getStatus());
	                response.setMessage(RequestStatus.SUCCESS.getStatus());
	        	}
	        	else if(encryptedTextPrefix.equals(Constants.ST_RC_NL)) {//receiver-without amount and currency
	        		symphonyQrCodePaymentService.paymentReceiverVerification(symphonyQrCodePayment, serviceContext, Constants.ST_RC_NL);
	        		response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
	        		response.setStatus(RequestStatus.SUCCESS.getStatus());
	                response.setMessage(RequestStatus.SUCCESS.getStatus());
	        	}
	        	else if(encryptedTextPrefix.equals(Constants.ST_RC_HB)) {//receiver-with amount and currency
	        		symphonyQrCodePaymentService.paymentReceiverVerification(symphonyQrCodePayment, serviceContext, Constants.ST_RC_HB);
	        		response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
	        		response.setStatus(RequestStatus.SUCCESS.getStatus());
	                response.setMessage(RequestStatus.SUCCESS.getStatus());
	        	}
	        	else {//this is for existing static QR s
	        		symphonyQrCodePayment.setQrEncryptedText(encryptedTextPrefix + encryptedText);
	        		symphonyQrCodePaymentService.paymentStaticVerification(symphonyQrCodePayment, serviceContext,Constants.QR_GROUP_NONE);
	        		response.setQrCodeVerificationData(symphonyQrCodePayment.getQrCodeVerificationData());
	                response.setSurchargeEnablePOList(symphonyQrCodePayment.getSurchargeEnablePOList());
	                response.setStatus(RequestStatus.SUCCESS.getStatus());
	                response.setMessage(RequestStatus.SUCCESS.getStatus());
	        	}

	        }else{
	        	response.setStatus(RequestStatus.FAILURE.getStatus());
	            response.setMessage(messageSource.getMessage(VALIDATION_FAILURE_INVALID_QR_CODE,null,serviceContext.getLocale()));
	        }
		} catch (InvalidRequestException exception) {
		    response.setStatus(RequestStatus.FAILURE.getStatus());
		    response.setMessage(exception.getMessage());
		}
		if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
		    log.warn("Service paymentVerification - failure [request: {}; response: {}]", qrCodePaymentRequest, response);
		} else {
		    log.debug("Service paymentVerification [request: {}; response: {}]", qrCodePaymentRequest, response);
		}
		return response;
    }*/

    @RequestMapping(value = "encryption/{userId}", method = RequestMethod.GET)
    @ResponseBody
    public Response getEncryptedValueStatic(@PathVariable Long userId,HttpServletRequest servletRequest){
    	QrCodePaymentRequest qrCodePaymentRequest = new QrCodePaymentRequest();
    	qrCodePaymentRequest.setUserId(userId);
    	
    	setClientIP(qrCodePaymentRequest, servletRequest);
        ServiceContext serviceContext = getServiceContext(qrCodePaymentRequest, false);
        
        SymphonyQrCodePayment piPayQrEncrypted = new SymphonyQrCodePayment();
        BeanUtils.copyProperties(qrCodePaymentRequest, piPayQrEncrypted);
        
        QrCodePaymentResponse response = new QrCodePaymentResponse();
        try {
        	piPayQrEncrypted = symphonyQrCodePaymentService.getStaticEncryptedText(piPayQrEncrypted, serviceContext);
        	response.setQrEncryptedTexts(piPayQrEncrypted.getQrEncryptedTexts());
        	response.setStatus(RequestStatus.SUCCESS.getStatus());
            response.setMessage(RequestStatus.SUCCESS.getStatus());
        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getEncryptedValue - Static - failure [request: {}; response: {}]", qrCodePaymentRequest, response);
        } else {
            log.debug("Service getEncryptedValue - Static [request: {}; response: {}]", qrCodePaymentRequest, response);
        }
        return response;
    }

    @RequestMapping(value = "get/txn/status" , method = RequestMethod.POST)
    @ResponseBody
    public Response getTxnStatus(final @RequestBody QrCodePaymentRequest _request, HttpServletRequest servletRequest){

        setClientIP(_request,servletRequest);
        ServiceContext serviceContext = getServiceContext(_request,false);
        SymphonyQrCodePayment piPayMerchant = new SymphonyQrCodePayment();
        BeanUtils.copyProperties(_request,piPayMerchant);
        QrCodePaymentResponse response = new QrCodePaymentResponse();

        try {
            SymphonyQrCodePayment result = symphonyQrCodePaymentService.checkTxnStatus(piPayMerchant,serviceContext);
            response.setTransactionId(result.getMerchantTransactionId());
            response.setTransactionStatus(result.getTransactionStatus());
            response.setTransactionType(result.getTransactionType());
            response.setMerchantPgIdentifier(result.getMerchantPgIdentifier());
            response.setChargeTotal(result.getChargeTotal());
            response.setCurrency(result.getCurrency());
            response.setPaymentMethod(result.getPaymentMethod());
            response.setInvoiceNumber(result.getInvoiceNumber());
            response.setOtherInfo(result.getOtherInfo());
            response.setTrxnReferenceNumber(result.getTrxnReferenceNumber());
            response.setMerchantPgConnection(result.getMerchantPgConnection());
            response.setQrScannedStatus(result.getQrScannedStatus());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());
        }catch (InvalidRequestException exception){
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }
        if(RequestStatus.FAILURE.getStatus().equals(response.getStatus())){
            log.warn("Service getTxnStatus - failure [request: {}; response: {}]",_request,response);
        }else {
            log.debug("Service getTxnStatus [request: {}; response: {}]",_request,response);
        }
        return response;
    }


    private void setClientIP(final QrCodePaymentRequest _request,HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}

}