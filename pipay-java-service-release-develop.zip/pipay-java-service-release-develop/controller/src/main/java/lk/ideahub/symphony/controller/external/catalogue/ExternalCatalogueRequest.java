package lk.ideahub.symphony.controller.external.catalogue;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class ExternalCatalogueRequest extends Request{

	private Long customerId;
	private String catalogueGroup;
	private Long externalCatalogueId;
}
