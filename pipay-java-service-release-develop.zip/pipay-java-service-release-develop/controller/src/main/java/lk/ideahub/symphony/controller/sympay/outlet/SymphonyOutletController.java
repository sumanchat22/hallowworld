package lk.ideahub.symphony.controller.sympay.outlet;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.outlet.entity.SymphonyOutlet;
import lk.ideahub.symphony.product.sympay.outlet.service.SymphonyOutletService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by mahesha on 1/2/19.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/outlet", consumes = "application/json", produces = "application/json")
public class SymphonyOutletController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyOutletController.class);

    @Autowired
    private SymphonyOutletService symphonyOutletService;

    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public Response list(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.list(symphonyOutlet, serviceContext);
            response.setNearByOutletList(result.getNearByOutletList());
            response.setRecommendedOutletList(result.getRecommendedOutletList());
            response.setFeaturedOutletList(result.getFeaturedOutletList());
            response.setFilterTagList(result.getFilterTagList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service get outlet list - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service get outlet list - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service get outlet list [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "search/outlet", method = RequestMethod.POST)
    @ResponseBody
    public Response searchOutlet(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);
        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);
        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.searchOutlet(symphonyOutlet, serviceContext);
            response.setOutletList(result.getOutletList());
            response.setOutletCount(result.getOutletCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service search nearby outlets - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service search nearby outlets - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service search nearby outlets [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "get/details", method = RequestMethod.POST)
    @ResponseBody
    public Response getOutletDetails(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.getOutletDetails(symphonyOutlet, serviceContext);
            response.setOutlet(result.getOutlet());
            response.setOutletImageList(result.getOutletImageList());
            response.setNearByOutletList(result.getNearByOutletList());
            response.setOutletReviewList(result.getOutletReviewList());
            response.setDealList(result.getDealList());
            response.setUserRate(result.getUserRate());
            response.setCouponPackList(result.getCouponPackList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getPlace - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getPlace - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getPlace [request: {}; response: {}]", request, response);
        }
        return response;

    }


    @RequestMapping(value = "add/review", method = RequestMethod.POST)
    @ResponseBody
    public Response addReview(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.addReview(symphonyOutlet, serviceContext);

            response.setErrorCode(result.getErrorCode());
            response.setOutletReviewList(result.getOutletReviewList());
            response.setUserRate(result.getUserRate());
            response.setOverallRate(result.getOverallRate());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service addReview - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addReview - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service addReview [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "update/review", method = RequestMethod.POST)
    @ResponseBody
    public Response updateReview(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.updateReview(symphonyOutlet, serviceContext);
            response.setOutletReview(result.getOutletReview());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service updateReview - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service updateReview - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service updateReview [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "get/review", method = RequestMethod.POST)
    @ResponseBody
    public Response getReview(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.getReview(symphonyOutlet, serviceContext);
            response.setOutletReviewList(result.getOutletReviewList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getReview - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getReview - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getReview [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "delete/review", method = RequestMethod.POST)
    @ResponseBody
    public Response deleteReview(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.deleteReview(symphonyOutlet, serviceContext);
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service deleteReview - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service deleteReview - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service deleteReview [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "add/rate", method = RequestMethod.POST)
    @ResponseBody
    public Response addRate(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, false);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.addRate(symphonyOutlet, serviceContext);
            response.setOutletReview(result.getOutletReview());
            response.setOverallRate(result.getOverallRate());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service addRate - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addRate - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service addRate [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "search", method = RequestMethod.POST)
    @ResponseBody
    public Response search(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.searchByAction(symphonyOutlet, serviceContext);
            response.setOutletObjList(result.getOutletObjList());
            response.setMerchantActionGroupList(result.getMerchantActionGroupList());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service search - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service search - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service search [request: {}; response: {}]", request, response);
        }
        return response;

    }

    @RequestMapping(value = "get/summary", method = RequestMethod.POST)
    @ResponseBody
    public Response getOutletSummaryDetails(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {

        setClientIP(request, servletRequest);
        ServiceContext serviceContext = getServiceContext(request, true);

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);

        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.getOutletSummaryDetails(symphonyOutlet, serviceContext);
            response.setOutletSummaryDto(result.getOutletSummaryDto());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service getOutletSummaryDetails - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service getOutletSummaryDetails - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service getOutletSummaryDetails [request: {}; response: {}]", request, response);
        }
        return response;

    }

    // Modify 2020.9.3 - Coupon redeemable location
    @RequestMapping(value = "redeem/coupon", method = RequestMethod.POST)
    @ResponseBody
    public Response findNearestRedeemableOutlets(final @RequestBody SymphonyOutletRequest request, HttpServletRequest servletRequest) {
        setClientIP(request, servletRequest);
        ServiceContext serviceContext;

        if(StringUtils.isNotBlank(request.getSearchType()) && request.getSearchType().equalsIgnoreCase(Constants.SEARCH_ALL)) {
            serviceContext = getServiceContext(request, false);
        } else {
            // prevent load all, so set pageEnd to 5
            if(request.getPageEnd() == null) {
                request.setPageEnd(5);
            }
            serviceContext = getServiceContext(request, true);
        }

        SymphonyOutlet symphonyOutlet = new SymphonyOutlet();
        BeanUtils.copyProperties(request, symphonyOutlet);
        SymphonyOutletResponse response = new SymphonyOutletResponse();

        try {
            SymphonyOutlet result = symphonyOutletService.findNearestRedeemableOutlets(symphonyOutlet, serviceContext);
            response.setOutletList(result.getOutletList());
            response.setOutletCount(result.getOutletCount());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (Exception exception) {
            log.error("Service find redeemable outlets - failure . exception : {}", exception);
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());
        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service find redeemable outlets - failure [request: {}; response: {}]", request, response);
        } else {
            log.debug("Service find redeemable outlets [request: {}; response: {}]", request, response);
        }
        return response;

    }

    private void setClientIP(final SymphonyOutletRequest request, HttpServletRequest servletRequest) {
        String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        request.setClientIp(clientIp);
    }
}
