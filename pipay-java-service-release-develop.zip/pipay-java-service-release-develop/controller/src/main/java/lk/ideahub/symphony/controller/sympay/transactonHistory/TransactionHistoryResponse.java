package lk.ideahub.symphony.controller.sympay.transactonHistory;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.product.sympay.transactionHistory.entity.Transactions;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString
public class TransactionHistoryResponse extends Response{

    private String status;
    private String message;
    private List<Transactions>  transactionsList;
}
