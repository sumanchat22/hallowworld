package lk.ideahub.symphony.controller.report;

import lk.ideahub.symphony.controller.common.Request;
import lk.ideahub.symphony.modules.common.Constants;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * Created by Anil on 6/26/19.
 */
@Getter
@Setter
@ToString
public class ReportRequest extends Request {

    //coupon Status
    private String couponName;
    private Long couponTypeId;
    private String merchantName;
    private String outletName;
    private Long couponStatusId;
    private String reportFile;

    //coupon Status & Claimed
    private Long couponPackId;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = Constants.TIME_ZONE)
    private Date transactionFromDate;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = Constants.TIME_ZONE)
    private Date transactionToDate;

    //coupon claimed
    private String currencyId;
    private String customerPhoneNum;

    private String reportCode;

    //coupon burnt
    private Long couponId;
    private Long merchantId;

    //coupon transaction inquiry
    private Long couponTransactionId;
    private Long couponTransactionStatusId;
    private String couponStockTrickingId;
    private String externalTxnReferenceId;
    private Long ownerMerchantId;
    private Long redemptionMerchant;
    private Long RedemptionOutlet;
    private Long RedemptionDevice;

    private String couponClaimMethod;
    private String fileType;
    private String rewardsTransactionId;
    private Long sourceTypeId;

    private Long externalReferenceMerchant;
    private Long externalReferenceOutlet;

}
