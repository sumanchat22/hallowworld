package lk.ideahub.symphony.controller.sympay.freeZone;

import lk.ideahub.symphony.controller.common.Response;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by Madhukara on 4/9/18.
 */
@ToString
@Setter
@Getter
public class FreeZoneResponse extends Response {

    private Boolean redeemSuccess;
    private String status;
    private String code;
    private String message;
}
