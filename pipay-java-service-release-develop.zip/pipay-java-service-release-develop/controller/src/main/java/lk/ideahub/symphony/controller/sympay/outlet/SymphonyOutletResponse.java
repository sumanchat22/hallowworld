package lk.ideahub.symphony.controller.sympay.outlet;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.deal.entity.Deal;
import lk.ideahub.symphony.modules.experienceCard.entity.FilterTag;
import lk.ideahub.symphony.modules.loyalty.entity.coupon.CouponPack;
import lk.ideahub.symphony.modules.outlet.entity.Outlet;
import lk.ideahub.symphony.modules.outlet.entity.OutletImage;
import lk.ideahub.symphony.modules.outlet.entity.OutletReview;
import lk.ideahub.symphony.modules.types.entity.MerchantActionGroup;
import lk.ideahub.symphony.product.sympay.deal.entity.DealDto;
import lk.ideahub.symphony.product.sympay.outlet.entity.OutletDto;
import lk.ideahub.symphony.product.sympay.outlet.entity.OutletObj;
import lk.ideahub.symphony.product.sympay.outlet.entity.OutletSummaryDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by mahesha on 1/2/19.
 */
@Getter
@Setter
@ToString
public class SymphonyOutletResponse extends Response {

    //get outlet detail
    private Outlet outlet;

    private OutletReview outletReview;
    private List<OutletReview> outletReviewList;
    private BigDecimal overallRate;



    // get outlet list
    private List<OutletDto> nearByOutletList;
    private List<OutletDto> recommendedOutletList;
    private List<OutletDto> featuredOutletList;
    private List<FilterTag> filterTagList;

    //search outlet
    private List<OutletDto> outletList;
    private List<OutletImage> outletImageList;

    //get nearby deals
    private List<DealDto> dealList;

    //get outlet by action
    private List<OutletObj> outletObjList;
    private List<MerchantActionGroup> merchantActionGroupList;

    private Long outletCount;
    private BigDecimal userRate;

    private List<CouponPack> couponPackList;

    private OutletSummaryDto outletSummaryDto;

    private String status;
    private String message;
}
