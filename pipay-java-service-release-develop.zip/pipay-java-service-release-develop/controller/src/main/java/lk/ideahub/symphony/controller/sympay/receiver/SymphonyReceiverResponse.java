package lk.ideahub.symphony.controller.sympay.receiver;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.merchant.entity.MerchantCategory;
import lk.ideahub.symphony.modules.receiver.entity.CustomerMerchantProfile;
import lk.ideahub.symphony.modules.receiver.entity.MerchantBusinessType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by mahesha on 12/3/18.
 */
@Getter
@Setter
@ToString
public class SymphonyReceiverResponse extends Response {

    //list business type
    private List<MerchantBusinessType> merchantBusinessTypeList;

    //add customer merchant profile
    private CustomerMerchantProfile customerMerchantProfile;

    //get business profile
    private List<CustomerMerchantProfile> customerMerchantProfileList;
    private String mainImageFolderPath;
    private String thumbnailImageFolderPath;

    //encryption
    private String qrEncryptedText;

    //get merchant types
    private List<MerchantCategory> merchantCategoryList;

    private String status;
    private String message;
}
