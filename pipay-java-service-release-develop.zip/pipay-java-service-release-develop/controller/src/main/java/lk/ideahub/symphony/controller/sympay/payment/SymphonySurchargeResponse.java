package lk.ideahub.symphony.controller.sympay.payment;

import lk.ideahub.symphony.controller.common.Response;
import java.math.BigDecimal;

/**
 * Created by Madhukara on 12/7/17.
 */
public class SymphonySurchargeResponse extends Response {

    private BigDecimal netAmount;
    private BigDecimal customerSurchargeAmount;
    private BigDecimal customerSurchargePercentage;
    private BigDecimal grossAmount;

    // status
    private String status;
    private String message;

    public BigDecimal getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(BigDecimal netAmount) {
        this.netAmount = netAmount;
    }

    public BigDecimal getCustomerSurchargeAmount() {
        return customerSurchargeAmount;
    }

    public void setCustomerSurchargeAmount(BigDecimal customerSurchargeAmount) {
        this.customerSurchargeAmount = customerSurchargeAmount;
    }

    public BigDecimal getCustomerSurchargePercentage() {
        return customerSurchargePercentage;
    }

    public void setCustomerSurchargePercentage(BigDecimal customerSurchargePercentage) {
        this.customerSurchargePercentage = customerSurchargePercentage;
    }

    public BigDecimal getGrossAmount() {
        return grossAmount;
    }

    public void setGrossAmount(BigDecimal grossAmount) {
        this.grossAmount = grossAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        return new StringBuilder("SymphonySurchargeResponse {")
                .append("netAmount=").append(netAmount).append(", ")
                .append("customerSurchargeAmount=").append(customerSurchargeAmount).append(", ")
                .append("customerSurchargePercentage=").append(customerSurchargePercentage).append(", ")
                .append("grossAmount=").append(grossAmount).append(", ")
                .append("status='").append(status).append("'").append(", ")
                .append("message='").append(message).append("'")
                .append('}').toString();
    }
}
