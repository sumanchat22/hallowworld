package lk.ideahub.symphony.controller.sympay.merchant;

import java.math.BigDecimal;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by samith on 12/20/15.
 */
@Getter
@Setter
public class SymphonyMerchantRequest extends Request {

    //common
    private Long merchantId;
    private Long merchantPgConnectionId;
    private Long userId;
    private String email;
    private Long merchantTransactionId;

    private String merchantPgIdentifier;
    private BigDecimal chargeTotal;
    private String currency;
    private String paymentMethod;
    private Long orderId;
    private String invoiceNumber;
    private String successUrl;
    private String errorUrl;
    private String transactionType;
    private Long timeOut;
    private String storeName;
    //Format(yyyy-MM-dd HH:mm:ss)
    private String transactionDateTime;
    private String token;
    private String language;
    private String paymentReference;
    private String itemList;
    private String otherInfo;
    private String merchantCustomerPhone;
    private String merchantCustomerEmail;

    private String merchantTxnStatusName;
    private String sessionToken;

    private String password;

    //otc init
    private String msisdn;

    private String disableWebCheckoutQr;
    private String disableWebCheckoutGuest;
    private String disableWebCheckoutSignIn;
    //Instant discount only
    private Long paymentOptionIssuersId;
    private String discountCode;

    //validate discount
    private String cardIdentifier;

    //Advanced discount only
    private Long merchantDiscountId;

    private String discountType;

    //get bank list
    private Long customerId;

    @Override
    public String toString() {
        return new StringBuilder("SymphonyMerchantRequest {")
                .append("merchantId=").append(merchantId).append(", ")
                .append("merchantPgConnectionId=").append(merchantPgConnectionId).append(", ")
                .append("userId=").append(userId).append(", ")
                .append("email='").append(email).append("'").append(", ")
                .append("merchantTransactionId=").append(merchantTransactionId).append(", ")
                .append("merchantPgIdentifier='").append(merchantPgIdentifier).append("'").append(", ")
                .append("chargeTotal=").append(chargeTotal).append(", ")
                .append("currency='").append(currency).append("'").append(", ")
                .append("paymentMethod='").append(paymentMethod).append("'").append(", ")
                .append("orderId=").append(orderId).append(", ")
                .append("invoiceNumber='").append(invoiceNumber).append("'").append(", ")
                .append("successUrl='").append(successUrl).append("'").append(", ")
                .append("errorUrl='").append(errorUrl).append("'").append(", ")
                .append("transactionType='").append(transactionType).append("'").append(", ")
                .append("timeout=").append(timeOut).append(", ")
                .append("storeName='").append(storeName).append("'").append(", ")
                .append("transactionDateTime='").append(transactionDateTime).append("'").append(", ")
                .append("token='").append(token).append("'").append(", ")
                .append("language='").append(language).append("'").append(", ")
                .append("paymentReference='").append(paymentReference).append("'").append(", ")
                .append("itemList='").append(itemList).append("'").append(", ")
                .append("otherInfo='").append(otherInfo).append("'").append(", ")
                .append("merchantCustomerPhone='").append(merchantCustomerPhone).append("'").append(", ")
                .append("merchantCustomerEmail='").append(merchantCustomerEmail).append("'").append(", ")
                .append("merchantTxnStatusName='").append(merchantTxnStatusName).append("'").append(", ")
                .append("sessionToken='").append(sessionToken).append("'").append(", ")
                .append("password='").append(password).append("'").append(", ")
                .append("msisdn='").append(msisdn).append("'").append(", ")
                .append("disableWebCheckoutQr='").append(disableWebCheckoutQr).append("'").append(", ")
                .append("disableWebCheckoutGuest='").append(disableWebCheckoutGuest).append("'").append(", ")
                .append("disableWebCheckoutSignIn='").append(disableWebCheckoutSignIn).append("'").append(", ")
                .append("discountCode='").append(discountCode).append("'").append(", ")
                .append("cardIdentifier='").append(cardIdentifier).append("'")
                .append('}').toString();
    }
}
