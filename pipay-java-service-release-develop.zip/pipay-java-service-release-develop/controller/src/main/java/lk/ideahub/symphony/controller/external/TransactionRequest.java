package lk.ideahub.symphony.controller.external;

import java.math.BigDecimal;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Lahiru Madushan
 *
 */
@Getter
@Setter
@ToString
public class TransactionRequest extends Request{

	private String phoneNo;
	private String transactionRefId;
	private BigDecimal originalAmount;
	private String currency;
	private String externalTrxRefId;
	private Long deviceId;
	private Boolean isV1Call;
	private BigDecimal discountedAmount;
	private String discountValueType;
	private Long couponId;
	private String qrType;
	private String transactionDateTime;
	private String initiateType;
	private String transactionType;
	private Long agentId;//merchantId
	private Long userId;//outletId
	private String externalBillerId;
	
	//MDR data
	private BigDecimal fixedRate;
	private BigDecimal percentageRate;
	private BigDecimal minAmount;
	private BigDecimal maxAmount;
	private BigDecimal calculatedCommissionValue;
	private BigDecimal pointCommissionValue;
}
