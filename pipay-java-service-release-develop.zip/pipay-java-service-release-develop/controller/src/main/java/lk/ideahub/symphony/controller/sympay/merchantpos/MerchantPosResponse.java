package lk.ideahub.symphony.controller.sympay.merchantpos;

import java.math.BigDecimal;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.counter.entity.OutletCounter;
import lk.ideahub.symphony.modules.merchant.entity.Merchant;
import lk.ideahub.symphony.modules.outlet.entity.Outlet;
import lk.ideahub.symphony.product.sympay.merchantpos.entity.MerchantPosTransactionData;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class MerchantPosResponse extends Response {

    // status
	private String jwtToken;
    private String status;
    private String message;
    private OutletCounter outletCounter;
    private Outlet outlet;
    private Merchant merchant;
    private MerchantPosTransactionData merchantPosTransactionData;
    private String privateKey;
    
    //loyalty
    private BigDecimal noOfPoints;
    private BigDecimal pointCashValue;
    private BigDecimal discountAmount;
    private String discountType;

    //change language pos
    private String language;
}
