package lk.ideahub.symphony.controller.sympay.device;

import javax.servlet.http.HttpServletRequest;

import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.product.sympay.device.entity.SymphonyDevice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import lk.ideahub.symphony.controller.common.GenericController;
import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.controller.common.ServletRequestUtil;
import lk.ideahub.symphony.modules.common.InvalidRequestException;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.device.service.SymphonyDeviceService;
/**
 * Created by samith on 6/7/16.
 */
@Controller
@RequestMapping(value = Constants.SYSTEM_NAME + "/device", consumes = "application/json", produces = "application/json")
public class SymphonyDeviceController extends GenericController {

    private static final Logger log = LoggerFactory.getLogger(SymphonyDeviceController.class);

    @Autowired
    SymphonyDeviceService symphonyDeviceService;

    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public Response addDevice(final @RequestBody SymphonyDeviceRequest _request, HttpServletRequest servletRequest) {

    	setClientIP(_request, servletRequest);
        ServiceContext serviceContext = getServiceContext(_request, false);

        SymphonyDevice symphonyDevice = new SymphonyDevice();
        BeanUtils.copyProperties(_request, symphonyDevice);

        SymphonyDeviceResponse response = new SymphonyDeviceResponse();
        try {
            SymphonyDevice result = symphonyDeviceService.addDevice(symphonyDevice, serviceContext);

            response.setErrorCode(result.getErrorCode());
            response.setStatus(result.getStatus());
            response.setMessage(result.getMessage());

        } catch (InvalidRequestException exception) {
            response.setStatus(RequestStatus.FAILURE.getStatus());
            response.setMessage(exception.getMessage());

        }

        if (RequestStatus.FAILURE.getStatus().equals(response.getStatus())) {
            log.warn("Service addDevice - failure [request: {}; response: {}]", _request, response);
        } else {
            log.debug("Service addDevice [request: {}; response: {}]", _request, response);
        }
        return response;
    }
    
    private void setClientIP(final SymphonyDeviceRequest _request, HttpServletRequest servletRequest) {
		String clientIp = ServletRequestUtil.getClientIP(servletRequest);
        _request.setClientIp(clientIp);
	}

}
