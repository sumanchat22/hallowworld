package lk.ideahub.symphony.controller.catalogue.geofence;

import java.math.BigDecimal;

import lk.ideahub.symphony.controller.common.Request;

/**
 * Created by samith on 8/13/15.
 */
public class CatalogueGeofenceRequest extends Request {

    private String phone;

    private BigDecimal latitude;
    private BigDecimal longitude;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CatalogueGeofenceRequest{");
        sb.append("phone='").append(phone).append('\'');
        sb.append(", latitude=").append(latitude);
        sb.append(", longitude=").append(longitude);
        sb.append('}');
        return sb.toString();
    }
}
