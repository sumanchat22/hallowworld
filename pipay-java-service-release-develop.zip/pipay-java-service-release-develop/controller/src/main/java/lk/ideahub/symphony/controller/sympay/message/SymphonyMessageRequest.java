package lk.ideahub.symphony.controller.sympay.message;

import lk.ideahub.symphony.controller.common.Request;

import java.util.ArrayList;

/**
 * Created by samith on 2/15/16.
 */
public class SymphonyMessageRequest extends Request {

    private ArrayList<Long> customerIdList;
    private ArrayList<Long> adminIdList;
    private String emailTypeCode;
    private String message;
    private ArrayList<String> transactionRefList;
    private String adminUrl;

    //update transaction
    private Long customerId;
    private String transactionReference;

    public ArrayList<Long> getCustomerIdList() {
        return customerIdList;
    }

    public void setCustomerIdList(ArrayList<Long> customerIdList) {
        this.customerIdList = customerIdList;
    }

    public ArrayList<Long> getAdminIdList() {
        return adminIdList;
    }

    public void setAdminIdList(ArrayList<Long> adminIdList) {
        this.adminIdList = adminIdList;
    }

    public String getEmailTypeCode() {
        return emailTypeCode;
    }

    public void setEmailTypeCode(String emailTypeCode) {
        this.emailTypeCode = emailTypeCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<String> getTransactionRefList() {
        return transactionRefList;
    }

    public void setTransactionRefList(ArrayList<String> transactionRefList) {
        this.transactionRefList = transactionRefList;
    }

    public String getAdminUrl() {
        return adminUrl;
    }

    public void setAdminUrl(String adminUrl) {
        this.adminUrl = adminUrl;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getTransactionReference() {
        return transactionReference;
    }

    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SymphonyMessageRequest{");
        sb.append("customerIdList=").append(customerIdList);
        sb.append(", adminIdList=").append(adminIdList);
        sb.append(", emailTypeCode='").append(emailTypeCode).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append(", transactionRefList=").append(transactionRefList);
        sb.append(", adminUrl='").append(adminUrl).append('\'');
        sb.append(", customerId='").append(customerId).append('\'');
        sb.append(", transactionReference='").append(transactionReference).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
