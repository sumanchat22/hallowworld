package lk.ideahub.symphony.controller.sympay.banks;

import lk.ideahub.symphony.controller.common.Response;
import lk.ideahub.symphony.modules.banks.entity.BankIntegrationType;
import lk.ideahub.symphony.modules.banks.entity.Banks;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */

@Getter
@Setter
@ToString
public class SymphonyBanksResponse extends Response {
    private String status;
    private String message;
    private Integer totalBanks;

    // Respond Bank List
    private List<Banks> banksList;

    // Respond Bank List by Integration Type
    private List<BankIntegrationType> bankIntegrationTypeList;
}
