package lk.ideahub.symphony.controller.sympay.external.merchant;

import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Created by Gayan on 03/04/18.
 */
@Getter
@Setter
@ToString
public class SymphonyExternalMerchantRequest extends Request {

    //common
    private Long merchantId;
    private Long merchantPgConnectionId;
    private Long userId;
    private String email;
    private Long merchantTransactionId;

    private String merchantPgIdentifier;
    private BigDecimal chargeTotal;
    private String currency;
    private String paymentMethod;
    private Long orderId;
    private String invoiceNumber;
    private String successUrl;
    private String errorUrl;
    private String transactionType;
    private Long timeout;
    private String storeName;
    //Format(yyyy-MM-dd HH:mm:ss)
    private String transactionDateTime;
    private String token;
    private String language;
    private String paymentReference;
    private String itemList;
    private String otherInfo;
    private String merchantCustomerPhone;
    private String merchantCustomerEmail;

    private String merchantTxnStatusName;
    private String sessionToken;

    private String password;

    //otc init
    private String msisdn;

    private String disableWebCheckoutQr;
    private String disableWebCheckoutGuest;
    private String disableWebCheckoutSignIn;
    //Instant discount only
    private Long paymentOptionIssuersId;
    private String discountCode;

    //validate discount
    private String cardIdentifier;

    //Advanced discount only
    private Long merchantDiscountId;

    private String discountType;

    private String externalMerchantTransactionId;
    private String symphonyTransactionId;
    private String fromDate;
    private String toDate;
    private Long counterId;
    private Long outletId;
    private String symphonyAccountNumber;
    private String description;

}
