package lk.ideahub.symphony.controller.sympay.payment;

import com.fasterxml.jackson.annotation.JsonFormat;
import lk.ideahub.symphony.controller.common.Request;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Created by samith on 11/19/15.
 */
@Getter
@Setter
@ToString
public class SymphonyPaymentRequest extends Request {

    private Long customerId;
    private Long customerPayeeId;
    private Long customerPaymentOptionId;
    private Long merchantId;
    private String merchantPgIdentifier;
    private BigDecimal amount;
    private String PIN;
    private String paymentReference;
    private Long customerPayeeTransactionId;


    //search
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm", timezone = "IST")
    private Date fromDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm", timezone = "IST")
    private Date toDate;
    private String txnReference;
    private BigDecimal fromAmount;
    private BigDecimal toAmount;
    private String amountOperator;
    private String isAscending;

    //session token
    private String sessionToken;

    //otc
    private Long merchantTransactionId;

    //Guest payment - customer details
    private String msisdn;
    private String email;
    
    //Guest payment - card details
 	private String cardNo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM", timezone = "UTC")
    private Date expiryDate;
 	private String cvc;
 	private String nameOnCard;

 	//Qr code payment
 	private String qrType;
 	private String description;

    //AMEX
    private Long customerAmexCardId;

    private String pinType;

    //validate token
    private String uid;
    private String deviceType;
    private String deviceName;

    //multiple biller payment
    private String multipleBillerRefCode;

    private String signature;
}
