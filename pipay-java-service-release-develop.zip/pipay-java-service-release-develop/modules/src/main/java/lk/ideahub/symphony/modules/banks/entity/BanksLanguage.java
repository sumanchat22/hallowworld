package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.types.entity.Language;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

@Entity
@Table(name = "bank_languages")
@Getter
@Setter
@ToString
public class BanksLanguage {
    @Id
    @SequenceGenerator(name="generator", sequenceName="BANK_LANGUAGE_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_languages_id")
    private Long bankLanguagesId;

    @Column(name = "column_key")
    private String columnKey;

    @ManyToOne
    @JoinColumn(name = "language_id")
    private Language language;

    @ManyToOne
    @JoinColumn(name = "bank_id")
    private Banks banks;

    @Column(name = "text")
    private String text;
}
