package lk.ideahub.symphony.modules.casa.repository;


import lk.ideahub.symphony.modules.casa.entity.CargillsCasaDevices;
import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.Customer;

import java.util.List;

public interface CargillsCasaDevicesRepository {

    CargillsCasaDevices get(final Object _CargillsCasaDevicesId, final ServiceContext _serviceContext);

    void add(final CargillsCasaDevices _CargillsCasaDevices, final ServiceContext _serviceContext);

    CargillsCasaDevices update(final CargillsCasaDevices _CargillsCasaDevices, final ServiceContext _serviceContext);

    void delete(final CargillsCasaDevices _CargillsCasaDevices, final ServiceContext _serviceContext);

    List<CargillsCasaDevices> getDevicesListByCustomerCasaAccount(CargillsCustomerCasaAccount cargillsCustomerCasaAccount, ServiceContext _serviceContext);

    CargillsCasaDevices findByDeviceIdAndCustomer(String deviceId, CargillsCustomerCasaAccount cargillsCustomerCasaAccount, ServiceContext _serviceContext);
}
