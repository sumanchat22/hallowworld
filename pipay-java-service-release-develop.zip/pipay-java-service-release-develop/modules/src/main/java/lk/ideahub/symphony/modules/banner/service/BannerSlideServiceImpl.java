package lk.ideahub.symphony.modules.banner.service;

import lk.ideahub.symphony.modules.banner.entity.BannerSlide;
import lk.ideahub.symphony.modules.banner.repository.BannerSlideRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BannerSlideServiceImpl extends GenericService implements BannerSlideService {

    private static final Logger log = LoggerFactory.getLogger(BannerSlideServiceImpl.class);

    @Autowired
    private BannerSlideRepository repository;

    @Override
    public BannerSlide get(final Object _bannerSlideId, final ServiceContext _serviceContext) {
        return repository.get(_bannerSlideId, _serviceContext);
    }

    @Override
    public List<BannerSlide> find(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        return repository.find(_bannerSlide, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        repository.add(_bannerSlide, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        repository.update(_bannerSlide, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        repository.delete(_bannerSlide, _serviceContext);
    }

    @Override
    public List<BannerSlide> findBannerSlide(BannerSlide _bannerSlideFind, ServiceContext _serviceContext)
    {
        List<Object[]> resultList = repository.findBannerSlide(_bannerSlideFind, _serviceContext);

        List<BannerSlide> bannerSlideList = new ArrayList<BannerSlide>(resultList.size());
        if (resultList.size() > 0)
        {
            BannerSlide bannerSlide = null;
            for (Object[] row : resultList) {
                Long bannerSlideId = Long.valueOf(row[0].toString());
                bannerSlide = repository.get(bannerSlideId, _serviceContext);
                if (bannerSlide.getBannerSlideReferenceTypeId() == null)
                {
                    bannerSlide.setBannerSlideReferenceTypeId((long) 0);
                }
                if (bannerSlide.getReferenceId() == null)
                {
                    bannerSlide.setReferenceId((long) 0);
                }

                bannerSlideList.add(bannerSlide);
            }
        }

        return bannerSlideList;
    }

	@Override
	public List<BannerSlide> getBannerSlidesForABanner(Long bannerId) {
		return repository.getBannerSlidesForABanner(bannerId);
	}
}
