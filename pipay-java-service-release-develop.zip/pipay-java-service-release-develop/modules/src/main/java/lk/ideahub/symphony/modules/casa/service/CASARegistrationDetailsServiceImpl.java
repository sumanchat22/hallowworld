package lk.ideahub.symphony.modules.casa.service;

import java.util.List;

import lk.ideahub.symphony.modules.casa.entity.CASARegistrationDetails;
import lk.ideahub.symphony.modules.casa.repository.CASARegistrationDetailsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CASARegistrationDetailsServiceImpl extends GenericService implements CASARegistrationDetailsService {

    private static final Logger log = LoggerFactory.getLogger(CASARegistrationDetailsServiceImpl.class);

    @Autowired
    private CASARegistrationDetailsRepository repository;

    @Override
    public CASARegistrationDetails get(final Object __casaRegistrationDetailsId, final ServiceContext _serviceContext) {
        return repository.get(__casaRegistrationDetailsId, _serviceContext);
    }

    @Override
    public List<CASARegistrationDetails> find(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        return repository.find(__casaRegistrationDetails, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        repository.add(__casaRegistrationDetails, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        repository.update(__casaRegistrationDetails, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        repository.delete(__casaRegistrationDetails, _serviceContext);
    }
}
