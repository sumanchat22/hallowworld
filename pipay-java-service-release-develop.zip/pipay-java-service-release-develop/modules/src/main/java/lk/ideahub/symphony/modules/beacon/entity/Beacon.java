package lk.ideahub.symphony.modules.beacon.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "beacons")
@NamedQueries({
        @NamedQuery(name = "Beacon.find", query = "select b from Beacon b" +
                "  where" +
                "    (:name is null or b.name = :name)")})
@Getter
@Setter
@ToString
public class Beacon extends AbstractEntity {

    // ### ORACLE CHANGE :  ADD SEQUENCE ###
    @Id
    @SequenceGenerator(name = "generator", sequenceName = "BEACONS_BEACON_ID_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "generator")
    @Column(name = "beacon_id")
    private Long beaconId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "model")
    private String model;

    @Column(name = "proximity_uuid")
    private String proximityUuid;

    @Column(name = "major")
    private Integer major;

    @Column(name = "minor")
    private Integer minor;

    @Column(name = "enterprise_id")
    private Long enterpriseId;

    @Column(name = "merchant_id")
    private Long merchantId;

    @Column(name = "outlet_id")
    private Long outletId;

    @Column(name = "device_status_id")
    private Long deviceStatusId;

    @Column(name = "beacon_type_id")
    private Long beaconTypeId;
}
