package lk.ideahub.symphony.modules.commission.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.types.entity.PaymentOptionType;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

/**
 * Created by Anil on 8/10/18.
 */
@Entity
@Table(name = "payment_aggregator_commissions")
@NamedQueries({
        @NamedQuery(name = "PaymentAggregatorCommission.findByPaymentOptionId", query = "select pac from PaymentAggregatorCommission pac " +
                "  where" +
                "    ( pac.paymentOptionType = :paymentOptionType) order by pac.startRange ")})
@Getter
@Setter
public class PaymentAggregatorCommission extends AbstractEntity {

    @Id
    @SequenceGenerator(name = "generator", sequenceName = "PAYMENT_AGGREGATOR_COMMISSION_SEQ", allocationSize = 1)
    @GeneratedValue(generator = "generator")
    @Column(name = "pymnt_aggregator_commission_id")
    private Long paymentAggregatorCommissionId;

    @ManyToOne
    @JoinColumn(name = "payment_option_type_id")
    private PaymentOptionType paymentOptionType;

    @Column(name = "value_type")
    private String valueType;

    @Column(name = "start_range")
    private BigDecimal startRange;

    @Column(name = "end_range")
    private BigDecimal endRange;

    @Column(name = "actual_value")
    private BigDecimal actualValue;

    @Column(name = "tier_value_type")
    private String tierSurchargeType;

    @Override
    public String toString() {
        return new StringBuilder("PaymentAggregatorCommission {")
                .append("paymentAggregatorCommissionId=").append(paymentAggregatorCommissionId).append(", ")
                .append("paymentOptionType=").append(paymentOptionType).append(", ")
                .append("valueType='").append(valueType).append("'").append(", ")
                .append("startRange=").append(startRange).append(", ")
                .append("endRange=").append(endRange).append(", ")
                .append("actualValue=").append(actualValue).append(", ")
                .append("tierSurchargeType='").append(tierSurchargeType).append("'")
                .append('}').toString();
    }
}
