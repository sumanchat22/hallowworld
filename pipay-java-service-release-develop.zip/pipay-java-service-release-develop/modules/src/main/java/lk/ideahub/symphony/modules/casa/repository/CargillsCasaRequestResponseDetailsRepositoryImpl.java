package lk.ideahub.symphony.modules.casa.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.casa.entity.CargillsCasaRequestResponseDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class CargillsCasaRequestResponseDetailsRepositoryImpl extends GenericRepository implements CargillsCasaRequestResponseDetailsRepository {

    private static final Logger log = LoggerFactory.getLogger(CargillsCasaRequestResponseDetailsRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public CargillsCasaRequestResponseDetails get(final Object _CargillsCasaRequestResponseDetailsRepositoryId, final ServiceContext _serviceContext) {
        return entityManager.find(CargillsCasaRequestResponseDetails.class, _CargillsCasaRequestResponseDetailsRepositoryId);
    }

    @Override
    public void add(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetailsRepository, final ServiceContext _serviceContext) {
        _CargillsCasaRequestResponseDetailsRepository.setCreatedDatetime(Calendar.getInstance().getTime());
        _CargillsCasaRequestResponseDetailsRepository.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_CargillsCasaRequestResponseDetailsRepository);
        entityManager.flush();
    }

    @Override
    public CargillsCasaRequestResponseDetails update(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetailsRepository, final ServiceContext _serviceContext) {
        _CargillsCasaRequestResponseDetailsRepository.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_CargillsCasaRequestResponseDetailsRepository);
    }

    @Override
    public void delete(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetailsRepository, final ServiceContext _serviceContext) {
        entityManager.remove(_CargillsCasaRequestResponseDetailsRepository);
    }
}
