package lk.ideahub.symphony.modules.common;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

@MappedSuperclass
@Getter
@Setter
@ToString
public abstract class AbstractEntity {

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "created_datetime")
    private Date createdDatetime;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "modified_datetime")
    private Date modifiedDatetime;

    @Version
    @Column(name = "version")
    private Integer version;
}
