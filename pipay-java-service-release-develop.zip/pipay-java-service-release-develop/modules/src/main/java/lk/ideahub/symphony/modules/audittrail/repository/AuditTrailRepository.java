package lk.ideahub.symphony.modules.audittrail.repository;

import lk.ideahub.symphony.modules.audittrail.entity.AuditTrail;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface AuditTrailRepository {

    void add(final AuditTrail auditTrail, final ServiceContext _serviceContext);

}
