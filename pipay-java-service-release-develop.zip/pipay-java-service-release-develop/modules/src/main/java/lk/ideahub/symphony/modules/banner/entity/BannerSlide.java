package lk.ideahub.symphony.modules.banner.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "banner_slides")
@NamedQueries({
        @NamedQuery(name = "BannerSlide.find", query = "select bs from BannerSlide bs" +
                "  where" +
                "    (:headerTitle is null or bs.headerTitle = :headerTitle)")})
@NamedNativeQueries({
        @NamedNativeQuery(name = "BannerSlide.findBannerSlide", query = "select bs.banner_slide_id, bs.banner_id" +
                " from banner_slides bs " +
                " inner join banners b on b.banner_id = bs.banner_id" +
                " inner join appl_deal_banner_types adbt on adbt.deal_banner_type_id = b.deal_banner_type_id" +
                " where " +
                  " adbt.deal_banner_type_id = :dealBannerTypeId" +
                  " and" +
                  " b.is_active = 'Y'")})

@Cacheable
@Getter
@Setter
@ToString
public class BannerSlide extends AbstractEntity
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "banner_slide_id")
    private Long bannerSlideId;

    /*@Column(name = "banner_id")
    private Long bannerId;*/
    
    @JsonIgnore
	@ManyToOne
    @JoinColumn(name = "banner_id")
    private Banner banner;

    @Column(name = "header_title")
    private String headerTitle;

    @Column(name = "title_description")
    private String titleDescription;

    @Column(name = "description")
    private String description;

    @Column(name = "sequence")
    private Integer sequence;

    @Column(name = "banner_slide_reference_type_id")
    private Long bannerSlideReferenceTypeId;

    @Column(name = "reference_id")
    private Long referenceId;

    @Column(name = "image")
    private String image;


    @Transient
    private Long dealBannerTypeId;

}
