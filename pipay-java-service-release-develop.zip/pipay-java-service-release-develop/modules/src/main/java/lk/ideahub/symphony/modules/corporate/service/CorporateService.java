package lk.ideahub.symphony.modules.corporate.service;

import java.util.List;

import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.corporate.entity.Corporate;

public interface CorporateService {

    Corporate get(final Object _corporateId, final ServiceContext _serviceContext);

    List<Corporate> find(final Corporate _corporate, final ServiceContext _serviceContext);

    void add(final Corporate _corporate, final ServiceContext _serviceContext);

    void update(final Corporate _corporate, final ServiceContext _serviceContext);

    void delete(final Corporate _corporate, final ServiceContext _serviceContext);
}
