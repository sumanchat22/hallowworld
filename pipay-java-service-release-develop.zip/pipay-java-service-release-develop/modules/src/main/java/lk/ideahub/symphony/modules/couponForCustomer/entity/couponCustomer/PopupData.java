package lk.ideahub.symphony.modules.couponForCustomer.entity.couponCustomer;


import com.fasterxml.jackson.annotation.*;

public class PopupData {
    public String id;
    public String type;
    public String url;
    public Double ratio;
    public String href;
    public String text;
    public Margin margin;
    public Style style;

    @JsonProperty("id")
    public String getID() { return id; }
    @JsonProperty("id")
    public void setID(String value) { this.id = value; }

    @JsonProperty("type")
    public String getType() { return type; }
    @JsonProperty("type")
    public void setType(String value) { this.type = value; }

    @JsonProperty("url")
    public String getURL() { return url; }
    @JsonProperty("url")
    public void setURL(String value) { this.url = value; }

    @JsonProperty("ratio")
    public Double getRatio() { return ratio; }
    @JsonProperty("ratio")
    public void setRatio(Double value) { this.ratio = value; }

    @JsonProperty("href")
    public String getHref() { return href; }
    @JsonProperty("href")
    public void setHref(String value) { this.href = value; }

    @JsonProperty("text")
    public String getText() { return text; }
    @JsonProperty("text")
    public void setText(String value) { this.text = value; }

    @JsonProperty("margin")
    public Margin getMargin() { return margin; }
    @JsonProperty("margin")
    public void setMargin(Margin value) { this.margin = value; }

    @JsonProperty("style")
    public Style getStyle() { return style; }
    @JsonProperty("style")
    public void setStyle(Style value) { this.style = value; }
}