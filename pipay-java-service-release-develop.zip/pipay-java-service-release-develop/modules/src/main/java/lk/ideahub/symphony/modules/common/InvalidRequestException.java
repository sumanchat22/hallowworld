package lk.ideahub.symphony.modules.common;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InvalidRequestException extends RuntimeException {

    private String status;
    private String code;
    private String message;

    public InvalidRequestException() {
        super();
    }

    public InvalidRequestException(String message) {
        super(message);
        this.message = message;
    }

    public InvalidRequestException(String errcode, String errmsg) {
        super(errmsg);
        this.setStatus(RequestStatus.FAILURE.getStatus());
        this.code = errcode;
        this.message = errmsg;
    }
}
