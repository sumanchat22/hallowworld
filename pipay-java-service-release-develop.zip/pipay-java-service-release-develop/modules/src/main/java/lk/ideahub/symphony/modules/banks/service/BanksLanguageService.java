package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.BanksLanguage;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

public interface BanksLanguageService {
    BanksLanguage get(final Object banksLanguageId, final ServiceContext serviceContext);

    List<BanksLanguage> find(final BanksLanguage banksLanguage, final ServiceContext serviceContext);

    void add(final BanksLanguage banksLanguage, final ServiceContext serviceContext);

    void update(final BanksLanguage banksLanguage, final ServiceContext serviceContext);

    void delete(final BanksLanguage banksLanguage, final ServiceContext serviceContext);

    List<BanksLanguage> getText(final BanksLanguage banksLanguage);
}
