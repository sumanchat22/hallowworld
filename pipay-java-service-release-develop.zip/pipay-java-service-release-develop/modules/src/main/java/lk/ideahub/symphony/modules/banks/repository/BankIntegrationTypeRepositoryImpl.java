package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BankIntegrationType;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 16-Dec-2021
 */

@Repository
public class BankIntegrationTypeRepositoryImpl extends GenericRepository implements BankIntegrationTypeRepository {
    private static final Logger log = LoggerFactory.getLogger(BankIntegrationTypeRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public BankIntegrationType get(final Object bankIntegrationTypeId, final ServiceContext serviceContext) {
        return entityManager.find(BankIntegrationType.class, bankIntegrationTypeId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<BankIntegrationType> find(final BankIntegrationType bankIntegrationTypeId, final ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(BankIntegrationType.class);
        return criteria.list();
    }

    @Override
    public void add(final BankIntegrationType bankIntegrationTypeId, final ServiceContext serviceContext) {
        entityManager.persist(bankIntegrationTypeId);
        entityManager.flush();
    }

    @Override
    public BankIntegrationType update(final BankIntegrationType bankIntegrationTypeId, final ServiceContext serviceContext) {
        return entityManager.merge(bankIntegrationTypeId);
    }

    @Override
    public void delete(final BankIntegrationType bankIntegrationTypeId, final ServiceContext serviceContext) {
        entityManager.remove(bankIntegrationTypeId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<BankIntegrationType> getBankIntegrationTypeList(BankIntegrationType bankIntegrationType, ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(BankIntegrationType.class,"bnit");

        criteria.addOrder(Order.asc("bnit.sequence"));
        if (serviceContext != null && serviceContext.isPageable()) {
            criteria.setFirstResult(serviceContext.getPageStart());
            if (serviceContext.getPageSize() != null) {
                criteria.setMaxResults(serviceContext.getPageSize()-1);
            }
        }

        return criteria.list();
    }
}
