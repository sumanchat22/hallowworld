package lk.ideahub.symphony.modules.banner.service;

import lk.ideahub.symphony.modules.banner.entity.DealBannerType;
import lk.ideahub.symphony.modules.banner.repository.DealBannerTypeRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class DealBannerTypeServiceImpl extends GenericService implements DealBannerTypeService {

    private static final Logger log = LoggerFactory.getLogger(DealBannerTypeServiceImpl.class);

    @Autowired
    private DealBannerTypeRepository repository;

    @Override
    public DealBannerType get(final Object _dealBannerTypeId, final ServiceContext _serviceContext) {
        return repository.get(_dealBannerTypeId, _serviceContext);
    }

    @Override
    public List<DealBannerType> find(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        return repository.find(_dealBannerType, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        repository.add(_dealBannerType, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        repository.update(_dealBannerType, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        repository.delete(_dealBannerType, _serviceContext);
    }
}
