package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BankUserWhiteList;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 06-Jan-2022
 */

@Repository
public class BankUserWhiteListRepositoryImpl extends GenericRepository implements BankUserWhiteListRepository {
    private static final Logger log = LoggerFactory.getLogger(BankUserWhiteListRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> getUserWhiteListByBankId(final Object banksId, final Object bankStatusId, final ServiceContext serviceContext) {
        Query query = entityManager.createNamedQuery("BankUserWhiteList.getUserWhiteListByBankId");

        query.setParameter("banksId", banksId);
        query.setParameter("bankStatusId", bankStatusId);

        handlePagination(query, serviceContext);

        return query.getResultList();
    }
}
