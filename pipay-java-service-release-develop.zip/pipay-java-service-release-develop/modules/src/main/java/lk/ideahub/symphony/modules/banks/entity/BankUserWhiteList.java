package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.customer.entity.CustomerGroup;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 13-Dec-2021
 */

@Entity
@Table(name = "bank_user_whitelist")
@NamedQueries({
        @NamedQuery(name = "BankUserWhiteList.find", query = "select uwl from BankUserWhiteList uwl" +
                "  where" +
                "    (:bankUserWhitelistId is null or uwl.bankUserWhitelistId = :bankUserWhitelistId)")})
@NamedNativeQueries({
        @NamedNativeQuery(name = "BankUserWhiteList.getUserWhiteListByBankId", query = "select cgc.customer_id from bank_user_whitelist buw" +
                " left join banks b on b.bank_id = buw.bank_id" +
                " left join customer_groups cg on cg.customer_group_id = buw.customer_group_id" +
                " left join customer_group_customers cgc on cgc.customer_group_id = cg.customer_group_id" +
                " where" +
                " (buw.bank_id = :banksId)" +
                " and "+
                " (b.bank_status_id = :bankStatusId)")
})

@Getter
@Setter
@ToString
public class BankUserWhiteList {
    @Id
    @SequenceGenerator(name="generator", sequenceName="BANK_USER_WHITELIST_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_user_whitelist_id")
    private Long bankUserWhitelistId;

    @Column(name = "bank_id")
    private String banksId;
    
}
