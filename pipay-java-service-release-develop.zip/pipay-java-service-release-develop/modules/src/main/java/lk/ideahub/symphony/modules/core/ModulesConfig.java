package lk.ideahub.symphony.modules.core;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.jolbox.bonecp.BoneCPDataSource;
import lk.ideahub.symphony.product.sympay.common.ChargingGatewayServiceProxy;
import lk.ideahub.symphony.product.sympay.common.SampathIpgProxy;
import net.sf.ehcache.Cache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.*;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResourceLoader;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import redis.clients.jedis.JedisPoolConfig;

import javax.persistence.SharedCacheMode;
import java.util.Properties;

@EnableAsync
@Configuration
@EnableCaching
@EnableAspectJAutoProxy
@ComponentScan(basePackages = {"lk.ideahub.symphony.security","lk.ideahub.symphony.modules", "lk.ideahub.symphony.product"})
@EnableTransactionManagement
@PropertySources(value = {@PropertySource(value = {"classpath:modules.properties","file:${user.home}/.symphony/modules.properties"})})
public class ModulesConfig {

    private static final Logger log = LoggerFactory.getLogger(ModulesConfig.class);

    @Autowired
    private Environment environment;

    @Autowired
    private MailSenderFactory mailSenderFactory;

    @Bean(destroyMethod = "close")
    public BoneCPDataSource getDataSource() {

        BoneCPDataSource dataSource = new BoneCPDataSource();
        dataSource.setDriverClass(environment.getProperty("database.driver"));
        dataSource.setJdbcUrl(environment.getProperty("database.url"));
        dataSource.setUsername(environment.getProperty("database.username"));
        dataSource.setPassword(environment.getProperty("database.password"));
        dataSource.setConnectionTestStatement(environment.getProperty("database.conTestStatement"));
        dataSource.setIdleConnectionTestPeriodInMinutes(Integer.parseInt(environment.getProperty("database.idleConTestPeriodInMinutes")));
        dataSource.setMaxConnectionsPerPartition(Integer.parseInt(environment.getProperty("hibernate.max.con.for.partition")));
        dataSource.setMinConnectionsPerPartition(Integer.parseInt(environment.getProperty("hibernate.min.con.for.partition")));
        dataSource.setPartitionCount(Integer.parseInt(environment.getProperty("hibernate.partition.count")));
        dataSource.setAcquireIncrement(Integer.parseInt(environment.getProperty("hibernate.acquirer.increment")));
        dataSource.setStatementsCacheSize(Integer.parseInt(environment.getProperty("hibernate.statement.cache.size")));

        return dataSource;
    }

    @Bean(destroyMethod = "close")
    public BoneCPDataSource getDataSource2() {
        BoneCPDataSource dataSource = new BoneCPDataSource();
        dataSource.setDriverClass(environment.getProperty("database.driver"));
        dataSource.setJdbcUrl(environment.getProperty("database.url.2"));
        dataSource.setUsername(environment.getProperty("database.username.2"));
        dataSource.setPassword(environment.getProperty("database.password.2"));
        dataSource.setConnectionTestStatement(environment.getProperty("database.conTestStatement"));
        dataSource.setIdleConnectionTestPeriodInMinutes(Integer.parseInt(environment.getProperty("database.idleConTestPeriodInMinutes.secDB")));
        dataSource.setMaxConnectionsPerPartition(Integer.parseInt(environment.getProperty("hibernate.max.con.for.partition")));
        dataSource.setMinConnectionsPerPartition(Integer.parseInt(environment.getProperty("hibernate.min.con.for.partition")));
        dataSource.setPartitionCount(Integer.parseInt(environment.getProperty("hibernate.partition.count")));
        dataSource.setAcquireIncrement(Integer.parseInt(environment.getProperty("hibernate.acquirer.increment")));
        dataSource.setStatementsCacheSize(Integer.parseInt(environment.getProperty("hibernate.statement.cache.size")));

        return dataSource;
    }

    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        // ### ORACLE CHANGE :  CONFIGURATION ###
        Properties jpaProperties = new Properties();
        //jpaProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        jpaProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
        jpaProperties.setProperty("hibernate.showSql", environment.getProperty("hibernate.showSql"));
        jpaProperties.setProperty("hibernate.jdbc.batch_size", environment.getProperty("hibernate.jdbc.batch.size"));
        //jpaProperties.setProperty("hibernate.globally_quoted_identifiers", "true");
        //jpaProperties.setProperty("spring.jpa.properties.hibernate.globally_quoted_identifiers", "true");

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(getDataSource());
        em.setPersistenceUnitName("entityManagerFactory");
        em.setPackagesToScan("lk.ideahub.symphony.modules", "lk.ideahub.symphony.product");
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(jpaProperties);
        em.setSharedCacheMode(SharedCacheMode.ENABLE_SELECTIVE);

        return em;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory2() {
        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();

        Properties jpaProperties = new Properties();
        //jpaProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        jpaProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
        jpaProperties.setProperty("hibernate.showSql", environment.getProperty("hibernate.showSql"));
        //jpaProperties.setProperty("hibernate.globally_quoted_identifiers", "true");

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(getDataSource2());
        em.setPersistenceUnitName("entityManagerFactory2");
        em.setPackagesToScan("lk.ideahub.symphony.modules", "lk.ideahub.symphony.product");
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(jpaProperties);
        em.setSharedCacheMode(SharedCacheMode.ENABLE_SELECTIVE);

        return em;
    }

    @Bean(name = "transactionManager1")
    @Primary
    public JpaTransactionManager getTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());

        return transactionManager;
    }

    @Bean(name = "transactionManager2")
    public JpaTransactionManager getTransactionManager2() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory2().getObject());

        return transactionManager;
    }

    @Bean
    @Qualifier("VoucherServiceMarshaller")
    public Jaxb2Marshaller getVoucherServiceMarshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(environment.getProperty("voucher.service.marshaller.contextPath"));

        return marshaller;
    }

    @Bean
    @Qualifier("VoucherServiceTemplate")
    public WebServiceTemplate getVoucherServiceTemplate() {
        WebServiceTemplate template = new WebServiceTemplate(getVoucherServiceMarshaller());
        template.setDefaultUri(environment.getProperty("voucher.service.defaultUri"));

        return template;
    }

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:messages");
        messageSource.setDefaultEncoding("UTF-8");

        return messageSource;
    }

	@Bean
	public JavaMailSender javaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		Properties mailProperties = new Properties();

        if (environment.getProperty("mail.smtp.type").equalsIgnoreCase("Gmail")){
            mailSenderFactory.gmailMailSender(mailSender, mailProperties);
        } else if (environment.getProperty("mail.smtp.type").equalsIgnoreCase("External")){
            mailSenderFactory.externalMailSender(mailSender, mailProperties);
        }

		return mailSender;
	}

    @Bean
    public SampathIpgProxy getSampathIpgProxy() {
        SampathIpgProxy sampathIpgProxy = new SampathIpgProxy(environment.getProperty("sampath.ipg.endpoint").trim(),
                environment.getProperty("sampath.ipg.customer.id").trim(),
                environment.getProperty("sampath.ipg.client.id.1").trim(),
                environment.getProperty("sampath.ipg.authtoken").trim(),
                environment.getProperty("sampath.ipg.hmac.secret").trim());

        return sampathIpgProxy;
    }

    @Bean
    public ChargingGatewayServiceProxy getChargingGatewayServiceProxy() {
        ChargingGatewayServiceProxy chargingGatewayServiceProxy = new ChargingGatewayServiceProxy();

        return chargingGatewayServiceProxy;
    }

    @Bean
    @Qualifier("ChargingGatewayServiceMarshaller")
    public Jaxb2Marshaller getChargingGatewayServiceMarshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath(environment.getProperty("cg.service.marshaller.contextPath1"));

        return marshaller;
    }

    @Bean
    @Qualifier("ChargingGatewayServiceTemplate")
    public WebServiceTemplate getChargingGatewayServiceTemplate() {
        WebServiceTemplate template = new WebServiceTemplate(getChargingGatewayServiceMarshaller());
        template.setDefaultUri(environment.getProperty("cg.service.url"));
        template.setMessageSender(getMessageSender());

        return template;
    }

    @Bean
    public HttpComponentsMessageSender getMessageSender() {
        HttpComponentsMessageSender httpComponentsMessageSender = new HttpComponentsMessageSender();
        httpComponentsMessageSender.setConnectionTimeout(Integer.parseInt(environment.getProperty("cg.connection.timeout")));
        httpComponentsMessageSender.setReadTimeout(Integer.parseInt(environment.getProperty("cg.read.timeout")));

        return  httpComponentsMessageSender;
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate(clientHttpRequestFactory());
    }

    private ClientHttpRequestFactory clientHttpRequestFactory() {
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
        factory.setReadTimeout(50000);
        factory.setConnectTimeout(50000);
        return factory;
    }

    @Bean
    public RedisConnectionFactory jedisConnectionFactory() {

        JedisPoolConfig poolConfig = new JedisPoolConfig();
        poolConfig.setMaxTotal(Integer.parseInt(environment.getProperty("redis.max.total")));
        poolConfig.setTestOnBorrow(Boolean.parseBoolean(environment.getProperty("redis.test.on.borrow")));
        poolConfig.setTestOnReturn(Boolean.parseBoolean(environment.getProperty("redis.test.on.return")));
        JedisConnectionFactory ob = new JedisConnectionFactory(poolConfig);
        ob.setUsePool(Boolean.parseBoolean(environment.getProperty("redis.use.pool")));
        ob.setHostName(environment.getProperty("redis.host.url"));
        ob.setPort(Integer.parseInt(environment.getProperty("redis.port")));
        String password = environment.getProperty("redis.password");
        if(password!=null && !password.trim().isEmpty()){
        	ob.setPassword(password);
        }

        return ob;
    }

    @Bean
    public StringRedisTemplate stringRedisTemplate(){
        return new StringRedisTemplate(jedisConnectionFactory());
    }

    @Bean
    public MappingJackson2HttpMessageConverter jsonMessageConverter() {
        return new MappingJackson2HttpMessageConverter();
    }
    
    @Bean
	public org.springframework.cache.CacheManager cacheManager() {
    	org.springframework.cache.CacheManager cacheManager = new EhCacheCacheManager(ehCacheCacheManager().getObject());
		return cacheManager;
	}

    @Bean
    public EhCacheManagerFactoryBean ehCacheCacheManager() {
        org.springframework.cache.ehcache.EhCacheManagerFactoryBean cmfb = new EhCacheManagerFactoryBean();
        String home = System.getProperty("user.home");
        cmfb.setConfigLocation(new FileSystemResourceLoader().getResource("file:"+home+"/.symphony/ehcache.xml"));
        cmfb.setShared(true);
        return cmfb;
    }

	@Bean
    public Cache cacheSecurityKey() {

		net.sf.ehcache.Cache ehCache = null;
		org.springframework.cache.Cache cacheSecurityKey = cacheManager().getCache("cacheSecurityKey");
		 Object nativeCache = cacheSecurityKey.getNativeCache();
	      if (nativeCache instanceof net.sf.ehcache.Cache) {
	    	  ehCache = (net.sf.ehcache.Cache) nativeCache;
	      }

		return ehCache;
	}


    @Bean
    public Cache cacheIdeabiz() {

        net.sf.ehcache.Cache ehCache = null;
        org.springframework.cache.Cache cacheIdeabiz = cacheManager().getCache("cacheIdeabiz");
        Object nativeCache = cacheIdeabiz.getNativeCache();
        if (nativeCache instanceof net.sf.ehcache.Cache) {
            ehCache = (net.sf.ehcache.Cache) nativeCache;
        }

        return ehCache;
    }

	@Bean
    public Cache cacheTemp() {
        net.sf.ehcache.Cache ehCache = null;
		org.springframework.cache.Cache cacheSecurityKey = cacheManager().getCache("cacheTemp");
		 Object nativeCache = cacheSecurityKey.getNativeCache();
	      if (nativeCache instanceof net.sf.ehcache.Cache) {
	    	  ehCache = (net.sf.ehcache.Cache) nativeCache;
	      }

		return ehCache;
    }

    @Bean
    public Cache cacheActive() {
        net.sf.ehcache.Cache ehCache = null;
		org.springframework.cache.Cache cacheSecurityKey = cacheManager().getCache("cacheActive");
		 Object nativeCache = cacheSecurityKey.getNativeCache();
	      if (nativeCache instanceof net.sf.ehcache.Cache) {
	    	  ehCache = (net.sf.ehcache.Cache) nativeCache;
	      }

		return ehCache;
    }

    @Bean
    public Cache cache() {
        net.sf.ehcache.Cache ehCache = null;
		org.springframework.cache.Cache cacheSecurityKey = cacheManager().getCache("cache");
		 Object nativeCache = cacheSecurityKey.getNativeCache();
	      if (nativeCache instanceof net.sf.ehcache.Cache) {
	    	  ehCache = (net.sf.ehcache.Cache) nativeCache;
	      }

		return ehCache;
    }
    
    @Bean
    @Qualifier("amazonSqs")
    public AmazonSQS getsAmazonSQS() {
    	String accesKey = environment.getProperty("aws.sqs.acces.key");
    	String secretKey = environment.getProperty("aws.sqs.secret.key");
    	String region = environment.getProperty("aws.sqs.region");
    	BasicAWSCredentials bAWSc = new BasicAWSCredentials(accesKey,secretKey);
    	AmazonSQS amazonSQS = AmazonSQSClientBuilder.standard()
    			.withCredentials(new AWSStaticCredentialsProvider(bAWSc))
    			.withRegion(region).build();
        return amazonSQS;
    }

    @Bean
    public AmazonS3 amazonS3() {
        String accessKey = environment.getProperty("aws.s3.access.key");
        String secretKey = environment.getProperty("aws.s3.secret.key");
        String region = environment.getProperty("aws.s3.region");
        BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
        AmazonS3 s3Client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(region)
                .build();
        return s3Client;
    }

}