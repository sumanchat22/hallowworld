package lk.ideahub.symphony.modules.casa.service;

import java.util.List;

import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.casa.repository.CargillsCustomerCasaAccountRepository;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import lk.ideahub.symphony.modules.customer.service.CustomerPaymentOptionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CargillsCustomerCasaAccountServiceImpl extends GenericService implements CargillsCustomerCasaAccountService {

    private static final Logger log = LoggerFactory.getLogger(CargillsCustomerCasaAccountServiceImpl.class);

    @Autowired
    private CargillsCustomerCasaAccountRepository repository;

    @Autowired
    private CustomerPaymentOptionService customerPaymentOptionService;

    @Override
    public CargillsCustomerCasaAccount get(final Object _CargillsCustomerCasaAccountServiceId, final ServiceContext _serviceContext) {
        return repository.get(_CargillsCustomerCasaAccountServiceId, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccountService, final ServiceContext _serviceContext) {
        repository.add(_CargillsCustomerCasaAccountService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccountService, final ServiceContext _serviceContext) {
        repository.update(_CargillsCustomerCasaAccountService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccountService, final ServiceContext _serviceContext) {
        repository.delete(_CargillsCustomerCasaAccountService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public CargillsCustomerCasaAccount findByPaymentOptionId(Long paymentOptionId, ServiceContext _serviceContext) {
        CustomerPaymentOption customerPaymentOption = customerPaymentOptionService.get(paymentOptionId,_serviceContext);
        CargillsCustomerCasaAccount casaAccount = repository.findByPaymentOption(customerPaymentOption,_serviceContext);
        return casaAccount;
    }

    @Override
    public CargillsCustomerCasaAccount findByAccountId(String accountId, ServiceContext _serviceContext) {
        CargillsCustomerCasaAccount casaAccount = repository.findByAccountId(accountId,_serviceContext);
        return casaAccount;
    }
}
