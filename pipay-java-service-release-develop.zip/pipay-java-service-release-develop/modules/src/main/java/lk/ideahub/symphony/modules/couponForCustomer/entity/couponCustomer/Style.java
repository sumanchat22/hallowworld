package lk.ideahub.symphony.modules.couponForCustomer.entity.couponCustomer;

import com.fasterxml.jackson.annotation.*;

public class Style {
    private String alignment;
    private long size;
    private String color;
    private String backgroundColor;
    private String weight;
    private long maxWidth;
    private Long cornerRadius;

    @JsonProperty("alignment")
    public String getAlignment() { return alignment; }
    @JsonProperty("alignment")
    public void setAlignment(String value) { this.alignment = value; }

    @JsonProperty("size")
    public long getSize() { return size; }
    @JsonProperty("size")
    public void setSize(long value) { this.size = value; }

    @JsonProperty("color")
    public String getColor() { return color; }
    @JsonProperty("color")
    public void setColor(String value) { this.color = value; }

    @JsonProperty("backgroundColor")
    public String getBackgroundColor() { return backgroundColor; }
    @JsonProperty("backgroundColor")
    public void setBackgroundColor(String value) { this.backgroundColor = value; }

    @JsonProperty("weight")
    public String getWeight() { return weight; }
    @JsonProperty("weight")
    public void setWeight(String value) { this.weight = value; }

    @JsonProperty("maxWidth")
    public long getMaxWidth() { return maxWidth; }
    @JsonProperty("maxWidth")
    public void setMaxWidth(long value) { this.maxWidth = value; }

    @JsonProperty("cornerRadius")
    public Long getCornerRadius() { return cornerRadius; }
    @JsonProperty("cornerRadius")
    public void setCornerRadius(Long value) { this.cornerRadius = value; }
}
