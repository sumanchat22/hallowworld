package lk.ideahub.symphony.modules.beacon.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.beacon.entity.Beacon;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class BeaconRepositoryImpl extends GenericRepository implements BeaconRepository {

    private static final Logger log = LoggerFactory.getLogger(BeaconRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public Beacon get(final Object _beaconId, final ServiceContext _serviceContext) {
        return entityManager.find(Beacon.class, _beaconId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Beacon> find(final Beacon _beacon, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("Beacon.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final Beacon _beacon, final ServiceContext _serviceContext) {
        _beacon.setCreatedDatetime(Calendar.getInstance().getTime());
        _beacon.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_beacon);
        entityManager.flush();
    }

    @Override
    public Beacon update(final Beacon _beacon, final ServiceContext _serviceContext) {
        _beacon.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_beacon);
    }

    @Override
    public void delete(final Beacon _beacon, final ServiceContext _serviceContext) {
        entityManager.remove(_beacon);
    }
}
