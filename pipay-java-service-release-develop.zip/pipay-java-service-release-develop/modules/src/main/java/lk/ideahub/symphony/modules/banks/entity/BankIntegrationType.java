package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.hashtag.entity.ApplicationLink;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */
@Entity
@Table(name = "bank_integration_type")
@Getter
@Setter
@ToString
public class BankIntegrationType {
    @Id
    @SequenceGenerator(name="generator", sequenceName="BANK_INTEGRATION_TYPE_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_integration_type_id")
    private Long bankIntegrationTypeId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "sequence")
    private Long sequence;

    @Column(name = "service_provider_logo")
    private String serviceProviderLogo;

    @Column(name = "service_provider_logo_url")
    private String serviceProviderLogoUrl;

    @Transient
    private List<Banks> banksList;


}
