package lk.ideahub.symphony.modules.amex.repository;

import lk.ideahub.symphony.modules.amex.entity.CustomerAmexCard;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
class CustomerAmexCardRepositoryImpl extends GenericRepository implements CustomerAmexCardRepository {

    private static final Logger log = LoggerFactory.getLogger(CustomerAmexCardRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CustomerAmexCard get(final Object _customerAmexCardId, final ServiceContext _serviceContext) {
        return entityManager.find(CustomerAmexCard.class, _customerAmexCardId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CustomerAmexCard> find(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CustomerAmexCard.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        _customerAmexCard.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        _customerAmexCard.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_customerAmexCard);
        entityManager.flush();
    }

    @Override
    public CustomerAmexCard update(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        _customerAmexCard.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_customerAmexCard);
    }

    @Override
    public void delete(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        entityManager.remove(_customerAmexCard);
    }

    @Override
    public List<Object[]> findByCustomerId(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CustomerAmexCard.findByCustomerId");
        query.setParameter("customerId",_customerAmexCard.getCustomerId());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public List<Object[]> findCard(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CustomerAmexCard.findCard");
        query.setParameter("customerId",_customerAmexCard.getCustomerId());
        query.setParameter("customerPaymentOptionId",_customerAmexCard.getCustomerPaymentOptionId());

        handlePagination(query, _serviceContext);

        return query.getResultList();

    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> findByCustomerPaymentOptionId(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext)
    {
        Query query = entityManager.createNamedQuery("CustomerAmexCard.findByCustomerPaymentOptionId");
        query.setParameter("customerPaymentOptionId",_customerAmexCard.getCustomerPaymentOptionId());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }
}
