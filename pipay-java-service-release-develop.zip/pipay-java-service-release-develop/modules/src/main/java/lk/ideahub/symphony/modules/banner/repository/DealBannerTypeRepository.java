package lk.ideahub.symphony.modules.banner.repository;

import lk.ideahub.symphony.modules.banner.entity.DealBannerType;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface DealBannerTypeRepository {

    DealBannerType get(final Object _dealBannerTypeId, final ServiceContext _serviceContext);

    List<DealBannerType> find(final DealBannerType _dealBannerType, final ServiceContext _serviceContext);

    void add(final DealBannerType _dealBannerType, final ServiceContext _serviceContext);

    DealBannerType update(final DealBannerType _dealBannerType, final ServiceContext _serviceContext);

    void delete(final DealBannerType _dealBannerType, final ServiceContext _serviceContext);
}
