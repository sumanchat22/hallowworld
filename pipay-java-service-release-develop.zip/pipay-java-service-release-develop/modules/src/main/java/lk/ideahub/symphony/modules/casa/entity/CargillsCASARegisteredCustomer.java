package lk.ideahub.symphony.modules.casa.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * Created by Madhukara on 4/6/18.
 */
@Entity
@Table(name = "crg_casa_reg_cus")
@Getter
@Setter
@ToString
public class CargillsCASARegisteredCustomer extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="CRG_CASA_REG_CUS_SQ",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "crg_casa_reg_cus_id")
    private Long cargillsCasaRegisteredCustomerId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "is_signature_created")
    private String isSignatureCreated = "N";

}
