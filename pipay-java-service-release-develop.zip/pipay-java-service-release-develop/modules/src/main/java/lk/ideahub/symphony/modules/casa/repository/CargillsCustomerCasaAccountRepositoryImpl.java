package lk.ideahub.symphony.modules.casa.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class CargillsCustomerCasaAccountRepositoryImpl extends GenericRepository implements CargillsCustomerCasaAccountRepository {

    private static final Logger log = LoggerFactory.getLogger(CargillsCustomerCasaAccountRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public CargillsCustomerCasaAccount get(final Object _CargillsCustomerCasaAccountRepositoryId, final ServiceContext _serviceContext) {
        return entityManager.find(CargillsCustomerCasaAccount.class, _CargillsCustomerCasaAccountRepositoryId);
    }

    @Override
    public void add(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccountRepository, final ServiceContext _serviceContext) {
        _CargillsCustomerCasaAccountRepository.setCreatedDatetime(Calendar.getInstance().getTime());
        _CargillsCustomerCasaAccountRepository.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_CargillsCustomerCasaAccountRepository);
        entityManager.flush();
    }

    @Override
    public CargillsCustomerCasaAccount update(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccountRepository, final ServiceContext _serviceContext) {
        _CargillsCustomerCasaAccountRepository.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_CargillsCustomerCasaAccountRepository);
    }

    @Override
    public void delete(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccountRepository, final ServiceContext _serviceContext) {
        entityManager.remove(_CargillsCustomerCasaAccountRepository);
    }

    @Override
    public CargillsCustomerCasaAccount findByPaymentOption(CustomerPaymentOption customerPaymentOption, ServiceContext _serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(CargillsCustomerCasaAccount.class);
        criteria.add(Restrictions.eq("customerPaymentOption",customerPaymentOption));
        return (CargillsCustomerCasaAccount)criteria.uniqueResult();
    }


    @Override
    public CargillsCustomerCasaAccount findByAccountId(String accountId, ServiceContext _serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(CargillsCustomerCasaAccount.class);
        criteria.add(Restrictions.eq("accountId",accountId));
        criteria.add(Restrictions.eq("isDeleted","N"));
        return (CargillsCustomerCasaAccount)criteria.uniqueResult();
    }
}
