package lk.ideahub.symphony.modules.beacon.repository;

import java.util.List;

import lk.ideahub.symphony.modules.beacon.entity.Beacon;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface BeaconRepository {

    Beacon get(final Object _beaconId, final ServiceContext _serviceContext);

    List<Beacon> find(final Beacon _beacon, final ServiceContext _serviceContext);

    void add(final Beacon _beacon, final ServiceContext _serviceContext);

    Beacon update(final Beacon _beacon, final ServiceContext _serviceContext);

    void delete(final Beacon _beacon, final ServiceContext _serviceContext);
}
