package lk.ideahub.symphony.modules.commission.service;

import java.util.List;

import lk.ideahub.symphony.modules.commission.entity.PaymentAggregatorCommission;
import lk.ideahub.symphony.modules.commission.repository.PaymentAggregatorCommissionRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class PaymentAggregatorCommissionServiceImpl extends GenericService implements PaymentAggregatorCommissionService {

    private static final Logger log = LoggerFactory.getLogger(PaymentAggregatorCommissionServiceImpl.class);

    @Autowired
    private PaymentAggregatorCommissionRepository repository;

    @Override
    public PaymentAggregatorCommission get(final Object _paymentAggregatorCommissionID, final ServiceContext _serviceContext) {
        return repository.get(_paymentAggregatorCommissionID, _serviceContext);
    }

    @Override
    public List<PaymentAggregatorCommission> find(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        return repository.find(_paymentAggregatorCommission, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        repository.add(_paymentAggregatorCommission, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        repository.update(_paymentAggregatorCommission, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        repository.delete(_paymentAggregatorCommission, _serviceContext);
    }

    @Override
    public List<PaymentAggregatorCommission> findByPaymentOptionId(PaymentAggregatorCommission _paymentAggregatorCommission, ServiceContext _serviceContext) {
        return repository.findByPaymentOptionId(_paymentAggregatorCommission,_serviceContext);
    }
}
