package lk.ideahub.symphony.modules.common;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class StaticQrCodeDecryption {

	private static final Logger log = LoggerFactory.getLogger(StaticQrCodeDecryption.class);
	
	private IvParameterSpec ivspec;
	private SecretKeySpec keyspec;
	private Cipher cipher;

	public static void main(String[] args) {
		StaticQrCodeDecryption javaDecryption = new StaticQrCodeDecryption();
		try {
			System.out.println("############### Decryption Starting ###############");
			String decrypted = new String(javaDecryption.decrypt("a1752b3159b8bf0f1863c29717456bc0", "6b23f948a02b1f3d", "5b4b2df504be6ab4"));
			System.out.println(decrypted);
			System.out.println("###################################################");
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}

	public StaticQrCodeDecryption() {
	}

	public byte[] encrypt(String plainString, String secretKey, String fixedSaltString) throws Exception {
		if (plainString == null || plainString.length() == 0)
			throw new Exception("Empty string");
		byte[] decrypted = null;

		try {
			ivspec = new IvParameterSpec(fixedSaltString.getBytes());
			keyspec = new SecretKeySpec(secretKey.getBytes(), "AES");
			cipher = Cipher.getInstance("AES/CBC/NoPadding");
			cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
			decrypted = cipher.doFinal(hexToBytes(plainString));
		} catch (Exception e) {
			throw new Exception("[encrypt] " + e.getMessage());
		}
		return decrypted;
	}
	
	public byte[] decrypt(String encryptedString, String secretKey, String fixedSaltString) throws Exception {
		if (encryptedString == null || encryptedString.length() == 0)
			throw new Exception("Empty string");
		byte[] decrypted = null;

		try {
			ivspec = new IvParameterSpec(fixedSaltString.getBytes());
			keyspec = new SecretKeySpec(secretKey.getBytes(), "AES");
			cipher = Cipher.getInstance("AES/CBC/NoPadding");
			cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);
			decrypted = cipher.doFinal(hexToBytes(encryptedString));
		} catch (Exception e) {
			throw new Exception("[decrypt] " + e.getMessage());
		}
		return decrypted;
	}

	public static String bytesToHex(byte[] data) {
		if (data == null) {
			return null;
		}

		int len = data.length;
		String str = "";
		for (int i = 0; i < len; i++) {
			if ((data[i] & 0xFF) < 16)
				str = str + "0" + java.lang.Integer.toHexString(data[i] & 0xFF);
			else
				str = str + java.lang.Integer.toHexString(data[i] & 0xFF);
		}
		return str;
	}

	public static byte[] hexToBytes(String str) {
		if (str == null) {
			return null;
		} else if (str.length() < 2) {
			return null;
		} else {
			int len = str.length() / 2;
			byte[] buffer = new byte[len];
			for (int i = 0; i < len; i++) {
				buffer[i] = (byte) Integer.parseInt(str.substring(i * 2, i * 2 + 2), 16);
			}
			return buffer;
		}
	}

	private static String padString(String source) {
		char paddingChar = ' ';
		int size = 16;
		int x = source.length() % size;
		int padLength = size - x;
		for (int i = 0; i < padLength; i++) {
			source += paddingChar;
		}
		return source;
	}
	
}
