package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.banks.entity.Banks;
import lk.ideahub.symphony.modules.customer.entity.CustomerAttempt;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */

public interface BanksService {

    Banks get(final Object banksId, final ServiceContext serviceContext);

    List<Banks> find(final Banks banks, final ServiceContext serviceContext);

    List<Banks> findByMainWallet(final String bankMainWallet, final ServiceContext serviceContext);

    List<Banks> findByMainWalletSuffix(final String bankMainWalletSuffix, final ServiceContext serviceContext);

    void add(final Banks banks, final ServiceContext serviceContext);

    void update(final Banks banks, final ServiceContext serviceContext);

    void delete(final Banks banks, final ServiceContext serviceContext);

    List<Banks> getBanksList(final Banks banks, final ServiceContext serviceContext);

    List<Banks> getBanksListByIntegrationType(final Banks banks, final ServiceContext serviceContext);
}
