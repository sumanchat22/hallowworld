package lk.ideahub.symphony.modules.amex.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;

import javax.persistence.*;

@Entity
@Table(name = "amex_card_reg_transactions")
/*@NamedQueries({
        @NamedQuery(name = "AMEXCardRegTransaction.find", query = "select ? from AMEXCardRegTransaction ?" +
                "  where" +
                "    (:name is null or ?.name = :name)")})*/

@NamedNativeQueries({
        @NamedNativeQuery(name = "AMEXCardRegTransaction.findByCustomerId", query = "select * from amex_card_reg_transactions trans " +
                " where (trans.customer_id = :customerId)" +
                " order by"+
                " trans.created_datetime desc")
})

public class AMEXCardRegTransaction extends AbstractEntity {

    @Id
    @SequenceGenerator(name = "generator", sequenceName = "AMEX_CARD_REG_TRANSACTION_SQ1", allocationSize = 1)
    @GeneratedValue(generator = "generator")
    @Column(name = "amex_card_reg_transaction_id")
    private Long amexCardRegTransactionId;

    @Column(name = "refresh_token")
    private String refreshToken;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "transaction_type")
    private String transactionType;

    @Column(name = "card_alias")
    private String cardAlias;

    public Long getAmexCardRegTransactionId() {
        return amexCardRegTransactionId;
    }

    public void setAmexCardRegTransactionId(Long amexCardRegTransactionId) {
        this.amexCardRegTransactionId = amexCardRegTransactionId;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getCardAlias() {
        return cardAlias;
    }

    public void setCardAlias(String cardAlias) {
        this.cardAlias = cardAlias;
    }

    @Override
    public String toString() {
        return new StringBuilder("AMEXCardRegTransaction {")
                .append("amexCardRegTransactionId=").append(amexCardRegTransactionId).append(", ")
                .append("refreshToken='").append(refreshToken).append("'").append(", ")
                .append("customerId=").append(customerId).append(", ")
                .append("transactionType='").append(transactionType).append("'").append(", ")
                .append("cardAlias='").append(cardAlias).append("'")
                .append('}').toString();
    }
}
