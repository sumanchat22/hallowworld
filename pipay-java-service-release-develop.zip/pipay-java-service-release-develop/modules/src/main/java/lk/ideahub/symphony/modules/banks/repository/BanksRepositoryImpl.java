package lk.ideahub.symphony.modules.banks.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.banks.entity.Banks;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */

@Repository
class BanksRepositoryImpl extends GenericRepository implements BanksRepository {

    private static final Logger log = LoggerFactory.getLogger(BanksRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public Banks get(final Object banksId, final ServiceContext serviceContext) {
        return entityManager.find(Banks.class, banksId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Banks> find(final Banks banks, final ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Banks.class);
        return criteria.list();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Banks> findByMainWallet(String bankMainWallet, ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Banks.class);
        criteria.add(Restrictions.eq("bankMainWallet", bankMainWallet));
        criteria.add(Restrictions.eq("bankStatusId", 1));
        return criteria.list();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Banks> findByMainWalletSuffix(String bankMainWalletSuffix, ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Banks.class);
        criteria.add(Restrictions.like("bankMainWallet", "%" + bankMainWalletSuffix));
        criteria.add(Restrictions.eq("bankStatusId", 1));
        return criteria.list();
    }

    @Override
    public void add(final Banks banks, final ServiceContext serviceContext) {
        entityManager.persist(banks);
        entityManager.flush();
    }

    @Override
    public Banks update(final Banks banks, final ServiceContext serviceContext) {
        return entityManager.merge(banks);
    }

    @Override
    public void delete(final Banks banks, final ServiceContext serviceContext) {
        entityManager.remove(banks);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Banks> getBanksList(Banks banks, ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Banks.class,"bn");
        criteria.createAlias("bn.bankTransferType", "bntt", JoinType.INNER_JOIN);
        criteria.createAlias("bn.bankIntegrationType", "bnit", JoinType.INNER_JOIN);
        criteria.add(Restrictions.ne("bn.bankStatusId", 2L));

        if(banks.getBanksId() != null){
            criteria.add(Restrictions.eq("bn.banksId", banks.getBanksId()));
        }

        if(banks.getTransferType() != null && !banks.getTransferType().equals("")){
            criteria.add(Restrictions.eq("bntt.name",banks.getTransferType()).ignoreCase());
        }

        if(banks.getIntegrationType() != null && !banks.getIntegrationType().equals("")){
            criteria.add(Restrictions.eq("bnit.name",banks.getIntegrationType()).ignoreCase());
        }

        criteria.addOrder(Order.asc("bn.bankName"));
        if (serviceContext != null && serviceContext.isPageable()) {
            criteria.setFirstResult(serviceContext.getPageStart());
            if (serviceContext.getPageSize() != null) {
                criteria.setMaxResults(serviceContext.getPageSize()-1);
            }
        }

        return criteria.list();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> getBanksListByIntegrationType(final Banks banks, final ServiceContext serviceContext) {
        Query query = entityManager.createNamedQuery("Banks.getBanksListByIntegrationType");

        if (banks.getIntegrationTypeId() != null) {
            query.setParameter("bankIntegrationTypeId", banks.getIntegrationTypeId());
        }  else {
            query.setParameter("bankIntegrationTypeId", "");
        }

        if (banks.getTransferTypeId() != null) {
            query.setParameter("bankTransferTypeId", banks.getTransferTypeId());
        }  else {
            query.setParameter("bankTransferTypeId", "");
        }

        handlePagination(query, serviceContext);

        return query.getResultList();
    }

}
