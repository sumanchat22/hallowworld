package lk.ideahub.symphony.modules.banner.entity;

import java.util.List;

import lk.ideahub.symphony.product.sympay.common.SymphonyDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BannerDto extends SymphonyDto{

	private List<BannerSlide> bannerSlides;
}
