package lk.ideahub.symphony.modules.casa.repository;

import java.util.List;

import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;

public interface CargillsCustomerCasaAccountRepository {

    CargillsCustomerCasaAccount get(final Object _CargillsCustomerCasaAccountId, final ServiceContext _serviceContext);

    void add(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    CargillsCustomerCasaAccount update(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    void delete(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    CargillsCustomerCasaAccount findByPaymentOption(CustomerPaymentOption customerPaymentOption, final ServiceContext _serviceContext);

    CargillsCustomerCasaAccount findByAccountId(String accountId, final ServiceContext _serviceContext);
}
