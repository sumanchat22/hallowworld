package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.types.entity.PayeeStatus;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * @author somma.soun - PiPay
 * @create 13-Dec-2021
 */
@Entity
@Table(name = "bank_statuses")
@Getter
@Setter
@ToString
public class BanksStatus {
    @Id
    @SequenceGenerator(name="generator", sequenceName="BANK_STATUSES_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_status_id")
    private Integer bankStatusId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    /**
     * Enumeration of PayeeStatus values.
     */
    public static enum Value {

        ACTIVE_STATUS("Active"),
        INACTIVE_STATUS("Inactive");

        private String name;

        private Value(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public BanksStatus getPayeeStatus() {
            BanksStatus banksStatus = new BanksStatus();
            banksStatus.setName(this.name);

            return banksStatus;
        }

        public static BanksStatus.Value getByName(String name) {
            for (BanksStatus.Value value : values()) {
                if (value.getName().equals(name)) {
                    return value;
                }
            }
            throw new AssertionError("BanksStatus value not found for given name [name: " + name + "]");
        }
    }
}
