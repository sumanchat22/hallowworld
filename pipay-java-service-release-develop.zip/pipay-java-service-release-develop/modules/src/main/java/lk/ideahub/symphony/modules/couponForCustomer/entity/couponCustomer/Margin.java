package lk.ideahub.symphony.modules.couponForCustomer.entity.couponCustomer;


import com.fasterxml.jackson.annotation.*;

public class Margin {
    private long top;
    private long left;
    private long bottom;
    private long right;

    @JsonProperty("top")
    public long getTop() { return top; }
    @JsonProperty("top")
    public void setTop(long value) { this.top = value; }

    @JsonProperty("left")
    public long getLeft() { return left; }
    @JsonProperty("left")
    public void setLeft(long value) { this.left = value; }

    @JsonProperty("bottom")
    public long getBottom() { return bottom; }
    @JsonProperty("bottom")
    public void setBottom(long value) { this.bottom = value; }

    @JsonProperty("right")
    public long getRight() { return right; }
    @JsonProperty("right")
    public void setRight(long value) { this.right = value; }
}