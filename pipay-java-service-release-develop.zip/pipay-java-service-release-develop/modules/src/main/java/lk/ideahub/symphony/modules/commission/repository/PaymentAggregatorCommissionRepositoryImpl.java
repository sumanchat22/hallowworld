package lk.ideahub.symphony.modules.commission.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.commission.entity.PaymentAggregatorCommission;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;


@Repository
class PaymentAggregatorCommissionRepositoryImpl extends GenericRepository implements PaymentAggregatorCommissionRepository {

    private static final Logger log = LoggerFactory.getLogger(PaymentAggregatorCommissionRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public PaymentAggregatorCommission get(final Object _paymentAggregatorCommissionID, final ServiceContext _serviceContext) {
        return entityManager.find(PaymentAggregatorCommission.class, _paymentAggregatorCommissionID);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<PaymentAggregatorCommission> find(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("PaymentAggregatorCommission.find");
        handlePagination(query, _serviceContext);
        return query.getResultList();
    }

    @Override
    public void add(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        _paymentAggregatorCommission.setCreatedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_paymentAggregatorCommission);
        entityManager.flush();
    }

    @Override
    public PaymentAggregatorCommission update(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        _paymentAggregatorCommission.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_paymentAggregatorCommission);
    }

    @Override
    public void delete(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext) {
        entityManager.remove(_paymentAggregatorCommission);
    }

    @Override
    public List<PaymentAggregatorCommission> findByPaymentOptionId(PaymentAggregatorCommission _paymentAggregatorCommission, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("PaymentAggregatorCommission.findByPaymentOptionId");
        query.setParameter("paymentOptionType",_paymentAggregatorCommission.getPaymentOptionType());
        handlePagination(query, _serviceContext);
        return query.getResultList();
    }
}
