package lk.ideahub.symphony.modules.counter.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "outlet_countrs_merchnt_actions")
public class OutletCounterMerchantAction extends AbstractEntity{

	@Id
    @SequenceGenerator(name="generator", sequenceName="COUNTER_MERCHANT_ACTIONS_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "countrs_merchnt_action_id")
    private Long outletCounterMerchantActionId;
	
	@ManyToOne
	@JoinColumn(name = "outlet_counter_id")
	OutletCounter outletCounter;
	
	@ManyToOne
	@JoinColumn(name = "merchant_action_id")
	MerchantAction merchantAction;
}
