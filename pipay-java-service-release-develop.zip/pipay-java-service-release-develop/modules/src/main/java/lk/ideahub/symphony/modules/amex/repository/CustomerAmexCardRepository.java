package lk.ideahub.symphony.modules.amex.repository;

import lk.ideahub.symphony.modules.amex.entity.CustomerAmexCard;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface CustomerAmexCardRepository {

    CustomerAmexCard get(final Object _customerAmexCardId, final ServiceContext _serviceContext);

    List<CustomerAmexCard> find(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    void add(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    CustomerAmexCard update(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    void delete(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    List<Object[]> findByCustomerId(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    List<Object[]> findCard(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    List<Object[]> findByCustomerPaymentOptionId(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext);
}
