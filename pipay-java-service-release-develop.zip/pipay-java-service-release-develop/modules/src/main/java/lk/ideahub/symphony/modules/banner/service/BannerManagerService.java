package lk.ideahub.symphony.modules.banner.service;

import lk.ideahub.symphony.modules.banner.entity.BannerDto;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface BannerManagerService {

	BannerDto getHomeBanner(BannerDto bannerDto);
}
