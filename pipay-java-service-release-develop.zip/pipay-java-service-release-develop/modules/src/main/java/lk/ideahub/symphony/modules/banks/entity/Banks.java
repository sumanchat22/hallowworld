package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.maintenaceMessages.entity.MaintenanceMessages;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */

@Entity
@Table(name = "banks")
@NamedQueries({
    @NamedQuery(name = "Banks.find", query = "select bn from Banks bn" +
        "  where" +
        "    (:banksId is null or bn.banksId = :banksId)")})
@NamedNativeQueries({
    @NamedNativeQuery(name = "Banks.getBanksListByIntegrationType", query = "select * from banks bn" +
        " where" +
        " (:bankIntegrationTypeId is null or bn.bank_integration_type_id = :bankIntegrationTypeId)" +
        " and "+
        " (:bankTransferTypeId is null or bn.bank_transfer_type_id = :bankTransferTypeId)" +
        " and "+
        " (bn.bank_status_id <> 2) ")
})

@Getter
@Setter
@ToString
public class Banks extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="BANKS_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_id")
    private Long banksId;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "bank_code")
    private String bankCode;

    @Column(name = "description")
    private String description;

    @Column(name = "bank_status_id")
    private Integer bankStatusId;

    @ManyToOne
    @JoinColumn(name = "bank_transfer_type_id")
    private BankTransferType bankTransferType;

    @ManyToOne
    @JoinColumn(name = "bank_integration_type_id")
    private BankIntegrationType bankIntegrationType;

    @ManyToOne
    @JoinColumn(name = "maintenance_messages_id")
    private MaintenanceMessages maintenanceMessages;

    @Column(name = "uuid")
    private String uuid;

    @Column(name = "service_provider_logo")
    private String serviceProviderLogo;

    @Column(name = "service_provider_logo_url")
    private String serviceProviderLogoUrl;

    @Column(name = "bank_main_wallet")
    private String bankMainWallet;

    @Transient
    private String transferType;

    @Transient
    private Long transferTypeId;

    @Transient
    private String integrationType;

    @Transient
    private Long integrationTypeId;

}
