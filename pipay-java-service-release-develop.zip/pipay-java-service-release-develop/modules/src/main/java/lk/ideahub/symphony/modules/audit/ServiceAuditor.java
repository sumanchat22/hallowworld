package lk.ideahub.symphony.modules.audit;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ServiceAuditor {
	
	@Autowired
	private ServiceAuditSupport serviceAuditSupport;
	
	private static final Logger log = LoggerFactory.getLogger(ServiceAuditor.class);
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.card.service.SymphonyCardServiceImpl.*(..))",
			 returning= "result")
	public void auditCardService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveCustomerAuditDetailAfterReturning(joinPoint, result);
	}

	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.card.service.SymphonyCardServiceImpl.*(..))",
		     throwing= "error")
	public void auditCardServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveCustomerAuditDetailAfterThrowing(joinPoint,error);
	}
	 
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.customer.service.SymphonyCustomerServiceImpl.*(..))",
			 returning= "result")
	public void auditCustomerService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveCustomerAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.customer.service.SymphonyCustomerServiceImpl.*(..))",
		     throwing= "error")
	public void auditCustomerServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveCustomerAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.device.service.SymphonyDeviceServiceImpl.*(..))",
			 returning= "result")
	public void auditDeviceService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveCustomerAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.device.service.SymphonyDeviceServiceImpl.*(..))",
		     throwing= "error")
	public void auditDeviceServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveCustomerAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.payee.service.SymphonyPayeeServiceImpl.*(..))",
			 returning= "result")
	public void auditPayeeService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveCustomerAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.payee.service.SymphonyPayeeServiceImpl.*(..))",
		     throwing= "error")
	public void auditPayeeServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveCustomerAuditDetailAfterThrowing(joinPoint,error);
	}

	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.payment.service.SymphonyPaymentServiceImpl.*(..))",
			 returning= "result")
	public void auditPayService(JoinPoint joinPoint, Object result) {
		log.info("AfterReturning");
		serviceAuditSupport.saveCustomerAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.payment.service.SymphonyPaymentServiceImpl.*(..))",
		     throwing= "error")
	public void auditPayServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
		log.info("AfterThrowing");
		serviceAuditSupport.saveCustomerAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantServiceImpl.*(..))",
			 returning= "result")
	public void auditMerchantService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantServiceImpl.*(..))",
		     throwing= "error")
	public void auditMerchantServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantTransactionServiceImpl.*(..))",
			 returning= "result")
	public void auditMerchantTransactionService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.merchant.service.SymphonyMerchantTransactionServiceImpl.*(..))",
		     throwing= "error")
	public void auditMerchantTransactionServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.user.service.SymphonyUserServiceImpl.*(..))",
			 returning= "result")
	public void auditUserTransactionService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.user.service.SymphonyUserServiceImpl.*(..))",
		     throwing= "error")
	public void auditUserTransactionServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.encryption.service.SymphonyEncryptionServiceImpl.*(..))",
			 returning= "result")
	public void auditEncryptionService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterReturning(joinPoint, result);
	}
	
	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.encryption.service.SymphonyEncryptionServiceImpl.*(..))",
		     throwing= "error")
	public void auditEncryptionServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveMerchantOrUserAuditDetailAfterThrowing(joinPoint,error);
	}
	
	@AfterReturning(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentServiceImpl.*(..))",
			 returning= "result")
	public void auditQrCodeService(JoinPoint joinPoint, Object result) {
		
		serviceAuditSupport.saveCustomerAuditDetailAfterReturning(joinPoint, result);
	}

	@AfterThrowing(
			 pointcut = "execution(* lk.ideahub.symphony.product.sympay.qrcode.payment.service.SymphonyQrCodePaymentServiceImpl.*(..))",
		     throwing= "error")
	public void auditQrCodeServiceAfterThrowing(JoinPoint joinPoint, Throwable error) {
	
		serviceAuditSupport.saveCustomerAuditDetailAfterThrowing(joinPoint,error);
	}
}
