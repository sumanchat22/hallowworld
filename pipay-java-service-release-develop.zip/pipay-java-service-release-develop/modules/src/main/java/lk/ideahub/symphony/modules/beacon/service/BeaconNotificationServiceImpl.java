package lk.ideahub.symphony.modules.beacon.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.beacon.entity.BeaconNotification;
import lk.ideahub.symphony.modules.beacon.repository.BeaconNotificationRepository;
import lk.ideahub.symphony.modules.beacon.repository.BeaconRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BeaconNotificationServiceImpl extends GenericService implements BeaconNotificationService {

    private static final Logger log = LoggerFactory.getLogger(BeaconNotificationServiceImpl.class);

    @Autowired
    private BeaconNotificationRepository repository;

    @Autowired
    private BeaconRepository beaconRepository;

    @Override
    public BeaconNotification get(final Object _beaconNotificationId, final ServiceContext _serviceContext) {
        return repository.get(_beaconNotificationId, _serviceContext);
    }

    @Override
    public List<BeaconNotification> findFromBeaconId(final List _beaconIdList, final ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findFromBeaconId(_beaconIdList, _serviceContext);

        List<BeaconNotification> notifications = new ArrayList<BeaconNotification>(resultList.size());
        if (resultList.size() > 0) {
            BeaconNotification bn = null;
            for (Object[] row : resultList) {
                Long beaconNotificationId = Long.valueOf(row[0].toString());
                bn = repository.get(beaconNotificationId, _serviceContext);

                notifications.add(bn);
            }
        }


        return notifications;
    }

    @Override
    public List<BeaconNotification> find(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        List<Object> resultList = repository.findIds(_beaconNotification, _serviceContext);

        List<BeaconNotification> notifications = new ArrayList<BeaconNotification>(resultList.size());
        if (resultList.size() > 0) {
            BeaconNotification bn = null;
            for (Object id : resultList) {
                Long beaconNotificationId = Long.valueOf(id.toString());
                bn = repository.get(beaconNotificationId, _serviceContext);

                notifications.add(bn);
            }
        }

        return notifications;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        repository.add(_beaconNotification, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        repository.update(_beaconNotification, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        repository.delete(_beaconNotification, _serviceContext);
    }
}
