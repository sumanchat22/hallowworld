package lk.ideahub.symphony.modules.casa.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "crg_casa_devices")
@Getter
@Setter
@ToString
public class CargillsCasaDevices extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="CRG_CASA_DEVICES_SQ",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "crg_casa_devices_id")
    private Long casaDevicesId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToOne
    @JoinColumn(name = "customer_casa_accounts_id")
    private CargillsCustomerCasaAccount cargillsCustomerCasaAccount;

    @Column(name = "device_id")
    private String deviceId;
}
