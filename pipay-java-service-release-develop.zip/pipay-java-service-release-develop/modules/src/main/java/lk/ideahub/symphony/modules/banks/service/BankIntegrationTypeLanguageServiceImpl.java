package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.BankIntegrationTypeLanguage;
import lk.ideahub.symphony.modules.banks.entity.BanksLanguage;
import lk.ideahub.symphony.modules.banks.repository.BankIntegrationTypeLanguageRepository;
import lk.ideahub.symphony.modules.banks.repository.BanksLanguageRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.hashtag.service.HashTagLanguageServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BankIntegrationTypeLanguageServiceImpl extends GenericService implements BankIntegrationTypeLanguageService {
    private static final Logger log = LoggerFactory.getLogger(BankIntegrationTypeLanguageServiceImpl.class);

    @Autowired
    private BankIntegrationTypeLanguageRepository repository;

    @Override
    public BankIntegrationTypeLanguage get(final Object bankIntegrationTypeLanguageId, final ServiceContext serviceContext) {
        return repository.get(bankIntegrationTypeLanguageId, serviceContext);
    }

    @Override
    public List<BankIntegrationTypeLanguage> find(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext) {
        return repository.find(bankIntegrationTypeLanguage, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext) {
        repository.add(bankIntegrationTypeLanguage, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext) {
        repository.update(bankIntegrationTypeLanguage, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext) {
        repository.delete(bankIntegrationTypeLanguage, serviceContext);
    }

    @Override
    public List<BankIntegrationTypeLanguage> getText(BankIntegrationTypeLanguage bankIntegrationTypeLanguage) {
        return repository.getText(bankIntegrationTypeLanguage);
    }
}
