package lk.ideahub.symphony.modules.casa.service;

import lk.ideahub.symphony.modules.casa.entity.CASAIntegrationResponse;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface CASAIntegrationResponseService {

    CASAIntegrationResponse get(final Object _casaIntegrationResponseId, final ServiceContext _serviceContext);

    List<CASAIntegrationResponse> find(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);

    void add(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);

    void update(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);

    void delete(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);
}
