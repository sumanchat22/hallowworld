package lk.ideahub.symphony.modules.beacon.entity;

import java.util.Date;
import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.notification.entity.Notification;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "beacon_notifications")
@NamedQueries({
        @NamedQuery(name = "BeaconNotification.find", query = "select bn from BeaconNotification bn" +
                //"  left join fetch bn.deal as d" +
                "  where (bn.beaconNotificationId = :beaconNotificationId)" /*+
                "    (:isActive is null or bn.isActive = :isActive)" +
                "    and (:effectiveDate is null or time(:effectiveDate) between bn.activeFrom and bn.activeTo)" +
                "    and (:effectiveDate is null" +
                "      or (bn.validFrom is null and bn.validTo is null)" +
                "      or (bn.validFrom is not null and bn.validTo is not null and date(:effectiveDate) between bn.validFrom and bn.validTo)" +
                "      or (bn.validFrom is not null and bn.validTo is null and date(:effectiveDate) >= bn.validFrom)" +
                "      or (bn.validFrom is null and bn.validTo is not null and date(:effectiveDate) <= bn.validTo))" +
                "    and (:proximityUuid is null or bn.beacon.proximityUuid = :proximityUuid)" +
                "    and (:major is null or bn.beacon.major = :major)" +
                "    and (:minor is null or bn.beacon.minor = :minor)" +
                "    and (d.dealId is null" +
                "      or (d.isActive = 'Y'" +
                "        and (:isVoucher is null or d.isVoucher = :isVoucher)" +
                "        and (:effectiveDate is null or date(:effectiveDate) between d.activeBy and d.validTo)))" +
                "  order by" +
                "    bn.isProminent desc, bn.priority, bn.createdDatetime desc"*/)})
@NamedNativeQueries({
        @NamedNativeQuery(name = "BeaconNotification.findIds", query = "select bn.beacon_notification_id from beacon_notifications bn" +
                "  inner join beacons b on b.beacon_id = bn.beacon_id" +
                "  inner join notifications n on n.notification_id = bn.notification_id" +
                "  left outer join deals d on d.deal_id = n.deal_id" +
                "  left outer join customers c on c.phone_1 = :phone" +
                "  left outer join notification_customer_types nct on nct.notification_id = n.notification_id" +
                "  left outer join deal_customer_types dct on dct.deal_id = d.deal_id" +
                "  where" +
                "   (:isActive is null or n.is_active = :isActive)" +
                "   and (:effectiveDate is null or time(:effectiveDate) between n.active_from and n.active_to)" +
                "   and (:effectiveDate is null" +
                "      or (n.valid_from is null and n.valid_to is null)" +
                "      or (n.valid_from is not null and n.valid_to is not null and date(:effectiveDate) between n.valid_from and n.valid_to)" +
                "      or (n.valid_from is not null and n.valid_to is null and date(:effectiveDate) >= n.valid_from)" +
                "      or (n.valid_from is null and n.valid_to is not null and date(:effectiveDate) <= n.valid_to))" +
                "    and (:proximityUuid is null or b.proximity_uuid = :proximityUuid)" +
                "    and (:major is null or b.major = :major)" +
                "    and (:minor is null or b.minor = :minor)" +
                "    and (d.deal_id is null" +
                "      or (d.is_active = 'Y'" +
                "        and (:isVoucher is null or d.is_voucher = :isVoucher)" +
                "        and (:effectiveDate is null or date(:effectiveDate) between d.active_by and d.valid_to)))" +
                "    and ((d.deal_id is null and" +
                "        ((c.customer_id is null and n.is_all_cx_types = 'Y')" +
                "        or (c.customer_id is not null and n.is_all_cx_types != 'Y' and c.customer_type_id = nct.customer_type_id)))" +
                "      or" +
                "        ((c.customer_id is null and d.is_all_cx_types = 'Y')" +
                "        or (c.customer_id is not null and (d.is_all_cx_types = 'Y' or c.customer_type_id = dct.customer_type_id))))" +
                "  order by" +
                "    n.is_prominent desc, n.priority, n.created_datetime desc"),
        @NamedNativeQuery(name = "BeaconNotification.findFromBeaconIdList", query = "select bn.beacon_notification_id,bn.notification_id " +
                " from beacon_notifications bn" +
                " inner join notifications noti on bn.notification_id = noti.notification_id" +

                "  left outer join deals d on d.deal_id = noti.deal_id" +
                "  left outer join customers c on c.phone_1 = :phone" +
                "  left outer join notification_customer_types nct on nct.notification_id = noti.notification_id" +
                "  left outer join deal_customer_types dct on dct.deal_id = d.deal_id" +

                "  where " +
                "   bn.beacon_id in (:beaconIdList)" +
                "   and (:isActive is null or noti.is_active = :isActive)" +
                "   and (:effectiveDate is null or time(:effectiveDate) between noti.active_from and noti.active_to)" +
                "   and (:effectiveDate is null" +
                "       or (noti.valid_from is null and noti.valid_to is null)" +
                "       or (noti.valid_from is not null and noti.valid_to is not null and date(:effectiveDate) between noti.valid_from and noti.valid_to)" +
                "       or (noti.valid_from is not null and noti.valid_to is null and date(:effectiveDate) >= noti.valid_from)" +
                "       or (noti.valid_from is null and noti.valid_to is not null and date(:effectiveDate) <= noti.valid_to))" +

                "   and (d.deal_id is null" +
                "     or (d.is_active = 'Y'" +
                "       and (:effectiveDate is null or date(:effectiveDate) between d.active_by and d.valid_to)))" +
                "   and ((d.deal_id is null and" +
                "       ((c.customer_id is null and noti.is_all_cx_types = 'Y')" +
                "       or (c.customer_id is not null and noti.is_all_cx_types != 'Y' and c.customer_type_id = nct.customer_type_id)))" +
                "     or" +
                "       ((c.customer_id is null and d.is_all_cx_types = 'Y')" +
                "       or (c.customer_id is not null and (d.is_all_cx_types = 'Y' or c.customer_type_id = dct.customer_type_id))))" +

                " order by" +
                "  noti.is_prominent desc, noti.priority, noti.created_datetime desc" )})
@Getter
@Setter
@ToString
public class BeaconNotification extends AbstractEntity {

    // ### ORACLE CHANGE :  ADD SEQUENCE ###
    @Id
    @SequenceGenerator(name="generator", sequenceName="BEACON_NOTIFICATIONS_BEACON_NO",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "beacon_notification_id")
    private Long beaconNotificationId;

    @ManyToOne
    @JoinColumn(name = "beacon_id")
    private Beacon beacon;

    @ManyToOne
    @JoinColumn(name = "notification_id")
    private Notification notification;

    @Transient
    private String phone;

    @Transient
    private BeaconId beaconId2;

    @Transient
    private String isVoucher;

    @Transient
    private Date effectiveDate;

}
