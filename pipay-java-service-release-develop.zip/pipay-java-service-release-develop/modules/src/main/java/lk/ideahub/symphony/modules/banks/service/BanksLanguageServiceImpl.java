package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.banks.entity.BanksLanguage;
import lk.ideahub.symphony.modules.banks.repository.BanksLanguageRepository;
import lk.ideahub.symphony.modules.hashtag.service.HashTagLanguageServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BanksLanguageServiceImpl  extends GenericService implements BanksLanguageService {
    private static final Logger log = LoggerFactory.getLogger(HashTagLanguageServiceImpl.class);

    @Autowired
    private BanksLanguageRepository repository;

    @Override
    public BanksLanguage get(final Object banksLanguageId, final ServiceContext serviceContext) {
        return repository.get(banksLanguageId, serviceContext);
    }

    @Override
    public List<BanksLanguage> find(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        return repository.find(banksLanguage, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        repository.add(banksLanguage, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        repository.update(banksLanguage, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        repository.delete(banksLanguage, serviceContext);
    }

    @Override
    public List<BanksLanguage> getText(BanksLanguage banksLanguage) {
        return repository.getText(banksLanguage);
    }
}
