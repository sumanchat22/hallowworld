package lk.ideahub.symphony.modules.commission.service;

import lk.ideahub.symphony.modules.commission.entity.ServiceProviderCommissionRate;
import lk.ideahub.symphony.modules.commission.repository.ServiceProviderCommissionRateRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class ServiceProviderCommissionRateServiceImpl extends GenericService implements ServiceProviderCommissionRateService {

    private static final Logger log = LoggerFactory.getLogger(ServiceProviderCommissionRateServiceImpl.class);

    @Autowired
    private ServiceProviderCommissionRateRepository repository;

    @Override
    public ServiceProviderCommissionRate get(final Object _serviceProviderCommissionRateId, final ServiceContext _serviceContext) {
        return repository.get(_serviceProviderCommissionRateId, _serviceContext);
    }

    @Override
    public List<ServiceProviderCommissionRate> find(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        return repository.find(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    public List<ServiceProviderCommissionRate> findCusComByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        return repository.findCusComByMerchant(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    public List<ServiceProviderCommissionRate> listAllCusComByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        return repository.listAllCusComByMerchant(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    public List<ServiceProviderCommissionRate> findMerComByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        return repository.findMerComByMerchant(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        repository.add(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        repository.update(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        repository.delete(_serviceProviderCommissionRate, _serviceContext);
    }

    @Override
    public List<ServiceProviderCommissionRate> findByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findByMerchant(_serviceProviderCommissionRate, _serviceContext);

        List<ServiceProviderCommissionRate> commissionRates = new ArrayList<ServiceProviderCommissionRate>(resultList.size());
        if (resultList.size() > 0) {
            ServiceProviderCommissionRate commissionRate = null;
            for (Object[] row : resultList) {
                Long commissionRateId = Long.valueOf(row[0].toString());
                commissionRate = repository.get(commissionRateId, _serviceContext);

                commissionRates.add(commissionRate);
            }
        }

        return commissionRates;
    }

    @Override
    public List<ServiceProviderCommissionRate> findMerComByAggregate(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        return repository.findMerComByAggregate(_serviceProviderCommissionRate,_serviceContext);
    }

}
