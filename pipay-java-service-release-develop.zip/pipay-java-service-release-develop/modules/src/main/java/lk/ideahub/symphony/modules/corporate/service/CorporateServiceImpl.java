package lk.ideahub.symphony.modules.corporate.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.corporate.entity.Corporate;
import lk.ideahub.symphony.modules.corporate.repository.CorporateRepository;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CorporateServiceImpl extends GenericService implements CorporateService {

    private static final Logger log = LoggerFactory.getLogger(CorporateServiceImpl.class);

    @Autowired
    private CorporateRepository repository;

    @Override
    public Corporate get(final Object _corporateId, final ServiceContext _serviceContext) {
        return repository.get(_corporateId, _serviceContext);
    }

    @Override
    public List<Corporate> find(final Corporate _corporate, final ServiceContext _serviceContext) {
        return repository.find(_corporate, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final Corporate _corporate, final ServiceContext _serviceContext) {
        repository.add(_corporate, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final Corporate _corporate, final ServiceContext _serviceContext) {
        repository.update(_corporate, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final Corporate _corporate, final ServiceContext _serviceContext) {
        repository.delete(_corporate, _serviceContext);
    }
}
