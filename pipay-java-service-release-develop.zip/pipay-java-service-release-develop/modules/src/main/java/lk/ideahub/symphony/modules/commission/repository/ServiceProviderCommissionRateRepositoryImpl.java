package lk.ideahub.symphony.modules.commission.repository;

import lk.ideahub.symphony.modules.commission.entity.ServiceProviderCommissionRate;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Calendar;
import java.util.List;

@Repository
class ServiceProviderCommissionRateRepositoryImpl extends GenericRepository implements ServiceProviderCommissionRateRepository {

    private static final Logger log = LoggerFactory.getLogger(ServiceProviderCommissionRateRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public ServiceProviderCommissionRate get(final Object _serviceProviderCommissionRateId, final ServiceContext _serviceContext) {
        return entityManager.find(ServiceProviderCommissionRate.class, _serviceProviderCommissionRateId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<ServiceProviderCommissionRate> find(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("ServiceProviderCommissionRate.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public List<ServiceProviderCommissionRate> findCusComByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {

        Query query = entityManager.createNamedQuery("ServiceProviderCommissionRate.findCusComByMerchant");
        query.setParameter("serviceProviderId",_serviceProviderCommissionRate.getServiceProviderId());
        query.setParameter("paymentOptionType",_serviceProviderCommissionRate.getPaymentOptionType());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public List<ServiceProviderCommissionRate> listAllCusComByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {

        Query query = entityManager.createNamedQuery("ServiceProviderCommissionRate.listAllCusComByMerchant");
        if (_serviceProviderCommissionRate.getServiceProviderId() == null){
            query.setParameter("serviceProviderId","");
        } else {
            query.setParameter("serviceProviderId",_serviceProviderCommissionRate.getServiceProviderId());
        }
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public List<ServiceProviderCommissionRate> findMerComByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {

        Query query = entityManager.createNamedQuery("ServiceProviderCommissionRate.findMerComByMerchant");
        query.setParameter("serviceProviderId",_serviceProviderCommissionRate.getServiceProviderId());
        query.setParameter("paymentOptionType",_serviceProviderCommissionRate.getPaymentOptionType());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        _serviceProviderCommissionRate.setCreatedDatetime(Calendar.getInstance().getTime());
        _serviceProviderCommissionRate.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_serviceProviderCommissionRate);
        entityManager.flush();
    }

    @Override
    public ServiceProviderCommissionRate update(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        _serviceProviderCommissionRate.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_serviceProviderCommissionRate);
    }

    @Override
    public void delete(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext) {
        entityManager.remove(_serviceProviderCommissionRate);
    }

    @Override
    public List<Object[]> findByMerchant(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("ServiceProviderCommissionRate.findByMerchant");
        query.setParameter("serviceProviderId",_serviceProviderCommissionRate.getServiceProviderId());
        query.setParameter("paymentOptionTypeId",_serviceProviderCommissionRate.getPaymentOptionType().getPaymentOptionTypeId());
        handlePagination(query,_serviceContext);
        return query.getResultList();
    }

    @Override
    public List<ServiceProviderCommissionRate> findMerComByAggregate(ServiceProviderCommissionRate _serviceProviderCommissionRate, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("ServiceProviderCommissionRate.findMerComByAggregate");
        query.setParameter("serviceProviderId",_serviceProviderCommissionRate.getServiceProviderId());
        query.setParameter("paymentOptionType",_serviceProviderCommissionRate.getPaymentOptionType());
        handlePagination(query, _serviceContext);
        return query.getResultList();
    }
}
