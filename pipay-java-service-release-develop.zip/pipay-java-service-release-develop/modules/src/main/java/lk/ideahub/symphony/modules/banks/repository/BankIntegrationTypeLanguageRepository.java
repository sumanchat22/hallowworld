package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BankIntegrationTypeLanguage;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

public interface BankIntegrationTypeLanguageRepository {
    BankIntegrationTypeLanguage get(final Object banksIntegrationTypeLanguageId, final ServiceContext serviceContext);

    List<BankIntegrationTypeLanguage> find(final BankIntegrationTypeLanguage banksIntegrationTypeLanguage, final ServiceContext serviceContext);

    void add(final BankIntegrationTypeLanguage banksIntegrationTypeLanguage, final ServiceContext serviceContext);

    BankIntegrationTypeLanguage update(final BankIntegrationTypeLanguage banksIntegrationTypeLanguage, final ServiceContext serviceContext);

    void delete(final BankIntegrationTypeLanguage banksIntegrationTypeLanguage, final ServiceContext serviceContext);

    List<BankIntegrationTypeLanguage> getText(final BankIntegrationTypeLanguage banksIntegrationTypeLanguage);
}
