package lk.ideahub.symphony.modules.banner.repository;

import lk.ideahub.symphony.modules.banner.entity.Banner;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface BannerRepository {

    Banner get(final Object _bannerId, final ServiceContext _serviceContext);

    List<Banner> find(final Banner _banner, final ServiceContext _serviceContext);

    void add(final Banner _banner, final ServiceContext _serviceContext);

    Banner update(final Banner _banner, final ServiceContext _serviceContext);

    void delete(final Banner _banner, final ServiceContext _serviceContext);
    
    List<Banner> getListFromDealBannerType(String bannerType);
}
