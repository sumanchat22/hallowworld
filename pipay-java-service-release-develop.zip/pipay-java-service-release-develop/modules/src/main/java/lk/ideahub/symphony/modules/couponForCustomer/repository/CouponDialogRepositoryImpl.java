package lk.ideahub.symphony.modules.couponForCustomer.repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.couponForCustomer.entity.CouponDialog;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
class CouponDialogRepositoryImpl extends GenericRepository implements CouponDialogRepository {

    private static final Logger log = LoggerFactory.getLogger(CouponDialogRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CouponDialog get(final Object couponDialogId, final ServiceContext serviceContext) {
        return entityManager.find(CouponDialog.class, couponDialogId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CouponDialog> find(final CouponDialog couponDialog, final ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(CouponDialog.class, "cdl");
        criteria.createAlias("cdl.language", "lg", JoinType.INNER_JOIN);
        criteria.add(Restrictions.eq("lg.languageId", couponDialog.getLanguage().getLanguageId()));
        return criteria.list();
    }


}
