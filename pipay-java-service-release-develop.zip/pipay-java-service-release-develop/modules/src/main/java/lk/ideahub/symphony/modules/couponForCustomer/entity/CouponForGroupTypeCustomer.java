package lk.ideahub.symphony.modules.couponForCustomer.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;


@Entity
@NamedQueries({
        @NamedQuery(name = "CouponForGroupTypeCustomer.find", query = "select cgc from CouponForGroupTypeCustomer cgc" +
                "  where" +
                "    (:groupTypeAppVersionId is null or cgc.groupTypeAppVersionId = :groupTypeAppVersionId)"
        )})
@Getter
@Setter
@ToString
@Table(name = "coupon_for_group_type_customer")
public class CouponForGroupTypeCustomer extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="COUPON_FOR_GROUP_TYPE_CUSTOMER_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "coupon_for_group_type_customer_id")
    private Long couponForGroupTypeCustomerId;

    @Column(name = "group_type_app_version_id")
    private Long groupTypeAppVersionId;

    @Column(name = "coupon_pack_id")
    private Long couponPackId;

}
