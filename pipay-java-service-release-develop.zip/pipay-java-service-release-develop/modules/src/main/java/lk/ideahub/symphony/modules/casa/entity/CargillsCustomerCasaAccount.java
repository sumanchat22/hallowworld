package lk.ideahub.symphony.modules.casa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.entity.CustomerPaymentOption;
import lk.ideahub.symphony.modules.types.entity.Bank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "crg_customer_casa_accounts")
@Getter
@Setter
@ToString
public class CargillsCustomerCasaAccount extends AbstractEntity{
    @Id
    @SequenceGenerator(name="generator", sequenceName="CRG_CUSTOMER_CASA_ACCOUNTS_SQ",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "customer_casa_accounts_id")
    private Long customerCasaAccountId;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToOne
    @JsonIgnore
    @JoinColumn(name = "customer_payment_option_id")
    private CustomerPaymentOption customerPaymentOption;

    @Column(name = "crg_account_id")
    private String accountId;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "is_deleted")
    private String isDeleted;

    @ManyToOne
    @JoinColumn(name = "bank_id")
    private Bank bank;

}
