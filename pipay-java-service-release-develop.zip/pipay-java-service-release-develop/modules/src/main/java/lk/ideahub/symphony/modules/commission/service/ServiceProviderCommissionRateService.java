package lk.ideahub.symphony.modules.commission.service;

import lk.ideahub.symphony.modules.commission.entity.ServiceProviderCommissionRate;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface ServiceProviderCommissionRateService {

    ServiceProviderCommissionRate get(final Object _serviceProviderCommissionRateId, final ServiceContext _serviceContext);

    List<ServiceProviderCommissionRate> find(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    List<ServiceProviderCommissionRate> findCusComByMerchant(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    List<ServiceProviderCommissionRate> listAllCusComByMerchant(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    List<ServiceProviderCommissionRate> findMerComByMerchant(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    void add(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    void update(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    void delete(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    List<ServiceProviderCommissionRate> findByMerchant(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);

    List<ServiceProviderCommissionRate> findMerComByAggregate(final ServiceProviderCommissionRate _serviceProviderCommissionRate, final ServiceContext _serviceContext);
}
