package lk.ideahub.symphony.modules.commission.service;

import lk.ideahub.symphony.modules.commission.entity.PaymentAggregatorCommission;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;


public interface PaymentAggregatorCommissionService {

    PaymentAggregatorCommission get(final Object _paymentAggregatorCommissionID, final ServiceContext _serviceContext);

    List<PaymentAggregatorCommission> find(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext);

    void add(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext);

    void update(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext);

    void delete(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext);

    List<PaymentAggregatorCommission> findByPaymentOptionId(final PaymentAggregatorCommission _paymentAggregatorCommission, final ServiceContext _serviceContext);
}
