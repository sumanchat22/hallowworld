package lk.ideahub.symphony.modules.amex.repository;

import lk.ideahub.symphony.modules.amex.entity.AMEXIntegrationResponse;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
class AMEXIntegrationResponseRepositoryImpl extends GenericRepository implements AMEXIntegrationResponseRepository {

    private static final Logger log = LoggerFactory.getLogger(AMEXIntegrationResponseRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public AMEXIntegrationResponse get(final Object _amexIntegrationResponseId, final ServiceContext _serviceContext) {
        return entityManager.find(AMEXIntegrationResponse.class, _amexIntegrationResponseId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<AMEXIntegrationResponse> find(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("AMEXIntegrationResponse.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        _amexIntegrationResponse.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        _amexIntegrationResponse.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_amexIntegrationResponse);
        entityManager.flush();
    }

    @Override
    public AMEXIntegrationResponse update(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        _amexIntegrationResponse.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_amexIntegrationResponse);
    }

    @Override
    public void delete(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        entityManager.remove(_amexIntegrationResponse);
    }
}
