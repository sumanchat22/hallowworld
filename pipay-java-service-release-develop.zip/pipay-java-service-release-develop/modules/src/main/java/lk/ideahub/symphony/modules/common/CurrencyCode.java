package lk.ideahub.symphony.modules.common;

/**
 * Enumeration of currency codes.
 * https://en.wikipedia.org/wiki/ISO_4217
 */
public enum CurrencyCode {
    LKR("LKR"),
    AUD("AUD"),
    USD("USD"),
    NZD("NZD");

    private String code;

    private CurrencyCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static CurrencyCode getByCode(String code) {
        for (CurrencyCode currencyCode : values()) {
            if (currencyCode.getCode().equals(code)) {
                return currencyCode;
            }
        }
        throw new AssertionError("Currency code not found for given code [code: " + code + "]");
    }
}