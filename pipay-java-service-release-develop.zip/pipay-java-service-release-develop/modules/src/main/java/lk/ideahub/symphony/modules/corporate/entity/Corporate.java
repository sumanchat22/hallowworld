package lk.ideahub.symphony.modules.corporate.entity;

import java.util.Date;
import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;

@Entity
@Table(name = "corporates")
@NamedQueries({
        @NamedQuery(name = "Corporate.find", query = "select cop from Corporate cop" +
                "  where" +
                "    (:name is null or cop.name = :name)" +
                "    and (:isStandard is null or cop.isStandard = :isStandard )")})

public class Corporate extends AbstractEntity {

        // ### ORACLE CHANGE :  ADD SEQUENCE ###
        @Id
        @SequenceGenerator(name="generator", sequenceName="CORPORATES_CORPORATE_ID_SEQ",allocationSize=1)
        @GeneratedValue(generator = "generator")
        @Column(name = "corporate_id")
        private Long corporateId;

        @Column(name = "name")
        private String name;

        @Column(name = "description")
        private String description;

        @Column(name = "brc")
        private String brc;

        @Column(name = "date_incorporation")
        private Date dateIncorporation;

        @Column(name = "first_name")
        private String firstName;

        @Column(name = "last_name")
        private String lastName;

        @Column(name = "email")
        private String email;

        @Column(name = "corporate_type_id")
        private Long corporateTypeId;

        @Column(name = "street_line_1")
        private String streetLine1;

        @Column(name = "street_line_2")
        private String streetLine2;

        @Column(name = "city")
        private String city;

        @Column(name = "state_province")
        private String stateProvince;

        @Column(name = "postal_code")
        private String postalCode;

        @Column(name = "country")
        private String country;

        @Column(name = "phone_1")
        private String phone1;

        @Column(name = "phone_2")
        private String phone2;

        @Column(name = "logo")
        private String logo;

        @Column(name = "uuid")
        private String uuid;

        @Column(name = "is_standard")
        private String isStandard;

        @Column(name = "enterprise_id")
        private Long enterpriseId;

        @Column(name = "primary_admin_id")
        private Long primaryAdminId;

        @Column(name = "corporate_status_id")
        private Long corporateStatusId;

        @Column(name = "corporate_parent_id")
        private Long corporateParentId;

        public Long getCorporateId() {
                return corporateId;
        }

        public void setCorporateId(Long corporateId) {
                this.corporateId = corporateId;
        }

        public String getName() {
                return name;
        }

        public void setName(String name) {
                this.name = name;
        }

        public String getDescription() {
                return description;
        }

        public void setDescription(String description) {
                this.description = description;
        }

        public String getBrc() {
                return brc;
        }

        public void setBrc(String brc) {
                this.brc = brc;
        }

        public Date getDateIncorporation() {
                return dateIncorporation;
        }

        public void setDateIncorporation(Date dateIncorporation) {
                this.dateIncorporation = dateIncorporation;
        }

        public String getFirstName() {
                return firstName;
        }

        public void setFirstName(String firstName) {
                this.firstName = firstName;
        }

        public String getLastName() {
                return lastName;
        }

        public void setLastName(String lastName) {
                this.lastName = lastName;
        }

        public String getEmail() {
                return email;
        }

        public void setEmail(String email) {
                this.email = email;
        }

        public Long getCorporateTypeId() {
                return corporateTypeId;
        }

        public void setCorporateTypeId(Long corporateTypeId) {
                this.corporateTypeId = corporateTypeId;
        }

        public String getStreetLine1() {
                return streetLine1;
        }

        public void setStreetLine1(String streetLine1) {
                this.streetLine1 = streetLine1;
        }

        public String getStreetLine2() {
                return streetLine2;
        }

        public void setStreetLine2(String streetLine2) {
                this.streetLine2 = streetLine2;
        }

        public String getCity() {
                return city;
        }

        public void setCity(String city) {
                this.city = city;
        }

        public String getStateProvince() {
                return stateProvince;
        }

        public void setStateProvince(String stateProvince) {
                this.stateProvince = stateProvince;
        }

        public String getPostalCode() {
                return postalCode;
        }

        public void setPostalCode(String postalCode) {
                this.postalCode = postalCode;
        }

        public String getCountry() {
                return country;
        }

        public void setCountry(String country) {
                this.country = country;
        }

        public String getPhone1() {
                return phone1;
        }

        public void setPhone1(String phone1) {
                this.phone1 = phone1;
        }

        public String getPhone2() {
                return phone2;
        }

        public void setPhone2(String phone2) {
                this.phone2 = phone2;
        }

        public String getLogo() {
                return logo;
        }

        public void setLogo(String logo) {
                this.logo = logo;
        }

        public String getUuid() {
                return uuid;
        }

        public void setUuid(String uuid) {
                this.uuid = uuid;
        }

        public String getIsStandard() {
                return isStandard;
        }

        public void setIsStandard(String isStandard) {
                this.isStandard = isStandard;
        }

        public Long getEnterpriseId() {
                return enterpriseId;
        }

        public void setEnterpriseId(Long enterpriseId) {
                this.enterpriseId = enterpriseId;
        }

        public Long getPrimaryAdminId() {
                return primaryAdminId;
        }

        public void setPrimaryAdminId(Long primaryAdminId) {
                this.primaryAdminId = primaryAdminId;
        }

        public Long getCorporateStatusId() {
                return corporateStatusId;
        }

        public void setCorporateStatusId(Long corporateStatusId) {
                this.corporateStatusId = corporateStatusId;
        }

        public Long getCorporateParentId() {
                return corporateParentId;
        }

        public void setCorporateParentId(Long corporateParentId) {
                this.corporateParentId = corporateParentId;
        }


        @Override
        public String toString() {
                final StringBuilder sb = new StringBuilder("Corporate{");
                sb.append("corporateId=").append(corporateId);
                sb.append(", name='").append(name).append('\'');
                sb.append(", description='").append(description).append('\'');
                sb.append(", brc='").append(brc).append('\'');
                sb.append(", dateIncorporation=").append(dateIncorporation);
                sb.append(", firstName='").append(firstName).append('\'');
                sb.append(", lastName='").append(lastName).append('\'');
                sb.append(", email='").append(email).append('\'');
                sb.append(", corporateTypeId=").append(corporateTypeId);
                sb.append(", streetLine1='").append(streetLine1).append('\'');
                sb.append(", streetLine2='").append(streetLine2).append('\'');
                sb.append(", city='").append(city).append('\'');
                sb.append(", stateProvince='").append(stateProvince).append('\'');
                sb.append(", postalCode='").append(postalCode).append('\'');
                sb.append(", country='").append(country).append('\'');
                sb.append(", phone1='").append(phone1).append('\'');
                sb.append(", phone2='").append(phone2).append('\'');
                sb.append(", logo='").append(logo).append('\'');
                sb.append(", uuid='").append(uuid).append('\'');
                sb.append(", isStandard='").append(isStandard).append('\'');
                sb.append(", enterpriseId=").append(enterpriseId);
                sb.append(", primaryAdminId=").append(primaryAdminId);
                sb.append(", corporateStatusId=").append(corporateStatusId);
                sb.append(", corporateParentId=").append(corporateParentId);
                sb.append('}');
                return sb.toString();
        }
}
