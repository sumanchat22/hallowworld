package lk.ideahub.symphony.modules.casa.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.types.entity.Bank;
import lk.ideahub.symphony.modules.types.entity.BankBranch;

import javax.persistence.*;

@Entity
@Table(name = "customer_casa_accounts")
/*
@NamedQueries({
        @NamedQuery(name = "CustomerCasaAccount.find", query = "select cca from CustomerCasaAccount cca" +
                "  where" +
                "    (:name is null or cca.name = :name)")})
*/

@NamedNativeQueries({
        @NamedNativeQuery(name = "CustomerCasaAccount.findAccount", query = "select * from customer_casa_accounts cca "+
                " where cca.customer_id = :customerId" +
                " and" +
                " cca.customer_payment_option_id = :customerPaymentOptionId"+
                " order by"+
                " cca.created_datetime desc"),

        @NamedNativeQuery(name = "CustomerCasaAccount.findByCustomerPaymentOptionId", query = "select * from customer_casa_accounts cca "+
                " where cca.customer_payment_option_id = :customerPaymentOptionId"+
                " order by"+
                " cca.created_datetime desc")
})

public class CustomerCasaAccount extends AbstractEntity
{
    @Id
    @SequenceGenerator(name="generator", sequenceName="CUSTOMER_CASA_ACCOUNTS_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "customer_casa_account_id")
    private Long customerCasaAccountId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "customer_payment_option_id")
    private Long customerPaymentOptionId;

    @Column(name = "customer_token")
    private String customerToken;

    @Column(name = "reference_id")
    private String referenceId;

    @Column(name = "account_reference")
    private String accountReference;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "is_deleted")
    private String isDeleted;

    @ManyToOne
    @JoinColumn(name = "bank_id")
    private Bank bank;

    @ManyToOne
    @JoinColumn(name = "bank_branch_id")
    private BankBranch bankBranch;

    @Column(name = "device_id")
    private String deviceId;

    public Long getCustomerCasaAccountId() { return customerCasaAccountId; }

    public void setCustomerCasaAccountId(Long customerCasaAccountId) { this.customerCasaAccountId = customerCasaAccountId; }

    public Long getCustomerId() { return customerId; }

    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public Long getCustomerPaymentOptionId() { return customerPaymentOptionId; }

    public void setCustomerPaymentOptionId(Long customerPaymentOptionId) { this.customerPaymentOptionId = customerPaymentOptionId; }

    public String getCustomerToken() { return customerToken; }

    public void setCustomerToken(String customerToken) { this.customerToken = customerToken; }

    public String getReferenceId() { return referenceId; }

    public void setReferenceId(String referenceId) { this.referenceId = referenceId; }

    public String getAccountReference() { return accountReference; }

    public void setAccountReference(String accountReference) { this.accountReference = accountReference; }

    public String getAccountNumber() { return accountNumber; }

    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getBankName() { return bankName; }

    public void setBankName(String bankName) { this.bankName = bankName; }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public BankBranch getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(BankBranch bankBranch) {
        this.bankBranch = bankBranch;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    @Override
    public String toString() {
        return new StringBuilder("CustomerCasaAccount {")
                .append("customerCasaAccountId=").append(customerCasaAccountId).append(", ")
                .append("customerId=").append(customerId).append(", ")
                .append("customerPaymentOptionId=").append(customerPaymentOptionId).append(", ")
                .append("customerToken='").append(customerToken).append("'").append(", ")
                .append("referenceId='").append(referenceId).append("'").append(", ")
                .append("accountReference='").append(accountReference).append("'").append(", ")
                .append("accountNumber='").append(accountNumber).append("'").append(", ")
                .append("bankName='").append(bankName).append("'").append(", ")
                .append("isDeleted='").append(isDeleted).append("'").append(", ")
                .append("bank=").append(bank).append(", ")
                .append("bankBranch=").append(bankBranch).append(", ")
                .append("deviceId='").append(deviceId).append("'")
                .append('}').toString();
    }
}
