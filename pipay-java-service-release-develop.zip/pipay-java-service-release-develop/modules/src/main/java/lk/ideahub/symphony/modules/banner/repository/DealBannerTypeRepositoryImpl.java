package lk.ideahub.symphony.modules.banner.repository;

import lk.ideahub.symphony.modules.banner.entity.DealBannerType;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Calendar;
import java.util.List;

@Repository
class DealBannerTypeRepositoryImpl extends GenericRepository implements DealBannerTypeRepository {

    private static final Logger log = LoggerFactory.getLogger(DealBannerTypeRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public DealBannerType get(final Object _dealBannerTypeId, final ServiceContext _serviceContext) {
        return entityManager.find(DealBannerType.class, _dealBannerTypeId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<DealBannerType> find(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("DealBannerType.find");
        query.setParameter("name", _dealBannerType.getName());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        _dealBannerType.setCreatedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_dealBannerType);
        entityManager.flush();
    }

    @Override
    public DealBannerType update(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        _dealBannerType.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_dealBannerType);
    }

    @Override
    public void delete(final DealBannerType _dealBannerType, final ServiceContext _serviceContext) {
        entityManager.remove(_dealBannerType);
    }
}
