package lk.ideahub.symphony.modules.casa.repository;

import lk.ideahub.symphony.modules.casa.entity.CustomerCasaAccount;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
class CustomerCasaAccountRepositoryImpl extends GenericRepository implements CustomerCasaAccountRepository {

    private static final Logger log = LoggerFactory.getLogger(CustomerCasaAccountRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CustomerCasaAccount get(final Object _customerCasaAccountId, final ServiceContext _serviceContext) {
        return entityManager.find(CustomerCasaAccount.class, _customerCasaAccountId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CustomerCasaAccount> find(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CustomerCasaAccount.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        _customerCasaAccount.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        _customerCasaAccount.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_customerCasaAccount);
        entityManager.flush();
    }

    @Override
    public CustomerCasaAccount update(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        _customerCasaAccount.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_customerCasaAccount);
    }

    @Override
    public void delete(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        entityManager.remove(_customerCasaAccount);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> findAccount(CustomerCasaAccount _customerCasaAccount, ServiceContext _serviceContext)
    {
        Query query = entityManager.createNamedQuery("CustomerCasaAccount.findAccount");
        query.setParameter("customerId", _customerCasaAccount.getCustomerId());
        query.setParameter("customerPaymentOptionId", _customerCasaAccount.getCustomerPaymentOptionId());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> findByCustomerPaymentOptionId(CustomerCasaAccount _customerCasaAccount, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CustomerCasaAccount.findByCustomerPaymentOptionId");
        query.setParameter("customerPaymentOptionId", _customerCasaAccount.getCustomerPaymentOptionId());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }
}
