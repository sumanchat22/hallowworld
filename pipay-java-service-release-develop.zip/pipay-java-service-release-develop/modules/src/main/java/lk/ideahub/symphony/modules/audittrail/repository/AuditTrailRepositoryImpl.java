package lk.ideahub.symphony.modules.audittrail.repository;

import lk.ideahub.symphony.modules.audittrail.entity.AuditTrail;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
class AuditTrailRepositoryImpl extends GenericRepository implements AuditTrailRepository {

    private static final Logger log = LoggerFactory.getLogger(AuditTrailRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;


    @Override
    public void add(final AuditTrail auditTrail, final ServiceContext _serviceContext) {

        if (auditTrail.getRequestDetail().length() > 1000) {
            auditTrail.setRequestDetail(auditTrail.getRequestDetail().substring(0, 1000));
        }
        if (auditTrail.getResponseMessage().length() > 1000){
            auditTrail.setResponseMessage(auditTrail.getResponseMessage().substring(0, 1000));
        }
    	auditTrail.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(auditTrail);
        entityManager.flush();
    }

    
}
