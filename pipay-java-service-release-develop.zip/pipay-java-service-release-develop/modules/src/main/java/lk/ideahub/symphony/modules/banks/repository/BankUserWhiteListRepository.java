package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BankTransferType;
import lk.ideahub.symphony.modules.banks.entity.BankUserWhiteList;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 06-Jan-2022
 */

public interface BankUserWhiteListRepository {

    List<Object[]> getUserWhiteListByBankId(final Object banksId, final Object bankStatusId, final ServiceContext serviceContext);

}
