package lk.ideahub.symphony.modules.audittrail.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.audittrail.entity.AuditTrail;
import lk.ideahub.symphony.modules.audittrail.repository.AuditTrailRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class AuditTrailServiceImpl extends GenericService implements AuditTrailService {

    private static final Logger log = LoggerFactory.getLogger(AuditTrailServiceImpl.class);

    @Autowired
    private AuditTrailRepository repository;

    

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final AuditTrail auditTrail, final ServiceContext _serviceContext) {
        repository.add(auditTrail, _serviceContext);
    }

  
}
