package lk.ideahub.symphony.modules.banner.repository;

import lk.ideahub.symphony.modules.banner.entity.Banner;
import lk.ideahub.symphony.modules.banner.entity.BannerSlide;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Calendar;
import java.util.List;

@Repository
class BannerRepositoryImpl extends GenericRepository implements BannerRepository {

    private static final Logger log = LoggerFactory.getLogger(BannerRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public Banner get(final Object _bannerId, final ServiceContext _serviceContext) {
        return entityManager.find(Banner.class, _bannerId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Banner> find(final Banner _banner, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("Banner.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final Banner _banner, final ServiceContext _serviceContext) {
        _banner.setCreatedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_banner);
        entityManager.flush();
    }

    @Override
    public Banner update(final Banner _banner, final ServiceContext _serviceContext) {
        _banner.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_banner);
    }

    @Override
    public void delete(final Banner _banner, final ServiceContext _serviceContext) {
        entityManager.remove(_banner);
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<Banner> getListFromDealBannerType(String bannerType) {
		Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(Banner.class);
        criteria.createAlias("dealBannerType", "dbt",JoinType.INNER_JOIN);
        criteria.add(Restrictions.eq("dbt.name", bannerType));
        criteria.add(Restrictions.eq("isActive", Constants.DB_TRUE));
        
        /*if(serviceContext.getPageStart() != null && serviceContext.getPageEnd() != null) {
        	criteria.setFirstResult(serviceContext.getPageStart());
        	criteria.setMaxResults(serviceContext.getPageEnd());
        }*/
        
		return criteria.list();
	}
}
