package lk.ideahub.symphony.modules.casa.service;

import java.util.List;

import lk.ideahub.symphony.modules.casa.entity.CASAEnabledDevice;
import lk.ideahub.symphony.modules.casa.repository.CASAEnabledDeviceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CASAEnabledDeviceServiceImpl extends GenericService implements CASAEnabledDeviceService {

    private static final Logger log = LoggerFactory.getLogger(CASAEnabledDeviceServiceImpl.class);

    @Autowired
    private CASAEnabledDeviceRepository repository;

    @Override
    public CASAEnabledDevice get(final Object _casaEnabledDeviceId, final ServiceContext _serviceContext) {
        return repository.get(_casaEnabledDeviceId, _serviceContext);
    }

    @Override
    public List<CASAEnabledDevice> find(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        return repository.find(_casaEnabledDevice, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        repository.add(_casaEnabledDevice, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        repository.update(_casaEnabledDevice, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        repository.delete(_casaEnabledDevice, _serviceContext);
    }
}
