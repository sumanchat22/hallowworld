package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.BankUserWhiteList;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 06-Jan-2022
 */

public interface BankUserWhiteListService {

    List<Integer> getUserWhiteListByBankId(final Object banksId, final Object bankStatusId, final ServiceContext serviceContext);

}
