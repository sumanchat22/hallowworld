package lk.ideahub.symphony.modules.casa.repository;

import java.util.List;

import lk.ideahub.symphony.modules.casa.entity.CASARegistrationDetails;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface CASARegistrationDetailsRepository {

    CASARegistrationDetails get(final Object __casaRegistrationDetailsId, final ServiceContext _serviceContext);

    List<CASARegistrationDetails> find(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext);

    void add(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext);

    CASARegistrationDetails update(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext);

    void delete(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext);
}
