package lk.ideahub.symphony.modules.banner.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "appl_deal_banner_types")
@NamedQueries({
        @NamedQuery(name = "DealBannerType.find", query = "select dbt from DealBannerType dbt" +
                "  where" +
                "    (:name is null or dbt.name = :name)")})
@Cacheable
@Getter
@Setter
@ToString
public class DealBannerType extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="APPL_DEAL_BANNER_TYPE_SQ1",allocationSize=1)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "deal_banner_type_id")
    private Long dealBannerTypeId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;
    /**
     * Enumeration of DealBannerType values.
     */
    public static enum Value {

        HOME_BANNER("Home Banner");

        private String name;

        private Value(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public DealBannerType getDealBannerType() {
            DealBannerType dealBannerType = new DealBannerType();
            dealBannerType.setName(this.name);

            return dealBannerType;
        }

        public static Value getByName(String name) {
            for (Value value : values()) {
                if (value.getName().equals(name)) {
                    return value;
                }
            }
            throw new AssertionError("DealBannerType value not found for given name [name: " + name + "]");
        }
    }
}
