package lk.ideahub.symphony.modules.amex.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;

import javax.persistence.*;

@Entity
@Table(name = "customer_amex_cards")
/*@NamedQueries({
        @NamedQuery(name = "CustomerAmexCard.find", query = "select ? from CustomerAmexCard ?" +
                "  where" +
                "    (:name is null or ?.name = :name)")})*/

@NamedNativeQueries({
        @NamedNativeQuery(name = "CustomerAmexCard.findByCustomerId" , query = "select * from customer_amex_cards cc "+
                " where cc.customer_id = :customerId" +
                " order by"+
                " cc.created_datetime desc"),

        @NamedNativeQuery(name = "CustomerAmexCard.findCard" , query = "select * from customer_amex_cards cc "+
                " where cc.customer_id = :customerId" +
                " and" +
                " cc.customer_payment_option_id = :customerPaymentOptionId"+
                " order by"+
                " cc.created_datetime desc"),


         @NamedNativeQuery(name = "CustomerAmexCard.findByCustomerPaymentOptionId", query = "select cac.customer_amex_card_id, cac.customer_payment_option_id" +
                " from customer_amex_cards cac" +
                " where cac.customer_payment_option_id = :customerPaymentOptionId")
})

public class CustomerAmexCard extends AbstractEntity {

    @Id
    @SequenceGenerator(name = "generator", sequenceName = "CUSTOMER_AMEX_CARD_SQ1", allocationSize = 1)
    @GeneratedValue(generator = "generator")
    @Column(name = "customer_amex_card_id")
    private Long customerAmexCardId;

    @Column(name = "customer_payment_option_id")
    private Long customerPaymentOptionId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "security_token")
    private String securityToken;


    public Long getCustomerAmexCardId() {
        return customerAmexCardId;
    }

    public void setCustomerAmexCardId(Long customerAmexCardId) {
        this.customerAmexCardId = customerAmexCardId;
    }

    public Long getCustomerPaymentOptionId() {
        return customerPaymentOptionId;
    }

    public void setCustomerPaymentOptionId(Long customerPaymentOptionId) {
        this.customerPaymentOptionId = customerPaymentOptionId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getSecurityToken() {
        return securityToken;
    }

    public void setSecurityToken(String securityToken) {
        this.securityToken = securityToken;
    }

    @Override
    public String toString() {
        return new StringBuilder("CustomerAmexCard {")
                .append("customerAmexCardId=").append(customerAmexCardId).append(", ")
                .append("customerPaymentOptionId=").append(customerPaymentOptionId).append(", ")
                .append("customerId=").append(customerId).append(", ")
                .append("securityToken='").append(securityToken).append("'")
                .append('}').toString();
    }
}
