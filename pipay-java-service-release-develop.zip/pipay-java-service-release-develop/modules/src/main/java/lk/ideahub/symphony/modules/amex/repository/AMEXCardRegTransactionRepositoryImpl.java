package lk.ideahub.symphony.modules.amex.repository;

import lk.ideahub.symphony.modules.amex.entity.AMEXCardRegTransaction;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
class AMEXCardRegTransactionRepositoryImpl extends GenericRepository implements AMEXCardRegTransactionRepository {

    private static final Logger log = LoggerFactory.getLogger(AMEXCardRegTransactionRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public AMEXCardRegTransaction get(final Object _amexCardRegTransactionId, final ServiceContext _serviceContext) {
        return entityManager.find(AMEXCardRegTransaction.class, _amexCardRegTransactionId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<AMEXCardRegTransaction> find(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("AMEXCardRegTransaction.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        _amexCardRegTransaction.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_amexCardRegTransaction);
        entityManager.flush();
    }

    @Override
    public AMEXCardRegTransaction update(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        _amexCardRegTransaction.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_amexCardRegTransaction);
    }

    @Override
    public void delete(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        entityManager.remove(_amexCardRegTransaction);
    }

    @Override
    public List<Object[]> findByCustomerId(AMEXCardRegTransaction _amexCardRegTransaction, ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("AMEXCardRegTransaction.findByCustomerId");
        query.setParameter("customerId",_amexCardRegTransaction.getCustomerId());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }
}
