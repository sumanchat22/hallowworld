package lk.ideahub.symphony.modules.beacon.repository;

import java.util.List;

import lk.ideahub.symphony.modules.beacon.entity.BeaconNotification;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface BeaconNotificationRepository {

    BeaconNotification get(final Object _beaconNotificationId, final ServiceContext _serviceContext);

    List<Object[]> findFromBeaconId(final List _beaconIdList, final ServiceContext _serviceContext);

    List<BeaconNotification> find(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    List<Object> findIds(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    void add(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    BeaconNotification update(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    void delete(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);
}
