package lk.ideahub.symphony.modules.casa.service;

import lk.ideahub.symphony.modules.casa.entity.CargillsCasaRequestResponseDetails;
import lk.ideahub.symphony.modules.casa.repository.CargillsCasaRequestResponseDetailsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CargillsCasaRequestResponseDetailsServiceImpl extends GenericService implements CargillsCasaRequestResponseDetailsService {

    private static final Logger log = LoggerFactory.getLogger(CargillsCasaRequestResponseDetailsServiceImpl.class);

    @Autowired
    private CargillsCasaRequestResponseDetailsRepository repository;

    @Override
    public CargillsCasaRequestResponseDetails get(final Object _CargillsCasaRequestResponseDetailsServiceId, final ServiceContext _serviceContext) {
        return repository.get(_CargillsCasaRequestResponseDetailsServiceId, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetailsService, final ServiceContext _serviceContext) {
        repository.add(_CargillsCasaRequestResponseDetailsService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetailsService, final ServiceContext _serviceContext) {
        repository.update(_CargillsCasaRequestResponseDetailsService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetailsService, final ServiceContext _serviceContext) {
        repository.delete(_CargillsCasaRequestResponseDetailsService, _serviceContext);
    }
}
