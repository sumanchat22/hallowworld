package lk.ideahub.symphony.modules.amex.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;

import javax.persistence.*;

@Entity
@Table(name = "amex_integration_responses")
/*@NamedQueries({
        @NamedQuery(name = "AMEXIntegrationResponse.find", query = "select ? from AMEXIntegrationResponse ?" +
                "  where" +
                "    (:name is null or ?.name = :name)")})*/

public class AMEXIntegrationResponse extends AbstractEntity {

    @Id
    @SequenceGenerator(name = "generator", sequenceName = "AMEX_INTEGRATION_RESPONSE_SQ1", allocationSize = 1)
    @GeneratedValue(generator = "generator")
    @Column(name = "amex_integration_response_id")
    private Long amexIntegrationResponseId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "response")
    private Long response;


    public Long getAmexIntegrationResponseId() {
        return amexIntegrationResponseId;
    }

    public void setAmexIntegrationResponseId(Long amexIntegrationResponseId) {
        this.amexIntegrationResponseId = amexIntegrationResponseId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getResponse() {
        return response;
    }

    public void setResponse(Long response) {
        this.response = response;
    }

    @Override
    public String toString() {
        return new StringBuilder("AMEXIntegrationResponse {")
                .append("amexIntegrationResponseId=").append(amexIntegrationResponseId).append(", ")
                .append("customerId=").append(customerId).append(", ")
                .append("response=").append(response)
                .append('}').toString();
    }
}
