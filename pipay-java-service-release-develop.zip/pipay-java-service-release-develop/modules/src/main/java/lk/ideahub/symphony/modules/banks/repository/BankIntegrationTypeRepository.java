package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BankIntegrationType;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 16-Dec-2021
 */

public interface BankIntegrationTypeRepository {
    BankIntegrationType get(final Object bankIntegrationTypeId, final ServiceContext serviceContext);

    List<BankIntegrationType> find(final BankIntegrationType bankIntegrationType, final ServiceContext serviceContext);

    void add(final BankIntegrationType bankIntegrationType, final ServiceContext serviceContext);

    BankIntegrationType update(final BankIntegrationType bankIntegrationType, final ServiceContext serviceContext);

    void delete(final BankIntegrationType bankIntegrationType, final ServiceContext serviceContext);

    List<BankIntegrationType> getBankIntegrationTypeList(final BankIntegrationType bankIntegrationType, final ServiceContext serviceContext);
}
