package lk.ideahub.symphony.modules.casa.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;

@Entity
@Table(name = "casa_registration_details")
@NamedQueries({
        @NamedQuery(name = "CASARegistrationDetails.find", query = "select crd from CASARegistrationDetails crd" +
                "  where" +
                "    (:referenceId is null or crd.referenceId = :referenceId)")})
public class CASARegistrationDetails extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="CASA_REGISTRATION_DETAILS_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "casa_registration_details_id")
    private Long casaRegistrationDetailsId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "bank_code")
    private String bankCode;

    @Column(name = "branch_code")
    private String branchCode;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "card_alias")
    private String cardAlias;

    @Column(name = "reference_id")
    private String referenceId;

    @Column(name = "device_id")
    private String deviceId;

    @Column(name = "platform")
    private String platform;

    public Long getCasaRegistrationDetailsId() {
        return casaRegistrationDetailsId;
    }

    public void setCasaRegistrationDetailsId(Long casaRegistrationDetailsId) {
        this.casaRegistrationDetailsId = casaRegistrationDetailsId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getCardAlias() {
        return cardAlias;
    }

    public void setCardAlias(String cardAlias) {
        this.cardAlias = cardAlias;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    @Override
    public String toString() {
        return new StringBuilder("CASARegistrationDetails {")
                .append("casaRegistrationDetailsId=").append(casaRegistrationDetailsId).append(", ")
                .append("customerId=").append(customerId).append(", ")
                .append("bankCode='").append(bankCode).append("'").append(", ")
                .append("branchCode='").append(branchCode).append("'").append(", ")
                .append("accountNumber='").append(accountNumber).append("'").append(", ")
                .append("cardAlias='").append(cardAlias).append("'").append(", ")
                .append("referenceId='").append(referenceId).append("'").append(", ")
                .append("deviceId='").append(deviceId).append("'").append(", ")
                .append("platform='").append(platform).append("'")
                .append('}').toString();
    }
}
