package lk.ideahub.symphony.modules.beacon.service;

import java.util.List;

import lk.ideahub.symphony.modules.beacon.entity.BeaconNotification;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface BeaconNotificationService {

    BeaconNotification get(final Object _beaconNotificationId, final ServiceContext _serviceContext);

    List<BeaconNotification> findFromBeaconId(final List _beaconIdList, final ServiceContext _serviceContext);

    List<BeaconNotification> find(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    void add(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    void update(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);

    void delete(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext);
}
