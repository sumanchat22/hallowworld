package lk.ideahub.symphony.modules.amex.service;

import lk.ideahub.symphony.modules.amex.entity.CustomerAmexCard;
import lk.ideahub.symphony.modules.amex.repository.CustomerAmexCardRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CustomerAmexCardServiceImpl extends GenericService implements CustomerAmexCardService {

    private static final Logger log = LoggerFactory.getLogger(CustomerAmexCardServiceImpl.class);

    @Autowired
    private CustomerAmexCardRepository repository;

    @Override
    public CustomerAmexCard get(final Object _customerAmexCardId, final ServiceContext _serviceContext) {
        return repository.get(_customerAmexCardId, _serviceContext);
    }

    @Override
    public List<CustomerAmexCard> find(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        return repository.find(_customerAmexCard, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        repository.add(_customerAmexCard, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        repository.update(_customerAmexCard, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext) {
        repository.delete(_customerAmexCard, _serviceContext);
    }

    @Override
    public List<CustomerAmexCard> findByCustomerId(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findByCustomerId(_customerAmexCard, _serviceContext);

        List<CustomerAmexCard> customerAmexCards = new ArrayList<CustomerAmexCard>(resultList.size());
        if (resultList.size() > 0) {
            CustomerAmexCard customerAmexCard = null;
            for (Object[] row : resultList) {
                Long customerAmexCardId = Long.valueOf(row[0].toString());
                customerAmexCard = repository.get(customerAmexCardId, _serviceContext);

                customerAmexCards.add(customerAmexCard);
            }
        }

        return customerAmexCards;
    }

    @Override
    public List<CustomerAmexCard> findCard(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findCard(_customerAmexCard, _serviceContext);

        List<CustomerAmexCard> customerAmexCards = new ArrayList<CustomerAmexCard>(resultList.size());
        if (resultList.size() > 0) {
            CustomerAmexCard customerAmexCard = null;
            for (Object[] row : resultList) {
                Long customerAmexCardId = Long.valueOf(row[0].toString());
                customerAmexCard = repository.get(customerAmexCardId, _serviceContext);

                customerAmexCards.add(customerAmexCard);
            }
        }

        return customerAmexCards;
    }

    @Override
    public List<CustomerAmexCard> findByCustomerPaymentOptionId(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext)
    {
        List<Object[]> resultList = repository.findByCustomerPaymentOptionId(_customerAmexCard, _serviceContext);

        List<CustomerAmexCard> customerAmexCards = new ArrayList<CustomerAmexCard>(resultList.size());
        if (resultList.size() > 0) {
            CustomerAmexCard customerAmexCard = null;
            for (Object[] row : resultList) {
                Long customerAmexCardId = Long.valueOf(row[0].toString());
                customerAmexCard = repository.get(customerAmexCardId, _serviceContext);

                customerAmexCards.add(customerAmexCard);
            }
        }

        return customerAmexCards;
    }

}
