package lk.ideahub.symphony.modules.banner.repository;

import lk.ideahub.symphony.modules.banner.entity.BannerSlide;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface BannerSlideRepository {

    BannerSlide get(final Object _bannerSlideId, final ServiceContext _serviceContext);

    List<BannerSlide> find(final BannerSlide _bannerSlide, final ServiceContext _serviceContext);

    void add(final BannerSlide _bannerSlide, final ServiceContext _serviceContext);

    BannerSlide update(final BannerSlide _bannerSlide, final ServiceContext _serviceContext);

    void delete(final BannerSlide _bannerSlide, final ServiceContext _serviceContext);

    List<Object[]> findBannerSlide(BannerSlide _bannerSlideFind, ServiceContext _serviceContext);
    
    List<BannerSlide> getBannerSlidesForABanner(Long bannerId);
}
