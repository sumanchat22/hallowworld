package lk.ideahub.symphony.modules.counter.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import lk.ideahub.symphony.modules.counter.entity.OutletCounter;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class OutletCounterRepositoryImpl extends GenericRepository implements OutletCounterRepository {

    private static final Logger log = LoggerFactory.getLogger(OutletCounterRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public OutletCounter get(final Object _outletCounterId, final ServiceContext _serviceContext) {
        return entityManager.find(OutletCounter.class, _outletCounterId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<OutletCounter> find(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("OutletCounter.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        _outletCounter.setCreatedDatetime(Calendar.getInstance().getTime());
        _outletCounter.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_outletCounter);
        entityManager.flush();
    }

    @Override
    public OutletCounter update(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        _outletCounter.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_outletCounter);
    }

    @Override
    public void delete(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        entityManager.remove(_outletCounter);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> findValidCounter(OutletCounter _outletCounter, ServiceContext _serviceContext)
    {
        Query query = entityManager.createNamedQuery("OutletCounter.findValidCounter");

        query.setParameter("outletCounterTypeId", _outletCounter.getOutletCounterType());
        //query.setParameter("outletCounterStatusId", _outletCounter.getOutletCounterStatusId());
        query.setParameter("counterReference", _outletCounter.getCounterReference());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

	@Override
	public OutletCounter getByExternalId(Long externalId, ServiceContext serviceContext) {
		try {
			Session session = entityManager.unwrap(Session.class);
	        Criteria criteria = session.createCriteria(OutletCounter.class);
	        criteria.add(Restrictions.eq("externalReferenceId",externalId));
	        return (OutletCounter) criteria.uniqueResult();
		}
		catch(Exception ex) {
			return null;
		}
	}

    @Override
    @SuppressWarnings("unchecked")
    public List<OutletCounter> findByOutletCounterId(final OutletCounter outletCounter, final ServiceContext _serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(OutletCounter.class);
        criteria.add(Restrictions.eq("outletCounterId",outletCounter.getOutletCounterId()));
        return criteria.list();
    }

}
