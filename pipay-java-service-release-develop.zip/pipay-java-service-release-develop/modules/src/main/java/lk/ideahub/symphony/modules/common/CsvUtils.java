package lk.ideahub.symphony.modules.common;

import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import com.amazonaws.services.s3.model.PutObjectResult;


@Component
public class CsvUtils {
	
	private static final Logger log = LoggerFactory.getLogger(CsvUtils.class);
	
	@Autowired
	FileUploaderEngine fileUploaderEngine;
	
	@Autowired
    private Environment environment;
	
	private DateFormat dateFormatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
	private final static String BUCKET_FOLDER = "reports/";

	public CSVPrinter initCsvFile(StringBuilder sb, List<String> headers,List<String> titleData){
		try {
			CSVPrinter csvPrinter = new CSVPrinter(sb, CSVFormat.DEFAULT);
			csvPrinter.printRecord(titleData);
			csvPrinter.println();
			csvPrinter.printRecord(headers);

			return csvPrinter;
		}
		catch(Exception ex) {
			log.error("CsvUtils - initCsvFile() error:" + ex.getMessage());
		}
		return null;
	} 
	
	public void addRecords(CSVPrinter csvPrinter,List<? extends Object> dataList,List<String> fieldList,Integer lastRecordId) throws Exception{
		for(Object obj : dataList) {
			List<String> row = new ArrayList<String>();
			if(lastRecordId != null) {// if records id exists add it by incrementing 
				lastRecordId++;
				row.add(lastRecordId.toString());
			}
			for(String field : fieldList) {
				row.add(getFieldValue(obj,field));
			}
			csvPrinter.printRecord(row);
		}
	}
	
	public String uploadFile(StringBuilder sb,String filePrefix,CSVPrinter csvPrinter,Date date) throws Exception{
			csvPrinter.flush();//generate csv string
			
			String bucket = environment.getProperty("s3.bucket.private");
			String fileName = BUCKET_FOLDER + filePrefix + "-" + dateFormatter.format(date) + ".csv";
			
			byte[] bytes = sb.toString().getBytes();
			InputStream inputStream = new ByteArrayInputStream(bytes);
			
			//upload to S3 bucket
			PutObjectResult result = fileUploaderEngine.uploadDocument(inputStream, bucket, fileName);
			if(result != null) {
				return fileName;
			}
			return null;
	}
	
	private String getFieldValue(Object obj, String fieldName){
		PropertyDescriptor pd;
		try {
			pd = new PropertyDescriptor(fieldName, obj.getClass());
			Object result = pd.getReadMethod().invoke(obj);
			if(result != null) {
				return result.toString();
			}
		} catch(Exception ex) {
			log.error("CsvUtils - getFieldValue() error:" + ex.getMessage());
		}
		return "";
	}
}
