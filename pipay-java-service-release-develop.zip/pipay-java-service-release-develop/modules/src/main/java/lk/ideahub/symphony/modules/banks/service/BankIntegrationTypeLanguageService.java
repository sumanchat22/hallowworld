package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.BankIntegrationTypeLanguage;
import lk.ideahub.symphony.modules.banks.entity.BanksLanguage;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

public interface BankIntegrationTypeLanguageService {
    BankIntegrationTypeLanguage get(final Object bankIntegrationTypeLanguageId, final ServiceContext serviceContext);

    List<BankIntegrationTypeLanguage> find(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext);

    void add(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext);

    void update(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext);

    void delete(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage, final ServiceContext serviceContext);

    List<BankIntegrationTypeLanguage> getText(final BankIntegrationTypeLanguage bankIntegrationTypeLanguage);
}
