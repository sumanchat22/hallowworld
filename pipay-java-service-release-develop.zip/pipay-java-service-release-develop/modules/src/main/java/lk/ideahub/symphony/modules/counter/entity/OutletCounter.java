package lk.ideahub.symphony.modules.counter.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.types.entity.OutletCounterStatus;
import lk.ideahub.symphony.modules.types.entity.OutletCounterType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "outlet_counters")
@NamedQueries({
        @NamedQuery(name = "OutletCounter.find", query = "select oc from OutletCounter oc" +
                "  where" +
                "    (:name is null or oc.name = :name)")})
@NamedNativeQueries({

        @NamedNativeQuery(name = "OutletCounter.findActiveCounter", query = "select oc.outlet_counter_id, oc.name" +
                "  from outlet_counters oc" +
                "  where" +
                "    oc.outlet_counter_id = :outletCounterId" +
                "    and oc.outlet_counter_status_id = :outletCounterStatusId"),

        @NamedNativeQuery(name = "OutletCounter.findValidCounter", query = "select oc.outlet_counter_id, oc.name" +
                "  from outlet_counters oc" +
                "  where" +
                "    oc.outlet_counter_type_id = :outletCounterTypeId" +
                //"    and oc.outlet_counter_status_id = :outletCounterStatusId" +
                "    and " +
                "    (oc.phone = :counterReference" +
                "    or " +
                "    oc.terminal_id = :counterReference)")
})
@Getter
@Setter
@ToString
public class OutletCounter extends AbstractEntity {

    // ### ORACLE CHANGE :  ADD SEQUENCE ###
    @Id
    @SequenceGenerator(name="generator", sequenceName="OUTLET_COUNTERS_OUTLET_COUNTER",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "outlet_counter_id")
    private Long outletCounterId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "phone")
    private String phone;

    @Column(name = "terminal_id")
    private Long terminalId;

    @Column(name = "enterprise_id")
    private Long enterpriseId;

    @Column(name = "merchant_id")
    private Long merchantId;

    @Column(name = "outlet_id")
    private Long outletId;

    @ManyToOne
    @JoinColumn(name = "outlet_counter_type_id")
    private OutletCounterType outletCounterType;

    @ManyToOne
    @JoinColumn(name = "outlet_counter_status_id")
    private OutletCounterStatus outletCounterStatus;

    @Column(name = "uuid")
    private String uuid;

    @Column(name = "identifier")
    private String identifier;

    @Column(name = "is_alert_enable")
    private String isAlertEnable;

    @Column(name = "transaction_alert_number")
    private String transactionAlertNumber;

    @Column(name = "redeem_attempt")
    private Long redeemAttempt;
    
    @Column(name = "external_reference_id")
    private Long externalReferenceId;

    @Transient
    private String counterReference;
    
    @Column(name = "hardware_id")
    private String hardwareId;

    @Column(name = "device_name")
    private String deviceName;

    @Column(name = "device_pin")
    private String devicePin;

    @Column(name = "language_id")
    private Long language;

    @Column(name = "cashier_name")
    private String cashierName;

    @ManyToOne
    @JoinColumn(name = "counter_channel_id")
    private OutletCounterChannels outletCounterChannels;


}
