package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.BankUserWhiteList;
import lk.ideahub.symphony.modules.banks.repository.BankUserWhiteListRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.product.sympay.common.LogSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 06-Jan-2022
 */

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BankUserWhiteListServiceImpl extends GenericService implements BankUserWhiteListService {
    private static final Logger log = LoggerFactory.getLogger(BankUserWhiteListServiceImpl.class);

    @Autowired
    private BankUserWhiteListRepository repository;


    @Override
    public List<Integer> getUserWhiteListByBankId(final Object banksId, final Object bankStatusId, final ServiceContext serviceContext) {
        List<Object[]> resultList = repository.getUserWhiteListByBankId(banksId, bankStatusId, serviceContext);
        List<Integer> bankUserWhiteListInteger = new ArrayList<>();

        if(resultList.size() > 0) {
            for  ( int  i =  0 ; i < resultList.size(); i++) {
                if (resultList.get(i) != null) {
                    int cusId = Integer.parseInt(String.valueOf(resultList.get(i)));
                    bankUserWhiteListInteger.add(cusId);
                }
            }
        }

        return bankUserWhiteListInteger;
    }
}
