package lk.ideahub.symphony.modules.common;

import java.math.BigDecimal;

public class Constants {

	public final static String SYSTEM_NAME = "pipay";
	public final static String TEST_OTP = "1111";
	public final static String TEST_TOUCH_ID = "abcdefgh";
	public final static String TIME_ZONE = "time.zone";
	public final static String SUCCESS_MSG = "message.success";
	public final static String FAILED_MSG = "message.failed";
	public final static String REDIS_MAP = "symphony_mp";
	public final static String SEPARATOR = "-";

	//Database common
	public static final String DB_TRUE = "Y";
	public static final String DB_FALSE = "N";

	// Customer/User Status
	public static final String BLOCKED_STATUS = "Blocked";
	public static final String ACTIVE_STATUS = "Active";
	public static final String INACTIVE_STATUS = "Inactive";
	public static final String SUCCESS_STATUS = "Success";
	public static final String FAILED_STATUS = "Failed";
	public static final String CREATED_STATUS = "Created";
	public static final String PENDING_STATUS = "Pending";
	public static final String TEMP_BLOCKED_STATUS = "Temporarily Blocked";
	public static final String CLOSED_STATUS = "Closed";

	// Action Types
	public static final String OTP_CONFIRMED = "OTP Confirmed";
	public static final String KYC_CONFIRMED = "KYC Confirmed";
	public static final String OTP_SEND = "OTP Send";
	public static final String PIN_CONFIRMED = "PIN Confirmed";
	public static final String LOGIN = "Login";

	// Attempt Types
	public static final String REG_CONFIRM_OTP = "Reg Confirm OTP";
	public static final String LOGIN_PW = "Login PW";

	// Auth Atribute Type
	public static final String OTP = "OTP";
	public static final String PASSWORD = "Password";
	public static final String PIN = "PIN";
	public static final String LOGIN_OTP = "LoginOTP";
	public static final String LOGIN_TOUCH_ID = "LoginTouchId";

	// email suffix
	public static final String EMAIL_SUFFIX = "@tobe.updated.com";

	//login types
	public static final String LOGIN_TYPE_OTP = "OTP";
	public static final String LOGIN_TYPE_TOUCH = "TOUCH";
	public static final String LOGIN_TYPE_PASSWORD = "PASSWORD";

	// customer account type
	public static final String LITE = "LITE";
	public static final String STANDARD = "STANDARD";
	public static final String PLUS = "PLUS";


	public static final String SILVER = "SILVER";
	public static final String PLATINUM = "PLATINUM";

	//sms sqs json
	public static final String MSISDN = "msisdn";
	public static final String MESSAGE = "message";
	public static final String SMS = "SMS";
	public static final String SMS_ENGINE_TYPE = "engineType";

	//push sqs json
	public static final String DEVICE_TOKEN = "deviceToken";
	public static final String OS_TYPE = "osType";
	public static final String NOTIFICATION_BODY = "body";
	public static final String TITLE = "title";
	public static final String PUSH = "PUSH";
	public static final String PUSH_DATA = "data";
	public static final String AUDIT_ID = "notificationAuditId";
	public static final String NOTIFICATION_ID = "notificationId";
	public static final String EXT_REF_ID = "extRefId";
	public static final String TYPE = "type";
	public static final String FOR_ALL = "forAll";
	public static final String TOPIC = "topic";

	//customer Auth Attribute Type
	public static final String TOUCH_ID = "TouchID";
	public static final String IS_ACTIVE = "Y";

	//Merchant transaction status
	public static final String MERCHANT_INITIATED = "Merchant Initiated";
	public static final String VERIFICATION_SUCCESS = "Verification Success";
	public static final String PAYMENT_SUCCESS = "Payment Success";
	public static final String PAYMENT_FAIL = "Payment Fail";
	public static final String CUSTOMER_APPROVED = "Customer Approved";
	public static final String PIN_IN_PROGRESS = "Pin In Progress";

	//Merchant status
	public static final String MERCHANT_BLOCKED_STATUS = "Blocked";
	public static final String MERCHANT_ACTIVE_STATUS = "Active";
	public static final String MERCHANT_INACTIVE_STATUS = "Inactive";
	public static final String MERCHANT_CLOSE_STATUS = "Closed";

	//Merchant transaction types
	public static final String OTC = "OTC";
	public static final String IN_APP = "IN-APP";

	//payment channels
	public static final String PAYMENT_CHANNEL_IN_APP = "In App";
	public static final String PAYMENT_CHANNEL_OTC = "OTC";
	public static final String PAYMENT_CHANNEL_ONLINE = "Online";

	//Outlet counter statuses
	public static final String OUTLET_COUNTER_STATUS_ACTIVE = "Active";

	//Merchant initiate types
	public static final String OTC_QR_DYNAMIC_EXTERNAL = "OTC_QR_DYNAMIC_EXTERNAL";
	public static final String OTC_QR_DYNAMIC = "OTC_QR_DYNAMIC";
	public static final String WEB_QR_DYNAMIC = "WEB_QR_DYNAMIC";
	public static final String OTC_QR_STATIC =  "OTC_QR_STATIC";
	public static final String IN_APP_BILLER =  "INAPP_BILLER";
	public static final String OTC_QR_HYBRID =  "OTC_QR_HYBRID";
	public static final String RECEIVER_QR_STATIC =  "RECEIVER_QR_STATIC";
	public static final String RECEIVER_QR_HYBRID =  "RECEIVER_QR_HYBRID";
	public static final String OTC_WALLET_PIN =  "OTC_WALLET_PIN";
	public static final String IN_APP_TOP_UP =  "IN_APP_TOP_UP";
	public static final String IN_APP_COUPON =  "INAPP_COUPON";
	public static final String IN_APP_POINT =  "INAPP_POINT";
	public static final String WEB_SIGNIN = "WEB_SIGNIN";
	public static final String ADMIN_REWARD_TRANSFER_IN = "ADMIN_REWARD_TRANSFER_IN";

	//User Types
	public static final String OTC_USER = "OTC User";
	public static final String OUTLET_USER = "Outlet User";

	//currencies
	public static final String KHR = "KHR";
	public static final String USD = "USD";
	public static final String POINT_WALLET_BALANCE = "POINT";

	//payment option types
	public static final String PIPAY_WALLET = "PIPAY_WALLET";

	//pipay wallet
	public static final String PAYROLL_USD = "PAYROLL_USD";
	public static final String PAYROLL_KHR = "PAYROLL_KHR";
	public static final String TRANSACTION_USD = "TRANSACTION_USD";
	public static final String TRANSACTION_KHR = "TRANSACTION_KHR";
	public static final String HOLD_USD = "HOLD_USD";
	public static final String HOLD_KHR = "HOLD_KHR";
	public static final String POINT_WALLET = "POINT_WALLET";
	public static final String FINANCIAL_USD = "FINANCIAL_USD";
	public static final String FINANCIAL_KHR = "FINANCIAL_KHR";
	public static final String POINT_KHR = "POINT_KHR";
	public static final String COUPON_WALLET = "COUPON";

	public static final String COUPON_WALLET_DISCRIPTION = "Coupon Wallet";
	public static final Long COUPON_WALLET_SEQUENCE = 100L;

	//media
	public static final String CLOUD_POS = "CLOUD_POS";
	public static final String MERCHANT_POS = "MERCHANT_POS";

	//Card status
	public static final String CARD_STATUS_ACTIVE = "Active";

	//Discount types
	public static final String DISCOUNT_STATUS_INSTANT = "Instant";
	public static final String DISCOUNT_STATUS_ADVANCED = "Advanced";

	//sms notification engine types
	public static final String SMS_NOTIFICATION_PRIMARY_ENGINE = "PRIMARY";
	public static final String SMS_NOTIFICATION_SECONDARY_ENGINE = "SECONDARY";

	//payment channel
	//public static final String ONLINE = "Online";
	//public static final String INAPP = "In App";

	//transaction types
	public static final String MERCHANT_TXN = "Merchant Txn";
	public static final String PAYEE_TXN = "Payee Txn";
	public static final String COUPON_TXN = "COUPON_TRANSACTION";

	//customer payee transaction status
	public static final String COMPLETED = "Completed";

	//merchant txn type
	public static final String WEB = "WEB";

	//card status
	public static final String ACTIVE_CARD = "Active";

	//biller status
	public static final String ACTIVE_BILLER = "Active";
	
	//QR types
	public static final String DY_MR_NL = "DY_MR_NL";//merchant-dynamic QR normal
	public static final String DY_MR_GT = "DY_MR_GT";//merchant-dynamic QR guest
	public static final String DY_MR_OL = "DY_MR_OL";//merchant-dynamic QR Offline
	public static final String ST_MR_NL = "ST_MR_NL";//merchant-static QR normal
	public static final String ST_MR_HB = "ST_MR_HB";//merchant-static QR hybrid
	public static final String ST_RC_NL = "ST_RC_NL";//receiver-static QR normal
	public static final String ST_RC_HB = "ST_RC_HB";//receiver-static QR hybrid
	public static final String QR_GROUP_NONE = "NONE";//Free
	public static final String QR_GROUP_DYNAMIC = "DYNAMIC";
	public static final String QR_GROUP_STATIC = "STATIC";
	public static final String QR_GROUP_AUAM = "RECEIVE_|_AUAM";//"AUAM";
	public static final String QR_GROUP_AUAM_V2 = "AUAM";

	//edit fiels
	public static final String CURRENCY = "Currency";
	public static final String LANGUAGE = "Language";

	//receiver QR content
	public static final String RECEIVER_QR_RECEIVER_ID = "receiverId";
	public static final String RECEIVER_QR_MERCHANT_PROFILE_ID = "receiverProfileId";
	public static final String RECEIVER_QR_AMOUNT = "amount";
	public static final String RECEIVER_QR_CURRENCY = "currency";
	public static final String RECEIVER_QR_CREATED_DATE = "createdDate";
	public static final String RECEIVER_PHONE_NO = "receiverPhoneNo";
	public static final String RECEIVER_NAME = "receiverName";
	public static final String V2 = "V2";
	
	//receiver transaction statuses
	public static final String RECEIVER_TXN_STATUS_INITIATED = "INITIATED";
	public static final String RECEIVER_TXN_STATUS_SUCCESS = "SUCCESS";
	public static final String RECEIVER_TXN_STATUS_FAILED = "FAILED";
	public static final String RECEIVER_TXN_STATUS_CANCELLED = "CANCEL";
	
	//push types
	public static final String AUAM_PAYMENT_CONFIRMATION = "AUAM_PAYMENT_CONFIRMATION";
	public static final String AUAM_PAYMENT_QR_SCANNED = "AUAM_QR_SCANNED";
	public static final String FRIEND_ACCEPT = "FRIENDS";
	public static final String PINK_PACKET_CREATION = "PINK_PACKET_CREATION";
	public static final String PINK_PACKET_CALIAMED_INFORMATION_TO_SENDER = "PINK_PACKET_CALIAMED_INFORMATION_TO_SENDER";
	public static final String MARKETING_NOTIFICATION = "MARKETING_NOTIFICATION";
	public static final String LOGIN_DEVICE_ALTERED = "LOGIN_DEVICE_ALTERED";
	public static final String EXTERNAL_PUSH_APP = "EXTERNAL_PUSH_APP";
	public static final String EXTERNAL_PUSH_POS = "EXTERNAL_PUSH_POS";
	public static final String POINT_TRANSFER = "POINT_TRANSFER";
	public static final String COUPON_TRANSFER = "COUPON_TRANSFER";
	public static final String WALLET_POS_UPGRADE = "WALLET_POS_UPGRADE";
	public static final String COUPON_REDEEM = "COUPON_REDEEM";
	public static final String QUICK_PAY = "QUICK_PAY";
	public static final String COUPON_REDEEM_MESG = "COUPON_REDEEM_MESG";
	public static final String COUPON_CLAIM = "COUPON_CLAIM";
	public static final String BILL_PAYMENT_REMINDER = "BILL_PAYMENT_REMINDER";
	public static final String BULK_REWARD_TRANSFER_IN = "BULK_REWARD_TRANSFER_IN";

	public static final String IOS_CONTENT_AVAILABLE = "content-available";
	public static final String IOS_SOUND = "sound";

	//merchant type
	public static final String PI_PAY_MERCHANT = "Pi Pay";

	//user statuses
	public static final String ACTIVE_USER = "Active";
	public static final String BLOCKED_USER = "Blocked";

	//merchant approval statuses
	public static final String INITIATE_APPROVAL_STATUS = "INITIATE";

	//user types
	public static final String MERCHANT_USER = "Merchant User";

	//customer account upgrade status
	public static final String PENDING_APPROVAL = "PENDING_APPROVAL";
	public static final String UPGRADE_STATUS_APPROVED = "APPROVED";
	public static final String UPGRADE_STATUS_RESUBMITTED = "RESUBMITTED";

	// app detail
	public static final String ABOUT = "ABOUT";
	public static final String POLICIES = "POLICIES";
	public static final String CONTACT = "CONTACT";
	public static final String ABOUT_CONFIG = "app.about";
	public static final String POLICY_CONFIG = "app.policies";
	public static final String CONTACT_CONFIG = "app.contact";

	//customer device statuses
	public static final String CUSTOMER_DEVICE_STATUS_ACTIVE = "Active";
	public static final String CUSTOMER_DEVICE_STATUS_INACTIVE = "InActive";

	//customer friend status
	public static final String FRIEND_REQUEST_SENT = "REQUEST_SENT";
	public static final String FRIEND_REQUEST_RECEIVED = "REQUEST_RECEIVED";
	public static final String FRIEND_REQUEST_ACTIVE = "ACTIVE";
	public static final String FRIEND_REQUEST_BLOCKED = "BLOCKED";
	public static final String FRIEND_REQUEST_PENDING = "REQUEST_PENDING";

	//document type
	public static final String DOC_TYPE_OTHER = "Other";

	//offline payment
	public static final String OFFLINE_PAY_STATUS_PENDING = "PENDING";
	public static final String OFFLINE_PAY_STATUS_COMPLETED = "COMPLETED";

	//system config
	public static final String JWT_SECRET_CODE = "app.jwt.secret";
	public static final String JWT_POS_EXPIRY = "app.jwt.merchant.pos.expiry";
	public static final String JWT_GENERAL_EXPIRY = "app.jwt.general.expiry";
	public static final String JWT_SESSION_EXPIRY = "app.jwt.general.expiry";
	public static final String JWT_EXTPG_EXPIRY = "app.jwt.extpg.expiry";
	public static final String JWT_OPEN_EXPIRY = "app.jwt.customer.registration.expiry";

	//merchant actions
	public static final String POS_CUSTOMER_CASH_IN = "CUSTOMER_CASH_IN";
	public static final String POS_CUSTOMER_CASH_OUT = "CUSTOMER_CASH_OUT";
	public static final String POS_MERCHANT_CASH_IN = "MERCHANT_CASH_IN";
	public static final String POS_MERCHANT_CASH_OUT = "MERCHANT_CASH_OUT";
	public static final String POS_WALLET_UPGRADE = "WALLET_UPGRADE";
	public static final String POS_QR_SCAN = "QR_SCAN";
	public static final String POS_PIN_PAY = "WALLET_PIN_PAY";
	public static final String POS_QUICK_PAY = "QUICK_PAY";
	//release type
	public static final String RELEASE_TYPE_DEV = "DEV";
	public static final String RELEASE_TYPE_PRD = "PRODUCTION";

	//paymet By
	public static final String PAY_BY_QR = "QR";
	public static final String PAY_BY_PIN = "PIN";

	public static final String SUCCESS_CODE = "0";
	
	//check txn status(external service)
	public static final String EXT_SERVICE_TXN_STASTUS_COMPLETED = "COMPLETED";


	//Merchant POS Transaction Types
	public static final String CASH_IN = "CASH_IN";
	public static final String CASH_OUT = "CASH_OUT";

	//Customer CashIn CashOut Status
	public static final String INITIATE = "INITIATE";
	public static final String PENDING = "PENDING";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAIL = "FAIL";

	//filter tag
	public static final String EXPERIENCE_TAG = "EXPERIENCE";
	public static final String PLACES_TAG = "PLACES";
	public static final String DEALS_TAG = "DEALS";
	public static final String COUPON_PACK_TAG = "COUPONS";

	// experience card categories
	public static final String HASH_TAG = "Hash Tag";
	public static final String MERCHANT = "Merchant";

	//exp crd content types
	public static final String CONTENT_MERCHANT = "Merchants";
	public static final String CONTENT_OUTLET = "Outlets";
	public static final String CONTENT_DEALS = "Deals";
	public static final String CONTENT_COUPON = "Coupons";

	//platform
	public static final String PLATFORM_ANDROID = "android";

	// deal & merchant
	public static final BigDecimal MIN_RATE = new BigDecimal(0);
	public static final BigDecimal MAX_RATE = new BigDecimal(5);

	//approval status
	public static final String APPROVED = "APPROVED";

	//Merchant POS OS Type;
	public static final String MERCHANT_POS_OS_TYPE = "Android";

	//OS types
	public static final String ANDROID = "Android";
	public static final String IOS = "IOS";
	public static final String ANDROID_EXT_DISCOUNT = "android";
	public static final String IOS_EXT_DISCOUNT = "ios";

	//external transactions
	public static final String V1_POS_TRANSACTION = "V1_POS_TRANSACTION";
	public static final String INITIATE_TYPE_QR = "QR";
	public static final String INITIATE_TYPE_PIN = "PIN";

	//wallet upgrade
	public static final String WALLET_UPGRADE = "UPGRADE";
	public static final String WALLET_DOWNGRADE = "DOWNGRADE";

	//external customer processes
	public static final String EXT_CUSTOMER_REGISTRATION_PROCESS = "REGISTRATION";
	public static final String EXT_CUSTOMER_UPGRADE_PROCESS = "CUSTOMER_UPGRADE";


	//Outlet search types
	public static final String SEARCH_NEARBY = "Nearby";
	public static final String SEARCH_RECOMMENDED = "Recommended";
	public static final String SEARCH_FEATURED = "Featured";
	public static final String SEARCH_ALL = "All";

	//deal/outlet/notification column key
	public static final String KEY_CAPTION = "caption";
	public static final String KEY_DESCRIPTION = "description";
	public static final String KEY_NAME = "name";
	public static final String KEY_SHORT_DESCRIPTION = "shortDescription";
	public static final String KEY_STREET_LINE_ONE = "streetLineOne";
	public static final String KEY_ADDRESS = "address";

	public static final String KEY_MESSAGE = "message";
	public static final String KEY_CONTENT_MESSAGE = "contentMessage";
	public static final String KEY_NOTIFICATION_TITLE = "title";
	public static final String KEY_BUTTON_NAME = "buttonName";
	public static final String KEY_TAG_NAME = "tagName";
	public static final String KEY_DISPLAY_NAME = "displayName";
	public static final String KEY_TITLE = "title";
	public static final String KEY_BANK_NAME = "bankName";


	//language
	public static final String LANG_ENGLISH = "en";
	public static final String LANG_KHMER = "km";
	public static final String LANG_CHINESE = "zh";

	//Pink Packet
	public static final String PINK_PACKET_GRP_TYPE_GROUP = "GROUP";
	public static final String PINK_PACKET_GRP_TYPE_INDIVIDUAL = "INDIVIDUAL";

	public static final String PINK_PACKET_SPLIT_TYPE_EVEN = "EVEN";
	public static final String PINK_PACKET_SPLIT_TYPE_RANDOM = "RANDOM";

	public static final String PINK_PACKET_SERVICE_CHARGE_TYPE_FIXED = "Fixed";
	public static final String PINK_PACKET_SERVICE_CHARGE_TYPE_PERCENTAGE = "Percentage";

	public static final String PINK_PACKET_STATUS_INITIATED = "INITIATED";
	public static final String PINK_PACKET_STATUS_CREATED = "CREATED";
	public static final String PINK_PACKET_STATUS_RESERVED = "RESERVED";
	public static final String PINK_PACKET_STATUS_ACCEPTED = "ACCEPTED";
	public static final String PINK_PACKET_STATUS_EXPIRED = "EXPIRED";
	
	public static final String PINK_PACKET_LIST_TYPE_SENT = "SENT_LIST";
	public static final String PINK_PACKET_LIST_TYPE_RECEIVED = "RECEIVED_LIST";
	
	public static final String PINK_PACKET_SUMMARY_TYPE_SENT = "SENT_SUMMARY";
	public static final String PINK_PACKET_SUMMARY_TYPE_RECEIVED = "RECEIVED_SUMMARY";
	
	public static final String PINK_PACKET_EXT_RESPONSE_HOLD_CONSUMED = "ErrorCode.HOLD_CONSUMED";
	public static final String PINK_PACKET_EXT_RESPONSE_HOLD_NOT_EXISTS = "ErrorCode.HOLD_NOT_EXISTS";
	public static final String PINK_PACKET_EXT_RESPONSE_HOLD_ALREADY_ACCEPTED = "ErrorCode.HOLD_ALREADY_ACCEPTED";
	public static final String PINK_PACKET_EXT_RESPONSE_HOLD_EXPIRED = "ErrorCode.HOLD_EXPIRED";
	public static final String PINK_PACKET_EXT_RESPONSE_OK = "OK";
	public static final String PINK_PACKET_EXT_RESPONSE_NOT_USABLE_DEVICE = "ErrorCode.NOT_USABLE_DEVICE";
	public static final String PINK_PACKET_EXT_RESPONSE_FAILED_WALLET_BALANCE_LIMIT = "ErrorCode.FAILED_WALLET_BALANCE_LIMIT";
	public static final String PINK_PACKET_EXT_RESPONSE_FAILED_LIMIT_AMOUNT = "ErrorCode.FAILED_LIMIT_AMOUNT";

	//merchant category types
	public static final String AUAM = "AUAM";
	public static final String ALL = "ALL";

	//nearby outlet list size
	public static final int MIN_SIZE = 0;
	public static final int OUTLET_MAX_SIZE = 10;
	public static final int DEAL_OUTLET_MAX_SIZE = 10;

	//Merchant Category Type
	public static final String GENERAL_MERCHANT = "GENERAL";

	//outlet type
	public static final String GENERAL_OUTLET = "GENERAL_MERCHANT";

	//Merchant Type
	public static final String GENERAL_MERCHANT_TYPE = "General";

	//qr prefix
	public static final String QR_PREFIX_FRIEND = "FRIEND_";

	//user types
	protected static final String[] USER_TYPES = {"Super Admin","Enterprise User"};
	public static String[] getUserTypes() {
		return USER_TYPES;
	}

	//Notification Statues
	public static final String NOTIFICATION_STATUS_PROCESSING = "Processing";
	public static final String NOTIFICATION_STATUS_INITIATE = "Initiate";
	public static final String NOTIFICATION_STATUS_COMPLETED = "Completed";

	//app versions
	public static final String ANDROID_VERSION = "app.type.android.version";
	public static final String IOS_VERSION = "app.type.ios.version";
	public static final String ANDROID_FORCE_UPDATE = "app.type.android.force.update";
	public static final String IOS_FORCE_UPDATE = "app.type.ios.force.update";

	public static final String PUSH_TYPE = "NOTIFICATION";

	//Banners
	public static final String HOME_BANNER = "Home Banner";

	//merchant types
	public static final String MERCHANT_TYPE_BANK = "Bank";

	//notification types
	public static final String NT_BIRTH_DATE = "BIRTH_DATE";
	public static final String NT_CUSTOMER = "CUSTOMER";
	public static final String NT_BILL_PAYMENT = "BILL_PAYMENT";

	//notification Gender
	public static final String NT_ALL_GENDER = "All";

	//notification delivery method
	public static final String NT_DELIVERY_MANUAL = "MANUAL";
	public static final String NT_DELIVERY_SCHEDULE = "SCHEDULE";

	//notification audience
	public static final String NT_AUDIENCE_ALL = "ALL";
	public static final String NT_AUDIENCE_CUSTOM = "CUSTOM";
	public static final String NT_AUDIENCE_FILE = "FILE";
	public static final String NT_AUDIENCE_FILTER = "FILTER";

	//days
	public static final String MONDAY = "MONDAY";
	public static final String TUESDAY = "TUESDAY";
	public static final String WEDNESDAY = "WEDNESDAY";
	public static final String THURSDAY = "THURSDAY";
	public static final String FRIDAY = "FRIDAY";
	public static final String SATURDAY = "SATURDAY";
	public static final String SUNDAY = "SUNDAY";

	//External Catalogue
	public static final String EXT_CATALOGUE_INTEGRATION_TYPE_UTILITY = "UTILITY";
	public static final String EXT_CATALOGUE_INTEGRATION_TYPE_LOTTERY = "LOTTERY";

	//Notification response status
	public static final String PARTIALLY_SENT = "Partially Sent";
	public static final String COMPLETELLY_SENT = "Completely Sent";
	public static final String FAILED = "Failed";

	//payment processor
	public static final String PAYMENT_PROCESS_MODE_INTERNAL = "INTERNAL";
	public static final String PAYMENT_PROCESS_MODE_EXTERNAL = "EXTERNAL";

	//Loyalty
	public static final String LOYALTY_REFERENCE_TYPE_COUPON = "COUPON";

	//customer loyalty point status
	public static final String POINT_EXPIRED = "EXPIRED";
	public static final String POINT_CLAIMED = "CLAIMED";
	public static final String POINT_UTILIZED = "UTILIZED";
	public static final String POINT_PARTIALLY_UTILIZED = "PARTIALLY_UTILIZED";

	//search point
	public static final String SEARCH_POINT_ALL = "ALL";
	public static final String SEARCH_POINT_EARNED = "EARNED";
	public static final String SEARCH_POINT_SPENT = "SPENT";
	public static final String SEARCH_POINT_EXPIRED = "EXPIRED";

	//coupon statuses
	public static final String COUPON_FREE = "FREE";
	public static final String COUPON_CLAIMED = "CLAIMED";
	public static final String COUPON_REDEEMED = "REDEEMED";
	public static final String COUPON_EXPIRED = "EXPIRED";
	public static final String COUPON_ALL = "ALL";
	public static final String COUPON_ASSIGNED = "ASSIGNED";

	//coupon transaction statuses
	public static final String COUPON_TRANSACTION_CLAIMED = "CLAIMED";
	public static final String COUPON_TRANSACTION_REDEEMED = "REDEEMED";
	public static final String COUPON_TRANSACTION_EXPIRED = "EXPIRED";
	public static final String COUPON_TRANSACTION_TRANSFERRED = "TRANSFERRED";

	//coupon types
	public static final String COUPON_TYPE_GIFT="GIFT";
	public static final String COUPON_TYPE_DISCOUNT="DISCOUNT";
	public static final String COUPON_TYPE_ALL="ALL";

	//coupon discount types
	public static final String COUPON_DISCOUNT_PERCENTAGE="PERCENTAGE";
	public static final String COUPON_DISCOUNT_FIXED="FIXED";

	//coupon pack types
	public static final String COUPON_PACK_TYPE_FREE = "FREE";
	public static final String COUPON_PACK_TYPE_GIFT = "GIFT";
	public static final String COUPON_PACK_TYPE_DISCOUNT = "DISCOUNT";

	//coupon value types
	public static final String COUPON_VALUE_TYPE_POINT = "POINT";
	public static final String COUPON_VALUE_TYPE_MONETARY = "MONETARY";

	//coupon creation status
	public static final String COUPON_CREATION_INITIATE = "INITIATE";
	public static final String COUPON_CREATION_PROCESSING = "PROCESSING";
	public static final String COUPON_CREATION_PARTIALLY_COMPLETED = "PARTIALLY_COMPLETED";
	public static final String COUPON_CREATION_COMPLETED = "COMPLETED";

	//coupon payable type
	public static final String COUPON_PAYABLE_TYPE_SCAN_PAY = "SCAN_AND_PAY";
	public static final String COUPON_PAYABLE_TYPE_GIFT = "GIFT";

	//coupon rules
	public static final String DAYS_OF_WEEK = "DATES_OF_WEEK";
	public static final String TIME = "TIME";
	public static final String DATES_OF_MONTH = "DATES_OF_MONTH";

	//coupon redeem status
	public static final String COUPON_REDEEM_TOKEN_CREATED = "TOKEN_CREATED";
	public static final String COUPON_REDEEM_CONFIRMATION_REQUIRED = "CONFIRMATION_REQUIRED";
	public static final String COUPON_REDEEM_CUSTOMER_APPROVED = "CUSTOMER_APPROVED";
	public static final String COUPON_REDEEM_EXPIRED = "EXPIRED";
	public static final String COUPON_REDEEM_SUCCESS = "SUCCESS";
	public static final String COUPON_REDEEM_FAILED = "FAILED";
	public static final String COUPON_REDEEM_CUSTOMER_REJECTED = "CUSTOMER_REJECTED";

	//coupon pack language
	public static final String COUPON_KEY_DESCRIPTION = "description";
	public static final String COUPON_KEY_TERM_CONDITION = "termsAndCondition";

	//Transaction Post Service transaction types
	public static final String TRX_TYPE_ONLINE_PAYMENT = "ONLINE_PAYMENT";
	public static final String TRX_TYPE_AUAM = "AUAM_PAYMENT";
	public static final String TRX_TYPE_MERCHANT_OTC_PAYMENT = "MERCHANT_OTC_PAYMENT";
	public static final String TRX_TYPE_BILL = "BILL_PAYMENT";
	public static final String TRX_TYPE_UTILITY = "UTILITY_PAYMENT";
	public static final String OTC_QUICK_PAY = "OTC_QUICK_PAY";

	//System config values
	public static final String MAX_PROMO_RATE = "app.max.promo.rate";
	public static final String MIN_PAYMENT_AMOUNT_KHR = "app.min.payment.amount.khr";
	public static final String MIN_PAYMENT_AMOUNT_USD = "app.min.payment.amount.usd";

	//payment push object
	public static final String CUS_PAYEE_TXN_ID = "customerPayeeTxnId";
	public static final String TXN_DATE_TIME = "transactionDate";
	public static final String AMOUNT = "amount";
	public static final String CURRENCY_PUSH = "currency";
	public static final String EXT_POST_TXN_ID = "externalPostTxnId";
	public static final String EXT_POST_TXN_REF = "externalPostTxnRef";
	public static final String CONVERSION_RATE = "conversionRate";
	public static final String CONVERSION_RATE_ID = "conversionRateId";
	public static final String CHANNEL = "channel";
	public static final String NET_AMOUNT = "netAmount";

	public static final String CUSTOMER_DTO = "customerDto";
	public static final String CUSTOMER_ID = "customerId";
	public static final String NAME = "name";
	public static final String BIRTHDAY = "birthday";
	public static final String CUSTOMER_GROUP_LIST = "customerGroupList";
	public static final String CUSTOMER_WALLET_GROUP = "walletGroup";
	public static final String SIMPHONY_OUTLET_ID = "externalStoreId";
	public static final String SIMPHONY_DEVICE_ID = "externalDeviceId";
	public static final String DEVICE_NAME = "deviceName";
	public static final String ENABLE_IS_POPUP = "Y";
	public static final String DISABLE_IS_POPUP = "N";

	public static final String MERCHANT_DTO = "merchantDto";
	public static final String MERCHANT_ID = "merchantId";

	public static final String OUTLET_DTO = "outletDto";
	public static final String OUTLET_ID = "outletId";

	public static final String BILLER_DTO = "billerDto";
	public static final String BILLER_ID = "billerId";

	public static final String DISCOUNT_DTO = "discountDto";
	public static final String DISCOUNT_ID = "discountId";
	public static final String DISCOUNT_TXN_ID = "discountTransactionId";
	public static final String DISCOUNT_AMOUNT = "discountAmount";

	public static final String COUPON_AMOUNT = "couponAmount";

	public static final String DEVICE_DTO = "deviceDto";
	public static final String MDR_DTO = "mdrDto";
	public static final String MDR_ID = "mdrId";
	public static final String MDR_MAX = "mdrMax";
	public static final String MDR_MIN = "mdrMin";
	public static final String MDR_PERCENTAGE = "mdrPercentage";
	public static final String MDR_FIX_RATE = "mdrFixRate";
	public static final String POINT_AMOUNT_AFTER_MDR = "pointAmountAfterMdr";
	public static final String MERC_POINT_COM_ALC= "merchantPointComCalc";
	public static final String DEVICE_ID= "deviceId";
	public static final String TRANSACTION_TYPE_CODE= "transactionTypeCode";
	public static final String INITIATE_TYPE = "initiateType";



	//Reports Codes
	public static final String COUPON_STATUS_REPORT = "COUPON_STATUS_REPORT";
	public static final String COUPON_CLAIMED_REPORT = "COUPON_CLAIMED_REPORT";
	public static final String COUPON_BURNT_REPORT = "COUPON_BURNT_REPORT";
	public static final String COUPON_TRANSACTION_INQUIRY_REPORT = "COUPON_TRANSACTION_INQUIRY_REPORT";

	//
	public static final String COUPON_SOURCE_TYPE_CONSIGNMENT = "CONSIGNMENT";
	public static final String COUPON_SOURCE_TYPE_PREPURCHASE = "PRE_PURCHASE";

	//txn type
	public static final String TXN_TYPE_MERCHANT = "MERCHANT_TRANSACTION";
	public static final String TXN_TYPE_BILLER = "BILLER_PAYMENT";
	public static final String TXN_TYPE_PHONE_TOPUP = "PHONE_TOP_UP";
	public static final String TXN_TYPE_REWARD_TRANSFER_IN = "REWARD_TRANSFER_IN";

	//payee group types
	public static final String PAYEE_GROUP_TYPES_PHONE_TOP_UP ="PHONE_TOPUP";

	//outlet status
	public static final String ACTIVE_OUTLET ="Active";

	//global conversion rate
	public static final String EARNING_CONVERSION_RATE ="EARNING_CONVERSION_RATE";
	public static final String BURNING_CONVERSION_RATE ="BURNING_CONVERSION_RATE";

	//coupon expiry days
	public static final String TODAY ="Today";
	public static final String YESTERDAY ="Yesterday";
	public static final String TOMORROW ="Tomorrow";
	//loyalty notifications
	public static final String POINT_EXPIRATION = "POINT_EXPIRATION";

	//discount type
	public static final String FALT ="flat";
	public static final String PERCENT ="percent";

	//merchant categories
	public static final String ALL_CATEGORY = "ALL";
	public static final String GENERAL_CATEGORY = "GENERAL";
	public static final String AUAM_CATEGORY = "AUAM";
	
	//file types
	public static final String FILE_TYPE_CSV = "CSV";
	public static final String FILE_TYPE_EXCEL = "EXCEL";

	// s3 image base url
	public static final String S3_IMAGE_URL = "s3.image.base.url";

	//customer group type version
	public static final String IS_NEW = "NEW";
	public static final String IS_V1 = "V1";
	public static final String IS_V2 = "V2";

	public static final String VERIFICATION_CODE = "VERIFICATION_CODE";

	//Bank status
	public static final String BANK_ACTIVE_STATUS = "Active";
	public static final String BANK_INACTIVE_STATUS = "Inactive";
	public static final String BANK_MAINTENANCE_STATUS = "Maintenance";
	public static final String BANK_QA_MODE_STATUS = "QA Mode";

	// Maintenance Message
	public static final String MESSAGE_KEY_NAME_SWEEPSTAKE = "SWEEPSTAKE";

	// Version tag for Java Core
	public static final String VERSION_TAG = "1.19.15.49";
}
