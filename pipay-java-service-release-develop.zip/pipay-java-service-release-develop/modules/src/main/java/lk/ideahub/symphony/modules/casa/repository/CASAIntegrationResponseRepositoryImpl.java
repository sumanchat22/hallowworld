package lk.ideahub.symphony.modules.casa.repository;

import lk.ideahub.symphony.modules.casa.entity.CASAIntegrationResponse;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
class CASAIntegrationResponseRepositoryImpl extends GenericRepository implements CASAIntegrationResponseRepository {

    private static final Logger log = LoggerFactory.getLogger(CASAIntegrationResponseRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CASAIntegrationResponse get(final Object _casaIntegrationResponseId, final ServiceContext _serviceContext) {
        return entityManager.find(CASAIntegrationResponse.class, _casaIntegrationResponseId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CASAIntegrationResponse> find(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CASAIntegrationResponse.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        _casaIntegrationResponse.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        _casaIntegrationResponse.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_casaIntegrationResponse);
        entityManager.flush();
    }

    @Override
    public CASAIntegrationResponse update(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        _casaIntegrationResponse.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_casaIntegrationResponse);
    }

    @Override
    public void delete(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        entityManager.remove(_casaIntegrationResponse);
    }
}
