package lk.ideahub.symphony.modules.beacon.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.beacon.entity.BeaconId;
import lk.ideahub.symphony.modules.beacon.entity.BeaconNotification;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;

@Repository
class BeaconNotificationRepositoryImpl extends GenericRepository implements BeaconNotificationRepository {

    private static final Logger log = LoggerFactory.getLogger(BeaconNotificationRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public BeaconNotification get(final Object _beaconNotificationId, final ServiceContext _serviceContext) {
        return entityManager.find(BeaconNotification.class, _beaconNotificationId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> findFromBeaconId(final List _beaconIdList, final ServiceContext _serviceContext) {

        Query query = entityManager.createNamedQuery("BeaconNotification.findFromBeaconIdList");
        query.setParameter("beaconIdList", _beaconIdList);
        query.setParameter("effectiveDate", Utils.getCurrentUtcDate());
        query.setParameter("isActive", "Y");
        query.setParameter("phone", null);

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }
    @Override
    @SuppressWarnings("unchecked")
    public List<BeaconNotification> find(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        String proximityUuid = null;
        Integer major = null;
        Integer minor = null;

        BeaconId beaconId = _beaconNotification.getBeaconId2();
        if (beaconId != null) {
            proximityUuid = beaconId.getProximityUuid();
            major = beaconId.getMajor();
            minor = beaconId.getMinor();
        }

        Query query = entityManager.createNamedQuery("BeaconNotification.find");
        //query.setParameter("isActive", _beaconNotification.getIsActive());
        query.setParameter("effectiveDate", _beaconNotification.getEffectiveDate());
        query.setParameter("proximityUuid", proximityUuid);
        query.setParameter("major", major);
        query.setParameter("minor", minor);
        query.setParameter("isVoucher", _beaconNotification.getIsVoucher());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object> findIds(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        String proximityUuid = null;
        Integer major = null;
        Integer minor = null;

        BeaconId beaconId = _beaconNotification.getBeaconId2();
        if (beaconId != null) {
            proximityUuid = beaconId.getProximityUuid();
            major = beaconId.getMajor();
            minor = beaconId.getMinor();
        }

        Query query = entityManager.createNamedQuery("BeaconNotification.findIds");
        query.setParameter("isActive", "Y");
        query.setParameter("effectiveDate", _beaconNotification.getEffectiveDate());
        query.setParameter("proximityUuid", proximityUuid);
        query.setParameter("major", major);
        query.setParameter("minor", minor);
        query.setParameter("isVoucher", _beaconNotification.getIsVoucher());
        query.setParameter("phone", _beaconNotification.getPhone());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        _beaconNotification.setCreatedDatetime(Calendar.getInstance().getTime());
        _beaconNotification.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_beaconNotification);
        entityManager.flush();
    }

    @Override
    public BeaconNotification update(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        _beaconNotification.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_beaconNotification);
    }

    @Override
    public void delete(final BeaconNotification _beaconNotification, final ServiceContext _serviceContext) {
        entityManager.remove(_beaconNotification);
    }
}
