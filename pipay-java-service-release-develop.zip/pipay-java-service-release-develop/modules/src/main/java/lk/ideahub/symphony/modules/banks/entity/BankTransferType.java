package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * @author somma.soun - PiPay
 * @create 14-Dec-2021
 */

@Entity
@Table(name = "bank_transfer_type")
@Getter
@Setter
@ToString
public class BankTransferType {
    @Id
    @SequenceGenerator(name="generator", sequenceName="BANK_TRANSFER_TYPE_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_transfer_type_id")
    private Long bankTransferTypeId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;
}
