package lk.ideahub.symphony.modules.corporate.repository;

import java.util.List;

import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.corporate.entity.Corporate;

public interface CorporateRepository {

    Corporate get(final Object _corporateId, final ServiceContext _serviceContext);

    List<Corporate> find(final Corporate _corporate, final ServiceContext _serviceContext);

    void add(final Corporate _corporate, final ServiceContext _serviceContext);

    Corporate update(final Corporate _corporate, final ServiceContext _serviceContext);

    void delete(final Corporate _corporate, final ServiceContext _serviceContext);
}
