package lk.ideahub.symphony.modules.casa.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;

import javax.persistence.*;

@Entity
@Table(name = "casa_integration_responses")

public class CASAIntegrationResponse extends AbstractEntity
{
    @Id
    @SequenceGenerator(name="generator", sequenceName="CASA_INTEGRATION_RESPONSES_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "casa_integration_response_id")
    private Long casaIntegrationResponseId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "response")
    private String response;

    @Column(name = "reference_id")
    private String referenceId;

    @Column(name = "request_type")
    private String requestType;

    @Column(name = "customer_token")
    private String customerToken;

    @Column(name = "account_references")
    private String accountReferences;

    public Long getCasaIntegrationResponseId() { return casaIntegrationResponseId; }

    public void setCasaIntegrationResponseId(Long casaIntegrationResponseId) { this.casaIntegrationResponseId = casaIntegrationResponseId; }

    public Long getCustomerId() { return customerId; }

    public void setCustomerId(Long customerId) { this.customerId = customerId; }

    public String getResponse() { return response; }

    public void setResponse(String response) { this.response = response; }

    public String getReferenceId() { return referenceId; }

    public void setReferenceId(String referenceId) { this.referenceId = referenceId; }

    public String getRequestType() { return requestType; }

    public void setRequestType(String requestType) { this.requestType = requestType; }

    public String getCustomerToken() { return customerToken; }

    public void setCustomerToken(String customerToken) { this.customerToken = customerToken; }

    public String getAccountReferences() { return accountReferences; }

    public void setAccountReferences(String accountReferences) { this.accountReferences = accountReferences; }

    @Override
    public String toString() {
        return new StringBuilder("CASAIntegrationResponse {")
                .append("casaIntegrationResponseId=").append(casaIntegrationResponseId).append(", ")
                .append("customerId=").append(customerId).append(", ")
                .append("response='").append(response).append("'").append(", ")
                .append("referenceId='").append(referenceId).append("'").append(", ")
                .append("requestType='").append(requestType).append("'").append(", ")
                .append("customerToken='").append(customerToken).append("'").append(", ")
                .append("accountReferences='").append(accountReferences).append("'")
                .append('}').toString();
    }
}
