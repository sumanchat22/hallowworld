package lk.ideahub.symphony.modules.casa.service;


import lk.ideahub.symphony.modules.casa.entity.CargillsCasaRequestResponseDetails;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface CargillsCasaRequestResponseDetailsService {

    CargillsCasaRequestResponseDetails get(final Object _CargillsCasaRequestResponseDetailsId, final ServiceContext _serviceContext);

    void add(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetails, final ServiceContext _serviceContext);

    void update(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetails, final ServiceContext _serviceContext);

    void delete(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetails, final ServiceContext _serviceContext);
}
