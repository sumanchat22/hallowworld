package lk.ideahub.symphony.modules.casa.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.casa.entity.CargillsCASARegisteredCustomer;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.payment.entity.PaymentOptionIssuers;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;


@Repository
class CargillsCASARegisteredCustomerRepositoryImpl extends GenericRepository implements CargillsCASARegisteredCustomerRepository {

    private static final Logger log = LoggerFactory.getLogger(CargillsCASARegisteredCustomerRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CargillsCASARegisteredCustomer get(final Object _cargillsCASARegisteredCustomerId, final ServiceContext _serviceContext) {
        return entityManager.find(CargillsCASARegisteredCustomer.class, _cargillsCASARegisteredCustomerId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CargillsCASARegisteredCustomer> find(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CargillsCASARegisteredCustomer.find");

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public CargillsCASARegisteredCustomer findbyCustomer(Customer _customer, ServiceContext _serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(CargillsCASARegisteredCustomer.class);
        criteria.add(Restrictions.eq("customer",_customer));
        return (CargillsCASARegisteredCustomer)criteria.uniqueResult();
    }

    @Override
    public void add(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext) {
        _cargillsCASARegisteredCustomer.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        _cargillsCASARegisteredCustomer.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_cargillsCASARegisteredCustomer);
        entityManager.flush();
    }

    @Override
    public CargillsCASARegisteredCustomer update(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext) {
        _cargillsCASARegisteredCustomer.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_cargillsCASARegisteredCustomer);
    }

    @Override
    public void delete(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext) {
        entityManager.remove(_cargillsCASARegisteredCustomer);
    }
}
