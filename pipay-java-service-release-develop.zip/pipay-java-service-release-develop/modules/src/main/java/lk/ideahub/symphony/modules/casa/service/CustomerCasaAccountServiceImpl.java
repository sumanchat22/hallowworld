package lk.ideahub.symphony.modules.casa.service;

import lk.ideahub.symphony.modules.casa.entity.CustomerCasaAccount;
import lk.ideahub.symphony.modules.casa.repository.CustomerCasaAccountRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CustomerCasaAccountServiceImpl extends GenericService implements CustomerCasaAccountService {

    private static final Logger log = LoggerFactory.getLogger(CustomerCasaAccountServiceImpl.class);

    @Autowired
    private CustomerCasaAccountRepository repository;

    @Override
    public CustomerCasaAccount get(final Object _customerCasaAccountId, final ServiceContext _serviceContext) {
        return repository.get(_customerCasaAccountId, _serviceContext);
    }

    @Override
    public List<CustomerCasaAccount> find(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        return repository.find(_customerCasaAccount, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        repository.add(_customerCasaAccount, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        repository.update(_customerCasaAccount, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext) {
        repository.delete(_customerCasaAccount, _serviceContext);
    }

    @Override
    public List<CustomerCasaAccount> findAccount(CustomerCasaAccount _customerCasaAccount, ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findAccount(_customerCasaAccount, _serviceContext);

        List<CustomerCasaAccount> customerCasaAccountList = new ArrayList<CustomerCasaAccount>(resultList.size());
        if (resultList.size() > 0) {
            CustomerCasaAccount customerCasaAccount = null;
            for (Object[] row : resultList) {
                Long customerCasaAccountId = Long.valueOf(row[0].toString());
                customerCasaAccount = repository.get(customerCasaAccountId, _serviceContext);

                customerCasaAccountList.add(customerCasaAccount);
            }
        }

        return customerCasaAccountList;
    }

    @Override
    public List<CustomerCasaAccount> findByCustomerPaymentOptionId(CustomerCasaAccount _customerCasaAccount, ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findByCustomerPaymentOptionId(_customerCasaAccount, _serviceContext);

        List<CustomerCasaAccount> customerCasaAccountList = new ArrayList<CustomerCasaAccount>(resultList.size());
        if (resultList.size() > 0) {
            CustomerCasaAccount customerCasaAccount = null;
            for (Object[] row : resultList) {
                Long customerCasaAccountId = Long.valueOf(row[0].toString());
                customerCasaAccount = repository.get(customerCasaAccountId, _serviceContext);

                customerCasaAccountList.add(customerCasaAccount);
            }
        }

        return customerCasaAccountList;
    }
}
