package lk.ideahub.symphony.modules.amex.service;

import lk.ideahub.symphony.modules.amex.entity.AMEXIntegrationResponse;
import lk.ideahub.symphony.modules.amex.repository.AMEXIntegrationResponseRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class AMEXIntegrationResponseServiceImpl extends GenericService implements AMEXIntegrationResponseService {

    private static final Logger log = LoggerFactory.getLogger(AMEXIntegrationResponseServiceImpl.class);

    @Autowired
    private AMEXIntegrationResponseRepository repository;

    @Override
    public AMEXIntegrationResponse get(final Object _amexIntegrationResponseId, final ServiceContext _serviceContext) {
        return repository.get(_amexIntegrationResponseId, _serviceContext);
    }

    @Override
    public List<AMEXIntegrationResponse> find(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        return repository.find(_amexIntegrationResponse, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        repository.add(_amexIntegrationResponse, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        repository.update(_amexIntegrationResponse, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext) {
        repository.delete(_amexIntegrationResponse, _serviceContext);
    }
}
