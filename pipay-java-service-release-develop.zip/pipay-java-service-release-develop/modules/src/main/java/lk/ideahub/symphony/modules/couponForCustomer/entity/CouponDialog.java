package lk.ideahub.symphony.modules.couponForCustomer.entity;
import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.types.entity.Language;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;


@Entity
@NamedNativeQueries({
        @NamedNativeQuery(name = "CouponDialog.find", query = "select * from coupon_dialog" +

                "  where" +
                "    (:lang is null or lang = :lang)"
        )})
@Getter
@Setter
@ToString
@Table(name = "coupon_dialog")
public class CouponDialog extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="COUPON_DIALOG_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "coupon_dialog_id")
    private Long couponDialogId;

    @Column(name = "title")
    private String title;

    @Column(name = "dialog")
    private String dialog;

    @ManyToOne
    @JoinColumn(name = "language_id")
    private Language language;

}
