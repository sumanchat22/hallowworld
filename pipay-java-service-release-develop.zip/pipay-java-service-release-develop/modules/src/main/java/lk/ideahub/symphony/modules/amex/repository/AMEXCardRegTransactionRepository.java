package lk.ideahub.symphony.modules.amex.repository;

import lk.ideahub.symphony.modules.amex.entity.AMEXCardRegTransaction;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface AMEXCardRegTransactionRepository {

    AMEXCardRegTransaction get(final Object _amexCardRegTransactionId, final ServiceContext _serviceContext);

    List<AMEXCardRegTransaction> find(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    void add(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    AMEXCardRegTransaction update(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    void delete(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    List<Object[]> findByCustomerId(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);
}
