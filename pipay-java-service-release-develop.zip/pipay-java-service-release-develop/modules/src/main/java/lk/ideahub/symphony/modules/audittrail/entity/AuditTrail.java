package lk.ideahub.symphony.modules.audittrail.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "audit_trail")
public class AuditTrail {

    @Id
    @SequenceGenerator(name="generator", sequenceName="AUDIT_TRAIL_SEQ",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "audit_trail_id")
    private Long auditTrailId;

    @Column(name = "identifier_id")
    private String identifierId;

    @Column(name = "identifier_string")
    private String identifierString;
    
    @Column(name = "operation_type")
    private String operationType;

    @Column(name = "client_ip")
    private String clientIp;

    @Column(name = "request_detail")
    private String requestDetail;

    @Column(name = "appl_class")
    private String applClass;

    @Column(name = "appl_method")
    private String applMethod;
    
    @Column(name = "response_status")
    private String responseStatus;

    @Column(name = "response_message")
    private String responseMessage;
    
    @Column(name = "created_datetime")
    private Date createdDatetime;

	public Long getAuditTrailId() {
		return auditTrailId;
	}

	public void setAuditTrailId(Long auditTrailId) {
		this.auditTrailId = auditTrailId;
	}

	public String getIdentifierId() {
		return identifierId;
	}

	public void setIdentifierId(String identifierId) {
		this.identifierId = identifierId;
	}

	public String getIdentifierString() {
		return identifierString;
	}

	public void setIdentifierString(String identifierString) {
		this.identifierString = identifierString;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getRequestDetail() {
		return requestDetail;
	}

	public void setRequestDetail(String requestDetail) {
		this.requestDetail = requestDetail;
	}

	public String getApplClass() {
		return applClass;
	}

	public void setApplClass(String applClass) {
		this.applClass = applClass;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getApplMethod() {
		return applMethod;
	}

	public void setApplMethod(String applMethod) {
		this.applMethod = applMethod;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public Date getCreatedDatetime() {
		return createdDatetime;
	}

	public void setCreatedDatetime(Date createdDatetime) {
		this.createdDatetime = createdDatetime;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
    
    
}
