package lk.ideahub.symphony.modules.banner.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

@Entity
@Table(name = "banners")
@NamedQueries({
        @NamedQuery(name = "Banner.find", query = "select b from Banner b" +
                "  where" +
                "    (:name is null or b.name = :name)")})
@Cacheable
@Getter
@Setter
@ToString
public class Banner extends AbstractEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "banner_id")
    private Long bannerId;

    @Column(name = "name")
    private String name;

    /*@Column(name = "deal_banner_type_id")
    private Long dealBannerTypeId;*/

    @Column(name = "is_active")
    private String isActive;

    @Column(name = "uuid")
    private String uuid;

    @Column(name = "enterprise_id")
    private Long enterpriseId;
    
    @JsonIgnore
	@ManyToOne
    @JoinColumn(name = "deal_banner_type_id")
    private DealBannerType dealBannerType;

    @Transient
    private List<BannerSlide> bannerSlideList;

    
}
