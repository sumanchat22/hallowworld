package lk.ideahub.symphony.modules.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuditUtil {
	
	public static final String CUSTOMER_ID = "customerID";
	public static final String MSISDN = "msisdn";
	
	public static final String USER_ID = "userID";
	public static final String MERCHANT_ID = "merchantID";
	public static final String EMAIL = "email";
	
	public static final String TYPE = "type";
	public static final String TYPE_CRON = "Cron";
	
	public static final String FAILURE = "failure";
	
	private static final Logger log = LoggerFactory.getLogger(AuditUtil.class);
	
	
	public static String getAuditFieldFromDetail(String field,String deatil){
		try{
		String details[] = deatil.split(",");
		for (int i = 0; i < details.length; i++) {
			String detailItem[] = details[i].split("=");
			if(detailItem[0].trim().equalsIgnoreCase(field)){
				return detailItem[1].trim();
			}
		}
		}catch(Exception e){
			log.error("Error in reading audit field : "+field+" from detail: " + deatil);
		}
		return "";
	}

}
