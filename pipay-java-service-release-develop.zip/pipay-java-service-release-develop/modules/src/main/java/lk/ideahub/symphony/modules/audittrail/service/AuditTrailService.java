package lk.ideahub.symphony.modules.audittrail.service;


import lk.ideahub.symphony.modules.audittrail.entity.AuditTrail;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface AuditTrailService {

    void add(final AuditTrail auditTrail, final ServiceContext _serviceContext);

}
