package lk.ideahub.symphony.modules.casa.service;

import java.util.List;

import lk.ideahub.symphony.modules.casa.entity.CASAEnabledDevice;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface CASAEnabledDeviceService {

    CASAEnabledDevice get(final Object _casaEnabledDeviceId, final ServiceContext _serviceContext);

    List<CASAEnabledDevice> find(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext);

    void add(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext);

    void update(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext);

    void delete(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext);
}
