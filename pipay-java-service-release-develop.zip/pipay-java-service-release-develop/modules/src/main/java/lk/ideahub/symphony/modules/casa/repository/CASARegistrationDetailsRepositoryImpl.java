package lk.ideahub.symphony.modules.casa.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.casa.entity.CASARegistrationDetails;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class CASARegistrationDetailsRepositoryImpl extends GenericRepository implements CASARegistrationDetailsRepository {

    private static final Logger log = LoggerFactory.getLogger(CASARegistrationDetailsRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CASARegistrationDetails get(final Object __casaRegistrationDetailsId, final ServiceContext _serviceContext) {
        return entityManager.find(CASARegistrationDetails.class, __casaRegistrationDetailsId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CASARegistrationDetails> find(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CASARegistrationDetails.find");
        query.setParameter("referenceId", __casaRegistrationDetails.getReferenceId());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        __casaRegistrationDetails.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        __casaRegistrationDetails.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(__casaRegistrationDetails);
        entityManager.flush();
    }

    @Override
    public CASARegistrationDetails update(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        __casaRegistrationDetails.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(__casaRegistrationDetails);
    }

    @Override
    public void delete(final CASARegistrationDetails __casaRegistrationDetails, final ServiceContext _serviceContext) {
        entityManager.remove(__casaRegistrationDetails);
    }
}
