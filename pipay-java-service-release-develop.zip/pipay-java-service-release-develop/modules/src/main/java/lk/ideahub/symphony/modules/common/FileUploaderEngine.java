package lk.ideahub.symphony.modules.common;

import java.io.InputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.amazonaws.services.s3.model.PutObjectResult;
import lk.ideahub.symphony.product.sympay.common.S3Wrapper;

@Component
public class FileUploaderEngine {
	
	private static final Logger log = LoggerFactory.getLogger(FileUploaderEngine.class);

	@Autowired
    private S3Wrapper s3Wrapper;
	
	public PutObjectResult uploadDocument(InputStream inputStream, String bucketName,String fileName) {
		PutObjectResult result = s3Wrapper.uploadDocToPrivateBucket(inputStream, fileName, bucketName);
        log.info("FileUploaderEngine - " + "Successfully uploaded", fileName);
        
        return result;
	}
}
