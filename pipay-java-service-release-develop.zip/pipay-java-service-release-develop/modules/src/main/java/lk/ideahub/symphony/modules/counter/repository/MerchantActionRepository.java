package lk.ideahub.symphony.modules.counter.repository;

import java.util.List;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.counter.entity.MerchantAction;


public interface MerchantActionRepository {

	MerchantAction get(final Object merchantActionId, final ServiceContext serviceContext);

    List<MerchantAction> find(final MerchantAction merchantAction, final ServiceContext serviceContext);

    void add(final MerchantAction merchantAction, final ServiceContext serviceContext);

    void update(final MerchantAction merchantAction, final ServiceContext serviceContext);

    void delete(final MerchantAction merchantAction, final ServiceContext serviceContext);

    List<Long> findByActionGrp(final MerchantAction merchantAction);
}
