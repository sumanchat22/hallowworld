package lk.ideahub.symphony.modules.amex.service;

import lk.ideahub.symphony.modules.amex.entity.AMEXIntegrationResponse;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface AMEXIntegrationResponseService {

    AMEXIntegrationResponse get(final Object _amexIntegrationResponseId, final ServiceContext _serviceContext);

    List<AMEXIntegrationResponse> find(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext);

    void add(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext);

    void update(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext);

    void delete(final AMEXIntegrationResponse _amexIntegrationResponse, final ServiceContext _serviceContext);
}
