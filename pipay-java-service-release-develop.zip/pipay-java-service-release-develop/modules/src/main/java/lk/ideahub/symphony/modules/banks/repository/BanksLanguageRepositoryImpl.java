package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BanksLanguage;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 15-Dec-2021
 */

@Repository
public class BanksLanguageRepositoryImpl extends GenericRepository implements BanksLanguageRepository {
    private static final Logger log = LoggerFactory.getLogger(BanksLanguageRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public BanksLanguage get(final Object banksLanguageId, final ServiceContext serviceContext) {
        return entityManager.find(BanksLanguage.class, banksLanguageId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<BanksLanguage> find(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        Query query = entityManager.createNamedQuery("BanksLanguage.find");

        handlePagination(query, serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        entityManager.persist(banksLanguage);
        entityManager.flush();
    }

    @Override
    public BanksLanguage update(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        return entityManager.merge(banksLanguage);
    }

    @Override
    public void delete(final BanksLanguage banksLanguage, final ServiceContext serviceContext) {
        entityManager.remove(banksLanguage);
    }

    @Override
    public List<BanksLanguage> getText(BanksLanguage banksLanguage) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(BanksLanguage.class);

        criteria.add(Restrictions.eq("language", banksLanguage.getLanguage()));
        criteria.add(Restrictions.eq("columnKey", banksLanguage.getColumnKey()));
        criteria.add(Restrictions.eq("banks", banksLanguage.getBanks()));

        return criteria.list();
    }

}
