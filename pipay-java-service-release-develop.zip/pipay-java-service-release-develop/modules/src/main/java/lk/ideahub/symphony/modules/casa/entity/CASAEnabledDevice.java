package lk.ideahub.symphony.modules.casa.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.customer.entity.Customer;

@Entity
@Table(name = "casa_enabled_devices")
@NamedQueries({
        @NamedQuery(name = "CASAEnabledDevice.find", query = "select CED from CASAEnabledDevice CED" +
                "  where" +
                "    (:customer is null or CED.customer = :customer)" +
                "  and" +
                "    (:uid is null or CED.uid = :uid)")})
public class CASAEnabledDevice extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="CASA_ENABLED_DEVICES_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "casa_enabled_device_id")
    private Long casaEnabledDeviceId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "casa_enbl_devc_uid")
    private String uid;

    @Column(name = "current_step")
    private String currentStep;

    public Long getCasaEnabledDeviceId() {
        return casaEnabledDeviceId;
    }

    public void setCasaEnabledDeviceId(Long casaEnabledDeviceId) {
        this.casaEnabledDeviceId = casaEnabledDeviceId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getCurrentStep() {
        return currentStep;
    }

    public void setCurrentStep(String currentStep) {
        this.currentStep = currentStep;
    }

    @Override
    public String toString() {
        return new StringBuilder("CASAEnabledDevice {")
                .append("casaEnabledDeviceId=").append(casaEnabledDeviceId).append(", ")
                .append("customer=").append(customer).append(", ")
                .append("uid='").append(uid).append("'")
                .append('}').toString();
    }
}
