package lk.ideahub.symphony.modules.common;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;

public class TransactionReferenceGenerator {


	public static String getReferenceNo(Long currentId) {
		// format of the generated no
		// Year(4) + Zeros(12-currentId) + currentId + Random No(1)

		int suffixLength = 12;
		int currentIdLength = (String.valueOf(currentId).trim()).length();
		int lengthDiff = suffixLength - currentIdLength;
		int noOfZeros = 0;
		if (lengthDiff > 0) {
				noOfZeros = lengthDiff;
		}
		
		int yearPrefix = Calendar.getInstance().get(Calendar.YEAR);

		StringBuilder zero = new StringBuilder("");
		for (int i = 0; i < noOfZeros; i++) {
			zero.append("0");
		}
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(10);
		
		String nextId = yearPrefix+zero.toString().trim()+currentId+randomInt;
		return nextId;

	}

	public static void main(String[] args) {
		String id = getReferenceNo(11223344556677l);
		System.out.println("Id=" + id);

	}
}
