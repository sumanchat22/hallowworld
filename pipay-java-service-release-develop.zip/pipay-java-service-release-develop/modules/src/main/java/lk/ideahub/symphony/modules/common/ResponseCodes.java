package lk.ideahub.symphony.modules.common;

public class ResponseCodes {

	public static final String INTERNAL_SERVER_ERROR_CODE = "500";
	public static final String INTERNAL_SERVER_ERROR_MSG = "Internal Server Error";

	public static final String INVALID_REGISTER_OTP_CONFIRM_ERROR_CODE = "6101";

	public static final String INVALID_LOGIN_OTP_CONFIRM_ERROR_CODE = "6201";

	public static final String EMPTY_NOTIFICATION_LIST_CODE = "6301";
	
	//pink packets
	public static final String PINK_PACKET_GROUP_INVALID_CODE = "6401";
	public static final String PINK_PACKET_GROUP_EXPIRED_CODE = "6402";
	public static final String PINK_PACKET_GROUP_NOT_COMPLETELY_INITIATED_CODE = "6403";
	public static final String PINK_PACKET_INVALID_STATUS_CODE = "6404";
	public static final String PINK_PACKET_NO_MORE_PACKETS_CODE = "6405";
	public static final String PINK_PACKET_CUSTOMER_NOT_ELIGIBALE_CODE = "6406";
	public static final String PINK_PACKET_ALREADY_RESERVED_BY_THIS_CUSTOMER_CODE = "6407";
	public static final String PINK_PACKET_ERROR_IN_ACCEPT_CODE = "6408";
	public static final String PINK_PACKET_HOLD_INVALID_AMOUNT_CODE = "6409";
	
	//Loyalty
	public static final String LOYALTY_POINTS_INSUFFICIENT_CODE = "6501";

	//outlet
	public static final String ALREADY_ADDED_REVIEW = "6601";

	//customer
	public static final String ALREADY_SENT_SMS_CODE = "6701";

	public static final String LOYALTY_EXTERNAL_SUCCESS = "00";
	public static final String LOYALTY_EXTERNAL_POINT_TXN_NOT_FOUND = "6002";

	public static final String AGG_EXTERNAL_SUCCESS = "OK";
	public static final String E_COMMERCE_EXTERNAL_SUCCESS = "0000";
}
