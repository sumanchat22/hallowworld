package lk.ideahub.symphony.modules.counter.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import lk.ideahub.symphony.modules.counter.entity.OutletCounterMerchantAction;

@Repository
public class OutletCounterMerchantActionRepositoryImpl extends GenericRepository implements OutletCounterMerchantActionRepository {

	private static final Logger log = LoggerFactory.getLogger(OutletCounterMerchantActionRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;
    
    @Autowired
    Environment environment;

	@Override
	public OutletCounterMerchantAction get(Object outletCounterMerchantActionId, ServiceContext serviceContext) {
		return entityManager.find(OutletCounterMerchantAction.class, outletCounterMerchantActionId);
	}

	@Override
	public void add(OutletCounterMerchantAction outletCounterMerchantAction, ServiceContext serviceContext) {
		outletCounterMerchantAction.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)));
		outletCounterMerchantAction.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)));
        entityManager.persist(outletCounterMerchantAction);
        entityManager.flush();
	}

	@Override
	public void update(OutletCounterMerchantAction outletCounterMerchantAction, ServiceContext serviceContext) {
		outletCounterMerchantAction.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)));
	    entityManager.merge(outletCounterMerchantAction);
	}

	@Override
	public void delete(OutletCounterMerchantAction outletCounterMerchantAction, ServiceContext serviceContext) {
		entityManager.remove(outletCounterMerchantAction);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OutletCounterMerchantAction> getByMerchantActionId(Long merchantActionId,Long outletCounterId) {
		Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(OutletCounterMerchantAction.class);
        criteria.add(Restrictions.eq("merchantAction.merchantActionId",merchantActionId));
        criteria.add(Restrictions.eq("outletCounter.outletCounterId",outletCounterId));
        return criteria.list();
	}
}
