package lk.ideahub.symphony.modules.banner.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.banner.entity.Banner;
import lk.ideahub.symphony.modules.banner.entity.BannerDto;
import lk.ideahub.symphony.modules.banner.entity.BannerSlide;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.RequestStatus;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.product.sympay.common.LogSupport;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BannerManagerServiceImpl extends GenericService implements BannerManagerService {

	private static final Logger log = LoggerFactory.getLogger(BannerManagerServiceImpl.class);
	
	@Autowired
	BannerService bannerService;
	
	@Autowired
	BannerSlideService bannerSlideService;

	@Override
	public BannerDto getHomeBanner(BannerDto bannerDto) {
		log.info(LogSupport.GET_HOME_BANNER + "Getting home banners..");
		
		bannerDto.setBannerSlides(new ArrayList<BannerSlide>());
		
		List<Banner> banners = bannerService.getListFromDealBannerType(Constants.HOME_BANNER);
		if(banners != null && banners.size() > 0) {
			List<BannerSlide> bannerSlides = bannerSlideService.getBannerSlidesForABanner(banners.get(0).getBannerId());
			bannerDto.setBannerSlides(bannerSlides);
		}
		
		//bannerDto.setMessage(getMessageSource().getMessage(Constants.SUCCESS_MSG,null,serviceContext.getLocale()));
		bannerDto.setMessage(RequestStatus.SUCCESS.getStatus());
		bannerDto.setStatus(RequestStatus.SUCCESS.getStatus());
		
		return bannerDto;
	}
}
