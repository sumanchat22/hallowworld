package lk.ideahub.symphony.modules.beacon.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.beacon.entity.Beacon;
import lk.ideahub.symphony.modules.beacon.repository.BeaconRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BeaconServiceImpl extends GenericService implements BeaconService {

    private static final Logger log = LoggerFactory.getLogger(BeaconServiceImpl.class);

    @Autowired
    private BeaconRepository repository;

    @Override
    public Beacon get(final Object _beaconId, final ServiceContext _serviceContext) {
        return repository.get(_beaconId, _serviceContext);
    }

    @Override
    public List<Beacon> find(final Beacon _beacon, final ServiceContext _serviceContext) {
        return repository.find(_beacon, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final Beacon _beacon, final ServiceContext _serviceContext) {
        repository.add(_beacon, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final Beacon _beacon, final ServiceContext _serviceContext) {
        repository.update(_beacon, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final Beacon _beacon, final ServiceContext _serviceContext) {
        repository.delete(_beacon, _serviceContext);
    }
}
