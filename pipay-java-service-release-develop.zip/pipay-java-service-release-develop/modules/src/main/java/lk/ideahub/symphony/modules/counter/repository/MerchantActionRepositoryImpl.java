package lk.ideahub.symphony.modules.counter.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;
import lk.ideahub.symphony.modules.common.Constants;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.common.Utils;
import lk.ideahub.symphony.modules.counter.entity.MerchantAction;

@Repository
public class MerchantActionRepositoryImpl extends GenericRepository implements MerchantActionRepository {

	private static final Logger log = LoggerFactory.getLogger(MerchantActionRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;
    
    @Autowired
    Environment environment;
    
	@Override
	public MerchantAction get(Object merchantActionId, ServiceContext serviceContext) {
		return entityManager.find(MerchantAction.class, merchantActionId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MerchantAction> find(MerchantAction merchantAction, ServiceContext serviceContext) {
		Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(MerchantAction.class);
        if(merchantAction!= null && merchantAction.getName() != null) {
        	criteria.add(Restrictions.eq("name",merchantAction.getName()));
        }
        return criteria.list();
	}

	@Override
	public void add(MerchantAction merchantAction, ServiceContext serviceContext) {
		merchantAction.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)));
		merchantAction.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)));
        entityManager.persist(merchantAction);
        entityManager.flush();
	}

	@Override
	public void update(MerchantAction merchantAction, ServiceContext serviceContext) {
		merchantAction.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty(Constants.TIME_ZONE)));
	    entityManager.merge(merchantAction);
	}

	@Override
	public void delete(MerchantAction merchantAction, ServiceContext serviceContext) {
		entityManager.remove(merchantAction);
	}

	@Override
	public List<Long> findByActionGrp(MerchantAction merchantAction) {
		Session session = entityManager.unwrap(Session.class);
		Criteria criteria = session.createCriteria(MerchantAction.class);
		criteria.setProjection(Projections.property("merchantActionId"));
		criteria.add(Restrictions.eq("merchantActionGroup", merchantAction.getMerchantActionGroup()));
		return criteria.list();
	}

}
