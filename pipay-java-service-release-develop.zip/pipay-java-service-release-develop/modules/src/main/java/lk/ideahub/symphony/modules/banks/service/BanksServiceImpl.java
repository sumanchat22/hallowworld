package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.Banks;
import lk.ideahub.symphony.modules.banks.repository.BanksRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.CustomerAttempt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 08-Dec-2021
 */

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BanksServiceImpl extends GenericService implements BanksService {

    private static final Logger log = LoggerFactory.getLogger(BanksServiceImpl.class);

    @Autowired
    private BanksRepository repository;

    @Override
    public Banks get(final Object banksId, final ServiceContext serviceContext) {
        return repository.get(banksId, serviceContext);
    }

    @Override
    public List<Banks> find(final Banks banks, final ServiceContext serviceContext) {
        return repository.find(banks, serviceContext);
    }

    @Override
    public List<Banks> findByMainWallet(String bankMainWallet, ServiceContext serviceContext) {
        return repository.findByMainWallet(bankMainWallet, serviceContext);
    }

    @Override
    public List<Banks> findByMainWalletSuffix(String bankMainWalletSuffix, ServiceContext serviceContext) {
        return repository.findByMainWalletSuffix(bankMainWalletSuffix, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final Banks banks, final ServiceContext serviceContext) {
        banks.setCreatedDatetime(Calendar.getInstance().getTime());
        repository.add(banks, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final Banks banks, final ServiceContext serviceContext) {
        banks.setModifiedDatetime(Calendar.getInstance().getTime());
        repository.update(banks, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final Banks banks, final ServiceContext serviceContext) {
        repository.delete(banks, serviceContext);
    }

    @Override
    public List<Banks> getBanksList(Banks banks, ServiceContext serviceContext) {
        return repository.getBanksList(banks, serviceContext);
    }

//    @Override
//    public List<Banks> getBanksListByIntegrationType(Banks banks, ServiceContext serviceContext) {
//
//        List<Object[]> resultList = repository.getBanksListByIntegrationType(banks, serviceContext);
//        System.out.println("resultList");
//        System.out.println(resultList);
//        List<Banks> banksList = new ArrayList<>();
//
//        if (resultList.size() > 0) {
//            Banks banksData = null;
//
//            for (Object[] row : resultList) {
//                System.out.println("row");
//                System.out.println(row);
//                Long bankId = Long.valueOf(row[0].toString());
//                System.out.println("bankId");
//                System.out.println(bankId);
//                banksData = repository.get(bankId, serviceContext);
//                System.out.println("banksData");
//                System.out.println(banksData);
//                //banksData = row;
//                banksList.add(banksData);
//            }
//
//        }
//
//        return banksList;
//    }

    @Override
    public List<Banks> getBanksListByIntegrationType(final Banks banks, final ServiceContext serviceContext) {
        List<Object[]> resultList = repository.getBanksListByIntegrationType(banks, serviceContext);
        List<Banks> banksList = new ArrayList<Banks>(resultList.size());

        if (resultList.size() > 0) {
            Banks banksNew = null;
            for (Object[] row : resultList) {
                Long banksId = Long.valueOf(row[0].toString());
                banksNew = repository.get(banksId, serviceContext);
                banksList.add(banksNew);
            }
        }

        return banksList;

    }

}
