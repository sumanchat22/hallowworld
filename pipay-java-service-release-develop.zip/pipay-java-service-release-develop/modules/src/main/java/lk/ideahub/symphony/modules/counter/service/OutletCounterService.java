package lk.ideahub.symphony.modules.counter.service;

import java.util.List;

import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.counter.entity.OutletCounter;

public interface OutletCounterService {

    OutletCounter get(final Object _outletCounterId, final ServiceContext _serviceContext);

    List<OutletCounter> find(final OutletCounter _outletCounter, final ServiceContext _serviceContext);

    void add(final OutletCounter _outletCounter, final ServiceContext _serviceContext);

    void update(final OutletCounter _outletCounter, final ServiceContext _serviceContext);

    void delete(final OutletCounter _outletCounter, final ServiceContext _serviceContext);

    List<OutletCounter> findValidCounter(OutletCounter _outletCounter, ServiceContext _serviceContext);
    
    /**
     * Get OutletCounter by External Id 
     * @param externalId
     * @param serviceContext
     * @return OutletCounter
     */
    OutletCounter getByExternalId(final Long externalId, final ServiceContext serviceContext);

    List<OutletCounter> findOutletCounterById(OutletCounter outletCounter,ServiceContext serviceContext);
}
