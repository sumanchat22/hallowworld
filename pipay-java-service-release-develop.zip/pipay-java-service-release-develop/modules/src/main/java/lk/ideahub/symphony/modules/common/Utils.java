package lk.ideahub.symphony.modules.common;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

public final class Utils {

	//public static final String IST_ZOME ="IST";
	public static final String IST_ZOME ="Asia/Colombo";
    private static final Logger log = LoggerFactory.getLogger(Utils.class);
    
    public static Date getCurrentUtcDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        SimpleDateFormat dateFormatUtc = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        dateFormatUtc.setTimeZone(TimeZone.getTimeZone("UTC"));

        Date date = new Date();
        Date utc = null;
        try {
            utc = dateFormat.parse(dateFormatUtc.format(date));
        } catch (ParseException exception) {
            log.warn("Unable to obtain UTC date using local date, defaulting to local date", exception);
            utc = date;
        }
        return utc;
    }
    public static String longToString(Long param){
        DecimalFormat decimalFormat = new DecimalFormat("#");
        return decimalFormat.format(param);
    }

    public static Date getCurrentIstDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        SimpleDateFormat dateFormatIst = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        dateFormatIst.setTimeZone(TimeZone.getTimeZone(IST_ZOME));

        Date date = new Date();
        Date ist = null;
        try {
            ist = dateFormat.parse(dateFormatIst.format(date));
        } catch (ParseException exception) {
            log.warn("Unable to obtain IST date using local date, defaulting to local date", exception);
            ist = date;
        }
        return ist;
    }

    private Utils() {
    }

    public static Date getDateFromString(String _date){

        DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
        Date date  = null;
        try {
            date = ((Date) formatter.parse(_date));
        }catch (ParseException e){
            log.error("Unable to obtain date using string date object", e);
        }
        return date;
    }


    public static Date getDateFromString2(String _date){

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date  = null;
        try {
            date = formatter.parse(_date);
        }catch (ParseException e){
            log.error("Unable to obtain date using string date object", e);
        }
        return date;
    }

    public static Date getDateFromString3(String _date){
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        Date date  = null;
        try {
            date = ((Date) formatter.parse(_date));
        }catch (ParseException e){
            log.error("Unable to obtain date using string date object", e);
        }
        return date;
    }
    
    public static String getDateOnly(Date date){

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String strDate  =  formatter.format(date);
        return strDate;
    }
    
    public static String getTimeOnly(Date date){

        DateFormat formatter = new SimpleDateFormat("HH:mm");
        String strDate  =  formatter.format(date);
        return strDate;
    }

    public static String getDateTime(Date date){

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String strDate  =  formatter.format(date);
        return strDate;
    }

    public static String getDateTime2(Date date){

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String strDate  =  formatter.format(date);
        return strDate;
    }
    
    public static String maskNumber(String number) {

        String response;
        if(number == null || number.equals("")){
            response = null;
        }else {

            String realNumber = number;
            char c = 'X';
            StringBuilder masked = new StringBuilder();
            for (int i = 0; i < number.length(); i++) {
                if (i == 0) {
                    masked.append(realNumber.charAt(i));
                } else if (i < number.length() - 4) {
                    masked.append(c);
                } else {
                    masked.append(realNumber.charAt(i));
                }
            }

            response = masked.toString();
        }
        return response;
    }

    public static String sha1(String input) {
        StringBuffer sb = new StringBuffer();
        try {
            MessageDigest mDigest = MessageDigest.getInstance("SHA1");
            byte[] result = mDigest.digest(input.getBytes());

            for (int i = 0; i < result.length; i++) {
                sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
            }
        }catch (NoSuchAlgorithmException e){
            log.error("Unable to obtain sha1 value", e);
        }
        return sb.toString();
    }

    public static boolean isGraterThan18(Date today, Date request) {

        boolean isGraterThan18 = false;

        try {

            Calendar requestCal = Calendar.getInstance();
            requestCal.setTime(request);

            Calendar todayCal = Calendar.getInstance();
            todayCal.setTime(today);

            long requestMilliSecond = requestCal.getTimeInMillis();
            long todayMilliSecond = todayCal.getTimeInMillis();

            long differMilliSecond = todayMilliSecond - requestMilliSecond;

            long diffDyas = differMilliSecond / 1000 / 60 / 60 / 24;

            //18years = 6575days
            /*if (diffDyas >= 6575 ) {
                isGraterThan18 = true;
            }*/
            //12years = 4384days
            if (diffDyas >= 4383 ) {
                isGraterThan18 = true;
            }


        } catch (Exception e) {
            log.error("Unable to get years form selected dates", e);
        }

        return isGraterThan18;
    }

    public static Date getCustomerZoneTime(Date date, String timeZone) {

        Date actual = null;

        if (date != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            SimpleDateFormat dateFormatZone = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
            dateFormatZone.setTimeZone(TimeZone.getTimeZone(timeZone));

            try {
                actual = dateFormat.parse(dateFormatZone.format(date));
            } catch (ParseException exception) {
                log.warn("Unable to obtain UTC date using local date, defaulting to local date", exception);
                actual = date;
            }
        }

        return actual;
    }
    
    public static String getThousandsSeparatorValue(BigDecimal amount){
    	String strAmount = String.format("%,.2f",amount);
    	return strAmount;
    }

    public static Date getCurrentDateByTimeZone(String timeZone) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        SimpleDateFormat dateFormatConf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        dateFormatConf.setTimeZone(TimeZone.getTimeZone(timeZone));


        Date date = new Date();
        Date confTime = null;
        try {
            confTime = dateFormat.parse(dateFormatConf.format(date));
        } catch (ParseException exception) {
            log.warn("Unable to obtain TimeZone date using local date, defaulting to local date", exception);
            confTime = date;
        }
        return confTime;
    }

    /**
     * This works to mask account number and only release last four number
     * @param number
     * @return masked number
     */
    public static String maskAccountNumber(String number) {

        String response;
        if(number == null || number.equals("")){
            response = null;
        }else {

            String realNumber = number;
            char c = 'X';
            StringBuilder masked = new StringBuilder();
            for (int i = 0; i < number.length(); i++) {
                if (i < number.length() - 4) {
                    masked.append(c);
                } else {
                    masked.append(realNumber.charAt(i));
                }
            }

            response = masked.toString();
        }
        return response;
    }

    public static String sayDayName(Date d) {
        DateFormat f = new SimpleDateFormat("EEEE");
        try {
            return f.format(d);
        }
        catch(Exception e) {
        	log.error(e.getMessage());
            return "";
        }
    }

    public static Date addDaysTodate(Date date, int days){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, days);
        return c.getTime();
    }

    public static String formatStringNumber(Double number) {
        DecimalFormat formatter = new DecimalFormat("#,###.00");
        try {
            return formatter.format(number);
        }
        catch(Exception e) {
            log.error(e.getMessage());
            return String.valueOf(number);
        }

    }
    public static String formatToYesterdayOrTodayOrTomorrow(String date) {
        try {
            Date dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateTime);
            Calendar today = Calendar.getInstance();
            Calendar yesterday = Calendar.getInstance();
            yesterday.add(Calendar.DATE, -1);
            Calendar tomorrow = Calendar.getInstance();
            tomorrow.add(Calendar.DATE, 1);


            if (calendar.get(Calendar.YEAR) == today.get(Calendar.YEAR) && calendar.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                return Constants.TODAY;
            } else if (calendar.get(Calendar.YEAR) == yesterday.get(Calendar.YEAR) && calendar.get(Calendar.DAY_OF_YEAR) == yesterday.get(Calendar.DAY_OF_YEAR)) {
                return Constants.YESTERDAY;
            } else if (calendar.get(Calendar.YEAR) == tomorrow.get(Calendar.YEAR) && calendar.get(Calendar.DAY_OF_YEAR) == tomorrow.get(Calendar.DAY_OF_YEAR)) {
                return Constants.TOMORROW;
            } else {
                return new SimpleDateFormat("MMM dd, yyyy hh:mm a").format(dateTime);
                //return Utils.getDateTime(dateTime);
            }
        } catch (Exception e) {
            log.info("Exception in formatToYesterdayOrTodayOrTomorrow " + e);
            return date;
        }
    }

    public static Date addMinuteToDate(Date date, int minute){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MINUTE, minute);
        return c.getTime();
    }

    public static Date addHourToDate(Date date, int hour){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.HOUR, hour);
        return c.getTime();
    }

    public static boolean isJSONValid(String jsonString) {
        try {
            new JSONObject(jsonString);
        } catch (JSONException ex) {
            // e.g. in case JSONArray is valid as well...
            try {
                new JSONArray(jsonString);
            } catch (JSONException e) {
                return false;
            }
        }
        return true;
    }
    
}
