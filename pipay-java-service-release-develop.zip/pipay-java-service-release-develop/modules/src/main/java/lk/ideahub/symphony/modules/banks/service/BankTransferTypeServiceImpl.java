package lk.ideahub.symphony.modules.banks.service;

import lk.ideahub.symphony.modules.banks.entity.BankTransferType;
import lk.ideahub.symphony.modules.banks.repository.BankTransferTypeRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 20-Dec-2021
 */

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BankTransferTypeServiceImpl extends GenericService implements BankTransferTypeService {
    private static final Logger log = LoggerFactory.getLogger(BankTransferTypeServiceImpl.class);

    @Autowired
    private BankTransferTypeRepository repository;

    @Override
    public BankTransferType get(final Object bankTransferTypeId, final ServiceContext serviceContext) {
        return repository.get(bankTransferTypeId, serviceContext);
    }

    @Override
    public List<BankTransferType> find(final BankTransferType bankTransferType, final ServiceContext serviceContext) {
        return repository.find(bankTransferType, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final BankTransferType bankTransferType, final ServiceContext serviceContext) {
        repository.add(bankTransferType, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final BankTransferType bankTransferType, final ServiceContext serviceContext) {
        repository.update(bankTransferType, serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final BankTransferType bankTransferType, final ServiceContext serviceContext) {
        repository.delete(bankTransferType, serviceContext);
    }

    @Override
    public List<BankTransferType> findByName(final BankTransferType bankTransferType, final ServiceContext serviceContext) {
        return repository.findByName(bankTransferType, serviceContext);
    }

}
