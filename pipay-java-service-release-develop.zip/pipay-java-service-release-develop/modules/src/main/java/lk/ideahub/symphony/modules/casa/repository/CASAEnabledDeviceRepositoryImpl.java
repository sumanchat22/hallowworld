package lk.ideahub.symphony.modules.casa.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.casa.entity.CASAEnabledDevice;
import lk.ideahub.symphony.modules.common.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class CASAEnabledDeviceRepositoryImpl extends GenericRepository implements CASAEnabledDeviceRepository {

    private static final Logger log = LoggerFactory.getLogger(CASAEnabledDeviceRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Autowired
    Environment environment;

    @Override
    public CASAEnabledDevice get(final Object _casaEnabledDeviceId, final ServiceContext _serviceContext) {
        return entityManager.find(CASAEnabledDevice.class, _casaEnabledDeviceId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<CASAEnabledDevice> find(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("CASAEnabledDevice.find");
        query.setParameter("customer", _casaEnabledDevice.getCustomer());
        query.setParameter("uid", _casaEnabledDevice.getUid());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        _casaEnabledDevice.setCreatedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        _casaEnabledDevice.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        entityManager.persist(_casaEnabledDevice);
        entityManager.flush();
    }

    @Override
    public CASAEnabledDevice update(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        _casaEnabledDevice.setModifiedDatetime(Utils.getCurrentDateByTimeZone(environment.getProperty("time.zone")));
        return entityManager.merge(_casaEnabledDevice);
    }

    @Override
    public void delete(final CASAEnabledDevice _casaEnabledDevice, final ServiceContext _serviceContext) {
        entityManager.remove(_casaEnabledDevice);
    }
}
