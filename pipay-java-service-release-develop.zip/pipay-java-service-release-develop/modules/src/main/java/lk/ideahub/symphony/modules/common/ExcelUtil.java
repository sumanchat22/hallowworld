package lk.ideahub.symphony.modules.common;

import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.amazonaws.services.s3.model.PutObjectResult;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Component
public class ExcelUtil {

private static final Logger log = LoggerFactory.getLogger(ExcelUtil.class);
	
	@Autowired
	FileUploaderEngine fileUploaderEngine;
	
	@Autowired
    private Environment environment;
	
	private DateFormat dateFormatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
	private final static String BUCKET_FOLDER = "reports/";

	public Workbook initExcelFile(List<String> headers,List<String> titleData){
		try {
			
			Workbook workbook = new XSSFWorkbook();
			CreationHelper createHelper = workbook.getCreationHelper();
			Sheet sheet = workbook.createSheet("Sheet 1");
			
			Font headerFont = workbook.createFont();
	        headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 12);
	        //headerFont.setColor(IndexedColors.RED.getIndex());

	        // Create a CellStyle with the font
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        
	        //titles
	        Row titleRow = sheet.createRow(0);
	        for(int i = 0; i < titleData.size(); i++) {
	            Cell cell = titleRow.createCell(i);
	            cell.setCellValue(titleData.get(i));
	            cell.setCellStyle(headerCellStyle);
	        }
	        
	        sheet.createRow(1);//create empty row
	        
	        //table headers
	        Row headerRow = sheet.createRow(2);
	        for(int i = 0; i < headers.size(); i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(headers.get(i));
	            cell.setCellStyle(headerCellStyle);
	            //sheet.autoSizeColumn(i);
	        }

			return workbook;
		}
		catch(Exception ex) {
			log.error("ExcelUtil - initExcelFile() error:" + ex.getMessage());
		}
		return null;
	} 
	
	public void addRecords(Workbook workbook,List<? extends Object> dataList,List<String> fieldList,Integer lastRecordId) throws Exception{
		Sheet sheet = workbook.getSheetAt(0);
		sheet.getLastRowNum();

		for(Object obj : dataList) {
			Row row = sheet.createRow(sheet.getLastRowNum() + 1);
			int cellNo = 0;
			if(lastRecordId != null) {// if records id exists add it by incrementing 
				lastRecordId++;
				row.createCell(cellNo).setCellValue(lastRecordId.toString());
				cellNo++;
			}
			for(String field : fieldList) {
				row.createCell(cellNo).setCellValue(getFieldValue(obj,field));
				cellNo++;
			}
		}
	}
	
	public String uploadFile(Workbook workbook,String filePrefix,CSVPrinter csvPrinter,Date date) throws Exception{
			String bucket = environment.getProperty("s3.bucket.private");
			String fileName = BUCKET_FOLDER + filePrefix + "-" + dateFormatter.format(date) + ".xlsx";
			
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			try {
			    workbook.write(bos);
			} finally {
			    bos.close();
			}
			
			byte[] bytes = bos.toByteArray();
			InputStream inputStream = new ByteArrayInputStream(bytes);
			
			//upload to S3 bucket
			PutObjectResult result = fileUploaderEngine.uploadDocument(inputStream, bucket, fileName);
			if(result != null) {
				return fileName;
			}
			return null;
	}
	
	private String getFieldValue(Object obj, String fieldName){
		PropertyDescriptor pd;
		try {
			pd = new PropertyDescriptor(fieldName, obj.getClass());
			Object result = pd.getReadMethod().invoke(obj);
			if(result != null) {
				return result.toString();
			}
		} catch(Exception ex) {
			log.error("ExcelUtil - getFieldValue() error:" + ex.getMessage());
		}
		return "";
	}
	
	public void autoSizeCols(Sheet sheet, List<String> headers) {
		try {
			for(int i = 0; i < headers.size(); i++) {
	            sheet.autoSizeColumn(i);
	        }
		}
		catch(Exception ex) {
			log.error("ExcelUtil - autoSizeCols() error:" + ex.getMessage());
		}
	}
}
