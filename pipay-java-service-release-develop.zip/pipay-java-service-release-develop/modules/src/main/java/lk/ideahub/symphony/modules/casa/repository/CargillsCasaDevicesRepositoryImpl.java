package lk.ideahub.symphony.modules.casa.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import lk.ideahub.symphony.modules.casa.entity.CargillsCasaDevices;
import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Repository
class CargillsCasaDevicesRepositoryImpl extends GenericRepository implements CargillsCasaDevicesRepository {

    private static final Logger log = LoggerFactory.getLogger(CargillsCasaDevicesRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public CargillsCasaDevices get(final Object _CargillsCasaDevicesRepositoryId, final ServiceContext _serviceContext) {
        return entityManager.find(CargillsCasaDevices.class, _CargillsCasaDevicesRepositoryId);
    }

    @Override
    public void add(final CargillsCasaDevices _CargillsCasaDevicesRepository, final ServiceContext _serviceContext) {
        _CargillsCasaDevicesRepository.setCreatedDatetime(Calendar.getInstance().getTime());
        _CargillsCasaDevicesRepository.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_CargillsCasaDevicesRepository);
        entityManager.flush();
    }

    @Override
    public CargillsCasaDevices update(final CargillsCasaDevices _CargillsCasaDevicesRepository, final ServiceContext _serviceContext) {
        _CargillsCasaDevicesRepository.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_CargillsCasaDevicesRepository);
    }

    @Override
    public void delete(final CargillsCasaDevices _CargillsCasaDevicesRepository, final ServiceContext _serviceContext) {
        entityManager.remove(_CargillsCasaDevicesRepository);
    }

    @Override
    public List<CargillsCasaDevices> getDevicesListByCustomerCasaAccount(CargillsCustomerCasaAccount cargillsCustomerCasaAccount, ServiceContext _serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(CargillsCasaDevices.class);
        criteria.add(Restrictions.eq("cargillsCustomerCasaAccount",cargillsCustomerCasaAccount));
        return criteria.list();
    }

    @Override
    public CargillsCasaDevices findByDeviceIdAndCustomer(String deviceId, CargillsCustomerCasaAccount cargillsCustomerCasaAccount, ServiceContext _serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(CargillsCasaDevices.class);
        criteria.add(Restrictions.eq("customer",cargillsCustomerCasaAccount.getCustomer()));
        criteria.add(Restrictions.eq("deviceId",deviceId));
        criteria.add(Restrictions.eq("cargillsCustomerCasaAccount",cargillsCustomerCasaAccount));
        return (CargillsCasaDevices)criteria.uniqueResult();
    }
}
