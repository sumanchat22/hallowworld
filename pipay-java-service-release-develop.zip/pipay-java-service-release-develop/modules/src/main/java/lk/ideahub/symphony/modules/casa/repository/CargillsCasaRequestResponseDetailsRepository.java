package lk.ideahub.symphony.modules.casa.repository;


import lk.ideahub.symphony.modules.casa.entity.CargillsCasaRequestResponseDetails;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface CargillsCasaRequestResponseDetailsRepository {

    CargillsCasaRequestResponseDetails get(final Object _cargillsCasaRequestResponseDetailsId, final ServiceContext _serviceContext);

    void add(final CargillsCasaRequestResponseDetails _CargillsCasaRequestResponseDetails, final ServiceContext _serviceContext);

    CargillsCasaRequestResponseDetails update(final CargillsCasaRequestResponseDetails _cargillsCasaRequestResponseDetails, final ServiceContext _serviceContext);

    void delete(final CargillsCasaRequestResponseDetails _cargillsCasaRequestResponseDetails, final ServiceContext _serviceContext);
}
