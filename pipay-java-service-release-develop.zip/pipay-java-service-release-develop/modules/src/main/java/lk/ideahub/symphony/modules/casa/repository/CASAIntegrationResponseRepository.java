package lk.ideahub.symphony.modules.casa.repository;

import lk.ideahub.symphony.modules.casa.entity.CASAIntegrationResponse;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface CASAIntegrationResponseRepository {

    CASAIntegrationResponse get(final Object _casaIntegrationResponseId, final ServiceContext _serviceContext);

    List<CASAIntegrationResponse> find(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);

    void add(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);

    CASAIntegrationResponse update(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);

    void delete(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext);
}
