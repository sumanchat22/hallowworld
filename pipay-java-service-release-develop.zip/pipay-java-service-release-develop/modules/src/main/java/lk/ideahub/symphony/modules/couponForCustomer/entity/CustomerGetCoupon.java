package lk.ideahub.symphony.modules.couponForCustomer.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;


@Entity
@NamedQueries({
        @NamedQuery(name = "CustomerGetCoupon.find", query = "select cgc from CustomerGetCoupon cgc" +
                "  where" +
                "    (:customerId is null or cgc.customerId = :customerId)" +
                " and (:couponPackId is null or cgc.couponPackId = :couponPackId)"
        )})
@Getter
@Setter
@ToString
@Table(name = "customer_get_coupon")
public class CustomerGetCoupon extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="CUSTOMER_GET_COUPON_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "customer_get_coupon_id")
    private Long customerGetCouponId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "coupon_id")
    private Long couponId;

    @Column(name = "coupon_pack_id")
    private Long couponPackId;

    @Column(name = "app_version")
    private String appVersion;

    @Column(name = "device_type")
    private String deviceType;

    @Column(name = "is_seen")
    private Integer isSeen;

}
