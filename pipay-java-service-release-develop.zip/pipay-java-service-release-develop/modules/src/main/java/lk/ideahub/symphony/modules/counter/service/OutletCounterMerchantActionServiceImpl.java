package lk.ideahub.symphony.modules.counter.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.counter.entity.OutletCounterMerchantAction;
import lk.ideahub.symphony.modules.counter.repository.OutletCounterMerchantActionRepository;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class OutletCounterMerchantActionServiceImpl extends GenericService implements OutletCounterMerchantActionService {

	private static final Logger log = LoggerFactory.getLogger(OutletCounterServiceImpl.class);

    @Autowired
    private OutletCounterMerchantActionRepository repository;

	@Override
	public OutletCounterMerchantAction get(Object outletCounterMerchantActionId, ServiceContext serviceContext) {
		return repository.get(outletCounterMerchantActionId, serviceContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void add(OutletCounterMerchantAction outletCounterMerchantAction, ServiceContext serviceContext) {
		repository.add(outletCounterMerchantAction, serviceContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void update(OutletCounterMerchantAction outletCounterMerchantAction, ServiceContext serviceContext) {
		repository.update(outletCounterMerchantAction, serviceContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void delete(OutletCounterMerchantAction outletCounterMerchantAction, ServiceContext serviceContext) {
		repository.delete(outletCounterMerchantAction, serviceContext);
	}

	@Override
	public List<OutletCounterMerchantAction> getByMerchantActionId(Long merchantActionId,Long outletCounterId) {
		return repository.getByMerchantActionId(merchantActionId,outletCounterId);
	}
}
