package lk.ideahub.symphony.modules.audit;

import lk.ideahub.symphony.modules.audittrail.entity.AuditTrail;
import lk.ideahub.symphony.modules.audittrail.service.AuditTrailService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.service.CustomerService;
import lk.ideahub.symphony.modules.user.entity.User;
import lk.ideahub.symphony.modules.user.service.UserService;
import lk.ideahub.symphony.product.sympay.common.SymphonyDto;

import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ServiceAuditSupport {
	
	@Autowired
	private CustomerService customerService;
	@Autowired
	private UserService userService;
	
	@Autowired
	private AuditTrailService auditTrailService;

	private static final Logger log = LoggerFactory.getLogger(ServiceAuditSupport.class);

	public void saveCustomerAuditDetailAfterReturning(JoinPoint joinPoint, Object result) {
		try {
			Object[] arguments = joinPoint.getArgs();
			Object requestInfo = arguments[0];
			SymphonyDto piPayRequest = (SymphonyDto) requestInfo;
			SymphonyDto piPayResponse = (SymphonyDto) result;

			AuditTrail auditTrail = getAuditTrail(joinPoint, requestInfo,piPayRequest, piPayResponse);
			
			addCustomerDeatil(requestInfo, auditTrail);
			
		} catch (Exception e) {
			log.error("Error in audit log. Class : "
					+ joinPoint.getTarget().getClass().getSimpleName()
					+ " method name : " + joinPoint.getSignature().getName() + " /n" + e);
		}
	}

	public void saveCustomerAuditDetailAfterThrowing(JoinPoint joinPoint, Throwable error) {
		try {
			Object[] arguments = joinPoint.getArgs();
			Object requestInfo = arguments[0];
			SymphonyDto piPayRequest = (SymphonyDto) requestInfo;
			SymphonyDto piPayResponse = new SymphonyDto();
			piPayResponse.setStatus(AuditUtil.FAILURE);
			piPayResponse.setMessage(error.getMessage());

			AuditTrail auditTrail = getAuditTrail(joinPoint, requestInfo,piPayRequest, piPayResponse);
			
			addCustomerDeatil(requestInfo, auditTrail);
			
		} catch (Exception e) {
			log.error("Error in audit log. Class : "
					+ joinPoint.getTarget().getClass().getSimpleName()
					+ " method name : " + joinPoint.getSignature().getName() + " /n" + e);
		}
	}
	
	public void saveMerchantOrUserAuditDetailAfterReturning(JoinPoint joinPoint, Object result) {
		try {
			Object[] arguments = joinPoint.getArgs();
			Object requestInfo = arguments[0];
			SymphonyDto piPayRequest = (SymphonyDto) requestInfo;
			SymphonyDto piPayResponse = (SymphonyDto) result;

			AuditTrail auditTrail = getAuditTrail(joinPoint, requestInfo,piPayRequest, piPayResponse);
			
			addUserDeatil(requestInfo, auditTrail);
			
		} catch (Exception e) {
			log.error("Error in audit log. Class : "
					+ joinPoint.getTarget().getClass().getSimpleName()
					+ " method name : " + joinPoint.getSignature().getName() + " /n" + e);
		}
	}
	
	public void saveMerchantOrUserAuditDetailAfterThrowing(JoinPoint joinPoint, Throwable error) {
		try {
			Object[] arguments = joinPoint.getArgs();
			Object requestInfo = arguments[0];
			SymphonyDto piPayRequest = (SymphonyDto) requestInfo;
			SymphonyDto piPayResponse = new SymphonyDto();
			piPayResponse.setStatus(AuditUtil.FAILURE);
			piPayResponse.setMessage(error.getMessage());

			AuditTrail auditTrail = getAuditTrail(joinPoint, requestInfo,piPayRequest, piPayResponse);
			
			addUserDeatil(requestInfo, auditTrail);
			
		} catch (Exception e) {
			log.error("Error in audit log. Class : "
					+ joinPoint.getTarget().getClass().getSimpleName()
					+ " method name : " + joinPoint.getSignature().getName() + " /n" + e);
		}
	}
	
	private void addCustomerDeatil(Object requestInfo, AuditTrail auditTrail) {
		Long customerId = null;
		String strCustomerId = AuditUtil.getAuditFieldFromDetail(AuditUtil.CUSTOMER_ID, requestInfo.toString());

		if(strCustomerId != null && !strCustomerId.trim().equalsIgnoreCase("null") && !strCustomerId.trim().equals("")){
			strCustomerId = strCustomerId.trim();
			customerId = Long.parseLong(strCustomerId);
		}
		auditTrail.setIdentifierId(strCustomerId);
		
		ServiceContext serviceContext = getServiceContext();
		Customer customer = null;
		if(customerId != null){
			 customer = customerService.get(customerId, serviceContext);
		}
		if(customer != null){
			auditTrail.setIdentifierString(customer.getEmail());
		}
		auditTrailService.add(auditTrail, serviceContext);
	}
	
	private void addUserDeatil(Object requestInfo, AuditTrail auditTrail) {
		Long userId = null;
		String strUserId = AuditUtil.getAuditFieldFromDetail(AuditUtil.USER_ID, requestInfo.toString());
		String email = AuditUtil.getAuditFieldFromDetail(AuditUtil.EMAIL, requestInfo.toString());

		if(strUserId != null && !strUserId.trim().equalsIgnoreCase("null") && !strUserId.trim().equals("")){
			strUserId = strUserId.trim();
			userId = Long.parseLong(strUserId);
		}
		auditTrail.setIdentifierId(strUserId);
		
		ServiceContext serviceContext = getServiceContext();
		if(email!=null && !email.trim().equals("")){
			auditTrail.setIdentifierString(email);
		}else{
			User user = null;
			if(userId != null){
				user = userService.get(userId, serviceContext);
			}
		
			if(user != null){
				auditTrail.setIdentifierString(user.getEmail());
			}
		}
		auditTrailService.add(auditTrail, serviceContext);
	}

	private AuditTrail getAuditTrail(JoinPoint joinPoint, Object requestInfo,
                                     SymphonyDto piPayRequest, SymphonyDto piPayResponse) {
		String operationType = AuditUtil.getAuditFieldFromDetail(
				AuditUtil.TYPE, requestInfo.toString());
		String applClass = joinPoint.getTarget().getClass().getSimpleName();
		String applMethod = joinPoint.getSignature().getName();
		String requestDetail = requestInfo.toString();
		String clientIp = piPayRequest.getClientIp();
		String responseStatus = piPayResponse.getStatus();
		String responseMessage = piPayResponse.getMessage();

		if(clientIp != null){
			String []clientIps = clientIp.split(",");
			clientIp = clientIps[0];
		}
		AuditTrail auditTrail = new AuditTrail();
		auditTrail.setApplClass(applClass);
		auditTrail.setApplMethod(applMethod);
		auditTrail.setOperationType(operationType);
		auditTrail.setRequestDetail(requestDetail);
		auditTrail.setClientIp(clientIp);
		auditTrail.setResponseStatus(responseStatus);
		auditTrail.setResponseMessage(responseMessage);
		return auditTrail;
	}
	
	private ServiceContext getServiceContext() {
		ServiceContext serviceContext = new ServiceContext();
		serviceContext.setPageable(false);
		serviceContext.setPageSize(5);
		serviceContext.setPageStart(1);
		serviceContext.setPageEnd(1);
		return serviceContext;
	}

}
