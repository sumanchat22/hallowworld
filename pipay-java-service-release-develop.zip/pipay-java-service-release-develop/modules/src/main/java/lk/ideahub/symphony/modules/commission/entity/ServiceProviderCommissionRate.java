package lk.ideahub.symphony.modules.commission.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.types.entity.PaymentOptionType;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "src_provd_commiss_rates")

@NamedQueries({
        /*@NamedQuery(name = "ServiceProviderCommissionRate.find", query = "select spcr from ServiceProviderCommissionRate spcr" +
                "  where" +
                "    (:name is null or spcr.name = :name)"),*/
        @NamedQuery(name = "ServiceProviderCommissionRate.findCusComByMerchant", query = "select cr from ServiceProviderCommissionRate cr" +
                " where"+
                " (cr.serviceProviderId = :serviceProviderId)"+
                " and"+
                " (cr.paymentOptionType = :paymentOptionType)"+
                " and"+
                " (cr.chargeToType = 'CUSTOMER')"+
                " order by cr.startRange"),
        @NamedQuery(name = "ServiceProviderCommissionRate.listAllCusComByMerchant", query = "select cr from ServiceProviderCommissionRate cr" +
                " where"+
                " (:serviceProviderId is null or cr.serviceProviderId = :serviceProviderId)"+
                " and"+
                " (cr.chargeToType = 'CUSTOMER')"+
                " order by cr.serviceProviderId,cr.paymentOptionType.paymentOptionTypeId,cr.startRange"),
        @NamedQuery(name = "ServiceProviderCommissionRate.findMerComByMerchant", query = "select cr from ServiceProviderCommissionRate cr" +
                " where"+
                " (cr.serviceProviderId = :serviceProviderId)"+
                " and"+
                " (cr.paymentOptionType = :paymentOptionType)"+
                " and"+
                " (cr.chargeToType = 'MERCHANT')"),
        @NamedQuery(name = "ServiceProviderCommissionRate.findMerComByAggregate", query = "select cr from ServiceProviderCommissionRate cr" +
                " where"+
                " (cr.serviceProviderId = :serviceProviderId)"+
                " and"+
                " (cr.paymentOptionType = :paymentOptionType)"+
                " and"+
                " (cr.chargeToType = 'AGGREGATE')")
})

@NamedNativeQueries({
        @NamedNativeQuery(name = "ServiceProviderCommissionRate.findByMerchant", query = "select * from src_provd_commiss_rates cr"+
                " where"+
                " (cr.service_provider_id = :serviceProviderId)"+
                " and"+
                " (cr.payment_option_type_id = :paymentOptionTypeId)")
})

public class ServiceProviderCommissionRate extends AbstractEntity {

    @Id
    @SequenceGenerator(name = "generator", sequenceName = "SRC_PROVD_COMMISS_RATES_SRC_PR", allocationSize = 1)
    @GeneratedValue(generator = "generator")
    @Column(name = "src_provd_commision_rate_id")
    private Long srcProvdCommisionRateId;

    @Column(name = "transaction_type_id")
    private Long transactionTypeId;

    @Column(name = "service_provider_id")
    private Long serviceProviderId;

    @ManyToOne
    @JoinColumn(name = "payment_option_type_id")
    private PaymentOptionType paymentOptionType;

    @Column(name = "charge_to_type")
    private String chargeToType;

    @Column(name = "value_type")
    private String valueType;

    @Column(name = "start_range")
    private BigDecimal startRange;

    @Column(name = "end_range")
    private BigDecimal endRange;

    @Column(name = "actual_value")
    private BigDecimal actualValue;

    @Column(name = "tier_surcharge_type")
    private String tierSurchargeType;


    public Long getServiceProviderId() {
        return serviceProviderId;
    }

    public void setServiceProviderId(Long serviceProviderId) {
        this.serviceProviderId = serviceProviderId;
    }

    public Long getSrcProvdCommisionRateId() {
        return srcProvdCommisionRateId;
    }

    public void setSrcProvdCommisionRateId(Long srcProvdCommisionRateId) {
        this.srcProvdCommisionRateId = srcProvdCommisionRateId;
    }

    public Long getTransactionTypeId() {
        return transactionTypeId;
    }

    public void setTransactionTypeId(Long transactionTypeId) {
        this.transactionTypeId = transactionTypeId;
    }

    public PaymentOptionType getPaymentOptionType() {
        return paymentOptionType;
    }

    public void setPaymentOptionType(PaymentOptionType paymentOptionType) {
        this.paymentOptionType = paymentOptionType;
    }

    public String getChargeToType() {
        return chargeToType;
    }

    public void setChargeToType(String chargeToType) {
        this.chargeToType = chargeToType;
    }

    public String getValueType() {
        return valueType;
    }

    public void setValueType(String valueType) {
        this.valueType = valueType;
    }

    public BigDecimal getStartRange() {
        return startRange;
    }

    public void setStartRange(BigDecimal startRange) {
        this.startRange = startRange;
    }

    public BigDecimal getEndRange() {
        return endRange;
    }

    public void setEndRange(BigDecimal endRange) {
        this.endRange = endRange;
    }

    public BigDecimal getActualValue() {
        return actualValue;
    }

    public void setActualValue(BigDecimal actualValue) {
        this.actualValue = actualValue;
    }

    public String getTierSurchargeType() {
        return tierSurchargeType;
    }

    public void setTierSurchargeType(String tierSurchargeType) {
        this.tierSurchargeType = tierSurchargeType;
    }

    @Override
    public String toString() {
        return new StringBuilder("ServiceProviderCommissionRate {")
                .append("srcProvdCommisionRateId=").append(srcProvdCommisionRateId).append(", ")
                .append("transactionTypeId=").append(transactionTypeId).append(", ")
                .append("serviceProviderId=").append(serviceProviderId).append(", ")
                .append("paymentOptionTypeId=").append(paymentOptionType).append(", ")
                .append("chargeToType='").append(chargeToType).append("'").append(", ")
                .append("valueType='").append(valueType).append("'").append(", ")
                .append("startRange=").append(startRange).append(", ")
                .append("endRange=").append(endRange).append(", ")
                .append("actualValue=").append(actualValue).append(", ")
                .append("tierSurchargeType=").append(tierSurchargeType)
                .append('}').toString();
    }
}
