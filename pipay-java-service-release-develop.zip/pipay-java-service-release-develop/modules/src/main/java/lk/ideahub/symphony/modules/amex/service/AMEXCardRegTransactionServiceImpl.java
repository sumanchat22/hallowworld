package lk.ideahub.symphony.modules.amex.service;

import lk.ideahub.symphony.modules.amex.entity.AMEXCardRegTransaction;
import lk.ideahub.symphony.modules.amex.repository.AMEXCardRegTransactionRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class AMEXCardRegTransactionServiceImpl extends GenericService implements AMEXCardRegTransactionService {

    private static final Logger log = LoggerFactory.getLogger(AMEXCardRegTransactionServiceImpl.class);

    @Autowired
    private AMEXCardRegTransactionRepository repository;

    @Override
    public AMEXCardRegTransaction get(final Object _amexCardRegTransactionId, final ServiceContext _serviceContext) {
        return repository.get(_amexCardRegTransactionId, _serviceContext);
    }

    @Override
    public List<AMEXCardRegTransaction> find(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        return repository.find(_amexCardRegTransaction, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        repository.add(_amexCardRegTransaction, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        repository.update(_amexCardRegTransaction, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext) {
        repository.delete(_amexCardRegTransaction, _serviceContext);
    }

    @Override
    public List<AMEXCardRegTransaction> findByCustomerId(AMEXCardRegTransaction _amexCardRegTransaction, ServiceContext _serviceContext) {
        List<Object[]> resultList = repository.findByCustomerId(_amexCardRegTransaction, _serviceContext);

        List<AMEXCardRegTransaction> regTransactions = new ArrayList<AMEXCardRegTransaction>(resultList.size());
        if (resultList.size() > 0) {
            AMEXCardRegTransaction regTransaction = null;
            for (Object[] row : resultList) {
                Long regTransactionId = Long.valueOf(row[0].toString());
                regTransaction = repository.get(regTransactionId, _serviceContext);

                regTransactions.add(regTransaction);
            }
        }

        return regTransactions;
    }
}
