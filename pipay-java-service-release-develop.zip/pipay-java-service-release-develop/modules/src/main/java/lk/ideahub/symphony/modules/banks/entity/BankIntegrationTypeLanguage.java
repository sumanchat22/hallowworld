package lk.ideahub.symphony.modules.banks.entity;

import lk.ideahub.symphony.modules.types.entity.Language;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * @author somma.soun - PiPay
 * @create 05-Jan-2022
 */

@Entity
@Table(name = "bank_integration_type_languages")
@Getter
@Setter
@ToString
public class BankIntegrationTypeLanguage {
    @Id
    @SequenceGenerator(name="generator", sequenceName="BANK_INTEGRATION_TYPE_LANGUAGE_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "bank_integration_type_languages_id")
    private Long bankIntegrationTypeLanguagesId;

    @Column(name = "column_key")
    private String columnKey;

    @ManyToOne
    @JoinColumn(name = "language_id")
    private Language language;

    @ManyToOne
    @JoinColumn(name = "bank_integration_type_id")
    private BankIntegrationType bankIntegrationType;

    @Column(name = "text")
    private String text;
}
