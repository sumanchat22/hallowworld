package lk.ideahub.symphony.modules.banner.service;

import lk.ideahub.symphony.modules.banner.entity.Banner;
import lk.ideahub.symphony.modules.banner.repository.BannerRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class BannerServiceImpl extends GenericService implements BannerService {

    private static final Logger log = LoggerFactory.getLogger(BannerServiceImpl.class);

    @Autowired
    private BannerRepository repository;

    @Override
    public Banner get(final Object _bannerId, final ServiceContext _serviceContext) {
        return repository.get(_bannerId, _serviceContext);
    }

    @Override
    public List<Banner> find(final Banner _banner, final ServiceContext _serviceContext) {
        return repository.find(_banner, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final Banner _banner, final ServiceContext _serviceContext) {
        repository.add(_banner, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final Banner _banner, final ServiceContext _serviceContext) {
        repository.update(_banner, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final Banner _banner, final ServiceContext _serviceContext) {
        repository.delete(_banner, _serviceContext);
    }

	@Override
	public List<Banner> getListFromDealBannerType(String bannerType) {
		return repository.getListFromDealBannerType(bannerType);
	}


}
