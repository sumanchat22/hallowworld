package lk.ideahub.symphony.modules.casa.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "carg_casa_req_res_details")
@Getter
@Setter
@ToString
public class CargillsCasaRequestResponseDetails extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="REQ_RES_DETAILS_ID_SQ",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "req_res_details_id")
    private Long cargillsCasaRegisteredCustomerId;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @Column(name = "account_number")
    private String accountNumber;

    @Column(name = "request_type")
    private String requestType;

    @Column(name = "casa_request")
    private String casaRequest;

    @Column(name = "casa_response")
    private String casaResponse;

    @Column(name = "device_id")
    private String deviceId;


}
