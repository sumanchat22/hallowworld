package lk.ideahub.symphony.modules.amex.service;

import lk.ideahub.symphony.modules.amex.entity.CustomerAmexCard;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface CustomerAmexCardService {

    CustomerAmexCard get(final Object _customerAmexCardId, final ServiceContext _serviceContext);

    List<CustomerAmexCard> find(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    void add(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    void update(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    void delete(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    List<CustomerAmexCard> findByCustomerId(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    List<CustomerAmexCard> findCard(final CustomerAmexCard _customerAmexCard, final ServiceContext _serviceContext);

    List<CustomerAmexCard> findByCustomerPaymentOptionId(CustomerAmexCard _customerAmexCard, ServiceContext _serviceContext);
}
