package lk.ideahub.symphony.modules.counter.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "appl_counter_channels")
@NamedQueries({
        @NamedQuery(name = "OutletCounterChannels.find", query = "select o from OutletCounterChannels o" +
                "  where" +
                "    (:name is null or o.name = :name)")})

public class OutletCounterChannels extends AbstractEntity{

    @Id
    @SequenceGenerator(name="generator", sequenceName="OUTLETS_OUTLET_ID_SEQ",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "counter_channel_id")
    private Long counterChannelId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;


}
