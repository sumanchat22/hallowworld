package lk.ideahub.symphony.modules.counter.service;

import java.util.List;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.counter.entity.OutletCounterMerchantAction;

public interface OutletCounterMerchantActionService {

	OutletCounterMerchantAction get(final Object outletCounterMerchantActionId, final ServiceContext serviceContext);

    void add(final OutletCounterMerchantAction outletCounterMerchantAction, final ServiceContext serviceContext);

    void update(final OutletCounterMerchantAction outletCounterMerchantAction, final ServiceContext serviceContext);

    void delete(final OutletCounterMerchantAction outletCounterMerchantAction, final ServiceContext serviceContext);
    
    List<OutletCounterMerchantAction> getByMerchantActionId(Long merchantActionId,Long outletCounterId);
}
