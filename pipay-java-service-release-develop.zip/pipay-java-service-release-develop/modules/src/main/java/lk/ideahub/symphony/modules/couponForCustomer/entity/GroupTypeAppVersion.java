package lk.ideahub.symphony.modules.couponForCustomer.entity;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;


@Entity
@NamedQueries({
        @NamedQuery(name = "GroupTypeAppVersion.find", query = "select gtav from GroupTypeAppVersion gtav" +
                "  where" +
                "    (:name is null or gtav.name = :name)")})
@Getter
@Setter
@ToString
@Table(name = "group_type_app_version")
public class GroupTypeAppVersion extends AbstractEntity {

    @Id
    @SequenceGenerator(name="generator", sequenceName="GROUP_TYPE_APP_VERSION_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "group_type_app_version_id")
    private Long groupTypeAppVersionId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "display_name")
    private String displayName;

}
