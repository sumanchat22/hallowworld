package lk.ideahub.symphony.modules.beacon.entity;

public class BeaconId {

    private String proximityUuid;
    private Integer major;
    private Integer minor;

    public String getProximityUuid() {
        return proximityUuid;
    }

    public void setProximityUuid(String proximityUuid) {
        this.proximityUuid = proximityUuid;
    }

    public Integer getMajor() {
        return major;
    }

    public void setMajor(Integer major) {
        this.major = major;
    }

    public Integer getMinor() {
        return minor;
    }

    public void setMinor(Integer minor) {
        this.minor = minor;
    }

    @Override
    public String toString() {
        return new StringBuilder("BeaconId {")
                .append("proximityUuid='").append(proximityUuid).append("'").append(", ")
                .append("major=").append(major).append(", ")
                .append("minor=").append(minor)
                .append('}').toString();
    }
}
