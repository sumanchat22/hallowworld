package lk.ideahub.symphony.modules.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.MailSender;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;

import java.util.Properties;

/**
 * Created by Madhukara on 9/8/17.
 */
@Service
public class MailSenderFactory {

    private static final Logger log = LoggerFactory.getLogger(MailSenderFactory.class);

    @Autowired
    private Environment environment;

    public JavaMailSender gmailMailSender (JavaMailSenderImpl mailSender, Properties mailProperties){

        mailProperties.put("mail.smtp.host", environment.getProperty("gmail.smtp.host"));
        mailProperties.put("mail.smtp.socketFactory.port", environment.getProperty("gmail.smtp.socketFactory.port"));
        mailProperties.put("mail.smtp.socketFactory.class", environment.getProperty("gmail.smtp.socketFactory.class"));
        mailProperties.put("mail.smtp.auth", environment.getProperty("gmail.smtp.auth"));

        mailSender.setJavaMailProperties(mailProperties);

        mailSender.setUsername(environment.getProperty("gmail.username"));
        mailSender.setPassword(environment.getProperty("gmail.password"));

        return  mailSender;
    }

    public JavaMailSender externalMailSender (JavaMailSenderImpl mailSender, Properties mailProperties){

        boolean isSslEnable = Boolean.parseBoolean(environment.getProperty("mail.smtp.starttls.enable"));
        mailProperties.put("mail.smtp.starttls.enable", isSslEnable);
        mailProperties.put("mail.smtp.host", environment.getProperty("mail.smtp.host"));
        if (isSslEnable) {
            mailProperties.put("mail.smtp.socketFactory.port",environment.getProperty("mail.smtp.socketFactory.port"));
            mailProperties.put("mail.smtp.socketFactory.class",environment.getProperty("mail.smtp.socketFactory.class"));
        } else {
            mailProperties.put("mail.smtp.port",environment.getProperty("mail.smtp.socketFactory.port"));
        }
        boolean isAuthEnable = Boolean.parseBoolean(environment.getProperty("mail.smtp.auth"));
        mailProperties.put("mail.smtp.auth", isAuthEnable);
        if (isAuthEnable) {
            mailSender.setUsername(environment.getProperty("mail.username"));
            mailSender.setPassword(environment.getProperty("mail.password"));
        }
        mailSender.setJavaMailProperties(mailProperties);

        return  mailSender;
    }
}
