package lk.ideahub.symphony.modules.amex.service;

import lk.ideahub.symphony.modules.amex.entity.AMEXCardRegTransaction;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface AMEXCardRegTransactionService {

    AMEXCardRegTransaction get(final Object _amexCardRegTransactionId, final ServiceContext _serviceContext);

    List<AMEXCardRegTransaction> find(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    void add(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    void update(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    void delete(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);

    List<AMEXCardRegTransaction> findByCustomerId(final AMEXCardRegTransaction _amexCardRegTransaction, final ServiceContext _serviceContext);
}
