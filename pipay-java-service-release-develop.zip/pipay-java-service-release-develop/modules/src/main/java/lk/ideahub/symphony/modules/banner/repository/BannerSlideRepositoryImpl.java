package lk.ideahub.symphony.modules.banner.repository;

import lk.ideahub.symphony.modules.banner.entity.BannerSlide;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.pinkpacket.entity.PinkPacket;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Calendar;
import java.util.List;

@Repository
class BannerSlideRepositoryImpl extends GenericRepository implements BannerSlideRepository {

    private static final Logger log = LoggerFactory.getLogger(BannerSlideRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public BannerSlide get(final Object _bannerSlideId, final ServiceContext _serviceContext) {
        return entityManager.find(BannerSlide.class, _bannerSlideId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<BannerSlide> find(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("BannerSlide.find");
        query.setParameter("headerTitle", _bannerSlide.getHeaderTitle());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        _bannerSlide.setCreatedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_bannerSlide);
        entityManager.flush();
    }

    @Override
    public BannerSlide update(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        _bannerSlide.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_bannerSlide);
    }

    @Override
    public void delete(final BannerSlide _bannerSlide, final ServiceContext _serviceContext) {
        entityManager.remove(_bannerSlide);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Object[]> findBannerSlide(BannerSlide _bannerSlideFind, ServiceContext _serviceContext)
    {
        Query query = entityManager.createNamedQuery("BannerSlide.findBannerSlide");
        query.setParameter("dealBannerTypeId", _bannerSlideFind.getDealBannerTypeId());
        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<BannerSlide> getBannerSlidesForABanner(Long bannerId) {
		Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(BannerSlide.class);
        criteria.add(Restrictions.eq("banner.bannerId", bannerId));
        criteria.addOrder(Order.asc("sequence"));
		return criteria.list();
	}
}
