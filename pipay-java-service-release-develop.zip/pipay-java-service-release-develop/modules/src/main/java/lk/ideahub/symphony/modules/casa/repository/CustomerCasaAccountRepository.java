package lk.ideahub.symphony.modules.casa.repository;

import lk.ideahub.symphony.modules.casa.entity.CustomerCasaAccount;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

public interface CustomerCasaAccountRepository {

    CustomerCasaAccount get(final Object _customerCasaAccountId, final ServiceContext _serviceContext);

    List<CustomerCasaAccount> find(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext);

    void add(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext);

    CustomerCasaAccount update(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext);

    void delete(final CustomerCasaAccount _customerCasaAccount, final ServiceContext _serviceContext);

    List<Object[]> findAccount(CustomerCasaAccount _customerCasaAccount, ServiceContext _serviceContext);

    List<Object[]> findByCustomerPaymentOptionId(CustomerCasaAccount _customerCasaAccount, ServiceContext _serviceContext);
}
