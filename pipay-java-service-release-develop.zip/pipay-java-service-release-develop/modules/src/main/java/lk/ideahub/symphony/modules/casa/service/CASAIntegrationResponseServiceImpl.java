package lk.ideahub.symphony.modules.casa.service;

import lk.ideahub.symphony.modules.casa.entity.CASAIntegrationResponse;
import lk.ideahub.symphony.modules.casa.repository.CASAIntegrationResponseRepository;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CASAIntegrationResponseServiceImpl extends GenericService implements CASAIntegrationResponseService {

    private static final Logger log = LoggerFactory.getLogger(CASAIntegrationResponseServiceImpl.class);

    @Autowired
    private CASAIntegrationResponseRepository repository;

    @Override
    public CASAIntegrationResponse get(final Object _casaIntegrationResponseId, final ServiceContext _serviceContext) {
        return repository.get(_casaIntegrationResponseId, _serviceContext);
    }

    @Override
    public List<CASAIntegrationResponse> find(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        return repository.find(_casaIntegrationResponse, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        repository.add(_casaIntegrationResponse, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        repository.update(_casaIntegrationResponse, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CASAIntegrationResponse _casaIntegrationResponse, final ServiceContext _serviceContext) {
        repository.delete(_casaIntegrationResponse, _serviceContext);
    }
}
