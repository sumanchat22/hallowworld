package lk.ideahub.symphony.modules.casa.service;


import lk.ideahub.symphony.modules.casa.entity.CargillsCasaDevices;
import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.Customer;

import java.util.List;

public interface CargillsCasaDevicesService {

    CargillsCasaDevices get(final Object _CargillsCasaDevicesId, final ServiceContext _serviceContext);

    void add(final CargillsCasaDevices _CargillsCasaDevices, final ServiceContext _serviceContext);

    void update(final CargillsCasaDevices _CargillsCasaDevices, final ServiceContext _serviceContext);

    void delete(final CargillsCasaDevices _CargillsCasaDevices, final ServiceContext _serviceContext);

    List<CargillsCasaDevices> getDevicesListByCustomerCasaAccount(CargillsCustomerCasaAccount cargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    CargillsCasaDevices findByDeviceIdAndCustomer(String deviceId, CargillsCustomerCasaAccount cargillsCustomerCasaAccount, final ServiceContext _serviceContext);
}
