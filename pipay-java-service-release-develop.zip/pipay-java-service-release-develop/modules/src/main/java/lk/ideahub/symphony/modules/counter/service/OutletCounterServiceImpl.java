package lk.ideahub.symphony.modules.counter.service;

import java.util.ArrayList;
import java.util.List;

import lk.ideahub.symphony.modules.counter.entity.OutletCounter;
import lk.ideahub.symphony.modules.counter.repository.OutletCounterRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class OutletCounterServiceImpl extends GenericService implements OutletCounterService {

    private static final Logger log = LoggerFactory.getLogger(OutletCounterServiceImpl.class);

    @Autowired
    private OutletCounterRepository repository;

    @Override
    public OutletCounter get(final Object _outletCounterId, final ServiceContext _serviceContext) {
        return repository.get(_outletCounterId, _serviceContext);
    }

    @Override
    public List<OutletCounter> find(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        return repository.find(_outletCounter, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        repository.add(_outletCounter, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        repository.update(_outletCounter, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final OutletCounter _outletCounter, final ServiceContext _serviceContext) {
        repository.delete(_outletCounter, _serviceContext);
    }

    @Override
    public List<OutletCounter> findValidCounter(OutletCounter _outletCounter, ServiceContext _serviceContext)
    {
        List<Object[]> resultList = repository.findValidCounter(_outletCounter, _serviceContext);
        List<OutletCounter> counterList = new ArrayList<OutletCounter>(resultList.size());

        OutletCounter outletCounter = null;
        for (Object[] row : resultList)
        {
            Long outletCounterId = Long.valueOf(row[0].toString());

            log.info("selectCounterId : " + outletCounterId);
            outletCounter = get(outletCounterId, _serviceContext);
            counterList.add(outletCounter);
        }

        return counterList;
    }

	@Override
	public OutletCounter getByExternalId(Long externalId, ServiceContext serviceContext) {
		return repository.getByExternalId(externalId, serviceContext);
	}


	public List<OutletCounter> findOutletCounterById(OutletCounter outletCounter,ServiceContext serviceContext){
        return repository.findByOutletCounterId(outletCounter,serviceContext);
    }
}
