package lk.ideahub.symphony.modules.casa.repository;

import lk.ideahub.symphony.modules.casa.entity.CargillsCASARegisteredCustomer;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.customer.entity.Customer;

import java.util.List;


public interface CargillsCASARegisteredCustomerRepository {

    CargillsCASARegisteredCustomer get(final Object _cargillsCASARegisteredCustomerId, final ServiceContext _serviceContext);

    List<CargillsCASARegisteredCustomer> find(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext);

    CargillsCASARegisteredCustomer findbyCustomer(final Customer _customer, final ServiceContext _serviceContext);

    void add(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext);

    CargillsCASARegisteredCustomer update(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext);

    void delete(final CargillsCASARegisteredCustomer _cargillsCASARegisteredCustomer, final ServiceContext _serviceContext);
}
