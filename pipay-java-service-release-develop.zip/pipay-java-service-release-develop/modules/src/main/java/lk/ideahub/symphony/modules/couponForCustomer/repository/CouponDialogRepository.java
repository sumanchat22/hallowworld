package lk.ideahub.symphony.modules.couponForCustomer.repository;

import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.couponForCustomer.entity.CouponDialog;

import java.util.List;

public interface CouponDialogRepository {

    CouponDialog get(final Object couponDialogId, final ServiceContext serviceContext);

    List<CouponDialog> find(final CouponDialog couponDialog, final ServiceContext serviceContext);
}
