package lk.ideahub.symphony.modules.banks.repository;

import lk.ideahub.symphony.modules.banks.entity.BankTransferType;
import lk.ideahub.symphony.modules.banks.entity.Banks;
import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

/**
 * @author somma.soun - PiPay
 * @create 20-Dec-2021
 */

@Repository
public class BankTransferTypeRepositoryImpl extends GenericRepository implements BankTransferTypeRepository {
    private static final Logger log = LoggerFactory.getLogger(BankTransferTypeRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public BankTransferType get(final Object bankTransferTypeId, final ServiceContext serviceContext) {
        return entityManager.find(BankTransferType.class, bankTransferTypeId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<BankTransferType> find(final BankTransferType bankTransferTypeId, final ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(BankTransferType.class);
        return criteria.list();
    }

    @Override
    public void add(final BankTransferType bankTransferTypeId, final ServiceContext serviceContext) {
        entityManager.persist(bankTransferTypeId);
        entityManager.flush();
    }

    @Override
    public BankTransferType update(final BankTransferType bankTransferTypeId, final ServiceContext serviceContext) {
        return entityManager.merge(bankTransferTypeId);
    }

    @Override
    public void delete(final BankTransferType bankTransferTypeId, final ServiceContext serviceContext) {
        entityManager.remove(bankTransferTypeId);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<BankTransferType> findByName(BankTransferType bankTransferType, ServiceContext serviceContext) {
        Session session = entityManager.unwrap(Session.class);
        Criteria criteria = session.createCriteria(BankTransferType.class,"btt");

        if(bankTransferType.getName() != null){
            criteria.add(Restrictions.eq("btt.name", bankTransferType.getName()));
        }

        return criteria.list();
    }
}
