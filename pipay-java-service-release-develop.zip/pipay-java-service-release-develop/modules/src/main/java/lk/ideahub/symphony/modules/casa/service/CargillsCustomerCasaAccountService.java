package lk.ideahub.symphony.modules.casa.service;


import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.common.ServiceContext;

public interface CargillsCustomerCasaAccountService {

    CargillsCustomerCasaAccount get(final Object _CargillsCustomerCasaAccountId, final ServiceContext _serviceContext);

    void add(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    void update(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    void delete(final CargillsCustomerCasaAccount _CargillsCustomerCasaAccount, final ServiceContext _serviceContext);

    CargillsCustomerCasaAccount findByPaymentOptionId(Long paymentOptionId, final ServiceContext _serviceContext);

    CargillsCustomerCasaAccount findByAccountId(String accountId, final ServiceContext _serviceContext);
}
