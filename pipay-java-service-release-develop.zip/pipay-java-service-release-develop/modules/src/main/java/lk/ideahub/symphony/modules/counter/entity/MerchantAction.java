package lk.ideahub.symphony.modules.counter.entity;

import javax.persistence.*;

import lk.ideahub.symphony.modules.common.AbstractEntity;
import lk.ideahub.symphony.modules.types.entity.MerchantActionGroup;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "appl_merchant_actions")
public class MerchantAction extends AbstractEntity{

	@Id
    @SequenceGenerator(name="generator", sequenceName="APPL_MERCHANT_ACTION_SQ1",allocationSize=1)
    @GeneratedValue(generator = "generator")
    @Column(name = "merchant_action_id")
    private Long merchantActionId;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @ManyToOne
    @JoinColumn(name = "merchant_action_group_id")
    private MerchantActionGroup merchantActionGroup;
}
