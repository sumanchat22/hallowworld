package lk.ideahub.symphony.modules.casa.service;


import lk.ideahub.symphony.modules.casa.entity.CargillsCasaDevices;
import lk.ideahub.symphony.modules.casa.entity.CargillsCustomerCasaAccount;
import lk.ideahub.symphony.modules.casa.repository.CargillsCasaDevicesRepository;
import lk.ideahub.symphony.modules.customer.entity.Customer;
import lk.ideahub.symphony.modules.customer.service.CustomerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;

import java.util.List;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class CargillsCasaDevicesServiceImpl extends GenericService implements CargillsCasaDevicesService {

    private static final Logger log = LoggerFactory.getLogger(CargillsCasaDevicesServiceImpl.class);

    @Autowired
    private CargillsCasaDevicesRepository repository;

    @Override
    public CargillsCasaDevices get(final Object _CargillsCasaDevicesServiceId, final ServiceContext _serviceContext) {
        return repository.get(_CargillsCasaDevicesServiceId, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void add(final CargillsCasaDevices _CargillsCasaDevicesService, final ServiceContext _serviceContext) {
        repository.add(_CargillsCasaDevicesService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void update(final CargillsCasaDevices _CargillsCasaDevicesService, final ServiceContext _serviceContext) {
        repository.update(_CargillsCasaDevicesService, _serviceContext);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void delete(final CargillsCasaDevices _CargillsCasaDevicesService, final ServiceContext _serviceContext) {
        repository.delete(_CargillsCasaDevicesService, _serviceContext);
    }

    @Override
    public List<CargillsCasaDevices> getDevicesListByCustomerCasaAccount(CargillsCustomerCasaAccount cargillsCustomerCasaAccount, ServiceContext _serviceContext) {
        return repository.getDevicesListByCustomerCasaAccount(cargillsCustomerCasaAccount, _serviceContext);
    }

    @Override
    public CargillsCasaDevices findByDeviceIdAndCustomer(String deviceId, CargillsCustomerCasaAccount cargillsCustomerCasaAccount, ServiceContext _serviceContext) {
        return repository.findByDeviceIdAndCustomer(deviceId,cargillsCustomerCasaAccount,_serviceContext);
    }
}
