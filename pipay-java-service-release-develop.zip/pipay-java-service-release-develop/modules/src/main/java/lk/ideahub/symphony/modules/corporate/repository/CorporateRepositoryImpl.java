package lk.ideahub.symphony.modules.corporate.repository;

import java.util.Calendar;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import lk.ideahub.symphony.modules.common.GenericRepository;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.corporate.entity.Corporate;

@Repository
class CorporateRepositoryImpl extends GenericRepository implements CorporateRepository {

    private static final Logger log = LoggerFactory.getLogger(CorporateRepositoryImpl.class);

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public Corporate get(final Object _corporateId, final ServiceContext _serviceContext) {
        return entityManager.find(Corporate.class, _corporateId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Corporate> find(final Corporate _corporate, final ServiceContext _serviceContext) {
        Query query = entityManager.createNamedQuery("Corporate.find");

        query.setParameter("name", _corporate.getName());
        query.setParameter("isStandard", _corporate.getIsStandard());

        handlePagination(query, _serviceContext);

        return query.getResultList();
    }

    @Override
    public void add(final Corporate _corporate, final ServiceContext _serviceContext) {
        _corporate.setCreatedDatetime(Calendar.getInstance().getTime());
        _corporate.setModifiedDatetime(Calendar.getInstance().getTime());
        entityManager.persist(_corporate);
        entityManager.flush();
    }

    @Override
    public Corporate update(final Corporate _corporate, final ServiceContext _serviceContext) {
        _corporate.setModifiedDatetime(Calendar.getInstance().getTime());
        return entityManager.merge(_corporate);
    }

    @Override
    public void delete(final Corporate _corporate, final ServiceContext _serviceContext) {
        entityManager.remove(_corporate);
    }
}
