package lk.ideahub.symphony.modules.counter.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import lk.ideahub.symphony.modules.common.GenericService;
import lk.ideahub.symphony.modules.common.ServiceContext;
import lk.ideahub.symphony.modules.counter.entity.MerchantAction;
import lk.ideahub.symphony.modules.counter.repository.MerchantActionRepository;

@Service
@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
public class MerchantActionServiceImpl extends GenericService implements MerchantActionService {
	
	private static final Logger log = LoggerFactory.getLogger(OutletCounterServiceImpl.class);

    @Autowired
    private MerchantActionRepository repository;

	@Override
	public MerchantAction get(Object merchantActionId, ServiceContext serviceContext) {
		return repository.get(merchantActionId, serviceContext);
	}

	@Override
	public List<MerchantAction> find(MerchantAction merchantAction, ServiceContext serviceContext) {
		return repository.find(merchantAction, serviceContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void add(MerchantAction merchantAction, ServiceContext serviceContext) {
		repository.add(merchantAction, serviceContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void update(MerchantAction merchantAction, ServiceContext serviceContext) {
		repository.update(merchantAction, serviceContext);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void delete(MerchantAction merchantAction, ServiceContext serviceContext) {
		repository.delete(merchantAction, serviceContext);
	}

	@Override
	public List<Long> findByActionGrp(MerchantAction merchantAction) {
		return repository.findByActionGrp(merchantAction);
	}

}
