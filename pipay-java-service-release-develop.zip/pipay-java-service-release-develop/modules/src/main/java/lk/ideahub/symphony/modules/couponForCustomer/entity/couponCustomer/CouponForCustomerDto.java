package lk.ideahub.symphony.modules.loyalty.entity.coupon;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CouponForCustomerDto {
    private Long customerId;
    private Long couponId;
    private Long appVersion;
}
