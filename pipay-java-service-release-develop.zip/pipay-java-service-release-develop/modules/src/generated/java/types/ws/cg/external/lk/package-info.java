@javax.xml.bind.annotation.XmlSchema(namespace = "urn:lk.external.cg.ws.types")
package types.ws.cg.external.lk;
