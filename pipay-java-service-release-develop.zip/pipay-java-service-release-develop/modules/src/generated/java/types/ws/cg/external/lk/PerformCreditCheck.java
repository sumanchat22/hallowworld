
package types.ws.cg.external.lk;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import lk.external.cg.ws.messages.jaws.CreditCheckRequest;


/**
 * <p>Java class for performCreditCheck complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="performCreditCheck"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CreditCheckRequest_1" type="{http://messages.ws.cg.external.lk/jaws}CreditCheckRequest"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "performCreditCheck", propOrder = {
    "creditCheckRequest1"
})
public class PerformCreditCheck {

    @XmlElement(name = "CreditCheckRequest_1", required = true, nillable = true)
    protected CreditCheckRequest creditCheckRequest1;

    /**
     * Gets the value of the creditCheckRequest1 property.
     * 
     * @return
     *     possible object is
     *     {@link CreditCheckRequest }
     *     
     */
    public CreditCheckRequest getCreditCheckRequest1() {
        return creditCheckRequest1;
    }

    /**
     * Sets the value of the creditCheckRequest1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCheckRequest }
     *     
     */
    public void setCreditCheckRequest1(CreditCheckRequest value) {
        this.creditCheckRequest1 = value;
    }

}
