
package types.ws.cg.external.lk;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import lk.external.cg.ws.messages.jaws.ChargeBySpecialDebitRequest;


/**
 * <p>Java class for chargeBySpecialDebit complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="chargeBySpecialDebit"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ChargeBySpecialDebitRequest_1" type="{http://messages.ws.cg.external.lk/jaws}ChargeBySpecialDebitRequest"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "chargeBySpecialDebit", propOrder = {
    "chargeBySpecialDebitRequest1"
})
public class ChargeBySpecialDebit {

    @XmlElement(name = "ChargeBySpecialDebitRequest_1", required = true, nillable = true)
    protected ChargeBySpecialDebitRequest chargeBySpecialDebitRequest1;

    /**
     * Gets the value of the chargeBySpecialDebitRequest1 property.
     * 
     * @return
     *     possible object is
     *     {@link ChargeBySpecialDebitRequest }
     *     
     */
    public ChargeBySpecialDebitRequest getChargeBySpecialDebitRequest1() {
        return chargeBySpecialDebitRequest1;
    }

    /**
     * Sets the value of the chargeBySpecialDebitRequest1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link ChargeBySpecialDebitRequest }
     *     
     */
    public void setChargeBySpecialDebitRequest1(ChargeBySpecialDebitRequest value) {
        this.chargeBySpecialDebitRequest1 = value;
    }

}
