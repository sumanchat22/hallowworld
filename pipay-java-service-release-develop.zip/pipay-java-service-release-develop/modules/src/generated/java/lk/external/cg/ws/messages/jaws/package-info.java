@javax.xml.bind.annotation.XmlSchema(namespace = "http://messages.ws.cg.external.lk/jaws")
package lk.external.cg.ws.messages.jaws;
