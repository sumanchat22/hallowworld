package com.atlinkcom.arapweb.model.xsd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MerchantModel complex type.
 * <p/>
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p/>
 * <pre>
 * &lt;complexType name="MerchantModel">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="active" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="idKey" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="merchantCategories" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/>
 *         &lt;element name="merchantCategoryId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantLocations" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/>
 *         &lt;element name="merchantLogo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shortCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tenantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MerchantModel", propOrder = {
        "active",
        "idKey",
        "merchantCategories",
        "merchantCategoryId",
        "merchantCode",
        "merchantDescription",
        "merchantId",
        "merchantLocations",
        "merchantLogo",
        "merchantName",
        "shortCode",
        "tenantId"
})
public class MerchantModel {

    protected Boolean active;
    protected Integer idKey;
    @XmlElementRef(name = "merchantCategories", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<Object> merchantCategories;
    @XmlElementRef(name = "merchantCategoryId", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> merchantCategoryId;
    @XmlElementRef(name = "merchantCode", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> merchantCode;
    @XmlElementRef(name = "merchantDescription", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> merchantDescription;
    @XmlElementRef(name = "merchantId", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> merchantId;
    @XmlElementRef(name = "merchantLocations", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<Object> merchantLocations;
    @XmlElementRef(name = "merchantLogo", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> merchantLogo;
    @XmlElementRef(name = "merchantName", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> merchantName;
    @XmlElementRef(name = "shortCode", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> shortCode;
    @XmlElementRef(name = "tenantId", namespace = "http://model.arapweb.atlinkcom.com/xsd", type = JAXBElement.class)
    protected JAXBElement<String> tenantId;

    /**
     * Gets the value of the active property.
     *
     * @return possible object is
     * {@link Boolean }
     */
    public Boolean isActive() {
        return active;
    }

    /**
     * Sets the value of the active property.
     *
     * @param value allowed object is
     *              {@link Boolean }
     */
    public void setActive(Boolean value) {
        this.active = value;
    }

    /**
     * Gets the value of the idKey property.
     *
     * @return possible object is
     * {@link Integer }
     */
    public Integer getIdKey() {
        return idKey;
    }

    /**
     * Sets the value of the idKey property.
     *
     * @param value allowed object is
     *              {@link Integer }
     */
    public void setIdKey(Integer value) {
        this.idKey = value;
    }

    /**
     * Gets the value of the merchantCategories property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link Object }{@code >}
     */
    public JAXBElement<Object> getMerchantCategories() {
        return merchantCategories;
    }

    /**
     * Sets the value of the merchantCategories property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link Object }{@code >}
     */
    public void setMerchantCategories(JAXBElement<Object> value) {
        this.merchantCategories = value;
    }

    /**
     * Gets the value of the merchantCategoryId property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getMerchantCategoryId() {
        return merchantCategoryId;
    }

    /**
     * Sets the value of the merchantCategoryId property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setMerchantCategoryId(JAXBElement<String> value) {
        this.merchantCategoryId = value;
    }

    /**
     * Gets the value of the merchantCode property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getMerchantCode() {
        return merchantCode;
    }

    /**
     * Sets the value of the merchantCode property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setMerchantCode(JAXBElement<String> value) {
        this.merchantCode = value;
    }

    /**
     * Gets the value of the merchantDescription property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getMerchantDescription() {
        return merchantDescription;
    }

    /**
     * Sets the value of the merchantDescription property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setMerchantDescription(JAXBElement<String> value) {
        this.merchantDescription = value;
    }

    /**
     * Gets the value of the merchantId property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getMerchantId() {
        return merchantId;
    }

    /**
     * Sets the value of the merchantId property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setMerchantId(JAXBElement<String> value) {
        this.merchantId = value;
    }

    /**
     * Gets the value of the merchantLocations property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link Object }{@code >}
     */
    public JAXBElement<Object> getMerchantLocations() {
        return merchantLocations;
    }

    /**
     * Sets the value of the merchantLocations property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link Object }{@code >}
     */
    public void setMerchantLocations(JAXBElement<Object> value) {
        this.merchantLocations = value;
    }

    /**
     * Gets the value of the merchantLogo property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getMerchantLogo() {
        return merchantLogo;
    }

    /**
     * Sets the value of the merchantLogo property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setMerchantLogo(JAXBElement<String> value) {
        this.merchantLogo = value;
    }

    /**
     * Gets the value of the merchantName property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getMerchantName() {
        return merchantName;
    }

    /**
     * Sets the value of the merchantName property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setMerchantName(JAXBElement<String> value) {
        this.merchantName = value;
    }

    /**
     * Gets the value of the shortCode property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getShortCode() {
        return shortCode;
    }

    /**
     * Sets the value of the shortCode property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setShortCode(JAXBElement<String> value) {
        this.shortCode = value;
    }

    /**
     * Gets the value of the tenantId property.
     *
     * @return possible object is
     * {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public JAXBElement<String> getTenantId() {
        return tenantId;
    }

    /**
     * Sets the value of the tenantId property.
     *
     * @param value allowed object is
     *              {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    public void setTenantId(JAXBElement<String> value) {
        this.tenantId = value;
    }
}
