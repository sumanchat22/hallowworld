@javax.xml.bind.annotation.XmlSchema(namespace = "http://model.arapweb.atlinkcom.com/xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED) package com.atlinkcom.arapweb.model.xsd;
