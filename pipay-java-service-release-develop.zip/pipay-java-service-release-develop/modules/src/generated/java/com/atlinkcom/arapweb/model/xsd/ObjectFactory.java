package com.atlinkcom.arapweb.model.xsd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each
 * Java content interface and Java element interface
 * generated in the com.atlinkcom.arapweb.model.xsd package.
 * <p>An ObjectFactory allows you to programatically
 * construct new instances of the Java representation
 * for XML content. The Java representation of XML
 * content can consist of schema derived interfaces
 * and classes representing the binding of schema
 * type definitions, element declarations and model
 * groups.  Factory methods for each of these are
 * provided in this class.
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _MerchantModelMerchantCode_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantCode");
    private final static QName _MerchantModelMerchantId_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantId");
    private final static QName _MerchantModelMerchantCategoryId_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantCategoryId");
    private final static QName _MerchantModelMerchantName_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantName");
    private final static QName _MerchantModelMerchantDescription_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantDescription");
    private final static QName _MerchantModelMerchantCategories_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantCategories");
    private final static QName _MerchantModelMerchantLocations_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantLocations");
    private final static QName _MerchantModelShortCode_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "shortCode");
    private final static QName _MerchantModelMerchantLogo_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "merchantLogo");
    private final static QName _MerchantModelTenantId_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "tenantId");
    private final static QName _PaymentModeModelDescription_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "description");
    private final static QName _PaymentModeModelPaymentModeId_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "paymentModeId");
    private final static QName _PaymentModeModelPaymentMode_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "paymentMode");
    private final static QName _CategoryModelCategoryId_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "categoryId");
    private final static QName _CategoryModelCategoryName_QNAME = new QName("http://model.arapweb.atlinkcom.com/xsd", "categoryName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.atlinkcom.arapweb.model.xsd
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PaymentModeModel }
     */
    public PaymentModeModel createPaymentModeModel() {
        return new PaymentModeModel();
    }

    /**
     * Create an instance of {@link CategoryModel }
     */
    public CategoryModel createCategoryModel() {
        return new CategoryModel();
    }

    /**
     * Create an instance of {@link MerchantModel }
     */
    public MerchantModel createMerchantModel() {
        return new MerchantModel();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantCode", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelMerchantCode(String value) {
        return new JAXBElement<String>(_MerchantModelMerchantCode_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantId", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelMerchantId(String value) {
        return new JAXBElement<String>(_MerchantModelMerchantId_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantCategoryId", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelMerchantCategoryId(String value) {
        return new JAXBElement<String>(_MerchantModelMerchantCategoryId_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantName", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelMerchantName(String value) {
        return new JAXBElement<String>(_MerchantModelMerchantName_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantDescription", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelMerchantDescription(String value) {
        return new JAXBElement<String>(_MerchantModelMerchantDescription_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantCategories", scope = MerchantModel.class)
    public JAXBElement<Object> createMerchantModelMerchantCategories(Object value) {
        return new JAXBElement<Object>(_MerchantModelMerchantCategories_QNAME, Object.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Object }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantLocations", scope = MerchantModel.class)
    public JAXBElement<Object> createMerchantModelMerchantLocations(Object value) {
        return new JAXBElement<Object>(_MerchantModelMerchantLocations_QNAME, Object.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "shortCode", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelShortCode(String value) {
        return new JAXBElement<String>(_MerchantModelShortCode_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "merchantLogo", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelMerchantLogo(String value) {
        return new JAXBElement<String>(_MerchantModelMerchantLogo_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "tenantId", scope = MerchantModel.class)
    public JAXBElement<String> createMerchantModelTenantId(String value) {
        return new JAXBElement<String>(_MerchantModelTenantId_QNAME, String.class, MerchantModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "description", scope = PaymentModeModel.class)
    public JAXBElement<String> createPaymentModeModelDescription(String value) {
        return new JAXBElement<String>(_PaymentModeModelDescription_QNAME, String.class, PaymentModeModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "paymentModeId", scope = PaymentModeModel.class)
    public JAXBElement<String> createPaymentModeModelPaymentModeId(String value) {
        return new JAXBElement<String>(_PaymentModeModelPaymentModeId_QNAME, String.class, PaymentModeModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "paymentMode", scope = PaymentModeModel.class)
    public JAXBElement<String> createPaymentModeModelPaymentMode(String value) {
        return new JAXBElement<String>(_PaymentModeModelPaymentMode_QNAME, String.class, PaymentModeModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "categoryId", scope = CategoryModel.class)
    public JAXBElement<String> createCategoryModelCategoryId(String value) {
        return new JAXBElement<String>(_CategoryModelCategoryId_QNAME, String.class, CategoryModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     */
    @XmlElementDecl(namespace = "http://model.arapweb.atlinkcom.com/xsd", name = "categoryName", scope = CategoryModel.class)
    public JAXBElement<String> createCategoryModelCategoryName(String value) {
        return new JAXBElement<String>(_CategoryModelCategoryName_QNAME, String.class, CategoryModel.class, value);
    }
}
