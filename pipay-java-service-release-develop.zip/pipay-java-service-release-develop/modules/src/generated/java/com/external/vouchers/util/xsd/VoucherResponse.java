
package com.external.vouchers.util.xsd;

import com.atlinkcom.arapweb.model.xsd.PaymentModeModel;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for VoucherResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VoucherResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="eventList" type="{http://util.vouchers.external.com/xsd}WSEventModel" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="paymentModel" type="{http://model.arapweb.atlinkcom.com/xsd}PaymentModeModel" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="paymentModelList" type="{http://model.arapweb.atlinkcom.com/xsd}PaymentModeModel" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="reservedVoucherIdList" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="statusCode" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="statusMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VoucherResponse", propOrder = {
    "eventList",
    "paymentModel",
    "paymentModelList",
    "reservedVoucherIdList",
    "status",
    "statusCode",
    "statusMessage"
})
public class VoucherResponse {

    @XmlElement(nillable = true)
    protected List<WSEventModel> eventList;
    @XmlElement(nillable = true)
    protected List<PaymentModeModel> paymentModel;
    @XmlElement(nillable = true)
    protected List<PaymentModeModel> paymentModelList;
    @XmlElement(nillable = true)
    protected List<String> reservedVoucherIdList;
    @XmlElementRef(name = "status", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> status;
    protected Integer statusCode;
    @XmlElementRef(name = "statusMessage", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> statusMessage;

    /**
     * Gets the value of the eventList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WSEventModel }
     * 
     * 
     */
    public List<WSEventModel> getEventList() {
        if (eventList == null) {
            eventList = new ArrayList<WSEventModel>();
        }
        return this.eventList;
    }

    /**
     * Gets the value of the paymentModel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymentModel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPaymentModel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentModeModel }
     * 
     * 
     */
    public List<PaymentModeModel> getPaymentModel() {
        if (paymentModel == null) {
            paymentModel = new ArrayList<PaymentModeModel>();
        }
        return this.paymentModel;
    }

    /**
     * Gets the value of the paymentModelList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymentModelList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPaymentModelList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentModeModel }
     * 
     * 
     */
    public List<PaymentModeModel> getPaymentModelList() {
        if (paymentModelList == null) {
            paymentModelList = new ArrayList<PaymentModeModel>();
        }
        return this.paymentModelList;
    }

    /**
     * Gets the value of the reservedVoucherIdList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reservedVoucherIdList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReservedVoucherIdList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getReservedVoucherIdList() {
        if (reservedVoucherIdList == null) {
            reservedVoucherIdList = new ArrayList<String>();
        }
        return this.reservedVoucherIdList;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStatus(JAXBElement<String> value) {
        this.status = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStatusCode(Integer value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the statusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStatusMessage() {
        return statusMessage;
    }

    /**
     * Sets the value of the statusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStatusMessage(JAXBElement<String> value) {
        this.statusMessage = value;
    }

}
