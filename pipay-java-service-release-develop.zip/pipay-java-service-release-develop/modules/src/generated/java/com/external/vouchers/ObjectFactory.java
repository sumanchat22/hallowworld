
package com.external.vouchers;

import com.external.vouchers.util.xsd.Status;
import com.external.vouchers.util.xsd.VoucherResponse;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.external.vouchers package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetPaymentMethodsByEventIdEventId_QNAME = new QName("http://vouchers.external.com", "eventId");
    private final static QName _GetPaymentMethodsByEventIdAppId_QNAME = new QName("http://vouchers.external.com", "appId");
    private final static QName _GetPaymentMethodsByEventIdMerchantId_QNAME = new QName("http://vouchers.external.com", "merchantId");
    private final static QName _GetPaymentMethodsByEventIdResponseReturn_QNAME = new QName("http://vouchers.external.com", "return");
    private final static QName _GiftVouchersBuyerMSISDN_QNAME = new QName("http://vouchers.external.com", "buyerMSISDN");
    private final static QName _GiftVouchersPaymentModeId_QNAME = new QName("http://vouchers.external.com", "paymentModeId");
    private final static QName _GiftVouchersMerchantLocationId_QNAME = new QName("http://vouchers.external.com", "merchantLocationId");
    private final static QName _GiftVouchersReceiverMSISDN_QNAME = new QName("http://vouchers.external.com", "receiverMSISDN");
    private final static QName _GiftVouchersCustomMessage_QNAME = new QName("http://vouchers.external.com", "customMessage");
    private final static QName _GiftVouchersDeliveryDateTime_QNAME = new QName("http://vouchers.external.com", "deliveryDateTime");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.external.vouchers
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetPaymentMethodsByEventId }
     * 
     */
    public GetPaymentMethodsByEventId createGetPaymentMethodsByEventId() {
        return new GetPaymentMethodsByEventId();
    }

    /**
     * Create an instance of {@link GetPaymentMethodsByEventIdResponse }
     * 
     */
    public GetPaymentMethodsByEventIdResponse createGetPaymentMethodsByEventIdResponse() {
        return new GetPaymentMethodsByEventIdResponse();
    }

    /**
     * Create an instance of {@link GiftVouchers }
     * 
     */
    public GiftVouchers createGiftVouchers() {
        return new GiftVouchers();
    }

    /**
     * Create an instance of {@link GiftVouchersResponse }
     * 
     */
    public GiftVouchersResponse createGiftVouchersResponse() {
        return new GiftVouchersResponse();
    }

    /**
     * Create an instance of {@link BuyVouchers }
     * 
     */
    public BuyVouchers createBuyVouchers() {
        return new BuyVouchers();
    }

    /**
     * Create an instance of {@link BuyVouchersResponse }
     * 
     */
    public BuyVouchersResponse createBuyVouchersResponse() {
        return new BuyVouchersResponse();
    }

    /**
     * Create an instance of {@link ViewVouchersByAppId }
     * 
     */
    public ViewVouchersByAppId createViewVouchersByAppId() {
        return new ViewVouchersByAppId();
    }

    /**
     * Create an instance of {@link ViewVouchersByAppIdResponse }
     * 
     */
    public ViewVouchersByAppIdResponse createViewVouchersByAppIdResponse() {
        return new ViewVouchersByAppIdResponse();
    }

    /**
     * Create an instance of {@link ViewVouchers }
     * 
     */
    public ViewVouchers createViewVouchers() {
        return new ViewVouchers();
    }

    /**
     * Create an instance of {@link ViewVouchersResponse }
     * 
     */
    public ViewVouchersResponse createViewVouchersResponse() {
        return new ViewVouchersResponse();
    }

    /**
     * Create an instance of {@link ReserveVouchers }
     * 
     */
    public ReserveVouchers createReserveVouchers() {
        return new ReserveVouchers();
    }

    /**
     * Create an instance of {@link ReserveVouchersResponse }
     * 
     */
    public ReserveVouchersResponse createReserveVouchersResponse() {
        return new ReserveVouchersResponse();
    }

    /**
     * Create an instance of {@link UnreserveVoucher }
     * 
     */
    public UnreserveVoucher createUnreserveVoucher() {
        return new UnreserveVoucher();
    }

    /**
     * Create an instance of {@link UnreserveVoucherResponse }
     * 
     */
    public UnreserveVoucherResponse createUnreserveVoucherResponse() {
        return new UnreserveVoucherResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "eventId", scope = GetPaymentMethodsByEventId.class)
    public JAXBElement<String> createGetPaymentMethodsByEventIdEventId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdEventId_QNAME, String.class, GetPaymentMethodsByEventId.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "appId", scope = GetPaymentMethodsByEventId.class)
    public JAXBElement<String> createGetPaymentMethodsByEventIdAppId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdAppId_QNAME, String.class, GetPaymentMethodsByEventId.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantId", scope = GetPaymentMethodsByEventId.class)
    public JAXBElement<String> createGetPaymentMethodsByEventIdMerchantId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdMerchantId_QNAME, String.class, GetPaymentMethodsByEventId.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = GetPaymentMethodsByEventIdResponse.class)
    public JAXBElement<VoucherResponse> createGetPaymentMethodsByEventIdResponseReturn(VoucherResponse value) {
        return new JAXBElement<VoucherResponse>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, VoucherResponse.class, GetPaymentMethodsByEventIdResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantId", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersMerchantId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdMerchantId_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "appId", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersAppId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdAppId_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "buyerMSISDN", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersBuyerMSISDN(String value) {
        return new JAXBElement<String>(_GiftVouchersBuyerMSISDN_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "paymentModeId", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersPaymentModeId(String value) {
        return new JAXBElement<String>(_GiftVouchersPaymentModeId_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantLocationId", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersMerchantLocationId(String value) {
        return new JAXBElement<String>(_GiftVouchersMerchantLocationId_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "receiverMSISDN", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersReceiverMSISDN(String value) {
        return new JAXBElement<String>(_GiftVouchersReceiverMSISDN_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "customMessage", scope = GiftVouchers.class)
    public JAXBElement<String> createGiftVouchersCustomMessage(String value) {
        return new JAXBElement<String>(_GiftVouchersCustomMessage_QNAME, String.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "deliveryDateTime", scope = GiftVouchers.class)
    public JAXBElement<XMLGregorianCalendar> createGiftVouchersDeliveryDateTime(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_GiftVouchersDeliveryDateTime_QNAME, XMLGregorianCalendar.class, GiftVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = GiftVouchersResponse.class)
    public JAXBElement<VoucherResponse> createGiftVouchersResponseReturn(VoucherResponse value) {
        return new JAXBElement<VoucherResponse>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, VoucherResponse.class, GiftVouchersResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantId", scope = BuyVouchers.class)
    public JAXBElement<String> createBuyVouchersMerchantId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdMerchantId_QNAME, String.class, BuyVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "appId", scope = BuyVouchers.class)
    public JAXBElement<String> createBuyVouchersAppId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdAppId_QNAME, String.class, BuyVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "buyerMSISDN", scope = BuyVouchers.class)
    public JAXBElement<String> createBuyVouchersBuyerMSISDN(String value) {
        return new JAXBElement<String>(_GiftVouchersBuyerMSISDN_QNAME, String.class, BuyVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "paymentModeId", scope = BuyVouchers.class)
    public JAXBElement<String> createBuyVouchersPaymentModeId(String value) {
        return new JAXBElement<String>(_GiftVouchersPaymentModeId_QNAME, String.class, BuyVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantLocationId", scope = BuyVouchers.class)
    public JAXBElement<String> createBuyVouchersMerchantLocationId(String value) {
        return new JAXBElement<String>(_GiftVouchersMerchantLocationId_QNAME, String.class, BuyVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = BuyVouchersResponse.class)
    public JAXBElement<VoucherResponse> createBuyVouchersResponseReturn(VoucherResponse value) {
        return new JAXBElement<VoucherResponse>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, VoucherResponse.class, BuyVouchersResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "appId", scope = ViewVouchersByAppId.class)
    public JAXBElement<String> createViewVouchersByAppIdAppId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdAppId_QNAME, String.class, ViewVouchersByAppId.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = ViewVouchersByAppIdResponse.class)
    public JAXBElement<VoucherResponse> createViewVouchersByAppIdResponseReturn(VoucherResponse value) {
        return new JAXBElement<VoucherResponse>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, VoucherResponse.class, ViewVouchersByAppIdResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantId", scope = ViewVouchers.class)
    public JAXBElement<String> createViewVouchersMerchantId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdMerchantId_QNAME, String.class, ViewVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "appId", scope = ViewVouchers.class)
    public JAXBElement<String> createViewVouchersAppId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdAppId_QNAME, String.class, ViewVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = ViewVouchersResponse.class)
    public JAXBElement<VoucherResponse> createViewVouchersResponseReturn(VoucherResponse value) {
        return new JAXBElement<VoucherResponse>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, VoucherResponse.class, ViewVouchersResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "merchantId", scope = ReserveVouchers.class)
    public JAXBElement<String> createReserveVouchersMerchantId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdMerchantId_QNAME, String.class, ReserveVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "eventId", scope = ReserveVouchers.class)
    public JAXBElement<String> createReserveVouchersEventId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdEventId_QNAME, String.class, ReserveVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "appId", scope = ReserveVouchers.class)
    public JAXBElement<String> createReserveVouchersAppId(String value) {
        return new JAXBElement<String>(_GetPaymentMethodsByEventIdAppId_QNAME, String.class, ReserveVouchers.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VoucherResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = ReserveVouchersResponse.class)
    public JAXBElement<VoucherResponse> createReserveVouchersResponseReturn(VoucherResponse value) {
        return new JAXBElement<VoucherResponse>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, VoucherResponse.class, ReserveVouchersResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Status }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://vouchers.external.com", name = "return", scope = UnreserveVoucherResponse.class)
    public JAXBElement<Status> createUnreserveVoucherResponseReturn(Status value) {
        return new JAXBElement<Status>(_GetPaymentMethodsByEventIdResponseReturn_QNAME, Status.class, UnreserveVoucherResponse.class, value);
    }

}
