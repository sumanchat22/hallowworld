
package com.external.vouchers.util.xsd;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.external.vouchers.util.xsd package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _StatusStatus_QNAME = new QName("http://util.vouchers.external.com/xsd", "status");
    private final static QName _StatusStatusMessage_QNAME = new QName("http://util.vouchers.external.com/xsd", "statusMessage");
    private final static QName _LocationModelAddress_QNAME = new QName("http://util.vouchers.external.com/xsd", "address");
    private final static QName _LocationModelEventID_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventID");
    private final static QName _LocationModelLabel_QNAME = new QName("http://util.vouchers.external.com/xsd", "label");
    private final static QName _LocationModelLocationId_QNAME = new QName("http://util.vouchers.external.com/xsd", "locationId");
    private final static QName _WSEventModelBuyUrl_QNAME = new QName("http://util.vouchers.external.com/xsd", "buyUrl");
    private final static QName _WSEventModelCampaignId_QNAME = new QName("http://util.vouchers.external.com/xsd", "campaignId");
    private final static QName _WSEventModelCampaignName_QNAME = new QName("http://util.vouchers.external.com/xsd", "campaignName");
    private final static QName _WSEventModelCategoryNameList_QNAME = new QName("http://util.vouchers.external.com/xsd", "categoryNameList");
    private final static QName _WSEventModelCouponPackId_QNAME = new QName("http://util.vouchers.external.com/xsd", "couponPackId");
    private final static QName _WSEventModelCouponSaveId_QNAME = new QName("http://util.vouchers.external.com/xsd", "couponSaveId");
    private final static QName _WSEventModelCustomMessage_QNAME = new QName("http://util.vouchers.external.com/xsd", "customMessage");
    private final static QName _WSEventModelDescription_QNAME = new QName("http://util.vouchers.external.com/xsd", "description");
    private final static QName _WSEventModelEndDate_QNAME = new QName("http://util.vouchers.external.com/xsd", "endDate");
    private final static QName _WSEventModelEventContactEmail_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventContactEmail");
    private final static QName _WSEventModelEventContactNumber_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventContactNumber");
    private final static QName _WSEventModelEventId_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventId");
    private final static QName _WSEventModelEventImage_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventImage");
    private final static QName _WSEventModelEventName_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventName");
    private final static QName _WSEventModelEventType_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventType");
    private final static QName _WSEventModelEventUrl_QNAME = new QName("http://util.vouchers.external.com/xsd", "eventUrl");
    private final static QName _WSEventModelExpiryDate_QNAME = new QName("http://util.vouchers.external.com/xsd", "expiryDate");
    private final static QName _WSEventModelMerchantId_QNAME = new QName("http://util.vouchers.external.com/xsd", "merchantId");
    private final static QName _WSEventModelShortDescription_QNAME = new QName("http://util.vouchers.external.com/xsd", "shortDescription");
    private final static QName _WSEventModelStartDate_QNAME = new QName("http://util.vouchers.external.com/xsd", "startDate");
    private final static QName _WSEventModelTermsAndCondition_QNAME = new QName("http://util.vouchers.external.com/xsd", "termsAndCondition");
    private final static QName _WSEventModelThumbnailImage_QNAME = new QName("http://util.vouchers.external.com/xsd", "thumbnailImage");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.external.vouchers.util.xsd
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link VoucherResponse }
     * 
     */
    public VoucherResponse createVoucherResponse() {
        return new VoucherResponse();
    }

    /**
     * Create an instance of {@link WSEventModel }
     * 
     */
    public WSEventModel createWSEventModel() {
        return new WSEventModel();
    }

    /**
     * Create an instance of {@link LocationModel }
     * 
     */
    public LocationModel createLocationModel() {
        return new LocationModel();
    }

    /**
     * Create an instance of {@link Status }
     * 
     */
    public Status createStatus() {
        return new Status();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "status", scope = Status.class)
    public JAXBElement<String> createStatusStatus(String value) {
        return new JAXBElement<String>(_StatusStatus_QNAME, String.class, Status.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "statusMessage", scope = Status.class)
    public JAXBElement<String> createStatusStatusMessage(String value) {
        return new JAXBElement<String>(_StatusStatusMessage_QNAME, String.class, Status.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "address", scope = LocationModel.class)
    public JAXBElement<String> createLocationModelAddress(String value) {
        return new JAXBElement<String>(_LocationModelAddress_QNAME, String.class, LocationModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventID", scope = LocationModel.class)
    public JAXBElement<String> createLocationModelEventID(String value) {
        return new JAXBElement<String>(_LocationModelEventID_QNAME, String.class, LocationModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "label", scope = LocationModel.class)
    public JAXBElement<String> createLocationModelLabel(String value) {
        return new JAXBElement<String>(_LocationModelLabel_QNAME, String.class, LocationModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "locationId", scope = LocationModel.class)
    public JAXBElement<String> createLocationModelLocationId(String value) {
        return new JAXBElement<String>(_LocationModelLocationId_QNAME, String.class, LocationModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "buyUrl", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelBuyUrl(String value) {
        return new JAXBElement<String>(_WSEventModelBuyUrl_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "campaignId", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelCampaignId(String value) {
        return new JAXBElement<String>(_WSEventModelCampaignId_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "campaignName", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelCampaignName(String value) {
        return new JAXBElement<String>(_WSEventModelCampaignName_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "categoryNameList", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelCategoryNameList(String value) {
        return new JAXBElement<String>(_WSEventModelCategoryNameList_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "couponPackId", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelCouponPackId(String value) {
        return new JAXBElement<String>(_WSEventModelCouponPackId_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "couponSaveId", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelCouponSaveId(String value) {
        return new JAXBElement<String>(_WSEventModelCouponSaveId_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "customMessage", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelCustomMessage(String value) {
        return new JAXBElement<String>(_WSEventModelCustomMessage_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "description", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelDescription(String value) {
        return new JAXBElement<String>(_WSEventModelDescription_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "endDate", scope = WSEventModel.class)
    public JAXBElement<XMLGregorianCalendar> createWSEventModelEndDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_WSEventModelEndDate_QNAME, XMLGregorianCalendar.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventContactEmail", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventContactEmail(String value) {
        return new JAXBElement<String>(_WSEventModelEventContactEmail_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventContactNumber", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventContactNumber(String value) {
        return new JAXBElement<String>(_WSEventModelEventContactNumber_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventId", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventId(String value) {
        return new JAXBElement<String>(_WSEventModelEventId_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventImage", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventImage(String value) {
        return new JAXBElement<String>(_WSEventModelEventImage_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventName", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventName(String value) {
        return new JAXBElement<String>(_WSEventModelEventName_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventType", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventType(String value) {
        return new JAXBElement<String>(_WSEventModelEventType_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "eventUrl", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelEventUrl(String value) {
        return new JAXBElement<String>(_WSEventModelEventUrl_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "expiryDate", scope = WSEventModel.class)
    public JAXBElement<XMLGregorianCalendar> createWSEventModelExpiryDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_WSEventModelExpiryDate_QNAME, XMLGregorianCalendar.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "merchantId", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelMerchantId(String value) {
        return new JAXBElement<String>(_WSEventModelMerchantId_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "shortDescription", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelShortDescription(String value) {
        return new JAXBElement<String>(_WSEventModelShortDescription_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "startDate", scope = WSEventModel.class)
    public JAXBElement<XMLGregorianCalendar> createWSEventModelStartDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_WSEventModelStartDate_QNAME, XMLGregorianCalendar.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "termsAndCondition", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelTermsAndCondition(String value) {
        return new JAXBElement<String>(_WSEventModelTermsAndCondition_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "thumbnailImage", scope = WSEventModel.class)
    public JAXBElement<String> createWSEventModelThumbnailImage(String value) {
        return new JAXBElement<String>(_WSEventModelThumbnailImage_QNAME, String.class, WSEventModel.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "status", scope = VoucherResponse.class)
    public JAXBElement<String> createVoucherResponseStatus(String value) {
        return new JAXBElement<String>(_StatusStatus_QNAME, String.class, VoucherResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://util.vouchers.external.com/xsd", name = "statusMessage", scope = VoucherResponse.class)
    public JAXBElement<String> createVoucherResponseStatusMessage(String value) {
        return new JAXBElement<String>(_StatusStatusMessage_QNAME, String.class, VoucherResponse.class, value);
    }

}
