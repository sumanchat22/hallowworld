@javax.xml.bind.annotation.XmlSchema(namespace = "http://util.vouchers.external.com/xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.external.vouchers.util.xsd;
