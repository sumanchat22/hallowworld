
package com.external.vouchers;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="merchantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="appId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="reservedVoucherIdList" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="buyerMSISDN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="paymentModeId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="merchantLocationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "merchantId",
    "appId",
    "reservedVoucherIdList",
    "buyerMSISDN",
    "paymentModeId",
    "merchantLocationId"
})
@XmlRootElement(name = "buyVouchers")
public class BuyVouchers {

    @XmlElementRef(name = "merchantId", namespace = "http://vouchers.external.com", type = JAXBElement.class, required = false)
    protected JAXBElement<String> merchantId;
    @XmlElementRef(name = "appId", namespace = "http://vouchers.external.com", type = JAXBElement.class, required = false)
    protected JAXBElement<String> appId;
    @XmlElement(nillable = true)
    protected List<String> reservedVoucherIdList;
    @XmlElementRef(name = "buyerMSISDN", namespace = "http://vouchers.external.com", type = JAXBElement.class, required = false)
    protected JAXBElement<String> buyerMSISDN;
    @XmlElementRef(name = "paymentModeId", namespace = "http://vouchers.external.com", type = JAXBElement.class, required = false)
    protected JAXBElement<String> paymentModeId;
    @XmlElementRef(name = "merchantLocationId", namespace = "http://vouchers.external.com", type = JAXBElement.class, required = false)
    protected JAXBElement<String> merchantLocationId;

    /**
     * Gets the value of the merchantId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMerchantId() {
        return merchantId;
    }

    /**
     * Sets the value of the merchantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMerchantId(JAXBElement<String> value) {
        this.merchantId = value;
    }

    /**
     * Gets the value of the appId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAppId() {
        return appId;
    }

    /**
     * Sets the value of the appId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAppId(JAXBElement<String> value) {
        this.appId = value;
    }

    /**
     * Gets the value of the reservedVoucherIdList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reservedVoucherIdList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReservedVoucherIdList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getReservedVoucherIdList() {
        if (reservedVoucherIdList == null) {
            reservedVoucherIdList = new ArrayList<String>();
        }
        return this.reservedVoucherIdList;
    }

    /**
     * Gets the value of the buyerMSISDN property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBuyerMSISDN() {
        return buyerMSISDN;
    }

    /**
     * Sets the value of the buyerMSISDN property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBuyerMSISDN(JAXBElement<String> value) {
        this.buyerMSISDN = value;
    }

    /**
     * Gets the value of the paymentModeId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPaymentModeId() {
        return paymentModeId;
    }

    /**
     * Sets the value of the paymentModeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPaymentModeId(JAXBElement<String> value) {
        this.paymentModeId = value;
    }

    /**
     * Gets the value of the merchantLocationId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMerchantLocationId() {
        return merchantLocationId;
    }

    /**
     * Sets the value of the merchantLocationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMerchantLocationId(JAXBElement<String> value) {
        this.merchantLocationId = value;
    }

}
