
package com.external.vouchers.util.xsd;

import com.atlinkcom.arapweb.model.xsd.CategoryModel;
import com.atlinkcom.arapweb.model.xsd.MerchantModel;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.ArrayList;
import java.util.List;


/**
 * <p>Java class for WSEventModel complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WSEventModel"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="active" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="buyUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="campaignId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="campaignName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="categoryNameList" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="conciergeValue" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="conciergeValueTax" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="couponCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="couponPackId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="couponPrice" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="couponSaveId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="couponWorth" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="cursorPosition" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="customMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Commission" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="endDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="endList" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="endTime" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="eventCategory" type="{http://model.arapweb.atlinkcom.com/xsd}CategoryModel" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="eventContactEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventContactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventImage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventLocations" type="{http://util.vouchers.external.com/xsd}LocationModel" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="eventMerchats" type="{http://model.arapweb.atlinkcom.com/xsd}MerchantModel" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="eventName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="eventUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="expiryDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="merchantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="shortDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="startTime" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="termsAndCondition" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="thumbnailImage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="timeBased" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WSEventModel", propOrder = {
    "active",
    "buyUrl",
    "campaignId",
    "campaignName",
    "categoryNameList",
    "conciergeValue",
    "conciergeValueTax",
    "couponCount",
    "couponPackId",
    "couponPrice",
    "couponSaveId",
    "couponWorth",
    "cursorPosition",
    "customMessage",
    "description",
    "Commission",
    "endDate",
    "endList",
    "endTime",
    "eventCategory",
    "eventContactEmail",
    "eventContactNumber",
    "eventId",
    "eventImage",
    "eventLocations",
    "eventMerchats",
    "eventName",
    "eventType",
    "eventUrl",
    "expiryDate",
    "merchantId",
    "shortDescription",
    "startDate",
    "startTime",
    "termsAndCondition",
    "thumbnailImage",
    "timeBased"
})
public class WSEventModel {

    protected Boolean active;
    @XmlElementRef(name = "buyUrl", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> buyUrl;
    @XmlElementRef(name = "campaignId", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> campaignId;
    @XmlElementRef(name = "campaignName", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> campaignName;
    @XmlElementRef(name = "categoryNameList", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> categoryNameList;
    protected Double conciergeValue;
    protected Double conciergeValueTax;
    protected Integer couponCount;
    @XmlElementRef(name = "couponPackId", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> couponPackId;
    protected Double couponPrice;
    @XmlElementRef(name = "couponSaveId", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> couponSaveId;
    protected Double couponWorth;
    protected Integer cursorPosition;
    @XmlElementRef(name = "customMessage", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> customMessage;
    @XmlElementRef(name = "description", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> description;
    protected Double Commission;
    @XmlElementRef(name = "endDate", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> endDate;
    protected Boolean endList;
    protected Integer endTime;
    @XmlElement(nillable = true)
    protected List<CategoryModel> eventCategory;
    @XmlElementRef(name = "eventContactEmail", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventContactEmail;
    @XmlElementRef(name = "eventContactNumber", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventContactNumber;
    @XmlElementRef(name = "eventId", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventId;
    @XmlElementRef(name = "eventImage", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventImage;
    @XmlElement(nillable = true)
    protected List<LocationModel> eventLocations;
    @XmlElement(nillable = true)
    protected List<MerchantModel> eventMerchats;
    @XmlElementRef(name = "eventName", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventName;
    @XmlElementRef(name = "eventType", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventType;
    @XmlElementRef(name = "eventUrl", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> eventUrl;
    @XmlElementRef(name = "expiryDate", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> expiryDate;
    @XmlElementRef(name = "merchantId", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> merchantId;
    @XmlElementRef(name = "shortDescription", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> shortDescription;
    @XmlElementRef(name = "startDate", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> startDate;
    protected Integer startTime;
    @XmlElementRef(name = "termsAndCondition", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> termsAndCondition;
    @XmlElementRef(name = "thumbnailImage", namespace = "http://util.vouchers.external.com/xsd", type = JAXBElement.class, required = false)
    protected JAXBElement<String> thumbnailImage;
    protected Boolean timeBased;

    /**
     * Gets the value of the active property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isActive() {
        return active;
    }

    /**
     * Sets the value of the active property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setActive(Boolean value) {
        this.active = value;
    }

    /**
     * Gets the value of the buyUrl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBuyUrl() {
        return buyUrl;
    }

    /**
     * Sets the value of the buyUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBuyUrl(JAXBElement<String> value) {
        this.buyUrl = value;
    }

    /**
     * Gets the value of the campaignId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCampaignId() {
        return campaignId;
    }

    /**
     * Sets the value of the campaignId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCampaignId(JAXBElement<String> value) {
        this.campaignId = value;
    }

    /**
     * Gets the value of the campaignName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCampaignName() {
        return campaignName;
    }

    /**
     * Sets the value of the campaignName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCampaignName(JAXBElement<String> value) {
        this.campaignName = value;
    }

    /**
     * Gets the value of the categoryNameList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCategoryNameList() {
        return categoryNameList;
    }

    /**
     * Sets the value of the categoryNameList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCategoryNameList(JAXBElement<String> value) {
        this.categoryNameList = value;
    }

    /**
     * Gets the value of the conciergeValue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getConciergeValue() {
        return conciergeValue;
    }

    /**
     * Sets the value of the conciergeValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setConciergeValue(Double value) {
        this.conciergeValue = value;
    }

    /**
     * Gets the value of the conciergeValueTax property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getConciergeValueTax() {
        return conciergeValueTax;
    }

    /**
     * Sets the value of the conciergeValueTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setConciergeValueTax(Double value) {
        this.conciergeValueTax = value;
    }

    /**
     * Gets the value of the couponCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCouponCount() {
        return couponCount;
    }

    /**
     * Sets the value of the couponCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCouponCount(Integer value) {
        this.couponCount = value;
    }

    /**
     * Gets the value of the couponPackId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCouponPackId() {
        return couponPackId;
    }

    /**
     * Sets the value of the couponPackId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCouponPackId(JAXBElement<String> value) {
        this.couponPackId = value;
    }

    /**
     * Gets the value of the couponPrice property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCouponPrice() {
        return couponPrice;
    }

    /**
     * Sets the value of the couponPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCouponPrice(Double value) {
        this.couponPrice = value;
    }

    /**
     * Gets the value of the couponSaveId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCouponSaveId() {
        return couponSaveId;
    }

    /**
     * Sets the value of the couponSaveId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCouponSaveId(JAXBElement<String> value) {
        this.couponSaveId = value;
    }

    /**
     * Gets the value of the couponWorth property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCouponWorth() {
        return couponWorth;
    }

    /**
     * Sets the value of the couponWorth property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCouponWorth(Double value) {
        this.couponWorth = value;
    }

    /**
     * Gets the value of the cursorPosition property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCursorPosition() {
        return cursorPosition;
    }

    /**
     * Sets the value of the cursorPosition property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCursorPosition(Integer value) {
        this.cursorPosition = value;
    }

    /**
     * Gets the value of the customMessage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCustomMessage() {
        return customMessage;
    }

    /**
     * Sets the value of the customMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCustomMessage(JAXBElement<String> value) {
        this.customMessage = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = value;
    }

    /**
     * Gets the value of the Commission property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCommission() {
        return Commission;
    }

    /**
     * Sets the value of the Commission property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCommission(Double value) {
        this.Commission = value;
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setEndDate(JAXBElement<XMLGregorianCalendar> value) {
        this.endDate = value;
    }

    /**
     * Gets the value of the endList property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isEndList() {
        return endList;
    }

    /**
     * Sets the value of the endList property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setEndList(Boolean value) {
        this.endList = value;
    }

    /**
     * Gets the value of the endTime property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEndTime() {
        return endTime;
    }

    /**
     * Sets the value of the endTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEndTime(Integer value) {
        this.endTime = value;
    }

    /**
     * Gets the value of the eventCategory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventCategory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventCategory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CategoryModel }
     * 
     * 
     */
    public List<CategoryModel> getEventCategory() {
        if (eventCategory == null) {
            eventCategory = new ArrayList<CategoryModel>();
        }
        return this.eventCategory;
    }

    /**
     * Gets the value of the eventContactEmail property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventContactEmail() {
        return eventContactEmail;
    }

    /**
     * Sets the value of the eventContactEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventContactEmail(JAXBElement<String> value) {
        this.eventContactEmail = value;
    }

    /**
     * Gets the value of the eventContactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventContactNumber() {
        return eventContactNumber;
    }

    /**
     * Sets the value of the eventContactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventContactNumber(JAXBElement<String> value) {
        this.eventContactNumber = value;
    }

    /**
     * Gets the value of the eventId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventId() {
        return eventId;
    }

    /**
     * Sets the value of the eventId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventId(JAXBElement<String> value) {
        this.eventId = value;
    }

    /**
     * Gets the value of the eventImage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventImage() {
        return eventImage;
    }

    /**
     * Sets the value of the eventImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventImage(JAXBElement<String> value) {
        this.eventImage = value;
    }

    /**
     * Gets the value of the eventLocations property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventLocations property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventLocations().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LocationModel }
     * 
     * 
     */
    public List<LocationModel> getEventLocations() {
        if (eventLocations == null) {
            eventLocations = new ArrayList<LocationModel>();
        }
        return this.eventLocations;
    }

    /**
     * Gets the value of the eventMerchats property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the eventMerchats property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEventMerchats().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MerchantModel }
     * 
     * 
     */
    public List<MerchantModel> getEventMerchats() {
        if (eventMerchats == null) {
            eventMerchats = new ArrayList<MerchantModel>();
        }
        return this.eventMerchats;
    }

    /**
     * Gets the value of the eventName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventName() {
        return eventName;
    }

    /**
     * Sets the value of the eventName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventName(JAXBElement<String> value) {
        this.eventName = value;
    }

    /**
     * Gets the value of the eventType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventType() {
        return eventType;
    }

    /**
     * Sets the value of the eventType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventType(JAXBElement<String> value) {
        this.eventType = value;
    }

    /**
     * Gets the value of the eventUrl property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEventUrl() {
        return eventUrl;
    }

    /**
     * Sets the value of the eventUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEventUrl(JAXBElement<String> value) {
        this.eventUrl = value;
    }

    /**
     * Gets the value of the expiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the value of the expiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setExpiryDate(JAXBElement<XMLGregorianCalendar> value) {
        this.expiryDate = value;
    }

    /**
     * Gets the value of the merchantId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMerchantId() {
        return merchantId;
    }

    /**
     * Sets the value of the merchantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMerchantId(JAXBElement<String> value) {
        this.merchantId = value;
    }

    /**
     * Gets the value of the shortDescription property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getShortDescription() {
        return shortDescription;
    }

    /**
     * Sets the value of the shortDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setShortDescription(JAXBElement<String> value) {
        this.shortDescription = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setStartDate(JAXBElement<XMLGregorianCalendar> value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the startTime property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStartTime() {
        return startTime;
    }

    /**
     * Sets the value of the startTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStartTime(Integer value) {
        this.startTime = value;
    }

    /**
     * Gets the value of the termsAndCondition property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTermsAndCondition() {
        return termsAndCondition;
    }

    /**
     * Sets the value of the termsAndCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTermsAndCondition(JAXBElement<String> value) {
        this.termsAndCondition = value;
    }

    /**
     * Gets the value of the thumbnailImage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getThumbnailImage() {
        return thumbnailImage;
    }

    /**
     * Sets the value of the thumbnailImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setThumbnailImage(JAXBElement<String> value) {
        this.thumbnailImage = value;
    }

    /**
     * Gets the value of the timeBased property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTimeBased() {
        return timeBased;
    }

    /**
     * Sets the value of the timeBased property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTimeBased(Boolean value) {
        this.timeBased = value;
    }

}
